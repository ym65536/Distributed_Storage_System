#include <sstream>
#include <ustevent/message_util.h>
#include <ustevent/connection_uevent.h>
#include <ustevent/base/logging.h>
#include "chunk_context.h"
#include "manager_handle.h"
#include "str_list.h"
#include "chunk_storage_errorcode.h"
#include "get_pg_pc.h"

namespace udisk {
namespace chunk {

using namespace uevent;
 
int GetPGPhysicalChunkHandle::type_ = ucloud::udisk::GET_PG_PHYSICAL_CHUNK_REQUEST;

void GetPGPhysicalChunkHandle::EntryInit(const uevent::ConnectionUeventPtr& conn, 
                                         const uevent::UMessagePtr& um) {
  ULOG_INFO << "protobuf recv conn=" << conn->GetId() << ", msg " << um->DebugString();
  conn_ = conn;
  assert(um->head().message_type() == type_);
  assert(um->body().HasExtension(ucloud::udisk::get_pg_physical_chunk_request));

  ucloud::udisk::GetPGPhysicalChunkRequest req_body = 
    um->body().GetExtension(ucloud::udisk::get_pg_physical_chunk_request);
  MakeResponse(um.get(), ucloud::udisk::GET_PG_PHYSICAL_CHUNK_RESPONSE, &response_);
  resp_body_ = response_.mutable_body()->
    MutableExtension(ucloud::udisk::get_pg_physical_chunk_response);
  GetPGPhysicalChunkProcess(req_body.pg_id(), req_body.cluster_version());
}

int GetPGPhysicalChunkHandle::GetPGPhysicalChunkInfo(int pg_id, 
    ::google::protobuf::RepeatedPtrField<::ucloud::udisk::PGPhysicalChunk>& pg_physical_chunks) {

  ChunkIDList chunkIDList;
  int32_t ret = g_context->chunk_pool()->GetExistChunkByPG(pg_id, &chunkIDList);

  if (ret != UDISK_OK) {
    ULOG_ERROR << "GetExistChunkByPG Error code :" << ret;
    return ret;
  }

  for (auto it = chunkIDList.begin(); it != chunkIDList.end(); ++it) {
      ULOG_DEBUG << "Chunk ID:" << it->to_string(); 
      ucloud::udisk::PGPhysicalChunk* pg_physical_chunk = pg_physical_chunks.Add();
      pg_physical_chunk->set_lc_id(it->lc_id);
      pg_physical_chunk->set_pc_id(it->pc_no);
      pg_physical_chunk->set_lc_random_id(it->lc_random_id);
      // TODO(fangran.fr)
      pg_physical_chunk->set_lc_size(0);
  }

  return ret;
}

void GetPGPhysicalChunkHandle::GetPGPhysicalChunkProcess(uint32_t pg_id, uint64_t cluster_version) {
  ULOG_INFO << "recv GetPGPhysicalChunk request: pg_id=" << pg_id 
    << ", cluster_version=" << cluster_version;
  ManagerHandle* manager_handle = g_context->manager_handle();
  cluster::ClusterMap cluster_map = manager_handle->const_cluster_map();
  if (cluster_map.GetClusterVersion() != cluster_version) {
    ULOG_ERROR << "Recv pg_id cluster version error. cluster_version=" << cluster_version;
    resp_body_->mutable_rc()->set_retcode(ucloud::udisk::EC_UDISK_VERSION_LAG);
    resp_body_->mutable_rc()->set_error_message("cluster version error");
    MessageUtil::SendPbResponse(conn_, response_);
    return;
  }
  std::vector<ucloud::udisk::PGInfoPb> pg_infos = cluster_map.pgs();
  if (pg_id >= (uint32_t)pg_infos.size()) {
    ULOG_ERROR << "Recv pg_id error. pg_id=" << pg_id;
    resp_body_->mutable_rc()->set_retcode(ucloud::udisk::EC_UDISK_PARAM_INVALID);
    resp_body_->mutable_rc()->set_error_message("input param error");
    MessageUtil::SendPbResponse(conn_, response_);
    return;
  }

  ucloud::udisk::PGInfoPb pg_info = pg_infos[pg_id];
  if (pg_info.primary_chunk_id() != static_cast<uint32_t>(g_context->config().my_id())) {
    ULOG_ERROR << "Not primary chunk. pg_id=" << pg_id;
    resp_body_->mutable_rc()->set_retcode(ucloud::udisk::EC_UDISK_PARAM_INVALID);
    resp_body_->mutable_rc()->set_error_message("This is secondary chunk");
    MessageUtil::SendPbResponse(conn_, response_);
  }

  ::google::protobuf::RepeatedPtrField<::ucloud::udisk::PGPhysicalChunk> pg_physical_chunks;
  if (GetPGPhysicalChunkInfo(pg_id, pg_physical_chunks) < 0) {
    ULOG_ERROR << "get pg_physical_chunk fail. pg_id=" << pg_id;
    resp_body_->mutable_rc()->set_retcode(ucloud::udisk::EC_UDISK_GET_PC_SLICE);
    resp_body_->mutable_rc()->set_error_message("get pg physical_chunk fail");
    MessageUtil::SendPbResponse(conn_, response_);
  }

  resp_body_->mutable_rc()->set_retcode(0);
  resp_body_->mutable_rc()->set_error_message("success");
  resp_body_->mutable_pcs()->Swap(&pg_physical_chunks);
  MessageUtil::SendPbResponse(conn_, response_);
}

} // namespace chunk
} // namespace udisk
