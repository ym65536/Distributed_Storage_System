#ifndef UDISK_CHUNK_GET_UDISK_IO_STATS_H_
#define UDISK_CHUNK_GET_UDISK_IO_STATS_H_

#include <ustevent/pb_request_handle.h>
#include "udisk_message.h"

namespace udisk {
namespace chunk {
 
class GetUDiskIOStatsHandle: public uevent::PbRequestHandle {
 public:
  explicit GetUDiskIOStatsHandle(uevent::EventLoop* loop) {
  }
  virtual ~GetUDiskIOStatsHandle() {
  }
  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         const uevent::UMessagePtr& um);
 
  MYSELF_CREATE(GetUDiskIOStatsHandle);

 private:
  static int type_;
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage response_;
  ucloud::udisk::ChunkGetUDisksIOStatsResponse* resp_body_;
};

}
}
#endif

