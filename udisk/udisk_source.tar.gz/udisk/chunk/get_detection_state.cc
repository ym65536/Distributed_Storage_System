#include "get_detection_state.h"

#include <sstream>
#include <ustevent/message_util.h>
#include <ustevent/connection_uevent.h>
#include <ustevent/base/logging.h>
#include "chunk_context.h"
#include "detection_loop_handle.h"

namespace udisk {
namespace chunk {

using namespace uevent;
 
int GetDetectionStateHandle::type_ = 
                       ucloud::udisk::CHUNK_GET_DETECTION_STATE_REQUEST;

void GetDetectionStateHandle::EntryInit(const uevent::ConnectionUeventPtr& conn, 
                                         const uevent::UMessagePtr& um) {
  ULOG_INFO << "protobuf recv conn=" << conn->GetId() << ", msg " << um->DebugString();
  conn_ = conn;
  assert(um->head().message_type() == type_);
  assert(um->body().HasExtension(ucloud::udisk::chunk_get_detection_state_request));

  ucloud::udisk::ChunkGetDetectionStateRequest req_body = 
    um->body().GetExtension(ucloud::udisk::chunk_get_detection_state_request);
  MakeResponse(um.get(), ucloud::udisk::CHUNK_GET_DETECTION_STATE_RESPONSE, 
                                                                   &response_);
  resp_body_ = response_.mutable_body()->
    MutableExtension(ucloud::udisk::chunk_get_detection_state_response);

  resp_body_->mutable_rc()->set_retcode(0);
  resp_body_->mutable_rc()->set_error_message("success");
  if (g_context->detection_handle()) {
    resp_body_->set_is_running(true);
    if (g_context->detection_handle()->is_init()) {
      resp_body_->set_is_init(true);
      resp_body_->set_is_overload(g_context->detection_handle()->is_overload());
      resp_body_->set_chunk_id(g_context->config().my_id());
      resp_body_->set_dev_name(g_context->detection_handle()->GetDevName());
      uint64_t next_pc_id = 0;
      uint64_t offset = 0;
      uint64_t length = 0;
      g_context->detection_handle()->GetNextDetectionPC(
                                       &next_pc_id, &offset, &length);
      resp_body_->set_next_pc_id(next_pc_id);
      resp_body_->set_offset(offset);
      resp_body_->set_length(length);
    } else {
      resp_body_->set_is_init(false);
    }
  } else {
    resp_body_->set_is_running(false);
  }
  MessageUtil::SendPbResponse(conn_, response_);
}

} // namespace chunk
} // namespace udisk
