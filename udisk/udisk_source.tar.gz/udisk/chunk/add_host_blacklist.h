#ifndef ADD_HOST_BLACKLIST_H_
#define ADD_HOST_BLACKLIST_H_

#include <ustevent/pb_request_handle.h>
#include "udisk_message.h"
//#include "connector_libevent.h"
//#include "eventloop_libevent.h"
//#include "thread.h"
//#include "pb_request_handle.h"
//#include "message_util.h"
//#include "my_uuid.h"
//#include "chunk_context.h"


namespace udisk {
namespace chunk {

class AddHostBlacklistHandle : public uevent::PbRequestHandle {
 public:
  explicit AddHostBlacklistHandle(uevent::EventLoop* loop) : loop_(loop) {}
  virtual ~AddHostBlacklistHandle() {}
  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn, const uevent::UMessagePtr& um);

  MYSELF_CREATE(AddHostBlacklistHandle);

 private:
  static int type_;
  uevent::EventLoop* loop_;
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage response_;
  ucloud::udisk::AddHostBlacklistResponse* resp_body_;
};

}  // ns chunk
}  // ns udisk
#endif
