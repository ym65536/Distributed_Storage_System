#include <ustevent/message_util.h>
#include <ustevent/connection_uevent.h>
#include <ustevent/base/logging.h>
#include "chunk_context.h"
#include "manager_handle.h"
#include "recycle_pc.h"

namespace udisk {
namespace chunk {

using namespace uevent;

void RecyclePCHandle::SendResponse(uint32_t retcode, const char* message) {
  ucloud::udisk::ChunkRecyclePCResponse* res = 
    response_.mutable_body()->MutableExtension(ucloud::udisk::chunk_recycle_pc_response);
  res->mutable_rc()->set_retcode(retcode);
  res->mutable_rc()->set_error_message(message);
  res->set_chunk_id(g_context->config().my_id());
  res->set_pc(req_.pc());
  ULOG_INFO << response_.DebugString();
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void RecyclePCHandle::EntryInit(const uevent::ConnectionUeventPtr& conn, 
                                const uevent::UMessagePtr& um) {
  // TODO
  // 判断chunk是否初始化完毕
  ULOG_INFO << um->DebugString();
  conn_ = conn;
  session_no_ = um->head().session_no();
  MakeResponse(um.get(), ucloud::udisk::CHUNK_RECYCLE_PC_RESPONSE, &response_);
  req_ = um->body().GetExtension(ucloud::udisk::chunk_recycle_pc_request);
  RecyclePC();
}

void RecyclePCHandle::EntryRecyclePC(int retcode, std::string msg) {
  ULOG_INFO << "recycle pc retcode: " << retcode << ", message: " << msg.c_str();
  SendResponse(retcode, msg.c_str());
}

void RecyclePCHandle::RecyclePC() {
  if (req_.cluster_version() != 
      g_context->manager_handle()->const_cluster_map().GetClusterVersion()) {
    ULOG_ERROR << "cluster version not same";
    SendResponse(-1, "cluster version not same");
    return;
  }
  if ((int)req_.chunk_id() != g_context->config().my_id()) {
    ULOG_ERROR << "chunk id not same";
    SendResponse(-1, "chunk_id not same");
    return;
  }
  std::shared_ptr<RecyclePCHandle> client_ptr = 
    std::dynamic_pointer_cast<RecyclePCHandle>(shared_from_this());
  g_context->recycle_loop()->RunInLoop(std::bind(
    &RecycleLoopHandle::RecyclePC, g_context->recycle_handle(), 
    ChunkID(req_.pg_id(), req_.lc_id(), req_.pc(), req_.lc_random_id()), client_ptr));
}

}; // end of ns chunk 
}; // end of ns udisk
