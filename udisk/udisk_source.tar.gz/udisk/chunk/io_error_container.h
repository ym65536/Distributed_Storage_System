#ifndef IO_ERROR_TYPE_H
#define IO_ERROR_TYPE_H

#include <string>
#include <unordered_map>

namespace udisk {
namespace chunk {

class IOErrorContainer {
 public:
  // io 错误类型
  enum IO_ERROR_TYPE {
    kRepairIOError = 0,
    kRecycleIOError = 1,
    kNormalIOError = 2,
    kDetectionIOError = 3,
    kJournalIOFull = 4,
    kJournalIOTimeout = 5,
    kJournalIOError = 6,
  };

  // io 操作类型
  enum IO_OP_TYPE {
    kIORead = 0,
    kIOWrite = 1,
  };

  // <lc_id-IO_ERROR_TYPE-IO_OP_TYPE, number>
  typedef std::unordered_map<std::string, uint32_t> LCIOErrorMap;
  void Add(uint32_t lc_id, IO_ERROR_TYPE error_type, IO_OP_TYPE op_type);
  void Add(const std::string& msg);
  void Add(const LCIOErrorMap& lc_io_error);

  const LCIOErrorMap& lc_io_errors() const { return lc_io_errors_; }

  void Clear() { lc_io_errors_.clear(); }

  bool IsEmpty() { return lc_io_errors_.empty(); }

 private:
  std::string IOErrorTypeString(IO_ERROR_TYPE type);
  std::string IOOpTypeString(IO_OP_TYPE type);

  LCIOErrorMap lc_io_errors_;
};

};  // end of ns chunk
};  // end of ns udisk

#endif /* !IO_ERROR_TYPE_H */
// vim: set ts=2 sw=2 sts=2 et:
