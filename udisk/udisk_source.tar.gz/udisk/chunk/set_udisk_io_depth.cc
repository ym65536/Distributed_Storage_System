#include <ustevent/message_util.h>
#include <ustevent/connection_uevent.h>
#include <ustevent/base/logging.h>
#include "chunk_context.h"
#include "manager_handle.h"
#include "set_udisk_io_depth.h"

namespace udisk {
namespace chunk {
 
int SetUDiskIODepthHandle::type_ = ucloud::udisk::CHUNK_SET_UDISK_IO_DEPTH_REQUEST;

void SetUDiskIODepthHandle::EntryInit(const uevent::ConnectionUeventPtr& conn, 
                                      const uevent::UMessagePtr& um) {
  ULOG_INFO << "protobuf recv conn_id=" << conn->GetId() << ", msg " << um->DebugString();
  conn_ = conn;
  assert(um->head().message_type() == type_);
  assert(um->body().HasExtension(ucloud::udisk::chunk_set_udisk_io_depth_request));

  const ucloud::udisk::ChunkSetUDiskIODepthRequest &req_body = 
    um->body().GetExtension(ucloud::udisk::chunk_set_udisk_io_depth_request);
  MakeResponse(um.get(), ucloud::udisk::CHUNK_SET_UDISK_IO_DEPTH_RESPONSE, &response_);
  resp_body_ = response_.mutable_body()->
    MutableExtension(ucloud::udisk::chunk_set_udisk_io_depth_response);

  if (req_body.io_depth_mode() == ucloud::udisk::SET_UDISKS_IO_DEPTH_MODE_LOOP) { 
    g_context->manager_handle()->DispatchIOInLoopMode(req_body.loop_io_depth());
  } else {
    for (int i = 0; i < req_body.io_depth_infos_size(); ++i) {
      g_context->manager_handle()->UpdateLCIODepthLimit(req_body.io_depth_infos(i).lc_id(),
          req_body.io_depth_infos(i).io_depth());
    }
  }
  
  resp_body_->mutable_rc()->set_retcode(0);
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

}
}
