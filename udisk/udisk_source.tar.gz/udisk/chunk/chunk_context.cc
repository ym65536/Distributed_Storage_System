#include <ustevent/base/ini_config.h> // for config parser
#include "chunk_context.h"

#include <cerrno>
#include <cstring>
#include <cstdlib>

namespace udisk {
namespace chunk {

const std::string UDiskConfig::kThreadNum = std::string("thread_num");
const std::string UDiskConfig::kMyId = std::string("my_id");
const std::string UDiskConfig::kStorageType = std::string("storage_type");
const std::string UDiskConfig::kStorageTypeMock = std::string("mock");
const std::string UDiskConfig::kStorageTypeFile = std::string("file");
const std::string UDiskConfig::kStorageTypeRaw = std::string("raw");
const std::string UDiskConfig::kDeviceUuid = std::string("device_uuid");
const std::string UDiskConfig::kDevicePrefix = std::string("device_prefix");
const std::string UDiskConfig::kStartDetectionThread = std::string("start_detection_thread");
const std::string UDiskConfig::kRepairRate = std::string("repair_rate");
const std::string UDiskConfig::kRepairPort = std::string("repair_port");
const std::string UDiskConfig::kRecycleRate = std::string("recycle_rate");
const std::string UDiskConfig::kChunkDir = std::string("chunk_dir");
const std::string UDiskConfig::kHeartbeatMetaServerInterval = std::string("heartbeat_metaserver_interval");
const std::string UDiskConfig::kIOReportInterval = std::string("io_report_interval");
const std::string UDiskConfig::kRecycleUDiskHandleInterval = std::string("recycle_udisk_handle_interval");
const std::string UDiskConfig::kHeartbeatChunkInterval = std::string("heartbeat_chunk_interval");
const std::string UDiskConfig::kChunkTimeout = std::string("chunk_timeout");
const std::string UDiskConfig::kRepairNotifyTimeout = std::string("repair_notify_timeout");
const std::string UDiskConfig::kRepairPCTimeout = std::string("repair_pc_timeout");
const std::string UDiskConfig::kMergeSubmitTimeout = std::string("merge_submit_timeout");
const std::string UDiskConfig::kMergeSubmitIODepth = std::string("merge_submit_iodepth");
const std::string UDiskConfig::kMaxConnNumPerLoop = std::string("max_conn_num_per_loop");
const std::string UDiskConfig::kFdCacheMaxSizePerLoop = std::string("fd_cache_max_size_per_loop");
const std::string UDiskConfig::kIOListenPort = std::string("io_listen_port");
const std::string UDiskConfig::kMaxUDiskNum = std::string("max_udisk_num");
const std::string UDiskConfig::kUDiskQueueMaxDepth = std::string("udisk_queue_max_depth");
const std::string UDiskConfig::kLcSizeLimit = std::string("lc_size_limit");
const std::string UDiskConfig::kDsync = std::string("dsync_mode");
const std::string UDiskConfig::kIOTimeout = std::string("io_timeout");
const std::string UDiskConfig::kMemCheckInterval = std::string("mem_check_interval");
const std::string UDiskConfig::kArkBwLimit = std::string("ark_bw_limit");
const std::string UDiskConfig::kThrottleSmoothFactor = std::string("throttle_smooth_factor");
const std::string UDiskConfig::kThrottleTimeout = std::string("throttle_timeout");
const std::string UDiskConfig::kLoopDispatchIODepth = std::string("loop_dispatch_io_depth");
const std::string UDiskConfig::kJournalEnable = std::string("journal_enable");
const std::string UDiskConfig::kCrcEnable = std::string("crc_enable");
const std::string UDiskConfig::kMemTableCap = std::string("memtable_cap");
const std::string UDiskConfig::kPCMaxSizeInVec = std::string("pc_max_size_in_vec");
const std::string UDiskConfig::kMigrateTimeout = std::string("migrate_timeout");
const std::string UDiskConfig::kMigrateRate = std::string("migrate_rate");
const std::string UDiskConfig::kMigratePcConcurrency = std::string("migrate_pc_concurrency");
const std::string UDiskConfig::kMigrateSwitchLimit = std::string("migrate_switch_limit");
const std::string UDiskConfig::kCompactDepth = std::string("compact_depth");
const std::string UDiskConfig::kMaxOpPoolNum = std::string("max_op_pool_num");

std::tuple<int, std::string> UDiskConfig::init() {
  ConfigParser::Init();
  //必要部分为填无法启动
  if (listen_ip().empty()) {
    ULOG_FATAL << "listen_ip is empty";
  }
  if (listen_port() == 0) {
    ULOG_FATAL << "listen_port is empty";
  }
  if (zk_server().empty()) {
    ULOG_FATAL << "zk server is empty";
  }
  if (metaserver_zk_path().empty()) {
    ULOG_FATAL << "metaserver_zk_path is empty";
  }
  if (odin_zk_path().empty()) {
    ULOG_FATAL << "odin_zk_path is empty";
  }
  std::tuple<int, std::string> ret = load();
  if (std::get<0>(ret)) {
    std::string msg = "load conf " + config_file_ + " failed for " + std::get<1>(ret);
    return std::make_tuple(std::get<0>(ret), msg);
  }
  return std::make_tuple(0, "");
}

std::tuple<int, std::string> UDiskConfig::load() {
  int ret = 0;
  std::string msg("");
  std::string my_id = parser_.GetValue(kSectionCommon, kMyId);
  if (my_id.empty()) {
    ret = -1;
    msg = "my id is empty";
    return std::make_tuple(ret, msg);
  } else {
    my_id_ = std::atoi(my_id.c_str());
    ULOG_INFO << "my chunk id: " << my_id_;
  }

  std::string repair_rate = parser_.GetValue(kSectionCommon, kRepairRate);
  if (repair_rate.empty()) {
    ret = -1;
    msg = "repair rate is empty";
    return std::make_tuple(ret, msg);
  } else {
    repair_rate_ = std::atoi(repair_rate.c_str());
    ULOG_INFO << "my repair rate: " << repair_rate_;
  }

  std::string migrate_rate = parser_.GetValue(kSectionCommon, kMigrateRate);
  if (migrate_rate.empty()) {
    ret = -1;
    msg = "migrate rate is empty";
    return std::make_tuple(ret, msg);
  } else {
    migrate_rate_ = std::atoi(migrate_rate.c_str());
    ULOG_INFO << "my migrate rate: " << migrate_rate_;
  }

  std::string compact_depth = parser_.GetValue(kSectionCommon, kCompactDepth);
  if (compact_depth.empty()) {
    compact_depth_ = 8;
  } else {
    compact_depth_ = std::atoi(compact_depth.c_str());
  }
  ULOG_INFO << "my compact depth: " << compact_depth_;

  std::string repair_port = parser_.GetValue(kSectionNetworks, kRepairPort);
  if (repair_port.empty()) {
    ret = -1;
    msg = "repair port is empty";
    return std::make_tuple(ret, msg);
  } else {
    repair_port_ = std::atoi(repair_port.c_str());
    ULOG_INFO << "my repair port: " << repair_port_;
  }

  recycle_rate_ = parser_.IntValue(kSectionCommon, kRecycleRate);
  if (recycle_rate_ == 0) {
    recycle_rate_ = 50;
    ULOG_INFO << "recycle_rate is empty or 0 in config file, set default value";
  }
  ULOG_INFO << "recycle rate: " << recycle_rate_;

  std::string storage_type = parser_.GetValue(kSectionCommon, kStorageType);
  if (storage_type.empty()) {
    ret = -1;
    msg = "storage type is empty";
    return std::make_tuple(ret, msg);
  }
  storage_type_ = storage_type;
  ULOG_INFO << "storage_type: " << storage_type_;

  if (storage_type_ == kStorageTypeRaw) {
    device_uuid_ = parser_.GetValue(kSectionCommon, kDeviceUuid);
    if (device_uuid_.empty()) {
      ret = -1;
      msg = "device uuid is empty";
      return std::make_tuple(ret, msg);
    }
    ULOG_INFO << "device uuid: " << device_uuid_;

    std::string device_prefix = parser_.GetValue(kSectionCommon, kDevicePrefix);
    if (device_prefix.empty()) {
      ret = -1;
      msg = "device prefix is empty";
      return std::make_tuple(ret, msg);
    }
    device_prefix_ = device_prefix;
    ULOG_INFO << "device prefix: " << device_prefix_;

    start_detection_thread_ = parser_.IntValue(kSectionCommon, kStartDetectionThread);
    ULOG_INFO << "start_detection_thread: " << start_detection_thread_;

  } else if (storage_type_ == kStorageTypeFile) {
    std::string chunk_dir = parser_.GetValue(kSectionCommon, kChunkDir);
    if (chunk_dir.empty()) {
      ret = -1;
      msg = "chunk dir is empty";
      return std::make_tuple(ret, msg);
    }
    chunk_dir_ = chunk_dir;
    ULOG_INFO << "chunk dir: " << chunk_dir_;
  }

  thread_num_ = parser_.IntValue(kSectionCommon, kThreadNum);
  if (thread_num_ == 0) {
    thread_num_ = 20;
    ULOG_INFO << "thread_num is empty or 0 in config file, set default value";
  }
  ULOG_INFO << "thread num: " << thread_num_;

  io_report_interval_ = parser_.IntValue(kSectionCommon, kIOReportInterval);
  if (io_report_interval_ == 0) {
    io_report_interval_ = 10;
    ULOG_INFO << "io_report_interval is empty or 0 in config file, set default value";
  }
  ULOG_INFO << "io_report_interval: " << io_report_interval_;

  recycle_udisk_handle_interval_ = parser_.IntValue(kSectionCommon, kRecycleUDiskHandleInterval);
  if (recycle_udisk_handle_interval_ == 0) {
    recycle_udisk_handle_interval_ = 60*60;
    ULOG_INFO << "recycle_udisk_handle_interval is empty or 0 in config file, set default value";
  }
  ULOG_INFO << "recycle_udisk_handle_interval: " << recycle_udisk_handle_interval_;


  heartbeat_metaserver_interval_ = parser_.IntValue(kSectionCommon, kHeartbeatMetaServerInterval);
  if (heartbeat_metaserver_interval_ == 0) {
    heartbeat_metaserver_interval_ = 1;
    ULOG_INFO << "heartbeat_metaserver_interval is empty or 0 in config file, set default value";
  }
  ULOG_INFO << "heartbeat_metaserver_interval: " << heartbeat_metaserver_interval_;

  heartbeat_chunk_interval_ = parser_.IntValue(kSectionCommon, kHeartbeatChunkInterval);
  if (heartbeat_chunk_interval_ == 0) {
    heartbeat_chunk_interval_ = 1;
    ULOG_INFO << "heartbeat_chunk_interval is empty or 0 in config file, set default value";
  }
  ULOG_INFO << "heartbeat_chunk_interval: " << heartbeat_chunk_interval_;

  chunk_timeout_ = parser_.IntValue(kSectionCommon, kChunkTimeout);
  if (chunk_timeout_ == 0) {
    chunk_timeout_ = 300;
    ULOG_INFO << "chunk_timeout is empty or 0 in config file, set default value";
  }
  ULOG_INFO << "chunk_timeout: " << chunk_timeout_;

  repair_notify_timeout_ = parser_.IntValue(kSectionCommon, kRepairNotifyTimeout);
  if (repair_notify_timeout_ == 0) {
    repair_notify_timeout_ = 2;
    ULOG_INFO << "repair_notify_timeout is empty or 0, use default = " << repair_notify_timeout_;
  }
  ULOG_INFO << "repair_notify_timeout_: " << repair_notify_timeout_;

  repair_pc_timeout_ = parser_.IntValue(kSectionCommon, kRepairPCTimeout);
  if (repair_pc_timeout_ == 0) {
    repair_pc_timeout_ = 8;
    ULOG_INFO << "repair_pc_timeout is empty or 0, use default = " << repair_pc_timeout_;
  }
  ULOG_INFO << "repair_pc_timeout_: " << repair_pc_timeout_;

  merge_submit_timeout_ = parser_.IntValue(kSectionCommon, kMergeSubmitTimeout);
  if (merge_submit_timeout_ == 0) {
    merge_submit_timeout_ = 2;
    ULOG_INFO << "merge_submit_timeout is empty or 0, use default = " << merge_submit_timeout_;
  }
  ULOG_INFO << "merge_submit_timeout_: " << merge_submit_timeout_;

  merge_submit_iodepth_ = parser_.IntValue(kSectionCommon, kMergeSubmitIODepth);
  if (merge_submit_iodepth_ == 0) {
    merge_submit_iodepth_ = 1;
    ULOG_INFO << "merge_submit_iodepth is empty or 0, use default = " << merge_submit_iodepth_;
  }
  ULOG_INFO << "merge_submit_iodepth_: " << merge_submit_iodepth_;

  max_conn_num_per_loop_ = parser_.IntValue(kSectionCommon, kMaxConnNumPerLoop);
  if (max_conn_num_per_loop_ == 0) {
    max_conn_num_per_loop_ = 10000;
    ULOG_INFO << "max_conn_num_per_loop is empty or 0 in config file, set default value";
  }
  ULOG_INFO << "max_conn_num_per_loop: " << max_conn_num_per_loop_;

  fd_cache_max_size_per_loop_ = parser_.IntValue(kSectionCommon, kFdCacheMaxSizePerLoop);
  if (fd_cache_max_size_per_loop_ == 0) {
    fd_cache_max_size_per_loop_ = 50000;
    ULOG_INFO << "fd_cache_max_size_per_loop is empty or 0 in config file, set default value";
  }
  ULOG_INFO << "fd_cache_max_size_per_loop: " << fd_cache_max_size_per_loop_;

  io_timeout_ = parser_.IntValue(kSectionCommon, kIOTimeout);
  if (io_timeout_ == 0) {
    io_timeout_ = 2;
    ULOG_INFO << "io_timeout is empty or 0 in config file, set default value";
  }
  io_timer_count_ = io_timeout_ * 1000;
  ULOG_INFO << "io_timeout: " << io_timeout_ << ", io_timer_count: " << io_timer_count_;

  migrate_timeout_ = parser_.IntValue(kSectionCommon, kMigrateTimeout);
  if (migrate_timeout_ == 0) {
    migrate_timeout_ = 30;
    ULOG_INFO << "migrate_timeout is empty or 0 in config file, set default value";
  }
  io_timer_count_ = io_timeout_ * 1000;
  ULOG_INFO << "io_timeout: " << io_timeout_ << ", io_timer_count: " << io_timer_count_;

  migrate_pc_concurrency_ = parser_.IntValue(kSectionCommon, kMigratePcConcurrency);
  if (migrate_pc_concurrency_ == 0) {
    migrate_pc_concurrency_ = 8;
    ULOG_INFO << "migrate_pc_concurrency is empty or 0, use default";
  }
  ULOG_INFO << "migrate_pc_concurrency: " << migrate_pc_concurrency_;

  migrate_switch_limit_ = parser_.IntValue(kSectionCommon, kMigrateSwitchLimit);
  if (migrate_switch_limit_ == 0) {
    migrate_switch_limit_ = 5;
    ULOG_INFO << "migrate_switch_limit is empty or 0, use default";
  }
  ULOG_INFO << "migrate_switch_limit:" << migrate_switch_limit_;

  smooth_factor_ = parser_.IntValue(kSectionCommon, kThrottleSmoothFactor);
  if (smooth_factor_ == 0 || smooth_factor_ > 1000) {
    smooth_factor_ = 10;
    ULOG_INFO << "throttle_smooth_factor is invalid, set default value";
  }
  ULOG_INFO << "smooth_factor: " << smooth_factor_;

  throttle_timeout_ = parser_.IntValue(kSectionCommon, kThrottleTimeout);
  if (throttle_timeout_ == 0 || throttle_timeout_ > 10) {
    throttle_timeout_ = 5;
    ULOG_INFO << "throttle_timeout is invalid, set default value";
  }
  ULOG_INFO << "throttle_timeout: " << throttle_timeout_;

  if (listen_ip().empty()) {
    ret = -1;
    msg = "listen_ip is empty";
    return std::make_tuple(ret, msg);
  }

  io_listen_port_ = parser_.IntValue(kSectionNetworks, kIOListenPort);
  if (io_listen_port_ == 0) {
    ret = -1;
    msg = "io_listen_port is empty or 0";
    return std::make_tuple(ret, msg);
  }

  max_udisk_num_ = parser_.IntValue(kSectionUDisk, kMaxUDiskNum);
  if (max_udisk_num_ < 200000) {
    ULOG_INFO << "max_udisk_num is empty or 0 in config file, set default value";
    max_udisk_num_ = 200000;
  }
  ULOG_INFO << "max_udisk_num: " << max_udisk_num_;

  udisk_queue_max_depth_ = parser_.IntValue(kSectionUDisk, kUDiskQueueMaxDepth);
  if (udisk_queue_max_depth_ == 0) {
    ULOG_INFO << "udisk_queue_max_depth is empty or 0 in config file, set default value";
    udisk_queue_max_depth_ = 128;
  }
  ULOG_INFO << "udisk_queue_max_depth_: " << udisk_queue_max_depth_;

  lc_size_limit_ = (uint32_t)parser_.IntValue(kSectionUDisk, kLcSizeLimit);
  if (lc_size_limit_ == 0) {
    ULOG_INFO << "lc_size_limit is empty or 0 in config file, set default value";
    lc_size_limit_ = 32 * 1024;
  }
  ULOG_INFO << "lc_size_limit_: " << lc_size_limit_;

  ark_bw_limit_ = (uint32_t)parser_.IntValue(kSectionUDisk, kArkBwLimit);
  if (ark_bw_limit_ == 0) {
    ULOG_INFO << "ark_bw_limit is empty or 0 in config file, set default value";
    ark_bw_limit_ = 100;
  }
  ULOG_INFO << "ark_bw_limit_: " << ark_bw_limit_;

  std::string dsync_mode = parser_.GetValue(kSectionCommon, kDsync);
  if (!dsync_mode.empty() && dsync_mode == "close") {
    dsync_mode_ = false;
    ULOG_INFO << "config set dsync_mode as DSYNC_ close";
  } else {
    dsync_mode_ = true;
    ULOG_INFO << "dsync_mode empty or open in config file, set default DSYNC_ open";
  }
  ULOG_INFO << "dsync_mode: " << dsync_mode_;


  loop_dispatch_io_depth_ = (uint32_t)parser_.IntValue(kSectionCommon, kLoopDispatchIODepth);
  if (loop_dispatch_io_depth_ != 0) {
    ULOG_INFO << "loop_dispatch_io_depth isn't 0 or empty, will dispatch io in loop";
  }
  ULOG_INFO << "loop_dispatch_io_depth_: " << loop_dispatch_io_depth_;

  pc_max_size_in_vec_ = (uint32_t)parser_.IntValue(kSectionCommon, kPCMaxSizeInVec);
  if (pc_max_size_in_vec_ == 0) {
    pc_max_size_in_vec_ = 0xFFFFFFFF;
    ULOG_INFO << "pc_max_size_in_vec is 0 or empty, set default 0xFFFFFFFF";
  }
  ULOG_INFO << "pc_max_size_in_vec_ : " << pc_max_size_in_vec_;

  max_op_pool_num_ = parser_.IntValue(kSectionCommon, kMaxOpPoolNum);
  if (max_op_pool_num_ == 0) {
    max_op_pool_num_ = 10000;
    ULOG_INFO << "max_op_pool_num is 0 or empty, set default: 10000";
  }
  ULOG_INFO << "max_op_pool_num_ : " << max_op_pool_num_;

  if (zk_server().empty()) {
    ret = -1;
    msg = "zk server is empty";
    return std::make_tuple(ret, msg);
  }
  if (metaserver_zk_path().empty()) {
    ret = -1;
    msg = "metaserver zk path is empty";
    return std::make_tuple(ret, msg);
  }

  mem_check_interval_ = parser_.IntValue(kSectionCommon, kMemCheckInterval);
  if (mem_check_interval_== 0) {
    mem_check_interval_ = 1800;
    ULOG_INFO << "mem_check_interval is empty or 0 in config file, set default value 30min";
  }
  ULOG_INFO << "mem_check_interval: " << mem_check_interval_;

  journal_enable_ = parser_.IntValue(kSectionCommon, kJournalEnable);
  ULOG_INFO << "journal_enable: " << journal_enable_;

  crc_enable_ = parser_.IntValue(kSectionCommon, kCrcEnable);
  ULOG_INFO << "crc_enable: " << crc_enable_;
  
  memtable_cap_ = parser_.IntValue(kSectionCommon, kMemTableCap);
  if (memtable_cap_ == 0 || memtable_cap_ > 100) {
    memtable_cap_ = 20; // 默认最大20G
  }
  ULOG_INFO << "memtable limit=" << memtable_cap_;

  return std::make_tuple(ret, msg);
}

void UDiskConfig::Reload() {
  if (ConfigParser::Reload() != 0) {
    ULOG_ERROR << "reload config file failed: " << config_file_;
    return;
  }
  io_timeout_ = parser_.IntValue(kSectionCommon, kIOTimeout);
  if (io_timeout_ == 0) {
    io_timeout_ = 2;
    ULOG_INFO << "io_timeout is empty or 0 in config file, set default value";
  }

  migrate_timeout_ = parser_.IntValue(kSectionCommon, kMigrateTimeout);
  if (migrate_timeout_ == 0) {
    migrate_timeout_ = 2;
    ULOG_INFO << "migrate_timeout is empty or 0 in config file, set default value";
  }

  io_timer_count_ = io_timeout_ * 1000;
  ULOG_INFO << "io_timeout: " << io_timeout_ << ", io_timer_count: " << io_timer_count_;

  repair_notify_timeout_ = parser_.IntValue(kSectionCommon, kRepairNotifyTimeout);
  if (repair_notify_timeout_ == 0) {
    repair_notify_timeout_ = 2;
    ULOG_INFO << "repair_notify_timeout is empty or 0, use default = " << repair_notify_timeout_;
  }
  ULOG_INFO << "repair_notify_timeout_: " << repair_notify_timeout_;

  repair_pc_timeout_ = parser_.IntValue(kSectionCommon, kRepairPCTimeout);
  if (repair_pc_timeout_ == 0) {
    repair_pc_timeout_ = 8;
    ULOG_INFO << "repair_pc_timeout is empty or 0, use default = " << repair_pc_timeout_;
  }
  ULOG_INFO << "repair_pc_timeout_: " << repair_pc_timeout_;

  merge_submit_timeout_ = parser_.IntValue(kSectionCommon, kMergeSubmitTimeout);
  if (merge_submit_timeout_ == 0) {
    merge_submit_timeout_ = 2;
    ULOG_INFO << "merge_submit_timeout is empty or 0, use default = " << merge_submit_timeout_;
  }
  ULOG_INFO << "merge_submit_timeout_: " << merge_submit_timeout_;
 
  log_level_ = parser_.GetValue(kSectionLog, kLogLevel);
  base::Logger::setLogLevel(log_level_);
  ULOG_INFO << "log_level: " << log_level_;
}

UDiskContext::UDiskContext(const std::string &conf_file)
    : config_(conf_file),
  manager_handle_(nullptr), detection_handle_(nullptr),
  man_listen_loop_(nullptr), man_listener_(nullptr),
  io_listen_loop_(nullptr), io_listener_(nullptr),
  nc_(nullptr), chunk_pool_(nullptr) {
  udisk_journals_.resize(MAX_PG_NUM, nullptr);
  migrate_tasks_.resize(MAX_PG_NUM, nullptr);
}

std::tuple<int, std::string> UDiskContext::init() {
  return config_.init();
}

}; // end of ns chunk
}; // end of ns udisk

// 在进程启动后，初始化成功后，设置
udisk::chunk::UDiskContext *g_context = nullptr;
