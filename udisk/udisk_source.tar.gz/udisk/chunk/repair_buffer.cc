#include "repair_buffer.h"
#include "chunk_loop_handle.h"
#include "chunk_context.h"

using namespace udisk::chunk;
using namespace std;

#define TPC_FINISH_CHECK(type, seq) ((tiny_pcs_[type][seq] == nullptr) \
    || (tiny_pcs_[type][seq]->state_ == TPC_EMPTY) \
    || (tiny_pcs_[type][seq]->state_ == TPC_FINISH))

#define OFFSET_TO_TPCNO(offset) (offset / CHUNK_REPAIR_TINYPC_SIZE)

void TinyPC::Insert(uint32_t offset, uint32_t length, const char* data) {
  uint32_t begin = offset;
  uint32_t end = begin + length; // [begin, end)
  char* addr = data_ + (offset % CHUNK_REPAIR_TINYPC_SIZE);
  memcpy(addr, data, length);
  
  ULOG_TRACE << "Before Insert: " << ToString();
  Interval new_interval(begin, end);
  auto compare = [] (const Interval &intv1, const Interval &intv2) { 
    return intv1.end < intv2.start; 
  };
  auto range = equal_range(
      write_ranges_.begin(), write_ranges_.end(), new_interval, compare);
  auto itr1 = range.first;
  auto itr2 = range.second;
  if (itr1 == itr2) {
    write_ranges_.insert(itr1, new_interval);
  } else {
    itr2--;
    itr2->start = min(new_interval.start, itr1->start);
    itr2->end = max(new_interval.end, itr2->end);
    write_ranges_.erase(itr1, itr2);
  }
  state_ = TPC_WRITE;
  ULOG_TRACE << "After Insert: " << ToString();
}

std::string TinyPC::ToString() {
  std::ostringstream oss;
  oss << "(state: " << state_ 
      << ", Intervals: ";
  for (size_t i = 0; i < write_ranges_.size(); i++) {
    Interval& item = write_ranges_[i];
    oss << "[" << item.start << ", " << item.end << "), ";
  }
  oss << "), lc_id=" << lc_id_ << ", pc_no=" << pc_no_ << ", tpc_no=" << tpc_no_;
  return oss.str();
}

bool RepairBuffer::PCNeedRepair(uint32_t offset) {
  uint32_t tpc_no = OFFSET_TO_TPCNO(offset);
  if (states_[tpc_no] == TPC_FINISH) {
    return false;
  }
  return true;
}

void RepairBuffer::Insert(uint32_t offset, uint32_t length, const char* data) {
  uint32_t tpc_no = OFFSET_TO_TPCNO(offset);
  uint32_t active = active_[tpc_no];
  if (tiny_pcs_[active][tpc_no] == nullptr) {
    tiny_pcs_[active][tpc_no] = std::make_shared<TinyPC>(lc_id_, pc_no_, tpc_no, slab_);
  }
  tiny_pcs_[active][tpc_no]->Insert(offset, length, data);
  states_[tpc_no] = TPC_WRITE;
  // 有front io insert, 说明需要merge到本地
  front_io_ = 1;
}

void RepairBuffer::MergePendingBuffer() {
  if (merge_tpc_seqno_ > 0) {
    // 还有tpc在merge中，返回error
    ULOG_ERROR << "pending buffer is merging. merge_tpc_seqno_=" << merge_tpc_seqno_ 
      << ", lc_id=" << lc_id_ << ", pc_no=" << pc_no_;
    error_flag_ = true;
    return;
  }
  ts_merge_ = base::Timestamp::now();
  ULOG_INFO << "Merge pending buffer, lc_id=" << lc_id_ << ", pc_no=" << pc_no_ 
    <<", start time=" << ts_merge_.toString();
  // 定时器, 每隔0.1s检查inflight_list是否超时
  ti_ = loop_handle_->GetLoop()->RunAfter(0.1, 
    std::bind(&RepairBuffer::IOSubmitTimer, shared_from_this()));

  MergeTPC();
}  

void RepairBuffer::MergeTPC() {
  ULOG_DEBUG << "Merging buffer. lc_id=" << lc_id_ << ", pc_no=" << pc_no_ 
    << ", tpc_no=" << merge_tpc_seqno_;
  // 找到第一个需要merge的tpc
  uint32_t active = TPC_ACTIVE_;
  uint32_t inactive = TPC_INACTIVE_;
  while (merge_tpc_seqno_ < TPC_SIZE_) {
    active = active_[merge_tpc_seqno_];
    inactive = inactive_[merge_tpc_seqno_];
    if (TPC_FINISH_CHECK(active, merge_tpc_seqno_) 
        && TPC_FINISH_CHECK(inactive, merge_tpc_seqno_)) { // 没有写或者写完，则这个tpc已经修复结束
      states_[merge_tpc_seqno_] = TPC_FINISH;
      ULOG_DEBUG << "tpc=" << merge_tpc_seqno_ << " already merge finish. lc_id="
        << lc_id_ << ", pc_no=" << pc_no_ << ". Next...";
      merge_tpc_seqno_++;
    } else {
      break;
    }
  }
  if (merge_tpc_seqno_ >= TPC_SIZE_) { // 说明没有需要merge的tpc, game over
    FinishNotify(0, "success");
    return;
  }
  TinyPCPtr& tpc = tiny_pcs_[active][merge_tpc_seqno_];
  ULOG_INFO << "Write_Range size=" << tpc->write_ranges_.size() << ", lc_id=" 
    << lc_id_ << ", pc_no=" << pc_no_ << ", tpc_no=" << merge_tpc_seqno_;
  SubmitLocalWrite(tpc);

  std::swap(active_[merge_tpc_seqno_], inactive_[merge_tpc_seqno_]);
  swap_times_[merge_tpc_seqno_]++;
  ULOG_INFO << "Repair swap times=" << swap_times_[merge_tpc_seqno_] 
    << ", lc_id=" << lc_id_ << ", pc_no=" << pc_no_ << ", tpc_no=" << merge_tpc_seqno_;
}

namespace {

struct AioCallbackArgs {
  std::shared_ptr<RepairBuffer> buffer;
  uint32_t offset;
  uint32_t length;
};

}


void RepairBuffer::SubmitLocalWrite(const TinyPCPtr& tpc) {
  int ret = 0;
  UDiskHandle* disk_handle = loop_handle_->LookupUDiskHandle(lc_id_, 0, 0, false);
  if (disk_handle == nullptr) {
    error_flag_ = true;
    ULOG_ERROR << "Lookup udisk handle fail! pg_id=" << pg_id_ << ", lc_id=" << lc_id_
      << ", pc_no=" << pc_no_;
    return;
  }
  OpenChunkCb cb = std::bind(&RepairBuffer::OpenChunkResCb, shared_from_this(), 
                       std::placeholders::_1, std::placeholders::_2, tpc);
  ret = loop_handle_->GetChunkStorage()->OpenChunk(
      ChunkID(pg_id_, lc_id_, pc_no_, lc_random_id_), true, cb);
  if (ret != UDISK_OK) {
      error_flag_ = true;
      ULOG_ERROR << "Get filehandle fail! pg_id=" << pg_id_ << ", lc_id=" << lc_id_
          << ", pc_no=" << pc_no_;
      return;
  }
}

void RepairBuffer::OpenChunkResCb(int retcode,
                                  ChunkHandle* handle, 
                                  const TinyPCPtr& tpc) {
  if (retcode != UDISK_OK) {
    error_flag_ = true;
    ULOG_ERROR << "Get filehandle fail! pg_id=" << pg_id_ << ", lc_id="
               << lc_id_ << ", pc_no=" << pc_no_;
    return;
  } 
  auto it = tpc->write_ranges_.begin();
  if (it == tpc->write_ranges_.end()) { // 发生异常，等待超时
    error_flag_ = true;
    ULOG_ERROR << "write ranges empty! pg_id=" << pg_id_ << ", lc_id=" << lc_id_
      << ", pc_no=" << pc_no_ << ", tpc_no=" << merge_tpc_seqno_;
    return;
  }

  while (((int)inflight_list_.size() < g_context->config().merge_submit_iodepth()) 
      && (it != tpc->write_ranges_.end())) {
    Interval& interval = *it;
    uint32_t offset = interval.start;
    uint32_t length = interval.end - interval.start;
    char* addr = (char* )tpc->data_ + (offset % CHUNK_REPAIR_TINYPC_SIZE);
    // FIXME(yeheng) flowno参数填上length, 而且repair_buffer 没有引用计数，
    // 之后所有的IO都会改成投递的方式

    //TODO obj pool
    auto cb_arg = new AioCallbackArgs;
    cb_arg->buffer = shared_from_this();
    cb_arg->offset = offset;
    cb_arg->length = length;
    int ret =  handle->PWrite(addr, length, offset, RepairBuffer::AioResponseHandle, cb_arg);
    if (ret != UDISK_OK) {
      error_flag_ = true;
      ULOG_ERROR<< "submit write fail, lc_id=" << lc_id_ << ", pc_no=" << pc_no_ 
        << ", ret=" << ret << ", offset=" << offset;
      // 处理失败直接返回，等待超时
      return;
    }
    inflight_list_.insert(std::make_pair(offset, base::Timestamp::now()));
    ++it;
    ULOG_DEBUG << "submit write succ, lc_id=" << lc_id_ << ", pc_no=" << pc_no_ 
      << ", infilght=" << inflight_list_.size() << ", offset=" << offset << ", length=" << length;
  }
  tpc->write_ranges_.erase(tpc->write_ranges_.begin(), it); // 发送merge range，erase
}

void RepairBuffer::AioResponseHandle(int retcode, void* arg) {

  auto cb_arg = std::unique_ptr<AioCallbackArgs>(reinterpret_cast<AioCallbackArgs*>(arg));
  auto pbuf = cb_arg->buffer;
  auto offset = cb_arg->offset;
  uint32_t length = cb_arg->length;
  ULOG_TRACE << "aio recv: lc_id=" << pbuf->lc_id_ << ", pc_no="
            << pbuf->pc_no_ <<  ", len=" << length << ", retcode=" 
            << retcode;
  if (retcode != (int)length) {
    pbuf->error_flag_ = true;
    ULOG_ERROR << "aio recv ERROR: lc_id=" << pbuf->lc_id_ << ", pc_no="
               << pbuf->pc_no_ << ", len=" << length << ", retcode="
               << retcode;
    return; 
  }

  uint32_t tpc_no = OFFSET_TO_TPCNO(offset); 
  if (pbuf->timeout_flag_ || pbuf->error_flag_) { // 这种情况下，timeout里已经回复，无需继续做无用功
    ULOG_ERROR << "Submit response already timeout/error! lc_id=" << pbuf->lc_id_
              << ", pc_no=" << pbuf->pc_no_ << ", offset=" << offset << ", merge_tpc_seq="
              << pbuf->merge_tpc_seqno_ << ", tpc_no=" << tpc_no << ", timeout_flag="
              << pbuf->timeout_flag_ << ", error_flag=" << pbuf->error_flag_;
    return;
  }

  auto it = pbuf->inflight_list_.find(offset);
  if ((tpc_no != pbuf->merge_tpc_seqno_) || (it == pbuf->inflight_list_.end())) {
    pbuf->error_flag_ = true;
    ULOG_ERROR << "Submit response offset error! lc_id=" << pbuf->lc_id_ << ", pc_no="
      << pbuf->pc_no_ << ", offset=" << offset << ", merge_tpc_seq=" << pbuf->merge_tpc_seqno_
      << ", tpc_no=" << tpc_no << ", inflight size=" << pbuf->inflight_list_.size();
    return;
  }
  pbuf->inflight_list_.erase(it);

  uint32_t inactive = pbuf->inactive_[tpc_no];
  TinyPCPtr& tpc = pbuf->tiny_pcs_[inactive][tpc_no];
  if (tpc->write_ranges_.empty()) { // 发送完成
    if (pbuf->inflight_list_.empty()) {//并收到所有回包，本次tpc修复结束
      ULOG_DEBUG << "Finish TPC=" << tpc_no << ". "  << ", lc_id=" << pbuf->lc_id_ << ", pc_no=" << pbuf->pc_no_;
      pbuf->tiny_pcs_[inactive][tpc_no]->state_ = TPC_FINISH;
      pbuf->MergeTPC();
    } else { // wait for left inflight merge request
      ULOG_DEBUG << "Wait for left inflight size=" << pbuf->inflight_list_.size()
        << ", lc_id=" << pbuf->lc_id_ << ", pc_no=" << pbuf->pc_no_ << ", tpc_no=" << tpc_no;
    }
  } else { // 继续merge这个tpc里的剩余分段
    pbuf->SubmitLocalWrite(tpc);
  }
}

void RepairBuffer::FinishNotify(uint32_t retcode, const std::string& errmsg) {
  base::Timestamp ts_finish(base::Timestamp::now());
  ULOG_INFO << "Repair buffer finish. lc_id=" << lc_id_ << ", pc_no=" << pc_no_ 
    << ". pending_time=" << ts_pending_.toString() << ", merge_time=" 
    << ts_merge_.toString() << ", finish_time=" << ts_finish.toString();
  // 通知primary chunk
  ManagerHandle* manage_handle = g_context->manager_handle();
  uevent::EventLoop *man_loop = g_context->man_listen_loop();
  man_loop->RunInLoop(std::bind(&ManagerHandle::RepairResponseHandles, 
    manage_handle, lc_id_, pc_no_, front_io_, retcode, errmsg));

  // 通知io chunk thread, 这里调用到udisk_handle中erase, 会释放repair_buffer自身，
  // 执行完RepairPCFinishNotify，RepairBuffer已经释放，不应有其他任何操作
  loop_handle_->RepairPCFinishNotify(lc_id_, lc_size_, pc_no_); 
  return;
}

void RepairBuffer::IOSubmitTimer() {
  base::Timestamp ts_finish = base::Timestamp::now();
  auto it = inflight_list_.begin();
  while (it != inflight_list_.end()) {
    if (timeDifference(ts_finish, it->second) >= 
        g_context->config().merge_submit_timeout()) {
      timeout_flag_ = true;
      ULOG_ERROR << "submit timeout. lc_id=" << lc_id_ << ", pc_no=" << pc_no_ 
        << ", offset=" << it->first << ", tpc_no=" << OFFSET_TO_TPCNO(it->first); 
      it = inflight_list_.erase(it);
    } else {
      ++it;
    }
  }
  if (timeout_flag_) { // 超时直接返回ERROR
    ULOG_ERROR << "timeout occur, response. lc_id=" << lc_id_ << ", pc_no=" << pc_no_ ;
    loop_handle_->GetLoop()->CancelTimer(ti_);
    FinishNotify(ucloud::udisk::EC_UDISK_REPAIR_TIMEOUT, "merge pending buffer timeout");
    return;
  }
  
  if (error_flag_) {
    ULOG_ERROR << "error occur, response. lc_id=" << lc_id_ << ", pc_no=" << pc_no_ ;
    loop_handle_->GetLoop()->CancelTimer(ti_);
    FinishNotify(ucloud::udisk::EC_UDISK_REPAIR_FAIL, "merge pending buffer error");
    return;
  }
}

