#ifndef UDISK_CHUNK_CONTEXT_H_
#define UDISK_CHUNK_CONTEXT_H_

#include <string>
#include <cassert>
#include <tuple>
#include <map>
#include "zk_name_container.h"
#include "manager_handle.h"
#include "recycle_loop_handle.h"
#include "detection_loop_handle.h"
#include "config_parser.h"
#include "chunk_pool.h"
#include "journal/journal_engine.h"

namespace udisk {
namespace chunk {

class RepairLoopHandle;
// chunk的配置对象，在进程启动的时候，
// 从配置文件加载到内存中。
class UDiskConfig : public common::ConfigParser {
 public:

  // 加载配置文件
  std::tuple<int, std::string> init();
  void Reload();
  int my_id() const { return my_id_; }
  const std::string &storage_type() const { return storage_type_; }
  const std::string &device_prefix() const { return device_prefix_; }
  const std::string &device_uuid() const { return device_uuid_; }
  int start_detection_thread() const { return start_detection_thread_; }
  int repair_port() const { return repair_port_; }
  int repair_rate() const { return repair_rate_; }
  int migrate_rate() const { return migrate_rate_; }
  int migrate_pc_concurrency() const { return migrate_pc_concurrency_; }
  int migrate_switch_limit() const { return migrate_switch_limit_; }
  int compact_depth() const { return compact_depth_; }
  int recycle_rate() const { return recycle_rate_; }

  int io_listen_port() const { return io_listen_port_; }
  int thread_num() const { return thread_num_; }

  int heartbeat_metaserver_interval() const {
    return heartbeat_metaserver_interval_;
  }

  int heartbeat_chunk_interval() const {
    return heartbeat_chunk_interval_;
  }

  int chunk_timeout() const {
    return chunk_timeout_;
  }

  int repair_notify_timeout() const {
    return repair_notify_timeout_;
  }

  int repair_pc_timeout() const {
    return repair_pc_timeout_;
  }

  int merge_submit_timeout() const {
    return merge_submit_timeout_;
  }

  int merge_submit_iodepth() const {
    return merge_submit_iodepth_;
  }

  int io_report_interval() const {
    return io_report_interval_;
  }

  int max_udisk_num() const { return max_udisk_num_; }
  int udisk_queue_max_depth() const { return udisk_queue_max_depth_; }
  const std::string &chunk_dir() const { return chunk_dir_; }
  const int &fd_cache_max_size_per_loop() const {
    return fd_cache_max_size_per_loop_;
  }
  const int &max_conn_num_per_loop() const {
    return max_conn_num_per_loop_;
  }
  int recycle_udisk_handle_interval() const {
    return recycle_udisk_handle_interval_;
  }
  uint32_t lc_size_limit() const {
    return lc_size_limit_;
  }
  uint64_t ark_bw_limit() const {
    return ark_bw_limit_;
  }
  bool dsync_mode() const {
    return dsync_mode_;
  }
  int io_timeout() const {
    return io_timeout_;
  }
  int migrate_timeout() const {
    return migrate_timeout_;
  }
  int io_timer_count() const {
    return io_timer_count_;
  }
  int mem_check_interval() const {
    return mem_check_interval_;
  }
  uint32_t smooth_factor() const {
    return smooth_factor_;
  }
  uint32_t throttle_timeout() const {
    return throttle_timeout_;
  }

  uint32_t loop_dispatch_io_depth() const {
    return loop_dispatch_io_depth_;
  }

  bool journal_enable() const {
    return (journal_enable_ != 0);
  }
  
  bool crc_enable() const {
    return (crc_enable_ != 0);
  }

  uint32_t memtable_cap() const {
    return memtable_cap_;
  }
  
  uint32_t pc_max_size_in_vec() const {
    return  pc_max_size_in_vec_;
  }

  int max_op_pool_num() const {
    return max_op_pool_num_;
  }

  // 从文件加载配置项,覆盖当前内容
  // 失败的话返回(非0,错误消息),
  // 否则返回(0,"")
  std::tuple<int, std::string> load();

  static const std::string kThreadNum;
  static const std::string kMyId;
  // mock; file; raw
  static const std::string kStorageType;
  static const std::string kStorageTypeMock;
  static const std::string kStorageTypeFile;
  static const std::string kStorageTypeRaw;

  static const std::string kDeviceUuid;
  static const std::string kDevicePrefix;
  static const std::string kStartDetectionThread;
  static const std::string kRepairRate;
  static const std::string kRepairPort;
  static const std::string kRecycleRate;
  static const std::string kChunkDir;
  static const std::string kHeartbeatMetaServerInterval;
  static const std::string kHeartbeatChunkInterval;
  static const std::string kChunkTimeout;
  static const std::string kRepairNotifyTimeout;
  static const std::string kRepairPCTimeout;
  static const std::string kMergeSubmitTimeout;
  static const std::string kMergeSubmitIODepth;
  static const std::string kIoReportInterval;
  static const std::string kIOReportInterval;
  static const std::string kRecycleUDiskHandleInterval;
  static const std::string kMaxConnNumPerLoop;
  static const std::string kFdCacheMaxSizePerLoop;
  static const std::string kIOListenPort;
  static const std::string kManListenPort;
  static const std::string kMaxUDiskNum;
  static const std::string kUDiskQueueMaxDepth;
  static const std::string kLcSizeLimit;
  static const std::string kDsync;
  static const std::string kIOTimeout;
  static const std::string kArkBwLimit;
  static const std::string kMemCheckInterval;
  static const std::string kThrottleSmoothFactor;
  static const std::string kThrottleTimeout;
  static const std::string kLoopDispatchIODepth;
  static const std::string kJournalEnable;
  static const std::string kCrcEnable;
  static const std::string kMemTableCap;
  static const std::string kPCMaxSizeInVec;
  static const std::string kMigrateTimeout;
  static const std::string kMigrateRate;
  static const std::string kMigratePcConcurrency;
  static const std::string kMigrateSwitchLimit;
  static const std::string kCompactDepth;
  static const std::string kMaxOpPoolNum;

 private:
  explicit UDiskConfig(const std::string& file)
      : ConfigParser(file),
        my_id_(0),
        io_listen_port_(0),
        thread_num_(0),
        heartbeat_metaserver_interval_(0),
        heartbeat_chunk_interval_(0),
        chunk_timeout_(0),
        repair_notify_timeout_(0),
        repair_pc_timeout_(0),
        io_report_interval_(0),
        recycle_udisk_handle_interval_(0),
        max_udisk_num_(0),
        udisk_queue_max_depth_(0),
        fd_cache_max_size_per_loop_(0),
        max_conn_num_per_loop_(0),
        lc_size_limit_(0),
        ark_bw_limit_(0),
        dsync_mode_(true),
        io_timeout_(0),
        migrate_timeout_(0),
        io_timer_count_(0),
        mem_check_interval_(1800),
        smooth_factor_(0),
        throttle_timeout_(0),
		    loop_dispatch_io_depth_(0),
        journal_enable_(0),
        crc_enable_(0),
        pc_max_size_in_vec_(0),
        max_op_pool_num_(0) {
  }

  UDiskConfig(const UDiskConfig &) = delete;
  UDiskConfig &operator = (const UDiskConfig &) = delete;

  // 只允许UDiskContext构造对象
  friend class UDiskContext;

  std::string config_file_;

  int my_id_;
  std::string storage_type_;
  std::string device_uuid_;
  std::string device_prefix_;
  int start_detection_thread_;
  int io_listen_port_;
  int thread_num_;
  int heartbeat_metaserver_interval_;
  int heartbeat_chunk_interval_;
  int chunk_timeout_;
  int repair_notify_timeout_;
  int repair_pc_timeout_;
  int merge_submit_timeout_;
  int merge_submit_iodepth_;
  int io_report_interval_;
  int recycle_udisk_handle_interval_;
  int max_udisk_num_;
  int udisk_queue_max_depth_;
  std::string chunk_dir_;
  int fd_cache_max_size_per_loop_;
  int max_conn_num_per_loop_;
  int repair_rate_;
  int migrate_rate_;
  int migrate_pc_concurrency_;
  int migrate_switch_limit_;
  int compact_depth_;
  int repair_port_;
  int recycle_rate_;
  uint32_t lc_size_limit_;
  uint32_t ark_bw_limit_; //单位MB
  bool dsync_mode_;
  int io_timeout_;
  int migrate_timeout_;
  int io_timer_count_;
  int mem_check_interval_;
  uint32_t smooth_factor_;
  uint32_t throttle_timeout_;
  uint32_t loop_dispatch_io_depth_;
  int journal_enable_;
  int crc_enable_;
  uint32_t pc_max_size_in_vec_; 
  int max_op_pool_num_;
  uint32_t memtable_cap_; // GB, 总的MemTable占用内存, 单个MemTable内存=memtable_cap_/(2*PG_NUM)
};

// 这个类管理所有的全局
// 变量，包括日志对象，配置
// 文件对象等等
class UDiskContext {
 public:
  explicit UDiskContext(const std::string &conf_file);

  UDiskContext(const UDiskContext &) = delete;
  UDiskContext& operator = (const UDiskContext &) = delete;

  // 初始化开始
  std::tuple<int, std::string> init();

  const UDiskConfig &config() const {
    return config_;
  };

  UDiskConfig *mutable_config() {
    return &config_;
  }

  void set_repair_handle(RepairLoopHandle *repair_handle) {
    repair_handle_ = repair_handle;
  }
  RepairLoopHandle *repair_handle() {
    return repair_handle_;
  }

  void set_recycle_handle(RecycleLoopHandle *recycle_handle) {
    recycle_handle_ = recycle_handle;
  }
  RecycleLoopHandle *recycle_handle() {
    return recycle_handle_;
  }

  void set_recycle_loop(uevent::EventLoop *loop) {
    recycle_loop_ = loop;
  }
  uevent::EventLoop *recycle_loop() {
    return recycle_loop_;
  }

  void set_detection_handle(DetectionLoopHandle *detection_handle) {
    detection_handle_ = detection_handle;
  }
  DetectionLoopHandle *detection_handle() {
    return detection_handle_;
  }

  void set_detection_loop(uevent::EventLoop *loop) {
    detection_loop_ = loop;
  }
  uevent::EventLoop *detection_loop() {
    return detection_loop_;
  }

  void set_repair_listener(uevent::ListenerUevent *listener) {
    repair_listener_ = listener;
  }
  uevent::ListenerUevent * repair_listener() {
    return repair_listener_;
  }

  void set_repair_loop(uevent::EventLoop *loop) {
    repair_loop_ = loop;
  }
  uevent::EventLoop *repair_loop() {
    return repair_loop_;
  }

  void set_manager_handle(ManagerHandle *man) {
    manager_handle_ = man;
  }

  ManagerHandle *manager_handle() {
    return manager_handle_;
  }

  void set_io_listener(uevent::ListenerUevent *listener) {
    io_listener_ = listener;
  }
  uevent::ListenerUevent * io_listener() {
    return io_listener_;
  }
  void set_man_listener(uevent::ListenerUevent *listener) {
    man_listener_ = listener;
  }
  uevent::ListenerUevent * man_listener() {
    return man_listener_;
  }

  void set_io_listen_loop(uevent::EventLoop *loop) {
    io_listen_loop_ = loop;
  }
  uevent::EventLoop *io_listen_loop() {
    return io_listen_loop_;
  }

  void set_man_listen_loop(uevent::EventLoop *loop) {
    man_listen_loop_ = loop;
  }

  uevent::EventLoop *man_listen_loop() {
    return man_listen_loop_;
  }

  void set_nc(common::NameContainer *nc) {
    nc_ = nc;
  }
  common::NameContainer *nc() {
    return nc_;
  }

  void set_chunk_pool(ChunkPool *chunk_pool) {
    chunk_pool_ = chunk_pool;
  }
  ChunkPool *chunk_pool() {
    return chunk_pool_;
  }

  void set_journal_meta(journal::JournalMeta* journal_meta) {
    journal_meta_ = journal_meta;
  }
  journal::JournalMeta* journal_meta() {
    assert(journal_enable());
    return journal_meta_;
  }

  void set_udisk_journals(std::vector<journal::UDiskJournal*>& udisk_journals) {
    for (uint32_t i = 0; i < udisk_journals.size(); ++ i) {
      udisk_journals_[i] = udisk_journals[i];
    }
  }

  journal::UDiskJournal* udisk_journal(uint32_t pg_id) {
    return udisk_journals_[pg_id];
  }

  journal::MigrateTask* migrate_task(uint32_t pg_id) {
    return migrate_tasks_[pg_id];
  }

  void set_migrate_tasks(std::vector<journal::MigrateTask*>& migrate_journals) {
    migrate_tasks_.swap(migrate_journals);
  }

  bool journal_enable() {
    return config_.journal_enable() &&
           (config_.storage_type() == UDiskConfig::kStorageTypeRaw || 
            config_.storage_type() == UDiskConfig::kStorageTypeFile); 
  }
  
 private:
  UDiskConfig config_;

  ManagerHandle *manager_handle_;
  RepairLoopHandle *repair_handle_;
  RecycleLoopHandle *recycle_handle_;
  DetectionLoopHandle *detection_handle_;

  uevent::EventLoop *recycle_loop_;

  uevent::EventLoop *detection_loop_;

  uevent::EventLoop *repair_loop_;
  uevent::ListenerUevent *repair_listener_;

  uevent::EventLoop *man_listen_loop_;
  uevent::ListenerUevent *man_listener_;

  uevent::EventLoop *io_listen_loop_;
  uevent::ListenerUevent *io_listener_;

  common::NameContainer *nc_;

  ChunkPool *chunk_pool_;
  journal::JournalMeta* journal_meta_;
  std::vector<journal::UDiskJournal*> udisk_journals_;
  std::vector<journal::MigrateTask*> migrate_tasks_;
};

} // end of ns chunk
} // end of ns udisk

extern udisk::chunk::UDiskContext *g_context;

#endif
