#include <ustevent/base/logging.h>
#include "udisk_handle.h"
#include "chunk_context.h"
#include "chunk_loop_handle.h"
#include "manager_handle.h"
#include "likely.h"
#include "io_error_container.h"

using namespace std::placeholders;
using namespace uevent;
using namespace udisk;
using namespace udisk::journal;
using namespace udisk::chunk;

UDiskHandle::UDiskHandle(uint32_t lc_id,
                         uint32_t lc_random_id,
                         uint32_t pc_count,
                         ChunkLoopHandle* lh)
    : lc_id_(lc_id),
      lc_random_id_(lc_random_id),
      pc_count_(pc_count),
      loop_handle_(lh),
      io_depth_limit_(g_context->config().udisk_queue_max_depth()) {
    ark_throttle_.reset(new OpThrottle(
        (uint64_t)g_context->config().ark_bw_limit() * MB_SIZE,
        std::bind(&UDiskHandle::OpEnqueue, this, std::placeholders::_1),
        std::bind(&UDiskHandle::ArkOpTimeout, this, std::placeholders::_1),
        g_context->config().throttle_timeout(), lh->GetLoop(),
        g_context->config().smooth_factor()));
}

UDiskHandle:: ~UDiskHandle() {
  for (auto it = pending_list_.begin(); it != pending_list_.end(); ++it) {
    if (*it) {
      delete *it;
      *it = nullptr;
    }
  }
  for (auto it = inflying_list_.begin(); it != inflying_list_.end(); ++it) {
    if (it->second) {
      delete it->second;
      it->second = nullptr;
    }
  }
}

const cluster::ClusterMap& UDiskHandle::cluster_map() {
  return loop_handle_->cluster_map();
}

int UDiskHandle::RepairPCStart(uint32_t pg_id, uint32_t pc_no) {
  inuse_flag_ = true;
  if (repair_pcs_.find(pc_no) != repair_pcs_.end()) {
    ULOG_ERROR << "PC is repairing... lc_id=" << lc_id_ << ", pc_no=" << pc_no;
    return -1;
  }
  ULOG_DEBUG << "insert repair pc, pg_id=" << pg_id << "lc_id=" << lc_id_
    << ", pc_no=" << pc_no;
  std::shared_ptr<RepairBuffer> repair_buffer = std::make_shared<RepairBuffer>
    (lc_id_, lc_size(), pc_no, pg_id, lc_random_id_, loop_handle_);
  repair_pcs_.insert(std::make_pair(pc_no, repair_buffer));
  return 0;
}

int UDiskHandle::RepairPCMerge(uint32_t pc_no) {
  std::unordered_map<uint32_t, std::shared_ptr<RepairBuffer>>::iterator it = repair_pcs_.find(pc_no);
  if (it == repair_pcs_.end()) {
    ULOG_ERROR << "Can not find repair pc, lc_id=" << lc_id_ << ", pc_no=" << pc_no;
    return -1;
  }
  ULOG_DEBUG << "merge pending buffer, lc_id=" << lc_id_ << ", pc_no=" << pc_no;
  it->second->MergePendingBuffer();
  return 0;
}

int UDiskHandle::RepairPCFinish(uint32_t pc_no) {
  std::unordered_map<uint32_t, std::shared_ptr<RepairBuffer>>::iterator it = repair_pcs_.find(pc_no);
  if (it == repair_pcs_.end()) {
    ULOG_ERROR << "Can not find finish pc, lc_id=" << lc_id_ << ", pc_no=" << pc_no;
    return -1;
  }
  ULOG_DEBUG << "pc repair finish, lc_id=" << lc_id_ << ", pc_no=" << pc_no;
  repair_pcs_.erase(it);
  return 0;
}

bool UDiskHandle::DoGateOpRequest(OpRequest* op) {
  ULOG_TRACE << op->trace_tag();
  inuse_flag_ = true;
  const common::GateIORequestHead* gate_hdr =
    (const common::GateIORequestHead*)op->sub_msg_hdr_offset();
  if (UNLIKELY(!loop_handle_->cluster_map().IsInit())) {
    ULOG_ERROR << "cluster_map not inited, chunk not ready";
    op->set_retcode(0, common::RETCODE_CHUNK_NOT_READY);
    AckGateIORequest(op);
    return false;
  }
  if (UNLIKELY(reset_flag_)) {
    ULOG_INFO << "connection reset for gate, lc: " << lc_id_
             << " in thread: " <<  std::string(base::CurrentThread::name());
    op->set_retcode(0, common::RETCODE_RESET_CONNECTION);
    AckGateIORequest(op);
    reset_flag_ = false; //生效一次后要清除, 否则可能会一直拒绝连接
    return false;
  }
  //是否是该pg的主chunk留在发送的时候判断,利用cache
  if (UNLIKELY(gate_hdr->route_version != loop_handle_->cluster_map().GetClusterVersion())) {
    ULOG_ERROR << "chunk cluster version "
              << loop_handle_->cluster_map().GetClusterVersion()
              << " != gate io version " << gate_hdr->route_version;
    op->set_retcode(0, common::RETCODE_CLUSTER_VERSION_ERR);
    AckGateIORequest(op);
    return false;
  }

  if (UNLIKELY(gate_hdr->pc_size != g_context->chunk_pool()->pc_size())) {
    ULOG_ERROR << "pc_size of gate header:" << gate_hdr->pc_size
               << " != pc_size of chunk pool:"
               << g_context->chunk_pool()->pc_size();
    // 如果pc_size不相同，不回复gate，由gate触发超时警告
    //op->set_retcode(0, common::RETCODE_OTHER_ERR);
    //AckGateIORequest(op);
    return false;
  }
  
  // 为保持兼容，剔除gate cluster uuid == 0 的情况
  if (UNLIKELY(gate_hdr->cluster_uuid != 0
      && gate_hdr->cluster_uuid != loop_handle_->cluster_map().GetClusterUuid())) {
    ULOG_ERROR << "chunk cluster uuid "
               << loop_handle_->cluster_map().GetClusterUuid()
               << " != gate cluster uuid " << gate_hdr->cluster_uuid;
    // 不回复gate，由gate触发超时警告
    //op->set_retcode(0, common::RETCODE_OTHER_ERR);
    //AckGateIORequest(op);
    return false;
  }

  OpEnqueue(op);
  return true;
}

void UDiskHandle::DoReplicaRemoteResponse(const common::MigrateHead* hdr) {
  uint32_t pg_id = hdr->reserved_pg_id;
  auto found = inflying_list_.find(std::make_pair(pg_id, hdr->flowno));
  if (found == inflying_list_.end()) {
    ULOG_ERROR << "Cannot find ReplicaRemote response, migrate_head=" 
        << DumpMigrateHead(*hdr);
    return;
  }
  OpRequest* op = found->second;
  uint32_t chunk_id = op->GetChunkId(common::kReplicaNum);
  assert(chunk_id == UINT32_MAX);
  ULOG_DEBUG << "migrate_dualwrite response head=" << DumpMigrateHead(*hdr)
      << " parent op: " << op->trace_tag();
  // 本地io未返回但该请求已超时，所以仍然在inflying list
  if (op->timeout()) {
    ULOG_ERROR << "ReplicaRemote response op timeout, migrate_head=" 
        << DumpMigrateHead(*hdr);
    return;
  }
  bool finished = op->mark_replica_received(common::kReplicaNum, hdr->retcode);
  ULOG_DEBUG << "replica_no=" << common::kReplicaNum << ", finish=" << finished;
  if (finished) {
    // 需要Chunk转发的可能是gate或ark的io
    EndIORequest(op);
  }
  // 需要主动断开连接, 由于这个错误码也返回给了gate,
  // gate 会主动断开连接，并重试这个连接上的所有IO
  // 所以这里不断开连接，因为连接是共用的，会使别的盘
  // 也会超时。
  if (hdr->retcode == common::RETCODE_RESET_CONNECTION) {
    ULOG_INFO << "connection from gate will be closed";
    return;
  } 
  if (hdr->retcode) {
    g_context->manager_handle()->ReportChunkFailure(chunk_id, hdr->retcode);
  }
  return;
}

// 不需要做version检查，放入pending 队列时已经检查过
void UDiskHandle::DispatchGateRequest(OpRequest* op) {
  ULOG_TRACE << op->trace_tag();
  const common::GateIORequestHead* gate_hdr =
    (const common::GateIORequestHead*)op->sub_msg_hdr_offset();
  switch (gate_hdr->cmd) {
    case common::GATE_CMD_READ: {
      LocalAioRequest(op);
      break;
    }
    case common::GATE_CMD_WRITE: {
      LocalAioRequest(op);
      ReplicaRequest(op);
      // 迁移结束双写
      loop_handle_->ReplicaRemoteRequest(op);
      break;
    }
    default: {
      assert(0 == "unkonw gate cmd");
      break;
    }
  }
}

void UDiskHandle::ArkOpTimeout(OpRequest* op) {
  ULOG_ERROR << "ArkOpTimeout " << op->trace_tag();
  op->TimeoutCb(false);
  AckArkIORequest(op);
  op->DecRefs();
}

bool UDiskHandle::DoArkOpRequest(OpRequest* op) {
  ULOG_TRACE << op->trace_tag();
  inuse_flag_ = true;
  const common::ArkIORequestHead* ark_hdr =
    (const common::ArkIORequestHead*)op->sub_msg_hdr_offset();
  if (UNLIKELY(!loop_handle_->cluster_map().IsInit())) {
    ULOG_ERROR << "cluster_map not inited, chunk not ready";
    op->set_retcode(0, common::RETCODE_CHUNK_NOT_READY);
    AckArkIORequest(op);
    return false;
  }
  //是否是该pg的主chunk留在发送的时候判断,利用cache
  if (UNLIKELY(ark_hdr->route_version != loop_handle_->cluster_map().GetClusterVersion())) {
    ULOG_ERROR << "chunk cluster version "
              << loop_handle_->cluster_map().GetClusterVersion()
              << " != ark io version " << ark_hdr->route_version;
    op->set_retcode(0, common::RETCODE_CLUSTER_VERSION_ERR);
    AckArkIORequest(op);
    return false;
  }

  ULOG_DEBUG << "ArkThrottle op_seq:" << op->op_seq();
  ark_throttle_->Flow(op, ark_hdr->length);
  return true;
}

// 不需要做version检查，放入pending 队列时已经检查过
void UDiskHandle::DispatchArkRequest(OpRequest* op) {
  const common::ArkIORequestHead* ark_hdr =
    (const common::ArkIORequestHead*)op->sub_msg_hdr_offset();
  switch (ark_hdr->cmd) {
    case common::ARK_CMD_READ: {
      LocalAioRequest(op);
      break;
    }
    case common::ARK_CMD_WRITE: {
      LocalAioRequest(op);
      ReplicaRequest(op);
      break;
    }
    default: {
      assert(0 == "unkonw ark cmd");
      break;
    }
  }
}

void UDiskHandle::DispatchMigrateJournalRequest(OpRequest* op) {
  const common::MigrateHead* migrate_hdr =
    (const common::MigrateHead*)op->sub_msg_hdr_offset();
  switch (migrate_hdr->cmd) {
    case common::MIGRATE_CMD_JOURNAL:
    case common::MIGRATE_CMD_MEMTABLE:
    case common::MIGRATE_CMD_PC_WRITE:
    case common::MIGRATE_CMD_DUALWRITE:
      LocalAioRequest(op);
      ReplicaRequest(op);
      break;
    case common::MIGRATE_CMD_PC_READ:
      // 不可能从迁移的目的chunk读
      ULOG_ERROR << "MIGRATE_CMD_PC_READ impossible for migrate destination chunk";
      break;
    default: 
      assert(0 == "unkonw ark cmd");
      break;
  }
}

bool UDiskHandle::DoHelaOpRequest(OpRequest* op) {
  ULOG_TRACE << op->trace_tag();
  inuse_flag_ = true;
  const common::HelaChunkRequestHead* hela_hdr =
    (const common::HelaChunkRequestHead*)op->sub_msg_hdr_offset();
  if (UNLIKELY(!loop_handle_->cluster_map().IsInit())) {
    ULOG_ERROR << "cluster_map not inited, chunk not ready";
    op->set_retcode(0, common::RETCODE_CHUNK_NOT_READY);
    AckHelaIORequest(op);
    return false;
  }
  if (UNLIKELY(reset_flag_)) {
    ULOG_INFO << "connection reset for hela, lc: " << lc_id_
             << " in thread: " <<  std::string(base::CurrentThread::name());
    op->set_retcode(0, common::RETCODE_RESET_CONNECTION);
    AckHelaIORequest(op);
    reset_flag_ = false; //生效一次后要清除, 否则可能会一直拒绝连接
    return false;
  }
  if (UNLIKELY(hela_hdr->route_version != loop_handle_->cluster_map().GetClusterVersion())) {
    ULOG_ERROR << "chunk cluster version "
              << loop_handle_->cluster_map().GetClusterVersion()
              << " != hela io version " << hela_hdr->route_version;
    op->set_retcode(0, common::RETCODE_CLUSTER_VERSION_ERR);
    AckHelaIORequest(op);
    return false;
  }

  OpEnqueue(op);
  return true;
}

void UDiskHandle::DispatchHelaRequest(OpRequest* op) {
  const common::HelaChunkRequestHead* hela_hdr =
    (const common::HelaChunkRequestHead*)op->sub_msg_hdr_offset();
  switch (hela_hdr->cmd) {
    case common::HELA_CMD_READ: {
      LocalAioRequest(op);
      break;
    }
    case common::HELA_CMD_WRITE: {
      LocalAioRequest(op);
      HelaReplicaRequest(op);
      break;
    }
    default: {
      assert(0 == "unkonw hela cmd");
      break;
    }
  }
}

int UDiskHandle::ReplicaRequest(OpRequest* op) {
  const common::MessageHeader  *src_common_hdr = op->msg_hdr();
  uint32_t pg_id;
  uint64_t route_version;
  const common::GateIORequestHead *gate_hdr = nullptr;
  const common::ArkIORequestHead *ark_hdr = nullptr;
  const common::MigrateHead *migrate_hdr = nullptr;
  if (op->msg_type() == common::MSG_GATE_IO_REQ) {
    gate_hdr = (const common::GateIORequestHead*)op->sub_msg_hdr_offset();
    pg_id = gate_hdr->pg_id;
    route_version = gate_hdr->route_version;
  } else if (op->msg_type() == common::MSG_ARK_IO_REQ) {
    ark_hdr = (const common::ArkIORequestHead*)op->sub_msg_hdr_offset();
    pg_id = ark_hdr->pg_id;
    route_version = ark_hdr->route_version;
  } else {
    migrate_hdr = (const common::MigrateHead*)op->sub_msg_hdr_offset();
    pg_id = migrate_hdr->pg_id;
    route_version = migrate_hdr->route_version;
  }

  std::vector<ChunkLoopHandle::ChunkRouteEntry>* chunk_routes;
  loop_handle_->GetPgRoute(pg_id, route_version, &chunk_routes);
  // 理论上不可能有pg_id 找不到路由的情况, 如果发生直接core
  if (chunk_routes == nullptr) {
    ULOG_FATAL << "pg route is null for pg_id: " << pg_id;
  }
  constexpr size_t msg_hdr_len = sizeof(common::MessageHeader) +
                       sizeof(common::ChunkIORequestHead);
  char msg_hdr[msg_hdr_len];
  auto dst_common_hdr = (common::MessageHeader*)msg_hdr;
  auto chunk_hdr = (common::ChunkIORequestHead*)(dst_common_hdr->next_header);
  ULOG_TRACE << "chunk_routes size: " <<  chunk_routes->size();
  for (size_t i = 0; i < chunk_routes->size(); ++i) {
    // 必须放在第一行，否则发送报错退出会认为不需要发送
    // 不能触发超时报错
    op->mark_replica_waiting(i + 1, (*chunk_routes)[i].chunk_id);
    if ((*chunk_routes)[i].primary_chunk_id != loop_handle_->my_chunk_id()) {
      ULOG_ERROR << "I am not primary chunk for pg_id: "
                <<  pg_id << " primary chunk id: "
                << (*chunk_routes)[i].primary_chunk_id << " my id: "
                <<  loop_handle_->my_chunk_id();
      return -1;
    }
    if ((*chunk_routes)[i].ctor->HasAvailableConnection() == false) {
      ULOG_ERROR << "no available connection to chunk:"
                << (*chunk_routes)[i].ctor->GetPeerAddress().ToString();
    }
    // 返回引用，减少智能指针拷贝开销
    const uevent::ConnectionUeventPtr& chunk_conn = (*chunk_routes)[i].ctor->GetConnection();
    if (op->msg_type() == common::MSG_GATE_IO_REQ) {
      BuildChunkRequestWithGateReq(*src_common_hdr, dst_common_hdr,
                      *gate_hdr, chunk_hdr,
                      op->op_seq(), i + 1);
    } else if (op->msg_type() == common::MSG_ARK_IO_REQ) {
      BuildChunkRequestWithArkReq(*src_common_hdr, dst_common_hdr,
                      *ark_hdr, chunk_hdr,
                      op->op_seq(), i + 1);
    } else {
      BuildChunkRequestWithMigrateReq(*src_common_hdr, dst_common_hdr,
                      *migrate_hdr, chunk_hdr,
                      op->op_seq(), i + 1);
    }

    //没有重试报错依赖超时检测
    int rc = chunk_conn->SendData(msg_hdr, msg_hdr_len);
    if (rc) {
      ULOG_ERROR << "Replicate Gate Op " << op->op_seq()
                << " 's hdr To Chunk" << (*chunk_routes)[i].chunk_id
                << " failed, retcode: " << rc;
    }
    rc = chunk_conn->SendData(op->msg_data(), chunk_hdr->size);
    if (rc) {
      ULOG_ERROR << "Replicate Gate Op " << op->op_seq()
                << " 's data To Chunk" << (*chunk_routes)[i].chunk_id
                << " failed, retcode: " << rc;
    }
    ULOG_DEBUG << "Replicate Gate Op " << op->op_seq()
              << " 's data To Chunk" << (*chunk_routes)[i].chunk_id 
              << ", op=" << op->trace_tag() 
              << ", chunk_hdr=" << DumpChunkIORequest(*chunk_hdr);
  }
  return 0;
}

int UDiskHandle::HelaReplicaRequest(OpRequest* op) {
  const common::MessageHeader  *src_common_hdr = op->msg_hdr();
  uint32_t pg_id;
  uint64_t route_version;

  const common::HelaChunkRequestHead *hela_hdr = nullptr;
  hela_hdr = (const common::HelaChunkRequestHead*)op->sub_msg_hdr_offset();
  pg_id = hela_hdr->pg_id;
  route_version = hela_hdr->route_version;

  std::vector<ChunkLoopHandle::ChunkRouteEntry>* chunk_routes;
  loop_handle_->GetHelaPgRoute(pg_id, route_version, &chunk_routes);
  // 理论上不可能有pg_id 找不到路由的情况, 如果发生直接core
  if (chunk_routes == nullptr) {
    ULOG_FATAL << "pg route is null for pg_id: " << pg_id;
  }
  // 没有修复状态的chunk路由，直接返回
  if (chunk_routes->size() == 0) {
    return 0;
  }
  // 由主chunk同步给从chunk
  if ((*chunk_routes)[0].primary_chunk_id != loop_handle_->my_chunk_id()) {
    return 0;
  }

  size_t msg_hdr_len = sizeof(common::MessageHeader) +
                       sizeof(common::ChunkIORequestHead);
  char msg_hdr[msg_hdr_len];
  common::MessageHeader *dst_common_hdr = (common::MessageHeader*)msg_hdr;
  common::ChunkIORequestHead *chunk_hdr =
      (common::ChunkIORequestHead*)(dst_common_hdr->next_header);
  ULOG_TRACE << "chunk_routes size: " <<  chunk_routes->size();
  for (size_t i = 0; i < chunk_routes->size(); ++i) {
    // 必须放在第一行，否则发送报错退出会认为不需要发送
    // 不能触发超时报错
    op->mark_replica_waiting(i + 1, (*chunk_routes)[i].chunk_id);

    if ((*chunk_routes)[i].ctor->HasAvailableConnection() == false) {
      ULOG_ERROR << "no available connection to chunk:"
                << (*chunk_routes)[i].ctor->GetPeerAddress().ToString();
    }
    // 返回引用，减少智能指针拷贝开销
    const uevent::ConnectionUeventPtr& chunk_conn = (*chunk_routes)[i].ctor->GetConnection();

    BuildChunkRequestWithHelaReq(*src_common_hdr, dst_common_hdr,
                          *hela_hdr, chunk_hdr,
                          op->op_seq(), i + 1);

    //没有重试报错依赖超时检测
    int rc = chunk_conn->SendData(msg_hdr, msg_hdr_len);
    if (rc) {
      ULOG_ERROR << "Replicate Hela Op " << op->op_seq()
                << " 's hdr To Chunk" << (*chunk_routes)[i].chunk_id
                << " failed, retcode: " << rc;
    }
    rc = chunk_conn->SendData(op->msg_data(), chunk_hdr->size);
    if (rc) {
      ULOG_ERROR << "Replicate Hela Op " << op->op_seq()
                << " 's data To Chunk" << (*chunk_routes)[i].chunk_id
                << " failed, retcode: " << rc;
    }
  }
  return 0;
}

void UDiskHandle::EndIORequest(OpRequest* op) {
  const common::MessageHeader* common_hdr = op->msg_hdr();
  switch (common_hdr->msg_type) {
    case common::MSG_GATE_IO_REQ:
      EndGateIORequest(op);
      break;
    case common::MSG_ARK_IO_REQ:
      EndArkIORequest(op);
      break;
    case common::MSG_CHUNK_IO_REQ:
      EndChunkIORequest(op);
      break;
    case common::MSG_MIGRATE_JOURNAL_REQ:
      EndMigrateJournalRequest(op);
      break;
    case common::MSG_HELA_CHUNK_REQ:
      EndHelaIORequest(op);
      break;
    default:
      // nerver here!
      ULOG_ERROR << "EndIORequest MSG_ERROR: msg_type=" << common_hdr->msg_type;
      assert(false);
      break;
  }
}

/*
 * memtable flush 结束才能 udisks[meta.lc_id] 置空
 */
void UDiskHandle::SubmitReadLocal(ChunkHandle* handle, 
                                  const IOMeta& meta, 
                                  OpRequest* op) {
  int32_t rc = 0;
  void *read_buf = nullptr;
  MemorySlab *slab = nullptr;
  std::tie(read_buf, slab) = loop_handle_->mem_pool().Malloc(meta.length, kDefaultDevBlockSize);
  assert(read_buf);

  uint32_t pg_id = handle->chunk_id_.pg_id;
  assert(pg_id == op->pg_id());
  auto migrate_task = g_context->migrate_task(pg_id);
  if (g_context->journal_enable() && 
      migrate_task->IsMigrate.load() && 
      migrate_task->udisks[meta.lc_id] != nullptr) { // lc_id正在迁移中
    vector<Interval>& intervals = op->intervals();
    uint64_t seqno = op->op_seq();
    auto journal_engine = loop_handle_->JournalEngine(pg_id);
    assert(journal_engine && journal_engine->IsInit());
    rc = journal_engine->Read(meta, (char* )read_buf, &intervals);
    for (auto& iter : intervals) {
      ULOG_DEBUG << "interval:[" << iter.start << "," << iter.end << "].";
    }
    if (rc == 0) { // 已经获取所有数据,直接调用callback即可.
      ULOG_DEBUG << "Recv all data in memory. seqno=" << seqno << ", meta=" 
          << meta.ToString();
      op->set_read_buffer((char*)read_buf, &loop_handle_->mem_pool(), slab);
      intervals.clear();
      DoLocalAioResponse(pg_id, seqno, meta.length, true);
    } else {
      ULOG_DEBUG << "Not recv all data in memory. seqno=" << seqno << ", meta=" 
          << meta.ToString() << ", intervals_size=" << intervals.size();
      void *mem_buf = nullptr;
      MemorySlab *mem_slab = nullptr;
      std::tie(mem_buf, mem_slab) = loop_handle_->mem_pool().Malloc(meta.length, kDefaultDevBlockSize);
      assert(mem_buf);
      // 这里read_buf里已经有了部分memtable中的数据，交换mem_buf和read_buf，
      // 后续读取磁盘使用read_buf
      std::swap(read_buf, mem_buf);
      std::swap(slab, mem_slab);
      op->set_read_buffer((char*)read_buf, &loop_handle_->mem_pool(), slab);
      op->set_mem_buffer((char*)mem_buf, &loop_handle_->mem_pool(), mem_slab);

      auto args = new AioCbArgs;
      args->loop_handle = loop_handle_;
      args->op_seq = op->op_seq();
      args->pg_id = op->pg_id();
      args->lc_id = lc_id_;
      rc = handle->PRead(read_buf, meta.length, meta.offset, 
          ChunkLoopHandle::LocalAioCb, args);
      if (rc != UDISK_OK) {
        ULOG_ERROR << "Submit Local Read Parent Op: " << op->trace_tag() 
            << " failed," << " rc: " << rc;
        loop_handle_->AddLCIOError(lc_id_, IOErrorContainer::kNormalIOError, 
                                   IOErrorContainer::kIORead); 
        return;
      } 
      //io下发成功，op增引用计数
      op->IncRefs();
      ULOG_TRACE << "Submit Local Read Parent Op: " << op->trace_tag() << 
        ", data=" << values_string((const char*)read_buf, meta.length);
    }
  } else {
    op->set_read_buffer((char*)read_buf, &loop_handle_->mem_pool(), slab);
    auto args = new AioCbArgs;
    args->loop_handle = loop_handle_;
    args->op_seq = op->op_seq();
    args->pg_id = op->pg_id();
    args->lc_id = lc_id_;
    int rc = handle->PRead(read_buf, meta.length, meta.offset, 
                           ChunkLoopHandle::LocalAioCb, args);
    if (rc != UDISK_OK) {
      ULOG_ERROR << "Submit Local Read Parent Op: " << op->trace_tag() 
          << " failed," << " rc: " << rc;
      loop_handle_->AddLCIOError(lc_id_, IOErrorContainer::kNormalIOError, 
                                 IOErrorContainer::kIORead); 
      return;
    }
    //io下发成功，op增引用计数
    op->IncRefs();
    ULOG_TRACE << "Submit Local Read Parent Op: " << op->trace_tag();
  }
}

/*
 * memtable flush 结束才能 udisks[meta.lc_id] 置空
 */
void UDiskHandle::SubmitWriteLocal(ChunkHandle* handle, 
                                   const IOMeta& meta, 
                                   OpRequest* op) {
  int32_t rc = 0;
  const char *msg_data = op->msg_data();
  uint32_t pg_id = handle->chunk_id_.pg_id;
  assert(pg_id == op->pg_id());
  auto migrate_task = g_context->migrate_task(pg_id);
  if (g_context->journal_enable() && 
      migrate_task->IsMigrate.load() && 
      migrate_task->udisks[meta.lc_id] != nullptr) { // lc_id正在迁移中
    uint64_t seqno = op->op_seq();
    uint32_t pg_id = handle->chunk_id_.pg_id;
    auto journal_engine = loop_handle_->JournalEngine(pg_id);
    assert(journal_engine && journal_engine->IsInit());
    ULOG_DEBUG << "journal_write: pg_id=" << pg_id << ", op=" << op->trace_tag();
    rc = journal_engine->Write(meta, msg_data, seqno, op);
    if (rc != 0) {  
      ULOG_ERROR  << "Submit Local Write seqno=" << seqno << " failed,rc:" 
          << rc << ",meta=" << meta.ToString();
      loop_handle_->AddLCIOError(lc_id_, IOErrorContainer::kNormalIOError, 
                                 IOErrorContainer::kIOWrite); 
      return;
    }
  } else {
    auto args = new AioCbArgs;
    args->loop_handle = loop_handle_;
    args->op_seq = op->op_seq();
    args->pg_id = op->pg_id();
    args->lc_id = lc_id_;
    int rc = handle->PWrite((void*)msg_data, meta.length, meta.offset, 
                            ChunkLoopHandle::LocalAioCb, args);
    if (rc != UDISK_OK) {
      ULOG_ERROR  << "Submit Local Write Parent Op: " << op->trace_tag() 
          << " failed," << " rc: " << rc;
      loop_handle_->AddLCIOError(lc_id_, IOErrorContainer::kNormalIOError, 
                                 IOErrorContainer::kIOWrite); 
      return;
    }
  }
  //io下发成功，op增引用计数 
  op->IncRefs();
  ULOG_TRACE << "Submit Local Write Parent Op:" << op->trace_tag()
      << ",value=" << values_string(msg_data, meta.length);
} 

// LocalAioRequest 中可能submit 报错或者获取fd 报错，这里都依赖超时报错，
// 省去IO路径过多的判断返回值的开销
bool UDiskHandle::LocalAioRequest(OpRequest* op) {
  ULOG_TRACE << op->trace_tag();
  const common::MessageHeader *common_hdr = op->msg_hdr();
  op->mark_replica_waiting(0, g_context->config().my_id());
  OpenChunkCb cb = 
      std::bind(&ChunkLoopHandle::OpenChunkResCb, loop_handle_, _1, _2, lc_id_, 
          op->op_seq());
  op->IncRefs();
  switch (common_hdr->msg_type) {
    case common::MSG_GATE_IO_REQ: {
      const common::GateIORequestHead *gate_hdr =
        (const common::GateIORequestHead*)op->sub_msg_hdr_offset();
      bool is_create = true;
      if (gate_hdr->cmd == common::GATE_CMD_READ) {
        is_create = false;
      }

      int32_t ret = loop_handle_->GetChunkStorage()->OpenChunk(
          ChunkID(gate_hdr->pg_id, lc_id_, gate_hdr->pc_no, lc_random_id_),
          is_create, cb);
      ULOG_TRACE << "chunk_id=" << ChunkID(gate_hdr->pg_id, lc_id_, gate_hdr->pc_no, lc_random_id_).to_string();
      // TODO(fangran.fr) check ret with error no
      if (ret == UDISK_OK) {
        ULOG_TRACE << "open chunk: " << FormatGateIOReq(*gate_hdr);
        return true;
      } else if (ret == UDISK_PC_NOT_EXIST_ERROR &&
                 gate_hdr->cmd == common::GATE_CMD_READ) {
        ULOG_DEBUG << "gate read zero, lc_id: " << gate_hdr->lc_id
                   << ", pc_no: " << gate_hdr->pc_no
                   << ", pg_id: " << gate_hdr->pg_id;
        op->DecRefs();
        ReadZeroResponse(op, common::RETCODE_PC_NOT_EXISTS);
        return true;
      } else {
        op->DecRefs();
        // 如果返回为空，则说明文件系统错误，不能开或则创建文件
        // 已经开始等待，等待后面会超时报错
        ULOG_SYSERR << "can't get slice fd, gate req head: "
                    << FormatGateIOReq(*gate_hdr);
        return false;
      }
    }
    case common::MSG_ARK_IO_REQ: {
      const common::ArkIORequestHead *ark_hdr =
        (const common::ArkIORequestHead*)op->sub_msg_hdr_offset();
      if (ark_hdr->cmd == common::ARK_CMD_READ) {
        return ArkReadRequest(op);
      } else {
        int32_t ret = loop_handle_->GetChunkStorage()->OpenChunk(
            ChunkID(ark_hdr->pg_id, lc_id_, ark_hdr->pc_no, lc_random_id_), true, cb);
        if (ret == UDISK_OK) {
          ULOG_TRACE << "open chunk: " << DumpArkReqHead(*ark_hdr);
          return true;
        } else {
          op->DecRefs();
          // 如果返回为空，则说明文件系统错误，不能开或则创建文件
          // 已经开始等待，等待后面会超时报错
          ULOG_SYSERR << "can't get slice fd, gate req head: "
                      << DumpArkReqHead(*ark_hdr);
          return false;
        }
      }
    }
    case common::MSG_CHUNK_IO_REQ: {
      const common::ChunkIORequestHead *chunk_hdr =
        (const common::ChunkIORequestHead*)op->sub_msg_hdr_offset();
      int32_t ret = loop_handle_->GetChunkStorage()->OpenChunk(
          ChunkID(chunk_hdr->pg_id, lc_id_, chunk_hdr->pc_no, lc_random_id_), true, cb);
      if (ret == UDISK_OK) {
        ULOG_TRACE << "open chunk, " << FormatChunkIOReq(*chunk_hdr);
        return true;
      } else {
        op->DecRefs();
        // 如果返回为空，则说明文件系统错误，不能打开或则创建文件
        // 已经开始等待，等待后面会超时报错
        ULOG_ERROR << "can't get slice fd, chunk req head: "
                  << FormatChunkIOReq(*chunk_hdr);
        return false;
      }
    }
    case common::MSG_MIGRATE_JOURNAL_REQ: {
      const common::MigrateHead *chunk_hdr =
        (const common::MigrateHead*)op->sub_msg_hdr_offset();
      int32_t ret = loop_handle_->GetChunkStorage()->OpenChunk(
          ChunkID(chunk_hdr->pg_id, lc_id_, chunk_hdr->pc_no, lc_random_id_), 
          true, 
          cb);
      ULOG_TRACE << "chunk_id=" << ChunkID(chunk_hdr->pg_id, lc_id_, chunk_hdr->pc_no, lc_random_id_).to_string();
      if (ret == UDISK_OK) {
        ULOG_TRACE << "open chunk, " << DumpMigrateHead(*chunk_hdr);
        return true;
      } else {
        op->DecRefs();
        // 如果返回为空，则说明文件系统错误，不能打开或则创建文件
        // 已经开始等待，等待后面会超时报错
        ULOG_ERROR << "can't get slice fd, chunk req head: "
                  << DumpMigrateHead(*chunk_hdr);
        return false;
      }
    }
    // Hela
    case common::MSG_HELA_CHUNK_REQ: {
      const common::HelaChunkRequestHead *hela_hdr =
        (const common::HelaChunkRequestHead*)op->sub_msg_hdr_offset();
      int32_t ret = loop_handle_->GetChunkStorage()->OpenChunk(
          ChunkID(hela_hdr->pg_id, lc_id_, hela_hdr->pc_no, lc_random_id_), true, cb);
      if (ret == UDISK_OK) {
        ULOG_TRACE << "open chunk, " << DumpHelaReqHead(*hela_hdr);
        //if (hela_hdr->cmd == common::HELA_CMD_READ) {
        //  SubmitReadLocal(handle, hela_hdr->offset, hela_hdr->length, op);
        //} else {
        //  SubmitWriteLocal(handle, hela_hdr->offset, hela_hdr->length, op);
        //}
        return true;
      } else {
        op->DecRefs();
        // 如果返回为空，则说明文件系统错误，不能开或则创建文件
        // 已经开始等待，等待后面会超时报错
        ULOG_SYSERR << "can't get slice fd, hela req head: "
                    << DumpHelaReqHead(*hela_hdr);
        return false;
      }
    }
    default:
      ULOG_ERROR << "unkonw msg_type: " << common_hdr->msg_type;
      break;
  }
  op->DecRefs();
  return false;
}

bool UDiskHandle::ArkReadRequest(OpRequest* op) {
  const common::ArkIORequestHead *ark_hdr =
      (const common::ArkIORequestHead*)op->sub_msg_hdr_offset();
  OpenChunkCb cb = std::bind(&ChunkLoopHandle::OpenChunkResCb, loop_handle_,
                       std::placeholders::_1, std::placeholders::_2, lc_id_,
                         op->op_seq());
  assert(ark_hdr->cmd == common::ARK_CMD_READ);
  int32_t ret = loop_handle_->GetChunkStorage()->OpenChunk(
      ChunkID(ark_hdr->pg_id, lc_id_, ark_hdr->pc_no, lc_random_id_), false, cb);
  if (ret == UDISK_OK) {
    ULOG_TRACE << "open chunk, " << DumpArkReqHead(*ark_hdr);
    return true;
  } else if (ret == UDISK_PC_NOT_EXIST_ERROR) {
    op->DecRefs();
    ULOG_INFO << "ark read zero, lc_id: " << ark_hdr->lc_id
             << ", pc_no: " << ark_hdr->pc_no
             << ", pg_id: " << ark_hdr->pg_id;
    ReadZeroResponse(op, common::RETCODE_PC_NOT_EXISTS);
    return true;
  } else {
    op->DecRefs();
    // 如果返回为空，则说明文件系统错误，不能开或则创建文件
    // 已经开始等待，等待后面会超时报错
    ULOG_SYSERR << "can't get slice fd, gate req head: "
              << DumpArkReqHead(*ark_hdr);
    return false;
  }
}

void UDiskHandle::BuildChunkRequestWithGateReq(const common::MessageHeader &src_common_hdr,
                                    common::MessageHeader *dst_common_hdr,
                                    const common::GateIORequestHead &gate_req,
                                    common::ChunkIORequestHead *chunk_req,
                                    uint64_t op_seq,
                                    uint8_t replica_no) {
  dst_common_hdr->msg_type = common::MSG_CHUNK_IO_REQ;
  // ChunkIORequestHead + data
  dst_common_hdr->data_len = sizeof(common::ChunkIORequestHead) + gate_req.size;
  dst_common_hdr->version = src_common_hdr.version;

  chunk_req->size = gate_req.size;
  chunk_req->version = gate_req.version;
  if (gate_req.cmd == common::GATE_CMD_READ) {
    chunk_req->cmd = common::CHUNK_CMD_READ;
  } else if (gate_req.cmd == common::GATE_CMD_WRITE) {
    chunk_req->cmd = common::CHUNK_CMD_WRITE;
  } else {
    chunk_req->cmd = common::CHUNK_CMD_NOP;
  }
  chunk_req->flowno = op_seq;
  chunk_req->replica_no = replica_no;
  chunk_req->offset = gate_req.offset;
  chunk_req->length = gate_req.length;
  chunk_req->lc_id = gate_req.lc_id;
  chunk_req->lc_random_id = gate_req.lc_random_id;
  chunk_req->lc_size = gate_req.lc_size;
  chunk_req->pc_no = gate_req.pc_no;
  chunk_req->pg_id = gate_req.pg_id;
  chunk_req->route_version = gate_req.route_version;
  chunk_req->reserved1 = 0;
  chunk_req->reserved2 = 0;
  chunk_req->magic = gate_req.magic;
}

void UDiskHandle::BuildChunkRequestWithArkReq(const common::MessageHeader &src_common_hdr,
                                    common::MessageHeader *dst_common_hdr,
                                    const common::ArkIORequestHead &ark_req,
                                    common::ChunkIORequestHead *chunk_req,
                                    uint64_t op_seq,
                                    uint8_t replica_no) {
  dst_common_hdr->msg_type = common::MSG_CHUNK_IO_REQ;
  // ChunkIORequestHead + data
  dst_common_hdr->data_len = sizeof(common::ChunkIORequestHead) + ark_req.size;
  dst_common_hdr->version = src_common_hdr.version;

  chunk_req->size = ark_req.size;
  chunk_req->version = ark_req.version;
  if (ark_req.cmd == common::GATE_CMD_READ) {
    chunk_req->cmd = common::CHUNK_CMD_READ;
  } else if (ark_req.cmd == common::GATE_CMD_WRITE) {
    chunk_req->cmd = common::CHUNK_CMD_WRITE;
  } else {
    chunk_req->cmd = common::CHUNK_CMD_NOP;
  }
  chunk_req->flowno = op_seq;
  chunk_req->replica_no = replica_no;
  chunk_req->offset = ark_req.offset;
  chunk_req->length = ark_req.length;
  chunk_req->lc_id = ark_req.lc_id;
  chunk_req->lc_random_id = ark_req.lc_random_id;
  chunk_req->lc_size = ark_req.lc_size;
  chunk_req->pc_no = ark_req.pc_no;
  chunk_req->pg_id = ark_req.pg_id;
  chunk_req->route_version = ark_req.route_version;
  chunk_req->reserved1 = 0;
  chunk_req->reserved2 = 0;
  chunk_req->magic = ark_req.magic;
}

void UDiskHandle::BuildChunkRequestWithMigrateReq(
                                    const common::MessageHeader &src_common_hdr,
                                    common::MessageHeader *dst_common_hdr,
                                    const common::MigrateHead &migrate_req,
                                    common::ChunkIORequestHead *chunk_req,
                                    uint64_t op_seq,
                                    uint8_t replica_no) {
  dst_common_hdr->msg_type = common::MSG_CHUNK_IO_REQ;
  // ChunkIORequestHead + data
  dst_common_hdr->data_len = sizeof(common::ChunkIORequestHead) + migrate_req.size;
  dst_common_hdr->version = src_common_hdr.version;

  chunk_req->size = migrate_req.size;
  chunk_req->version = migrate_req.version;
  assert(migrate_req.cmd == common::MIGRATE_CMD_JOURNAL ||
      migrate_req.cmd == common::MIGRATE_CMD_MEMTABLE ||
      migrate_req.cmd == common::MIGRATE_CMD_DUALWRITE ||
      migrate_req.cmd == common::MIGRATE_CMD_PC_WRITE);
  chunk_req->cmd = common::CHUNK_CMD_WRITE; // migrate只有写
  chunk_req->flowno = op_seq;
  chunk_req->replica_no = replica_no;
  chunk_req->offset = migrate_req.offset;
  chunk_req->length = migrate_req.length;
  chunk_req->lc_id = migrate_req.lc_id;
  chunk_req->lc_random_id = migrate_req.lc_random_id;
  chunk_req->lc_size = migrate_req.lc_size;
  chunk_req->pc_no = migrate_req.pc_no;
  chunk_req->pg_id = migrate_req.pg_id;
  chunk_req->route_version = migrate_req.route_version;
  chunk_req->reserved1 = 0;
  chunk_req->reserved2 = 0;
  chunk_req->magic = migrate_req.magic;
}

bool UDiskHandle::ProcessMigrateJournalRequest(OpRequest* op) {
  inuse_flag_ = true;
  const common::MigrateHead* chunk_hdr =
    (const common::MigrateHead*)op->sub_msg_hdr_offset();
  if (UNLIKELY(!loop_handle_->cluster_map().IsInit())) {
    ULOG_ERROR << "cluster_map not inited, chunk not ready";
    op->set_retcode(0, common::RETCODE_CHUNK_NOT_READY);
    AckChunkIORequest(op);
    return false;
  }
  if (UNLIKELY(chunk_hdr->route_version !=
      loop_handle_->cluster_map().GetClusterVersion())) {
    ULOG_ERROR << "chunk cluster version " << cluster_map().GetClusterVersion()
              << " != chunk io version " << chunk_hdr->route_version; 
    op->set_retcode(0, common::RETCODE_CLUSTER_VERSION_ERR);
    AckChunkIORequest(op);
    return false;
  }
  //通知主chunk断开连接
  if (UNLIKELY(reset_flag_)) {
    ULOG_INFO << "connection reset for chunk, lc: " << lc_id_
             << " in thread: " <<  std::string(base::CurrentThread::name());
    op->set_retcode(0, common::RETCODE_RESET_CONNECTION);
    AckChunkIORequest(op);
    reset_flag_ = false; //生效一次后要清除, 否则可能会一直拒绝连接
    return false;
  }

  OpEnqueue(op);
  return true;
}

void UDiskHandle::BuildChunkRequestWithHelaReq(const common::MessageHeader &src_common_hdr,
                                    common::MessageHeader *dst_common_hdr,
                                    const common::HelaChunkRequestHead &hela_req,
                                    common::ChunkIORequestHead *chunk_req,
                                    uint64_t op_seq,
                                    uint8_t replica_no) {
  dst_common_hdr->msg_type = common::MSG_CHUNK_IO_REQ;
  // ChunkIORequestHead + data
  dst_common_hdr->data_len = sizeof(common::ChunkIORequestHead) + hela_req.size;
  dst_common_hdr->version = src_common_hdr.version;

  chunk_req->size = hela_req.size;
  chunk_req->version = hela_req.version;
  if (hela_req.cmd == common::HELA_CMD_READ) {
    chunk_req->cmd = common::CHUNK_CMD_READ;
  } else if (hela_req.cmd == common::HELA_CMD_WRITE) {
    chunk_req->cmd = common::CHUNK_CMD_WRITE;
  } else {
    chunk_req->cmd = common::CHUNK_CMD_NOP;
  }
  chunk_req->flowno = op_seq;
  chunk_req->replica_no = replica_no;
  chunk_req->offset = hela_req.offset;
  chunk_req->length = hela_req.length;
  chunk_req->lc_id = hela_req.lc_id;
  chunk_req->lc_random_id = hela_req.lc_random_id;
  chunk_req->lc_size = hela_req.lc_size;
  chunk_req->pc_no = hela_req.pc_no;
  chunk_req->pg_id = hela_req.pg_id;
  chunk_req->route_version = hela_req.route_version;
  chunk_req->reserved1 = 0;
  chunk_req->reserved2 = 0;
  chunk_req->magic = hela_req.magic;
}

bool UDiskHandle::DoChunkOpRequest(OpRequest* op) {
  inuse_flag_ = true;
  const common::ChunkIORequestHead* chunk_hdr =
    (const common::ChunkIORequestHead*)op->sub_msg_hdr_offset();
  if (UNLIKELY(!loop_handle_->cluster_map().IsInit())) {
    ULOG_ERROR << "cluster_map not inited, chunk not ready";
    op->set_retcode(0, common::RETCODE_CHUNK_NOT_READY);
    AckChunkIORequest(op);
    return false;
  }
  if (UNLIKELY(chunk_hdr->route_version !=
      loop_handle_->cluster_map().GetClusterVersion())) {
    ULOG_ERROR << "chunk cluster version " << cluster_map().GetClusterVersion()
              << " != chunk io version " << chunk_hdr->route_version;
    op->set_retcode(0, common::RETCODE_CLUSTER_VERSION_ERR);
    AckChunkIORequest(op);
    return false;
  }
  //通知主chunk断开连接
  if (UNLIKELY(reset_flag_)) {
    ULOG_INFO << "connection reset for chunk, lc: " << lc_id_
             << " in thread: " <<  std::string(base::CurrentThread::name());
    op->set_retcode(0, common::RETCODE_RESET_CONNECTION);
    AckChunkIORequest(op);
    reset_flag_ = false; //生效一次后要清除, 否则可能会一直拒绝连接
    return false;
  }

  OpEnqueue(op);
  return true;
}

void UDiskHandle::DispatchChunkRequest(OpRequest* op) {
  const common::ChunkIORequestHead* chunk_hdr =
    (const common::ChunkIORequestHead*)op->sub_msg_hdr_offset();
  switch (chunk_hdr->cmd) {
    case common::CHUNK_CMD_READ:
    case common::CHUNK_CMD_WRITE:
      // hack chunk write request if repairing.
      ULOG_TRACE << "Recv Chunk Request. req=" << FormatChunkIOReq(*chunk_hdr);
      if (UNLIKELY(repair_pcs_.size() > 0)) {
        auto it = repair_pcs_.find(chunk_hdr->pc_no);
        if (it != repair_pcs_.end()) {
          // 修复过程中需要保证gate端IO大小不能超过TinyPC大小
          // 目前默认大小为1MB
          assert(chunk_hdr->length <= CHUNK_REPAIR_TINYPC_SIZE);
          if (it->second->PCNeedRepair(chunk_hdr->offset)) {// pending 请求到内存
            it->second->Insert(chunk_hdr->offset, chunk_hdr->length, op->msg_data());
            ULOG_TRACE << "Pending req in buffer, req=" << FormatChunkIOReq(*chunk_hdr);
            EndChunkIORequest(op);
            return;
          }
        }
      }
      LocalAioRequest(op);
      break;
    default:
      // ignore this request
      ULOG_ERROR << "Msg Type: "
               << common::msg_type_name(common::MSG_CHUNK_IO_REQ)
               << " Sub Cmd: " << common::chunk_cmd_name(chunk_hdr->cmd)
               << " can not handle, ignore!";
      break;
  }
}
void UDiskHandle::DoChunkResponse(const common::ChunkIOResponseHead* hdr) {
  ULOG_TRACE <<"get a chunk res, flowno: " << hdr->flowno;
  auto found = inflying_list_.find(std::make_pair(hdr->pg_id, hdr->flowno));
  if (found != inflying_list_.end()) {
    OpRequest* op = found->second;
    uint32_t chunk_id = op->GetChunkId(hdr->replica_no);
    ULOG_TRACE << common::msg_type_name(common::MSG_CHUNK_IO_RES)
              << " Sub Cmd: " << common::chunk_cmd_name(hdr->cmd)
              << " replica_no: " << (uint32_t)hdr->replica_no
              << " from chunk " << chunk_id
              << " parent op: " << op->trace_tag();
    // 本地io未返回但该请求已超时，所以仍然在inflying list
    if (op->timeout()) {
      ULOG_ERROR << "Get a Msg Type: "
            << common::msg_type_name(common::MSG_CHUNK_IO_RES)
            << " Sub Cmd: " << common::chunk_cmd_name(hdr->cmd)
            << " op_seq: " << hdr->flowno
            << ", this op_seq timeout,Ignore!";
      return;
    }
    bool finished = op->mark_replica_received(
        hdr->replica_no, hdr->retcode);
    ULOG_DEBUG << "replica_no=" << hdr->replica_no << ", finish=" << finished;
    if (finished) {
      // 需要Chunk转发的可能是gate或ark的io
      EndIORequest(op);
    }
    // 需要主动断开连接, 由于这个错误码也返回给了gate,
    // gate 会主动断开连接，并重试这个连接上的所有IO
    // 所以这里不断开连接，因为连接是共用的，会使别的盘
    // 也会超时。
    if (hdr->retcode == common::RETCODE_RESET_CONNECTION) {
      ULOG_INFO << "connection from gate will be closed";
      return;
    }
    if (hdr->retcode) {
      g_context->manager_handle()->ReportChunkFailure(chunk_id, hdr->retcode);
    }
    return;
  }
  ULOG_ERROR << "Get a Msg Type: "
            << common::msg_type_name(common::MSG_CHUNK_IO_RES)
            << " Sub Cmd: " << common::chunk_cmd_name(hdr->cmd)
            << " op_seq: " << hdr->flowno
            << ", can't find this op_seq in inflying list,Ignore!";
}

void UDiskHandle::DoLocalAioResponse(uint32_t pg_id, 
                                     uint64_t op_seq,
                                     int32_t retcode, 
                                     bool sync) {
  int32_t x_retcode = 0; // 返回给gate或者chunk的retcode
  auto found = inflying_list_.find(std::make_pair(pg_id, op_seq));
  if (found == inflying_list_.end()) {
    ULOG_ERROR << "local aio response, op_seq: " << op_seq
        << ", can't find this op_seq in inflying list,Ignore!";
    return;
  }
  OpRequest* op = found->second;
  ULOG_TRACE << "local aio response, parent op:" << op->trace_tag() 
      << ", retcode=" << retcode << ", op_seq=" << op_seq;
  // journal写模式下，会增加一些header封装，会比原始数据大
  int32_t journal_enable = g_context->config().journal_enable();
  if ((!journal_enable && retcode != (int)op->data_len()) || 
      (journal_enable && retcode < (int)op->data_len())) {
    ULOG_SYSERR << "libaio error retcode=" << retcode << ",journal=" << journal_enable
                << ", data_len=" << op->data_len() << op->trace_tag();
    if (journal_enable && retcode == IOErrorContainer::kJournalIOTimeout) {
      // journal超时暂时不上报aio error
      ULOG_ERROR << "Journal Timeout, not response. op=" << op->trace_tag();
      if (op->DecRefs()) { // op已经超时了
        ULOG_ERROR << "local aio response timeout, op_seq: " << op_seq;
        inflying_list_.erase(found);
        DispatchPendingIO();
      } else { // 没有超时情况下，模拟op超时返回
        op->TimeoutCb();
        EndIORequest(op); // IO 超时后需要返回
      }
      return;
    } else {
      IOErrorContainer::IO_OP_TYPE type = (op->cmd() == 0) ?
          IOErrorContainer::kIORead : IOErrorContainer::kIOWrite; 
      loop_handle_->AddLCIOError(lc_id_, IOErrorContainer::kNormalIOError, type); 
      uint32_t chunk_id = op->GetChunkId(0);
      x_retcode = common::RETCODE_AIO_ERR;
      g_context->manager_handle()->ReportChunkFailure(chunk_id, x_retcode);
    }
  }
  bool finished = op->mark_replica_received(0, x_retcode);
  // 引用减为0，说明io已超时(journal模式部分情况同步返回,没有bind op的read_buffer)
  if (!sync && op->DecRefs()) {
    ULOG_ERROR << "local aio response timeout, op_seq: " << op_seq;
    inflying_list_.erase(found);
    DispatchPendingIO();
    return;
  }
  if (finished) { // 这个io请求所有的副本都完成了
    // journal模式，用内存中数据覆盖磁盘
    std::vector<Interval>& intervals = op->intervals();
    char* read_buffer = op->mutable_read_buffer();
    const char* mem_buffer = op->mem_buffer();
    for (auto iter : intervals) {
      memcpy(&read_buffer[iter.start], &mem_buffer[iter.start], 
          iter.end - iter.start);
    }
    if (read_buffer) {
      ULOG_DEBUG << "data=" << values_string((const char*)read_buffer, op->data_len()) 
          << ",trace=" << op->trace_tag();
    }
    EndIORequest(op);
  }
}

void UDiskHandle::DoOpenChunkResCb(uint64_t op_seq, int32_t retcode,
                                     ChunkHandle* handle) {
  auto found = inflying_list_.find(std::make_pair(handle->chunk_id_.pg_id, op_seq));
  if (found == inflying_list_.end()) {
    ULOG_ERROR << "openchunk response, op_seq: " << op_seq
            << ", can't find this op_seq in inflying list,Ignore!";
    return;
  }
  OpRequest* op = found->second;
  ULOG_TRACE << "open chunk response, parent op:" << op->trace_tag();
  // 引用减为0，说明io已超时
  if (op->DecRefs()) {
    ULOG_ERROR << "openchunk response timeout, op_seq: " << op_seq;
    inflying_list_.erase(found);
    DispatchPendingIO();
    return;
  }
  const common::MessageHeader *common_hdr = op->msg_hdr();
  switch (common_hdr->msg_type) {
    case common::MSG_GATE_IO_REQ: {
      const common::GateIORequestHead *gate_hdr =
        (const common::GateIORequestHead*)op->sub_msg_hdr_offset();
      if (handle == nullptr || retcode != UDISK_OK) {
        // 如果返回为空，则说明文件系统错误，不能开或则创建文件
        // 已经开始等待，等待后面会超时报错
        ULOG_SYSERR << "can't get slice fd, gate req head: "
                   << FormatGateIOReq(*gate_hdr);
        return;
      }
      IOMeta iometa = 
          {lc_id_, lc_random_id_, gate_hdr->pc_no, gate_hdr->offset, gate_hdr->length};
      if (gate_hdr->cmd == common::GATE_CMD_READ) {
        SubmitReadLocal(handle, iometa, op);
      } else {
        SubmitWriteLocal(handle, iometa, op);
      }
      return;
    }
    case common::MSG_ARK_IO_REQ: {
      const common::ArkIORequestHead *ark_hdr =
        (const common::ArkIORequestHead*)op->sub_msg_hdr_offset();
      IOMeta iometa = 
          {lc_id_, lc_random_id_, ark_hdr->pc_no, ark_hdr->offset, ark_hdr->length};
      if (ark_hdr->cmd == common::ARK_CMD_READ) {
        if (handle != nullptr && retcode == UDISK_OK) {
          SubmitReadLocal(handle, iometa, op);
        } else if (retcode == UDISK_PC_NOT_EXIST_ERROR) {
          ULOG_INFO << "ark read zero, lc_id: " << ark_hdr->lc_id
                   << ", pc_no: " << ark_hdr->pc_no
                   << ", pg_id: " << ark_hdr->pg_id;
          ReadZeroResponse(op, common::RETCODE_PC_NOT_EXISTS);
        } else {
          // 如果返回为空，则说明文件系统错误，不能开或则创建文件
          // 已经开始等待，等待后面会超时报错
          ULOG_SYSERR << "can't get slice fd, gate req head: "
                    << DumpArkReqHead(*ark_hdr);
        }
      } else {
        if (handle != nullptr && retcode == UDISK_OK) {
          SubmitWriteLocal(handle, iometa, op);
        } else {
          // 如果返回为空，则说明文件系统错误，不能开或则创建文件
          // 已经开始等待，等待后面会超时报错
          ULOG_SYSERR << "can't get slice fd, gate req head: "
                    << DumpArkReqHead(*ark_hdr);
        }
      }
      return;
    }
    case common::MSG_HELA_CHUNK_REQ: {
      const common::HelaChunkRequestHead *hela_hdr =
        (const common::HelaChunkRequestHead*)op->sub_msg_hdr_offset();
      IOMeta iometa = 
          {lc_id_, lc_random_id_, hela_hdr->pc_no, hela_hdr->offset, hela_hdr->length};
      if (handle != nullptr && retcode == UDISK_OK) {
        if (hela_hdr->cmd == common::HELA_CMD_READ) {
          SubmitReadLocal(handle, iometa, op);
        } else {
          SubmitWriteLocal(handle, iometa, op);
        }
        return;
      } else {
        // 如果返回为空，则说明文件系统错误，不能打开或则创建文件
        // 已经开始等待，等待后面会超时报错
        ULOG_ERROR << "can't get slice fd, hela req head: "
                   << DumpHelaReqHead(*hela_hdr);
        return;
      }
    }
    case common::MSG_CHUNK_IO_REQ: {
      const common::ChunkIORequestHead *chunk_hdr =
        (const common::ChunkIORequestHead*)op->sub_msg_hdr_offset();
      if (handle == nullptr || retcode != UDISK_OK) {
        // 如果返回为空，则说明文件系统错误，不能打开或则创建文件
        // 已经开始等待，等待后面会超时报错
        ULOG_ERROR << "can't get slice fd, chunk req head: "
                  << FormatChunkIOReq(*chunk_hdr);
        return;
      }
      IOMeta iometa = 
          {lc_id_, lc_random_id_, chunk_hdr->pc_no, chunk_hdr->offset, chunk_hdr->length};
      if (chunk_hdr->cmd == common::CHUNK_CMD_READ) {
        SubmitReadLocal(handle, iometa, op);
      } else {
        SubmitWriteLocal(handle, iometa, op);
      }
      return;
    }
    case common::MSG_MIGRATE_JOURNAL_REQ: {
      const common::MigrateHead *chunk_hdr =
        (const common::MigrateHead*)op->sub_msg_hdr_offset();
      if (handle == nullptr || retcode != UDISK_OK) {
        // 如果返回为空，则说明文件系统错误，不能打开或则创建文件
        // 已经开始等待，等待后面会超时报错
        ULOG_ERROR << "can't get slice fd, chunk req head: "
                  << DumpMigrateHead(*chunk_hdr);
        return;
      }
      IOMeta iometa = 
          {lc_id_, lc_random_id_, chunk_hdr->pc_no, chunk_hdr->offset, chunk_hdr->length};
      SubmitWriteLocal(handle, iometa, op);
      return;
    }
    default:
      ULOG_ERROR << "unkonw msg_type: " << common_hdr->msg_type;
      break;
  }

  ULOG_ERROR << "openchunk response, op_seq: " << op_seq
             << ", can't find this op_seq in inflying list,Ignore!";
}

void UDiskHandle::ReadZeroResponse(OpRequest* op, int32_t retcode) {
  assert(retcode == common::RETCODE_PC_NOT_EXISTS);
  ULOG_TRACE << "local aio response, parent op: "
            << op->trace_tag();
  bool finished = op->mark_replica_received(0, retcode);
  if (!finished) {
    ULOG_ERROR << "abnormal read op, " << op->trace_tag();
    return;
  }
  EndIORequest(op);
  return;
}

void UDiskHandle::AckArkIORequest(OpRequest* op) {
  const common::MessageHeader* src_common_hdr = op->msg_hdr();
  auto src_ark_hdr = (const common::ArkIORequestHead*)op->sub_msg_hdr_offset();
  UsockAddress addr(op->conn()->GetPeerAddress().ToIpString(), src_ark_hdr->res_port, false);
  uevent::ConnectionUeventPtr connection = loop_handle_->GetArkConnection(addr);
  if (!connection) {
    ULOG_ERROR << "Ack Ark Op: " << op->op_seq()
              << " ark req flowno: " << src_ark_hdr->flowno
              << " with retcode: " << op->retcode()
              << " error, the response connection has closed";
    return;
  }
  constexpr size_t msg_hdr_len = sizeof(common::MessageHeader)
      + sizeof(common::ArkIOResponseHead);
  char msg_hdr[msg_hdr_len];
  auto dst_common_hdr = (common::MessageHeader*)msg_hdr;
  auto dst_ark_hdr = (common::ArkIOResponseHead*)(dst_common_hdr->next_header);
  size_t data_len = 0;
  if (src_ark_hdr->cmd == common::GATE_CMD_READ && !op->retcode()) {
    data_len = src_ark_hdr->length;
  }
  BuildArkResponse(op->retcode(), *src_common_hdr, dst_common_hdr, *src_ark_hdr, dst_ark_hdr, data_len);
  int rc = connection->SendData(msg_hdr, msg_hdr_len);
  if (rc) {
    ULOG_ERROR << "Ack Ark Op: " << op->op_seq() << " failed, retcode: " << rc;
  }
  if (data_len && op->read_buffer()) {
    rc = connection->SendData(op->read_buffer(), data_len);
    if (rc) {
      ULOG_ERROR << "Ack Ark Op: " << op->op_seq() << " failed, retcode: " << rc;
    }
  }
  ULOG_TRACE << "Ack Ark Op: " << op->op_seq()
            << "ark req flowno: " << src_ark_hdr->flowno
            << " with retcode: " << op->retcode();
  return;
}

void UDiskHandle::AckGateIORequest(OpRequest* op) {
  const common::MessageHeader* src_common_hdr = op->msg_hdr();
  auto src_gate_hdr = (const common::GateIORequestHead*)op->sub_msg_hdr_offset();
  const ConnectionUeventPtr& connection = op->conn();
  if (connection->IsClosed()) {
    ULOG_ERROR << "Ack Gate Op: " << op->op_seq()
              << "gate req flowno: " << src_gate_hdr->flowno
              << " with retcode: " <<op->retcode()
              << " error, the response connection has closed";
    return;
  }
  constexpr size_t msg_hdr_len = sizeof(common::MessageHeader)
      + sizeof(common::GateIOResponseHead);
  char msg_hdr[msg_hdr_len];
  auto dst_common_hdr = (common::MessageHeader*)msg_hdr;
  auto dst_gate_hdr = (common::GateIOResponseHead*)(dst_common_hdr->next_header);
  size_t data_len = 0;
  if (src_gate_hdr->cmd == common::GATE_CMD_READ && !op->retcode()) {
    data_len = src_gate_hdr->length;
  }
  BuildGateResponse(op->retcode(), *src_common_hdr, dst_common_hdr, *src_gate_hdr, dst_gate_hdr, data_len);
  int rc = connection->SendData(msg_hdr, msg_hdr_len);
  if (rc) {
    ULOG_ERROR << "Ack Gate Op: " << op->op_seq() << " failed, retcode: " << rc;
  }
  if (data_len && op->read_buffer()) {
    rc = connection->SendData(op->read_buffer(), data_len);
    if (rc) {
      ULOG_ERROR << "Ack Gate Op: " << op->op_seq() << " failed, retcode: " << rc;
    }
  }
  ULOG_TRACE << "Ack Gate Op: " << op->op_seq()
            << "gate req flowno: " << src_gate_hdr->flowno
            << " with retcode: " << op->retcode();
}

void UDiskHandle::EndGateIORequest(OpRequest* op) {
  // 性能统计
  GateIOCount(op);

  AckGateIORequest(op);
  uint64_t op_seq = op->op_seq();
  uint32_t pg_id = op->pg_id();
  if (op->DecRefs()) {
    inflying_list_.erase(std::make_pair(pg_id, op_seq));
  }

  DispatchPendingIO();
}

void UDiskHandle::GateIOCount(OpRequest *op) {
  const common::GateIORequestHead* src_gate_hdr =
    (const common::GateIORequestHead*)op->sub_msg_hdr_offset();
  // 性能统计
  if (src_gate_hdr->cmd == common::GATE_CMD_READ) {
    r_io_count_++;
    r_io_bytes_ += src_gate_hdr->length;
    r_io_latency_ = op->latency();
    r_aio_latency_ = op->aio_latency();
  } else if (src_gate_hdr->cmd == common::GATE_CMD_WRITE) {
    w_io_count_++;
    w_io_bytes_ += src_gate_hdr->length;
    w_io_latency_ = op->latency();
    w_aio_latency_ = op->aio_latency();
    w_rep_latency_ = op->rep_latency();
  }
}

void UDiskHandle::EndArkIORequest(OpRequest* op) {
  // 性能统计
  ArkIOCount(op);

  AckArkIORequest(op);
  uint64_t op_seq = op->op_seq();
  uint32_t pg_id = op->pg_id();
  if (op->DecRefs()) {
    inflying_list_.erase(std::make_pair(pg_id, op_seq));
  }

  DispatchPendingIO();
}

void UDiskHandle::ArkIOCount(OpRequest *op) {
  const common::ArkIORequestHead* src_ark_hdr =
    (const common::ArkIORequestHead*)op->sub_msg_hdr_offset();
  // 性能统计
  if (src_ark_hdr->cmd == common::ARK_CMD_READ) {
    r_io_count_++;
    r_io_bytes_ += src_ark_hdr->length;
    r_io_latency_ = op->latency();
    r_aio_latency_ = op->aio_latency();
  } else if (src_ark_hdr->cmd == common::ARK_CMD_WRITE) {
    w_io_count_++;
    w_io_bytes_ += src_ark_hdr->length;
    w_io_latency_ = op->latency();
    w_aio_latency_ = op->aio_latency();
    w_rep_latency_ = op->rep_latency();
  }
}

void UDiskHandle::AckChunkIORequest(OpRequest* op) {
  const common::MessageHeader *src_common_hdr = op->msg_hdr();
  auto src_chunk_hdr =
      (const common::ChunkIORequestHead*)op->sub_msg_hdr_offset();
  const uevent::ConnectionUeventPtr& connection = op->conn();
  if (connection->IsClosed()) {
    ULOG_ERROR << "Ack Chunk Op: " << op->op_seq()
              << "chunk req flowno: " << src_chunk_hdr->flowno
              << " with retcode: " <<op->retcode()
              << " error, the response connection has closed";
    return;
  }
  constexpr size_t msg_hdr_len = sizeof(common::MessageHeader)
      + sizeof(common::ChunkIOResponseHead);
  char msg_hdr[msg_hdr_len];
  auto dst_common_hdr = (common::MessageHeader*)msg_hdr;
  auto dst_chunk_hdr = (common::ChunkIOResponseHead*)(dst_common_hdr->next_header);
  // 目前不可能从Secondary chunk 读数据
  size_t data_len = 0;
  if (src_chunk_hdr->cmd == common::CHUNK_CMD_READ && !op->retcode()) {
    data_len = src_chunk_hdr->length;
    assert(data_len == 0);
  }
  BuildChunkResponse(op->retcode(), *src_common_hdr, dst_common_hdr,
      *src_chunk_hdr, dst_chunk_hdr, data_len);
  int rc = connection->SendData(msg_hdr, msg_hdr_len);
  if (rc) {
    ULOG_ERROR << "Ack Chunk Op: " << op->op_seq() << " failed, retcode: " << rc;
  }
  //FIXME lizhou.gao data_len will always be zero, this piece of dead code should remove.
  if (data_len && op->read_buffer()) {
    rc = connection->SendData(op->read_buffer(), data_len);
    if (rc) {
      ULOG_ERROR << "Ack Chunk Op: " << op->op_seq() << " failed, retcode: " << rc;
    }
  }
  ULOG_TRACE << "Ack Chunk Op: " << op->op_seq()
            << "chunk req flowno: " << src_chunk_hdr->flowno
            << " with retcode: " << op->retcode();
}

void UDiskHandle::AckMigrateJournalRequest(OpRequest* op) {
  const common::MessageHeader *src_common_hdr = op->msg_hdr();
  auto src_migrate_hdr =
      (const common::MigrateHead*)op->sub_msg_hdr_offset();
  const uevent::ConnectionUeventPtr& connection = op->conn();
  if (connection->IsClosed()) {
    ULOG_ERROR << "Ack Chunk Op: " << op->op_seq()
              << "chunk req flowno: " << src_migrate_hdr->flowno
              << " with retcode: " <<op->retcode()
              << " error, the response connection has closed";
    return;
  }
  constexpr size_t msg_hdr_len = sizeof(common::MessageHeader)
      + sizeof(common::MigrateHead);
  char msg_hdr[msg_hdr_len];
  auto dst_common_hdr = (common::MessageHeader*)msg_hdr;
  auto dst_migrate_hdr = (common::MigrateHead*)(dst_common_hdr->next_header);
  // 迁移目的journal只能是写数据
  BuildMigrateJournalRemoteResponse(op->retcode(), 
                              *src_common_hdr, 
                              dst_common_hdr,
                              *src_migrate_hdr, 
                              dst_migrate_hdr);
  int rc = connection->SendData(msg_hdr, msg_hdr_len);
  if (rc) {
    ULOG_ERROR << "Ack Chunk Op: " << op->op_seq() << " failed, retcode: " << rc;
  }
  ULOG_TRACE << "Ack Chunk Op: " << op->op_seq()
            << "chunk req flowno: " << src_migrate_hdr->flowno
            << " with retcode: " << op->retcode();
}

void UDiskHandle::EndChunkIORequest(OpRequest* op) {
  ChunkIOCount(op);
  AckChunkIORequest(op);

  uint64_t op_seq = op->op_seq();
  uint32_t pg_id = op->pg_id();
  if (op->DecRefs()) {
    inflying_list_.erase(std::make_pair(pg_id, op_seq));
  }

  DispatchPendingIO();
}

void UDiskHandle::EndMigrateJournalRequest(OpRequest* op) {
  AckMigrateJournalRequest(op);

  uint64_t op_seq = op->op_seq();
  uint32_t pg_id = op->pg_id();
  if (op->DecRefs()) {
    inflying_list_.erase(std::make_pair(pg_id, op_seq));
  }

  DispatchPendingIO();
}

void UDiskHandle::ChunkIOCount(OpRequest *op) {
  const common::ChunkIORequestHead* src_chunk_hdr =
    (const common::ChunkIORequestHead*)op->sub_msg_hdr_offset();
  // 性能统计
  if (src_chunk_hdr->cmd == common::CHUNK_CMD_READ) {
    r_io_count_++;
    r_io_bytes_ += src_chunk_hdr->length;
    r_io_latency_ = op->latency();
    r_aio_latency_ = op->aio_latency();
  } else if (src_chunk_hdr->cmd == common::CHUNK_CMD_WRITE) {
    w_io_count_++;
    w_io_bytes_ += src_chunk_hdr->length;
    w_io_latency_ = op->latency();
    w_aio_latency_ = op->aio_latency();
    w_rep_latency_ = op->rep_latency();
  }
}

void UDiskHandle::AckHelaIORequest(OpRequest* op) {
  const common::MessageHeader* src_common_hdr = op->msg_hdr();
  const common::HelaChunkRequestHead* src_hela_hdr = (const common::HelaChunkRequestHead*)op->sub_msg_hdr_offset();
  const ConnectionUeventPtr& connection = op->conn();
  if (connection->IsClosed()) {
    ULOG_ERROR << "Ack Hela Op: " << op->op_seq()
              << "hela req flowno: " << src_hela_hdr->flowno
              << " with retcode: " <<op->retcode()
              << " error, the response connection has closed";
    return;
  }

  size_t msg_hdr_len = sizeof(common::MessageHeader) + sizeof(common::HelaChunkResponseHead);
  char* msg_hdr = (char*)malloc(msg_hdr_len);
  common::MessageHeader* dst_common_hdr = (common::MessageHeader*)msg_hdr;
  common::HelaChunkResponseHead* dst_hela_hdr = (common::HelaChunkResponseHead*)(msg_hdr +
     sizeof(common::MessageHeader));
  size_t data_len = 0;
  if (src_hela_hdr->cmd == common::HELA_CMD_READ && !op->retcode()) {
    data_len = src_hela_hdr->length;
  }
  BuildHelaResponse(op->retcode(), *src_common_hdr, dst_common_hdr, *src_hela_hdr, dst_hela_hdr, data_len);
  int rc = connection->SendData(msg_hdr, msg_hdr_len);
  if (rc) {
    ULOG_ERROR << "Ack Hela Op: " << op->op_seq() << " failed, retcode: " << rc;
  }
  if (data_len && op->read_buffer()) {
    rc = connection->SendData(op->read_buffer(), data_len);
    if (rc) {
      ULOG_ERROR << "Ack Hela Op: " << op->op_seq() << " failed, retcode: " << rc;
    }
  }
  free(msg_hdr);
  ULOG_TRACE << "Ack Hela Op: " << op->op_seq()
            << "hela req flowno: " << src_hela_hdr->flowno
            << " with retcode: " << op->retcode();
  return;
}

void UDiskHandle::EndHelaIORequest(OpRequest* op) {
  // 性能统计
  HelaIOCount(op);

  AckHelaIORequest(op);
  uint64_t op_seq = op->op_seq();
  uint32_t pg_id = op->pg_id();
  if (op->DecRefs()) {
    inflying_list_.erase(std::make_pair(pg_id, op_seq));
  }

  DispatchPendingIO();
}

void UDiskHandle::HelaIOCount(OpRequest *op) {
  const common::HelaChunkRequestHead* src_hela_hdr =
    (const common::HelaChunkRequestHead*)op->sub_msg_hdr_offset();
  // 性能统计
  if (src_hela_hdr->cmd == common::HELA_CMD_READ) {
    r_io_count_++;
    r_io_bytes_ += src_hela_hdr->length;
    r_io_latency_ = op->latency();
    r_aio_latency_ = op->aio_latency();
  } else if (src_hela_hdr->cmd == common::HELA_CMD_WRITE) {
    w_io_count_++;
    w_io_bytes_ += src_hela_hdr->length;
    w_io_latency_ = op->latency();
    w_aio_latency_ = op->aio_latency();
    w_rep_latency_ = op->rep_latency();
  }
}

// 不需要做version检查，放入pending 队列时已经检查过
void UDiskHandle::DispatchOpRequest(OpRequest* op) {
  ULOG_TRACE << op->trace_tag();
  switch (op->msg_type()) {
    case common::MSG_GATE_IO_REQ:
      DispatchGateRequest(op);
      break;
    case common::MSG_ARK_IO_REQ:
      DispatchArkRequest(op);
      break;
    case common::MSG_CHUNK_IO_REQ:
      DispatchChunkRequest(op);
      break;
    case common::MSG_MIGRATE_JOURNAL_REQ:
      DispatchMigrateJournalRequest(op);
      break;
    case common::MSG_HELA_CHUNK_REQ:
      DispatchHelaRequest(op);
      break;
    default:
      ULOG_FATAL << "Invalid message type:" << op->msg_type();
      break;
  }
}

void UDiskHandle::BuildChunkResponse(int retcode,
                                     const common::MessageHeader &req_common_hdr,
                                     common::MessageHeader *res_common_hdr,
                                     const common::ChunkIORequestHead &req_hdr,
                                     common::ChunkIOResponseHead *res_hdr,
                                     size_t data_len) {
  size_t msg_data_len = data_len + sizeof(common::ChunkIOResponseHead);
  res_common_hdr->msg_type = common::MSG_CHUNK_IO_RES;
  res_common_hdr->data_len = msg_data_len;
  res_common_hdr->version = req_common_hdr.version;
  res_hdr->size = data_len;
  res_hdr->version = req_hdr.version;
  res_hdr->cmd = req_hdr.cmd;
  res_hdr->flowno = req_hdr.flowno;
  res_hdr->replica_no = req_hdr.replica_no;
  res_hdr->lc_id = req_hdr.lc_id;
  res_hdr->lc_random_id = req_hdr.lc_random_id;
  res_hdr->lc_size = req_hdr.lc_size;
  res_hdr->pc_no = req_hdr.pc_no;
  res_hdr->pg_id = req_hdr.pg_id;
  res_hdr->route_version = req_hdr.route_version;
  res_hdr->retcode = retcode;
  res_hdr->reserved1 = 0;
  res_hdr->reserved2 = 0;
  res_hdr->magic = req_hdr.magic;
}

void UDiskHandle::BuildMigrateJournalRemoteResponse(int retcode,
                                     const common::MessageHeader &req_common_hdr,
                                     common::MessageHeader *res_common_hdr,
                                     const common::MigrateHead &req_hdr,
                                     common::MigrateHead *res_hdr) {
  size_t msg_data_len = sizeof(common::MigrateHead);
  res_common_hdr->msg_type = common::MSG_MIGRATE_JOURNAL_RES;
  res_common_hdr->data_len = msg_data_len;
  res_common_hdr->version = req_common_hdr.version;
  res_hdr->size = 0;
  res_hdr->cmd = req_hdr.cmd;
  res_hdr->flowno = req_hdr.flowno;
  res_hdr->lc_id = req_hdr.lc_id;
  res_hdr->lc_size = req_hdr.lc_size;
  res_hdr->pc_no = req_hdr.pc_no;
  res_hdr->pg_id = req_hdr.pg_id;
  res_hdr->lc_random_id = req_hdr.lc_random_id;//migrate pc完成是时校验
  res_hdr->route_version = req_hdr.route_version;
  res_hdr->reserved_lc_id = req_hdr.reserved_lc_id;
  res_hdr->reserved_lc_random_id = req_hdr.reserved_lc_random_id;
  res_hdr->reserved_pg_id = req_hdr.reserved_pg_id;
  res_hdr->retcode = retcode;
  res_hdr->magic = req_hdr.magic;
}

void UDiskHandle::BuildGateResponse(int retcode,
                                    const common::MessageHeader &req_common_hdr,
                                    common::MessageHeader *res_common_hdr,
                                    const common::GateIORequestHead &req_gate_hdr,
                                    common::GateIOResponseHead *res_gate_hdr,
                                    size_t data_len) {
  size_t msg_data_len = data_len + sizeof(common::GateIOResponseHead);
  res_common_hdr->msg_type = common::MSG_GATE_IO_RES;
  res_common_hdr->data_len = msg_data_len;
  res_common_hdr->version = req_common_hdr.version;
  res_gate_hdr->size = data_len;
  res_gate_hdr->version = req_gate_hdr.version;
  res_gate_hdr->cmd = req_gate_hdr.cmd;
  res_gate_hdr->flowno = req_gate_hdr.flowno;
  res_gate_hdr->fragno = req_gate_hdr.fragno;
  res_gate_hdr->lc_id = req_gate_hdr.lc_id;
  res_gate_hdr->lc_random_id = req_gate_hdr.lc_random_id;
  res_gate_hdr->pc_no = req_gate_hdr.pc_no;
  res_gate_hdr->route_version = req_gate_hdr.route_version;
  res_gate_hdr->retcode = retcode;
  res_gate_hdr->reserved1 = 0;
  res_gate_hdr->reserved2 = 0;
  res_gate_hdr->magic = req_gate_hdr.magic;
}

void UDiskHandle::BuildArkResponse(int retcode,
                                    const common::MessageHeader &req_common_hdr,
                                    common::MessageHeader *res_common_hdr,
                                    const common::ArkIORequestHead &req_ark_hdr,
                                    common::ArkIOResponseHead *res_ark_hdr,
                                    size_t data_len) {
  size_t msg_data_len = data_len + sizeof(common::ArkIOResponseHead);
  res_common_hdr->msg_type = common::MSG_ARK_IO_RES;
  res_common_hdr->data_len = msg_data_len;
  res_common_hdr->version = req_common_hdr.version;
  res_ark_hdr->size = data_len;
  res_ark_hdr->version = req_ark_hdr.version;
  res_ark_hdr->cmd = req_ark_hdr.cmd;
  res_ark_hdr->flowno = req_ark_hdr.flowno;
  res_ark_hdr->fragno = req_ark_hdr.fragno;
  res_ark_hdr->lc_id = req_ark_hdr.lc_id;
  res_ark_hdr->lc_random_id = req_ark_hdr.lc_random_id;
  res_ark_hdr->pc_no = req_ark_hdr.pc_no;
  res_ark_hdr->route_version = req_ark_hdr.route_version;
  res_ark_hdr->retcode = retcode;
  res_ark_hdr->res_port = req_ark_hdr.res_port;
  res_ark_hdr->state_machine_id = req_ark_hdr.state_machine_id;
  res_ark_hdr->reserved1 = 0;
  res_ark_hdr->reserved2 = 0;
  res_ark_hdr->magic = req_ark_hdr.magic;
}

void UDiskHandle::BuildHelaResponse(int retcode,
                                    const common::MessageHeader &req_common_hdr,
                                    common::MessageHeader *res_common_hdr,
                                    const common::HelaChunkRequestHead &req_hela_hdr,
                                    common::HelaChunkResponseHead *res_hela_hdr,
                                    size_t data_len) {
  size_t msg_data_len = data_len + sizeof(common::HelaChunkResponseHead);
  res_common_hdr->msg_type = common::MSG_HELA_CHUNK_RES;
  res_common_hdr->data_len = msg_data_len;
  res_common_hdr->version = req_common_hdr.version;
  res_hela_hdr->size = data_len;
  res_hela_hdr->version = req_hela_hdr.version;
  res_hela_hdr->cmd = req_hela_hdr.cmd;
  res_hela_hdr->flowno = req_hela_hdr.flowno;
  res_hela_hdr->fragno = req_hela_hdr.fragno;
  res_hela_hdr->lc_id = req_hela_hdr.lc_id;
  res_hela_hdr->lc_random_id = req_hela_hdr.lc_random_id;
  res_hela_hdr->pc_no = req_hela_hdr.pc_no;
  res_hela_hdr->route_version = req_hela_hdr.route_version;
  res_hela_hdr->retcode = retcode;
  res_hela_hdr->handle_id = req_hela_hdr.handle_id;
  res_hela_hdr->reserved1 = 0;
  res_hela_hdr->reserved2 = 0;
  res_hela_hdr->magic = req_hela_hdr.magic;
}

void UDiskHandle::EndPendingIO(OpRequest *op) {
  const common::MessageHeader *hdr = op->msg_hdr();
  if (hdr->msg_type == common::MSG_GATE_IO_REQ) {
    AckGateIORequest(op);
  } else if (hdr->msg_type == common::MSG_ARK_IO_REQ) {
    AckArkIORequest(op);
  } else if (hdr->msg_type == common::MSG_CHUNK_IO_REQ) {
    AckChunkIORequest(op);
  } else if (hdr->msg_type == common::MSG_HELA_CHUNK_REQ) {
    AckHelaIORequest(op);
  }
  op->DecRefs();
}

void UDiskHandle::IOTimerCb() {
  for (auto it = inflying_list_.begin(); it != inflying_list_.end();) {
    // 因为在EndIORequest里会删除迭代器，导致迭代器失效，所以必须先自加
    auto it1 = it++;
    if (UNLIKELY(it1->second->IncTimerCount())) { // 触发超时函数
      it1->second->TimeoutCb();
      EndIORequest(it1->second); // IO 超时后需要返回
    }
  }
  for (auto it = pending_list_.begin(); it != pending_list_.end();) {
    OpRequest *op = *it;
    if (UNLIKELY(op->IncTimerCount())) {
      op->TimeoutCb(false);
      it = pending_list_.erase(it);
      EndPendingIO(op);
    } else {
      it++;
    }
  }
}

void UDiskHandle::EnqueueInflying(OpRequest* op) {
  uint32_t pg_id = op->pg_id();
  uint64_t seqno = op->op_seq();
  inflying_list_.insert(std::make_pair(std::make_pair(pg_id, seqno), op));
}

// OpRequest入队列
void UDiskHandle::OpEnqueue(OpRequest* op) {
  ULOG_TRACE << op->trace_tag();
  uint32_t io_depth = inflying_list_.size();
  uint32_t io_depth_limit = (uint32_t)io_depth_limit_;
  if (loop_handle_->IsLoopDispatchIO()) {
    io_depth = loop_handle_->dispatch_io_cur_total();
    io_depth_limit = loop_handle_->dispatch_io_depth();
  }

  if (io_depth >= io_depth_limit) {
    ULOG_TRACE << "PENDING: " << pending_list_.size()
              << ";Request:" << op->trace_tag()
              << ";io_depth:" << io_depth
              << ";io_depth_limit:" << io_depth_limit;
    EnqueuePending(op);
    return;
  }

  EnqueueInflying(op);
  if (loop_handle_->IsLoopDispatchIO()) {
    ULOG_TRACE << "dispatch io inflying, io_depth:" << io_depth
              << ";io_depth_limit" << io_depth_limit
              << ";pending_list num:" << pending_list_.size();
    loop_handle_->CurrentIODepthTotalInc();
  }

  DispatchOpRequest(op);
}

void UDiskHandle::DispatchPendingIO() {
   // 如果是由loop统一派发io的模式，则由loop派发
   if (loop_handle_->IsLoopDispatchIO()) {
     loop_handle_->DispatchNextPendingIO(this);
   } else {
     // 队列低于限制，防止已经触发过载保护
     if ((int)inflying_list_.size() >= io_depth_limit_) {
        return;
     }

     DispatchNextPendingIO();
   }
}

bool UDiskHandle::DispatchNextPendingIO() {
  // pending list 非空，防止已经触发过载保护
  if (pending_list_.size() == 0) {
    return false;
  }

  OpRequest* op = pending_list_.front();
  ULOG_TRACE << "Pop IO op " << op->op_seq() << " from pending list";
  pending_list_.pop_front();
  EnqueueInflying(op);
  DispatchOpRequest(op);
  return true;
}

void UDiskHandle::ClearOpRequstByConnId(int64_t conn_id) {
  for (auto it = pending_list_.begin(); it != pending_list_.end();) {
    OpRequest *op = *it;
    if (op->conn()->GetId() == conn_id) {
      it = pending_list_.erase(it);
      op->DecRefs();
    } else {
      ++it;
    }
  }
}

