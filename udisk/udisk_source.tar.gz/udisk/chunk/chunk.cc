#include "chunk_context.h"
#include <ustevent/base/logging.h>
#include "chunk_loop_handle.h"
#include <ustevent/base/async_logging.h>
#include <ustevent/libevent/listener_libevent.h>
#include <ustevent/worker_thread.h>
#include "manager_handle.h"
#include "repair_loop_handle.h"
#include "recycle_loop_handle.h"
#include "detection_loop_handle.h"
#include "chunk_storage_type.h"
#include "file_chunk_pool.h"
#include "mock_chunk_pool.h"
#include "raw_chunk_pool.h"
#include "str_list.h"

#include <sys/types.h>
#include <sys/stat.h>
#include <iostream>
#include <getopt.h>
#include <unistd.h>
#include <signal.h>

using namespace udisk;
using namespace chunk;

#define str(a) (#a)
#define xstr(a) (str(a))

#ifdef VERSION_TAG
//用于标识版本号，可以用nm -C 查看
const  char *version_tag = xstr(VERSION_TAG); //两次转换将宏的值转成字符串
#else
const  char *version_tag = "unknown";
#endif

static struct option long_options[] = {
  {"help", 0, nullptr, 'h'},
  {"version", 0, nullptr, 'v'},
  {"conf", 1, nullptr, 'c'},
  {"print", 0, nullptr, 'p'},
  {"foregroud", 0, nullptr, 'f'},
};

static void print_help(const char *name) {
  std::cout << name
            << " Usage: \n"
            << "-h | --help, print this\n"
            << "-c | --conf config file, conf file\n"
            << "-v | --version, get the version\n"
            << "-p | --print log, print log on screen\n"
            << "-f | --foregroud, run this on front end\n";
}

static const char *short_options = "hvpfc:";

static void print_version(const char *name) {
  printf("chunk version tag: %s\n", version_tag);
}

static void context_init(const std::string &conf_file) {
  UDiskContext *context = new UDiskContext(conf_file);
  std::tuple<int, std::string> result = context->init();
  if (std::get<0>(result)) {
    std::cerr << "Init Failed," << std::get<1>(result) << std::endl;
    std::exit(-1);
  }
  //初始化成功
  g_context = context;
}

static void init_daemon() {
  pid_t pid;

  pid = fork();
  if (pid < 0)
    exit(EXIT_FAILURE);
  if (pid > 0)
    exit(EXIT_SUCCESS);
  if (setsid() < 0)
    exit(EXIT_FAILURE);

  signal(SIGCHLD, SIG_IGN);
  signal(SIGHUP, SIG_IGN);

  pid = fork();
  if (pid < 0)
    exit(EXIT_FAILURE);
  if (pid > 0)
    exit(EXIT_SUCCESS);

  umask(0);
  chdir("/");

  close(STDOUT_FILENO);
  close(STDIN_FILENO);
}

static base::AsyncLogging *logger = nullptr;
static void logger_putfn(const char *msg, int len) {
  if (logger) {
    logger->append(msg, len);
  }
}

static void init_zkclient() {
  common::NameContainer *nc = new common::NameContainer(g_context->config().zk_server(),
      nullptr,
      g_context->config().zk_timeout(),
      g_context->config().zk_log());
  if (nc->Init() == -1) {
    ULOG_SYSFATAL << "can't connect to zookeeper";
  }
  common::ZkNameOfSetPtr set_ptr(new common::ZkNameOfSet(g_context->config().my_set()));
  ULOG_INFO << g_context->config().odin_zk_path();
  ULOG_INFO << g_context->config().metaserver_zk_path();
  set_ptr->AddNamePath(common::ConfigParser::kOdinName,
                        g_context->config().odin_zk_path());
  set_ptr->AddNamePath(common::ConfigParser::kMetaServerName,
                        g_context->config().metaserver_zk_path());
  nc->AddZkNameOfSet(set_ptr);
  g_context->set_nc(nc);
  ULOG_INFO << "zkclient init finished";
}

static void init_logging(const char* argv0, bool is_print_log) {
  char name[256];
  strncpy(name, argv0, 256);
  std::string name_str = g_context->config().log_common_path() +
      std::string(::basename(name)); // 加上程序名
  base::Logger::setLogLevel(g_context->config().log_level());
  if (!is_print_log) {
    logger = new base::AsyncLogging(name_str,
                                    g_context->config().log_roll_size(),
                                    1,
                                    g_context->config().sync_log());
    logger->start();
    base::Logger::setOutput(logger_putfn);
  }
}

static void init_chunk_pool() {
  ChunkPool *chunk_pool = nullptr;
  if (g_context->config().storage_type() == UDiskConfig::kStorageTypeMock) {
    chunk_pool = new MockChunkPool();
  } else if (g_context->config().storage_type() == UDiskConfig::kStorageTypeFile) {
    chunk_pool = new FileChunkPool(g_context->config().chunk_dir());
  } else if (g_context->config().storage_type() == UDiskConfig::kStorageTypeRaw) {
    chunk_pool = new RawChunkPool();
  } else {
    ULOG_FATAL << "unknown chunk storage type";
  }

  // TODO(fangran.fr) using errno
  if (chunk_pool->Init() != 0) {
    ULOG_SYSFATAL << "chunk pool init error";
  }
  g_context->set_chunk_pool(chunk_pool);
}

static void check_chunk_conf() {
  ULOG_INFO << "check chunk conf";
  std::vector<std::string> vec;
  common::get_str_vec(g_context->config().chunk_dir(), "/", vec);
  std::string uuid = vec[0];
  std::string dir = vec[1];
  std::string cmd = "cat /proc/mounts | grep " + uuid
      + "| awk '{print $1}' | xargs blkid | grep "
      + uuid + " | wc -l";
  ULOG_INFO << cmd.c_str();
  FILE *fp = popen(cmd.c_str(), "r");
  char buffer[128];
  memset(buffer, 0, sizeof(buffer));
  fgets(buffer, sizeof(buffer), fp);
  pclose(fp);
  ULOG_INFO << buffer;
  int rc = atoi(buffer);
  if (rc != 1) {
    ULOG_SYSFATAL << "check chunk dir error:" << rc;
  }
  vec.clear();
  common::get_str_vec(dir, "-", vec);
  int chunk_id = stoi(vec[1]);
  if (chunk_id != g_context->config().my_id()) {
    ULOG_SYSFATAL << "check my id error";
  }
}

static void BindListenerCb(uevent::ListenerLibevent& listener) {
  listener.SetConnectionSuccessCb(ChunkLoopHandle::ConnectionSuccessHandle);
  listener.SetConnectionClosedCb(ChunkLoopHandle::ConnectionClosedHandle);
  listener.SetMessageReadCb(ChunkLoopHandle::MessageReadHandle);
  listener.SetMessageWriteCb(ChunkLoopHandle::MessageWriteHandle);
  listener.SetCreateLoopHandleCb(ChunkLoopHandle::CreateMyself);
  listener.SetThreadNum(g_context->config().thread_num());
}

static void StartManagerModule() {
  // 管理网络模块启动
  ManagerHandle *man = new ManagerHandle;
  man->start(g_context->config().listen_ip(), g_context->config().listen_port());
  ULOG_INFO << "Manager Listener started on " << g_context->config().listen_ip()
           << ":" << g_context->config().listen_port();
}

void sTerminate(int signo)
{
  std::cout << "Get a SIGTERM signal, signo=" << signo << std::endl;
  exit(EXIT_SUCCESS);
  return;
}

void ReloadConfig(int signo) {
  g_context->mutable_config()->Reload();
}

int main(int argc, char** argv) {
  sigset(SIGTERM, sTerminate);
  std::string conf_file;
  bool foreground(false);
  bool is_print_log(false);
  // 解析命令行输入
  while (true) {
    int c = -1;
    int index = -1;
    c = getopt_long(argc, argv, short_options, long_options, &index);
    if (c == -1) {
      break;
    }
    switch (c) {
      case 'v':
        print_version(argv[0]);
        std::exit(0);
      case 'c':
        conf_file = std::string(optarg);
        break;
      case 'h':
        print_help(argv[0]);
        std::exit(0);
      case 'p':
        is_print_log = true;
        break;
      case 'f':
        foreground = true;
        break;
      default:
        print_help(argv[0]);
        std::exit(-1);
    }
  }
  if (conf_file.empty()) {
    conf_file = "/etc/udisk/chunk.conf";
  }
  context_init(conf_file);

  signal(SIGUSR1, ReloadConfig);

  if (g_context->config().storage_type() ==
                          UDiskConfig::kStorageTypeFile) {
    check_chunk_conf();
  }

  if (!foreground) {
    init_daemon();
  }

  // 初始化日志模块
  init_logging(argv[0], is_print_log);
  ULOG_INFO << "================Chunk Restart=====================";

  // zkclient启动
  init_zkclient();

  init_chunk_pool();

  // 修复模块启动
  RepairLoopHandle *repair_handle = new RepairLoopHandle;
  repair_handle->Start(g_context->config().listen_ip(), g_context->config().repair_port());
  ULOG_INFO << "repair handler started on " << g_context->config().listen_ip()
           << ":" << g_context->config().repair_port();

  // 回收模块启动
  RecycleLoopHandle *recycle_handle = new RecycleLoopHandle;
  recycle_handle->Start();
  ULOG_INFO << "recycle handler started";

  if ((g_context->config().storage_type() ==
                      UDiskConfig::kStorageTypeRaw)
        && (g_context->config().start_detection_thread())) {
    // 检测模块启动
    DetectionLoopHandle *detection_handle = new DetectionLoopHandle;
    detection_handle->Start();
    ULOG_INFO << "detection handler started";
  }

  // io网络模块启动
  uevent::Option option;
  option.worker_strategy = uevent::Option::kRoundRobin;
  uevent::UsockAddress io_addr(g_context->config().listen_ip(),
      g_context->config().io_listen_port(), false);
//# ifdef ENABLE_POSIX
# if 1
  option.enable_aio = true;
  uevent::PosixWorker* worker = new uevent::PosixWorker(0, nullptr, option);
  worker->Init();
  uevent::ListenerLibevent* io_listener = new uevent::ListenerLibevent(
      worker, io_addr, "ChunkListener", option);
# endif
  uevent::EventLoop* io_evloop = worker->eventloop();
  g_context->set_io_listen_loop(io_evloop);
  g_context->set_io_listener(io_listener);

  //FIXME(yeheng) 更新路由是可能有的线程还没有启动, 框架中采用了sleep的方法规避
  // 最好将管理线程作为主线程
  StartManagerModule();

  ULOG_INFO << "IO Listener started on " << g_context->config().listen_ip()
           << ":" << g_context->config().io_listen_port();
  BindListenerCb(*io_listener);
  io_listener->Start();
  // journal meta 初始化
  if (g_context->journal_enable()) {
    ULOG_DEBUG << "JournalMetaInit start...";
    journal::JournalMeta* journal_meta = new journal::JournalMeta();
    g_context->set_journal_meta(journal_meta);
    journal_meta->Init();
    ULOG_DEBUG << "JournalMetaInit finish...";
  }
  worker->Running("IOListener");
  return 0;
}
