#ifndef UDISK_CHUNK_REPAIR_HANDLE_H_
#define UDISK_CHUNK_REPAIR_HANDLE_H_

#include <algorithm>
#include <deque>
#include <ustevent/disk_io_util.h>
#include <ustevent/libevent/listener_libevent.h>
#include <ustevent/libevent/eventloop_libevent.h>
#include <ustevent/libevent/connector_libevent.h>
#include <ustevent/callbacks.h>
#include <ustevent/base/obj_pool.h>
#include <ustevent/worker_thread.h>
#include "chunk_begin_repair.h"
#include "cluster_map.h"
#include "udisk_time.h"
#include "op_request.h"
#include "cluster_hash_ring.h"
#include "flow_ctrl.h"
#include "io_error_container.h"
#include "pool/memory_pool.h"

#define REPAIR_CHUNK_REP_NO (1)

namespace udisk {
namespace chunk {

//lc_id, lc_size, pc_no, lc_random_id, pg_id
//typedef std::list<std::pair<
//  std::tuple<uint32_t, uint32_t, uint32_t, uint32_t, uint32_t>, 
//  base::Timestamp>> RepairPCList;

typedef std::list<std::pair<PhysicalChunk , base::Timestamp>> RepairPCList;

class RepairLoopHandle {
 public:
  RepairLoopHandle();

  virtual ~RepairLoopHandle();

  void Start(const std::string &ip, int port);

  void SyncDataProcess(uint32_t repair_chunk, PhysicalChunkSet pcs);

  void CheckRepairPCState();

  void UpdateClusterMap(cluster::ClusterMap map); 

  const cluster::ClusterMap& const_cluster_map() const {
    return cluster_map_;
  }

  void NotifyIOLoopHandle(uint32_t lc_id, uint32_t lc_size, uint32_t pc_no);

  uevent::EventLoop* uevent_loop() {
    return repair_loop_;
  }
  MemoryPool &mem_pool() { return mem_pool_;}

 private:
  uint64_t get_next_op_seq() {
    return ++last_op_seq_;
  }

  bool DoLocal(ChunkHandle* handle, OpRequest* op);
  int SubmitReadLocal(ChunkHandle *handle, uint32_t offset,
                        uint32_t len, OpRequest* op); 
  int SubmitWriteLocal(ChunkHandle *handle, uint32_t offset,
                        uint32_t len, OpRequest* op); 
  static void LocalAioCB(int retcode, void* arg);
  void OpenChunkResCB(int retcode, ChunkHandle* handle, OpRequest* op);
  int SyncChunkDataRequest(OpRequest* op);
  bool SendMsg(const char *msg, size_t len, 
      const std::string& ip, int port, uint32_t chunk_id);
  void BuildChunkRepairRequest(common::MessageHeader* msg_hdr,
                                uint64_t op_seq, uint64_t offset, 
                                uint32_t lc_id, uint32_t lc_random_id, uint32_t lc_size,
                                uint32_t pc_no, uint32_t pg_id);
  void BuildChunkRepairResponse(int retcode,
                                const common::MessageHeader &req_common_hdr,
                                common::MessageHeader *res_common_hdr,
                                const common::ChunkRepairHead &req_hdr,
                                common::ChunkRepairHead *res_hdr); 
  void SendRepairPCRequest(uint32_t pg_id, uint32_t lc_id, uint32_t pc_id, 
                    uint32_t lc_size, uint32_t lc_random_id, uint32_t offset);
  void SendNextRepairPC();
 
  typedef std::pair<std::string, int> ConnectorKey;
  
  void ConnectionSuccessHandle(const uevent::ConnectionUeventPtr& conn);
  void ConnectionClosedHandle(const uevent::ConnectionUeventPtr& conn);
  void MessageReadHandle(const uevent::ConnectionUeventPtr& conn);
  void MessageWriteHandle(const uevent::ConnectionUeventPtr& conn);
  bool DecodeMsg(const uevent::ConnectionUeventPtr &conn,
                   uint8_t msg_type,
                   common::MessageHeader **hdr,
                   char **data,
                   uint32_t *data_size,
                   MemorySlab **slab);
  void DoChunkRequest(OpRequest* op); 
  void ProcessChunkResponse(common::MessageHeader* msg_hdr, const char* data); 
  void EndChunkIORequest(int retcode, OpRequest* op);

  void OutConnectionSuccessHandle(const uevent::ConnectionUeventPtr& conn);
  void OutConnectionCloseHandle(uint32_t chunk_id, const uevent::ConnectionUeventPtr& conn);

  uevent::ConnectionUeventPtr get_out_connection(const std::string &ip,
    int port, uint32_t chunk_id);

  void ReportLCIOError();
   
 private:
  uevent::WorkerThread *repair_thread_;
  uevent::EventLoop *repair_loop_;
  uevent::ListenerUevent *repair_listener_;
  std::shared_ptr<TokenBucket> token_bucket_;
  cluster::ClusterMap cluster_map_;
  RepairPCList repair_pcs_;
  std::unordered_map<uint64_t, OpRequest*> inflying_list_;
  ChunkStorage *chunk_storage_;
  uint64_t last_op_seq_;
  uint32_t repair_chunk_id_;
  std::vector<uevent::ConnectorUeventPtr> chunk_connectors_;
  
  // io 读写错误统计 
  IOErrorContainer io_error_container_;
  base::ObjPool<OpRequest> op_pool_;
  MemoryPool mem_pool_;
  MemorySlab msg_header_slab_;
};

}; // end of ns chunk
}; // end of ns udisk

#endif
