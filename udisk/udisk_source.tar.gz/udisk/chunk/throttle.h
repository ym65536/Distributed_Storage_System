#ifndef UDISK_CHUNK_THROTTLE_H_
#define UDISK_CHUNK_THROTTLE_H_

#include <deque>
#include <ustevent/timer.h>
#include "flow_ctrl.h"
#include "likely.h"
#include "op_request.h"
#include "udisk_types.h"
#include "chunk_context.h"

namespace udisk {
namespace chunk {

template <class ReqPtr>
class Throttle {
 public:
  typedef std::function<void(ReqPtr)> HandleCB;
  typedef std::function<void(ReqPtr)> TimeoutCB;
  explicit Throttle(uint64_t rate, HandleCB handle_cb, TimeoutCB timeout_cb,
                    uint32_t timeout, uevent::EventLoop* loop,
                    uint32_t smooth_factor)
      : handle_cb_(handle_cb),
        timeout_cb_(timeout_cb),
        loop_(loop),
        io_timeout_count_(timeout * smooth_factor) {
    uint64_t capacity = rate > g_context->chunk_pool()->pc_size() 
                          ? rate : g_context->chunk_pool()->pc_size();
    token_bucket_.reset(new TokenBucket(capacity, rate));
    if (io_timeout_count_ != 0) {
      timer_id_ = loop_->RunEvery((1.0 / smooth_factor),
                                  std::bind(&Throttle::OverFlow, this));
    }
  }

  ~Throttle() {
    if (io_timeout_count_ != 0) {
      loop_->CancelTimer(timer_id_);
    }
  }

  void Flow(ReqPtr req, uint32_t size) {
    if (queue_.empty() && token_bucket_->grant(size)) {
      handle_cb_(req);
    } else {
      queue_.emplace_back(Job(req, size));
      Flow();
    }
  }

  void Flow() {
    while (!queue_.empty()) {
      const Job& job = queue_.front();
      ReqPtr req = job.req;
      if (!token_bucket_->grant(job.size)) {
        break;
      }
      queue_.pop_front();
      handle_cb_(req);
    }
  }

  void OverFlow() {
    for (auto it = queue_.begin(); it != queue_.end();) {
      it->io_timer_count++;
      // 超时
      if (UNLIKELY(it->io_timer_count >= io_timeout_count_)) {
        timeout_cb_(it->req);
        it = queue_.erase(it);
      } else {
        ++it;
      }
    }
    Flow();
  }

 private:
  template <class T>
  struct Element {
    Element(T t, uint32_t s) : req(t), size(s), io_timer_count(0) {}
    T req;
    uint32_t size;
    uint32_t io_timer_count;
  };
  typedef Element<ReqPtr> Job;
  std::unique_ptr<TokenBucket> token_bucket_;
  std::deque<Job> queue_;
  HandleCB handle_cb_;
  TimeoutCB timeout_cb_;
  uevent::EventLoop* loop_;
  uevent::TimerId timer_id_;
  uint32_t io_timeout_count_;
};

}  // namespace chunk
}  // namespace udisk
#endif
