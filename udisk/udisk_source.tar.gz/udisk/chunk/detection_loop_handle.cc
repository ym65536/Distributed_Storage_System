#include "detection_loop_handle.h"

#include <sstream>
#include <string>
#include <string.h>
#include <malloc.h>
#include <stdlib.h>
#include <time.h>
#include <algorithm>
#include <ustevent/base/logging.h>
#include "chunk_context.h"
#include "udisk_types.h"
#include "kernel_raw_device_manager.h"

namespace udisk {
namespace chunk {

static const int kPCInterval = 6;

DetectionLoopHandle::DetectionLoopHandle()
    : is_overload_(false),
      is_init_(false),
      pre_io_depth_(g_context->config().udisk_queue_max_depth()),
      current_pc_index_(0),
      current_detection_period_(SUPERBLOCK_PERIOD) {
  detection_thread_ = nullptr;
  detection_loop_ = nullptr;
  pcs_.clear();

  // TODO(alan.ding) 根据输入创建对应的设备管理类
  dev_manager_ = new KernelRawDeviceManager();
}

DetectionLoopHandle::~DetectionLoopHandle() { delete dev_manager_; }

void DetectionLoopHandle::Start() {
  detection_thread_ = new uevent::WorkerThread("DetectionThread", nullptr);
  detection_loop_ = detection_thread_->StartWorker()->eventloop();

  g_context->set_detection_loop(detection_loop_);
  g_context->set_detection_handle(this);
  detection_loop_->RunInLoop(
      std::bind(&DetectionLoopHandle::StartInLoop, this));
}

void DetectionLoopHandle::StartInLoop() {
  detection_loop_->RunEvery(
      g_context->config().heartbeat_chunk_interval(),
      std::bind(&DetectionLoopHandle::ReportLCIOError, this));
  detection_loop_->RunEvery(
      1.0, std::bind(&DetectionLoopHandle::DetectionDevice, this));
  int fd = dev_manager_->Open(g_context->config().my_id(),
                              g_context->config().device_uuid(),
                              g_context->config().device_prefix());
  if (fd < 0) {
    ULOG_SYSFATAL << "open dev error";
  }
  is_init_ = true;
}

void DetectionLoopHandle::NotifyIODepthModify(uint32_t io_depth) {
  detection_loop_->RunInLoop(std::bind(
      &DetectionLoopHandle::NotifyIODepthModifyInLoop, this, io_depth));
}

void DetectionLoopHandle::NotifyIODepthModifyInLoop(uint32_t io_depth) {
  if (!is_init_) {
    ULOG_ERROR << "detection loop handle is not init";
    return;
  }
  if (io_depth < pre_io_depth_) {
    is_overload_ = true;
  } else {
    is_overload_ = false;
  }
  pre_io_depth_ = io_depth;
}

void DetectionLoopHandle::DetectionDevice() {
  if (!is_init_) {
    ULOG_ERROR << "detection loop handle is not init";
    return;
  }
  ULOG_INFO << "start detect device, period: " << current_detection_period_;
  ULOG_INFO << "current_pc_index: " << current_pc_index_;
  if (is_overload_) {
    ULOG_INFO << "device is over load, detection will not execute";
    return;
  }
  if (current_detection_period_ == SUPERBLOCK_PERIOD) {
    if (dev_manager_->ReadSuperBlock() != 0) {
      ULOG_ERROR << "read super block error";
      io_error_container_.Add(EncodeMsg(current_detection_period_));
    } else {
      current_detection_period_ = PCMETA_PERIOD;
    }
  } else if (current_detection_period_ == PCMETA_PERIOD) {
    pcs_.clear();
    if (dev_manager_->ReadAllPCMeta(pcs_) != 0) {
      ULOG_ERROR << "read pc meta error";
      io_error_container_.Add(EncodeMsg(current_detection_period_));
    } else {
      std::map<ChunkID, uint64_t> chunkid_map;
      for (auto it = pcs_.begin(); it != pcs_.end(); it++) {
        if ((*it)->is_used != 0) {
          ChunkID chunkid((*it)->pg_id, (*it)->lc_id,
                          (*it)->pc_no, (*it)->lc_random_id);
          auto result = 
              chunkid_map.insert(std::make_pair(chunkid, (uint64_t)((*it)->pc_id)));
          if (!result.second) {
            std::stringstream ss;
            ULOG_ERROR << " pc_id: " << (*it)->pc_id
                       << " pc_id: " << result.first->second
                       << " has same lc_id: " << ((*it)->lc_id)
                       << " pc_no: " << (*it)->pc_no;
            ss << "pc_id: " << (*it)->pc_id << " pc_id: " << result.first->second
               << " has same lc_id: " << (*it)->lc_id << " pc_no: " << (*it)->pc_no;
            io_error_container_.Add(ss.str());
          }
        }
      }
      std::random_shuffle(pcs_.begin(), pcs_.end());
      current_detection_period_ = CHECK_PERIOD;
      current_pc_index_ = 0;
    }
  } else if (current_detection_period_ == CHECK_PERIOD) {
    if ((pcs_.at(current_pc_index_)->has_detection)) {
      uint64_t offset = pcs_.at(current_pc_index_)->offset +
                        dev_manager_->super_block().pc_size;
      ULOG_INFO << pcs_.at(current_pc_index_)->pc_id << " has detection, "
               << "detection offset: " << offset;
      ULOG_INFO << "begin read detection";
      if (dev_manager_->CheckDetectionData(offset) != 0) {
        ULOG_ERROR << "read detection error";
        io_error_container_.Add(EncodeMsg(current_detection_period_));
        return;
      }
      ULOG_INFO << "begin write detection";
      if (dev_manager_->WriteDetectionData(offset) != 0) {
        ULOG_ERROR << "write detection error";
        io_error_container_.Add(EncodeMsg(current_detection_period_));
        return;
      }
    }
    current_pc_index_ += kPCInterval;
    if (current_pc_index_ >= pcs_.size()) {
      current_detection_period_ = SUPERBLOCK_PERIOD;
      current_pc_index_ = 0;
    }
  } else {
    ULOG_ERROR << "unknown detection period";
    current_detection_period_ = SUPERBLOCK_PERIOD;
  }
}

void DetectionLoopHandle::ReportLCIOError() {
  if (!is_init_) {
    ULOG_ERROR << "detection loop handle is not init";
    return;
  }
  if (io_error_container_.IsEmpty()) {
    return;
  }

  g_context->manager_handle()->ReportLCIOError(
      io_error_container_.lc_io_errors());
  io_error_container_.Clear();
}

std::string DetectionLoopHandle::EncodeMsg(DetectionPeriod dp) {
  std::ostringstream ss;
  ss << dev_manager_->dev_name()
     << " chunk_id: " << g_context->config().my_id();
  switch (dp) {
    case SUPERBLOCK_PERIOD:
      ss << " read superblock error";
      break;
    case PCMETA_PERIOD:
      ss << " read pc meta error";
      break;
    case CHECK_PERIOD:
      ss << " detection check error";
      break;
    default:
      break;
  }
  return ss.str();
}

void DetectionLoopHandle::GetNextDetectionPC(uint64_t* pc_id, 
                              uint64_t* offset, uint64_t* length) {
  uint64_t cur_pc_id = current_pc_index_ + 10 * kPCInterval;
  if (cur_pc_id >= pcs_.size()) {
    cur_pc_id = 0 + 10 * kPCInterval;
  }
  while(true) {
    if (pcs_.at(cur_pc_id)->has_detection) {
      *pc_id = pcs_.at(cur_pc_id)->pc_id;
      *offset = pcs_.at(cur_pc_id)->offset + dev_manager_->super_block().pc_size;
      *length = dev_manager_->super_block().detection_size;
      return;
    }
    cur_pc_id += kPCInterval;
    if (cur_pc_id >= pcs_.size()) {
      cur_pc_id = 0;
    }
  }
}

}  // end of chunk
}  // end of udisk
