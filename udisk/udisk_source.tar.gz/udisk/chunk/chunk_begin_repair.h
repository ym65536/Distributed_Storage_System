#ifndef UDISK_CHUNK_BEGIN_REPAIR_HANDLE_H_
#define UDISK_CHUNK_BEGIN_REPAIR_HANDLE_H_

#include <atomic>
#include <tuple>
#include <set>
#include <ustevent/pb_request_handle.h>
#include <ucloud.pb.h>


namespace udisk {
namespace chunk {
// lc_id, lc_size, pc_no, lc_random_id
//typedef std::set<std::tuple<uint32_t, uint32_t, uint32_t, uint32_t, uint32_t>> PhysicalChunkSet;

struct PhysicalChunk {
  uint32_t lc_id;//lc_id
  uint32_t lc_size;//lc_size
  uint32_t pc_no;//pc_no
  uint32_t lc_random_id;//lc_random_id
  uint32_t pg_id;//pg_id

  PhysicalChunk(uint32_t lc_id, uint32_t lc_size, uint32_t pc_no, uint32_t lc_random_id, uint32_t pg_id): 
    lc_id(lc_id), 
    lc_size(lc_size),
    pc_no(pc_no),
    lc_random_id(lc_random_id),
    pg_id(pg_id) {
  }

  bool operator < (const PhysicalChunk &pc) const{
    if (lc_id < pc.lc_id) {
      return true;
    } else if (lc_id == pc.lc_id) {
      if (pc_no < pc.pc_no) {
        return true;
      } else if (pc_no == pc.pc_no) {
        if (lc_size < pc.lc_size) {
          return true;
        } else if (lc_size == pc.lc_size){
          if (lc_random_id < pc.lc_random_id) {
            return true;
          } else if (lc_random_id == pc.lc_random_id){
            if (pg_id < pc.pg_id) {
              return true;
            } else { 
              return false;
            }
          } else {
            return false;
          }
        } else { 
          return false;
        }
      } else {
        return false;
      }
    } else { 
      return false;
    }
  } 

  bool operator == (const PhysicalChunk &pc) const{
    if (pc.lc_id == lc_id &&
        pc.lc_size == lc_size &&
        pc.pc_no == pc_no &&
        pc.lc_random_id == lc_random_id &&
        pc.pg_id == pg_id){
      return true;
    } else {
      return false;
    }
  }
};

typedef std::set<PhysicalChunk> PhysicalChunkSet;

class ChunkBeginRepairHandle: public uevent::PbRequestHandle {
 public:
  explicit ChunkBeginRepairHandle(uevent::EventLoop* loop) {
  }
  virtual ~ChunkBeginRepairHandle() {
  }
  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         const uevent::UMessagePtr& um);
 
  void ChunkBeginRepairProcess(const uevent::UMessagePtr& um);

  void NotifyPendingIOResponse(const uevent::UMessagePtr& um);
  void NotifyPendingIOTimeout();

  void NotifyRepairChunkResponse(const uevent::UMessagePtr& um);
  void NotifyRepairChunkTimeout();

  void NotifyIOLoopHandle();

  MYSELF_CREATE(ChunkBeginRepairHandle);

  void SendResponse(uint32_t retcode, const std::string& message); 
  void DestroyMyself();
   
 private:
  static int type_;
  PhysicalChunkSet pcs_;
  uint32_t pg_id_;
  uint32_t repair_chunk_;
  static std::atomic<uint32_t> concurrent_;
  uevent::ConnectionUeventPtr conn_;
  uevent::UMessagePtr request_;
  ucloud::UMessage response_;
  std::string session_no_;
};

}
}
#endif

