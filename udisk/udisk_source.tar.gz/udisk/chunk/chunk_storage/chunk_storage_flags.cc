#include "chunk_storage_flags.h"

DEFINE_string(udisk_chunkserver_PoolDir, "/pool",
              "chunkserver file chunkserver storage pool path");
DEFINE_string(udisk_chunkserver_DataDir, "/data",
              "chunkserver file chunkserver storage data path");
DEFINE_int32(udisk_chunkserver_StorageType, 1,
             "chunkserver default storage type is file storage, 0 for mock 1 "
             "for file 2 for raw 3 for spdk");
DEFINE_int32(udisk_chunkserver_MaxUDiskNum, 200000,
             "chunkserver default max udisk number");
DEFINE_int32(udisk_chunkserver_FDCacheNum, 50000,
             "chunkserver cache file fd number");
DEFINE_int32(udisk_chunkserver_ChunkSize, 33554432,
             "chunk size in bytes default is 32MB");
DEFINE_bool(udisk_chunkserver_DsyncMode, true, "open file dysnc");
