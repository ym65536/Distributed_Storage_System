#ifndef CHUNK_HANDLE_VEC_TYPE_H
#define CHUNK_HANDLE_VEC_TYPE_H

#include <stddef.h>
#include <stdint.h>
#include <vector>

namespace udisk {
namespace chunk {

class ChunkHandle;

class ChunkHandleVecType {
 public:
  bool IsNeedResize(uint32_t index);
  void Resize(uint32_t index, ChunkHandle* value); 
  ChunkHandle* Get(uint32_t index); 
  void Set(uint32_t index, ChunkHandle* handle); 

 private:
  std::vector<std::vector<ChunkHandle*>> handle_vec_;
};

};  // end of namespace chunk
};  // end of namespace udisk

#endif /* !CHUNK_HANDLE_VEC_TYPE_H */
// vim: set ts=2 sw=2 sts=2 et:
