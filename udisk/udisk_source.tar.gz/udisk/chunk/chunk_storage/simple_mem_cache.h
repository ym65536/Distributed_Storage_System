#ifndef UDISK_CHUNK_MEMORY_SIMPLE_MEM_CACHE_H
#define UDISK_CHUNK_MEMORY_SIMPLE_MEM_CACHE_H

#include <malloc.h>
#include <string>
#include <vector>
#include <stdint.h>

#include "chunk_storage_type.h"
#include <ustevent/base/logging.h>

namespace udisk {
namespace chunk {

struct SimpleMemCacheOptions {
  std::string name;
  void (*ctor)(void* object);
  void (*dtor)(void* object);
  size_t reserve;
  size_t limit;
  size_t objectSize;

  SimpleMemCacheOptions()
      : name("unnamed_simple_mem_cache"),
        ctor(NULL),
        dtor(NULL),
        reserve(16),
        limit(SIZE_MAX),
        objectSize(0) {}
};

struct SimpleMemCacheStats {
  std::string name;
  size_t reserve;
  size_t limit;
  size_t objectSize;
  size_t objectCount;
  size_t reservedObjectCount;

  SimpleMemCacheStats()
      : reserve(0),
        limit(0),
        objectSize(0),
        objectCount(0),
        reservedObjectCount(0) {}
};

/**
 * A simple mem cache. for fixed size.
 */

class SimpleMemCache {
 public:
  SimpleMemCache();
  ~SimpleMemCache();

  void Init(const SimpleMemCacheOptions& options);
  void* Alloc();
  void Free(void* ptr);
  bool IsEmtpy() const { return mObjectCount == 0; }
  void GetStats(SimpleMemCacheStats* stats) const;

 private:
  std::vector<void*> mReserveObjects;
  size_t mObjectCount;
  bool mInitFlag;
  SimpleMemCacheOptions mOptions;
};

inline void* SimpleMemCache::Alloc() {
  if (UNLIKELY(!mInitFlag)) {
    return NULL;
  }

  assert(mObjectCount <= mOptions.limit);

  if (UNLIKELY(mObjectCount >= mOptions.limit)) {
    return NULL;
  }
  ++mObjectCount;
  void* object = NULL;
  if (!mReserveObjects.empty()) {
    object = mReserveObjects.back();
    mReserveObjects.pop_back();
  } else {
    object = malloc(mOptions.objectSize);
  }
  if (mOptions.ctor != NULL) {
    mOptions.ctor(object);
  }
  return object;
}

inline void SimpleMemCache::Free(void* ptr) {
  if (UNLIKELY(ptr == NULL)) {
    return;
  }
  --mObjectCount;
  if (mOptions.dtor != NULL) {
    mOptions.dtor(ptr);
  }
  if (LIKELY(mReserveObjects.size() < mOptions.reserve)) {
    mReserveObjects.push_back(ptr);
  } else {
    free(ptr);
  }
}

}  // namespace chunk
}  // namespace udisk

#endif  // UDISK_CHUNK_MEMORY_SIMPLE_MEM_CACHE_H
