#include "kernel_raw_device_manager.h"
#include "raw_chunk_storage_type.h"
#include "umongo.h"
#include "str_list.h"
#include <string>
#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <getopt.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <ustevent/base/logging.h>
#include <ustevent/base/async_logging.h>
#include <ustevent/disk_io_util.h>
#include <ustevent/libevent/listener_libevent.h>
#include <ustevent/libevent/eventloop_libevent.h>
#include <ustevent/libevent/connector_libevent.h>
#include <ustevent/callbacks.h>
#include <ustevent/base/obj_pool.h>
#include <ustevent/worker_thread.h>
#include <ustevent/message_util.h>
#include <ustevent/base/my_uuid.h>

using namespace std;
using namespace udisk::chunk;

static void print_help(const char* name) {
  cout << "Usage: \n" << name << " [command] [args...] \n"
       << "help                                          | print this\n"
       << "format [dev chunk_id is_reset(true|false) has_journal(true|false) "
          "pc_size force(true|false) worker_num]\n"
       << "| 格式化磁盘, is_reset=true 抹零, has_journal=true 开辟日志存储区, "
          "pc_size(byte), force默认为false 磁盘已格式化,则操作失败, worker_num：工作线程数(格式化journal时有效)\n"
       << "dumpSuperBlock [dev]                          | 打印Superblock\n"
       << "dumpPCMeta [dev [pc_id]]                      | 打印pc meta\n"
       << "dumpPCMetaJson [dev [pc_id]]                  | 按json格式打印pc "
          "meta\n"
       << "dumpPCMetaJsonByType [dev is_used(true|false)] | "
          "按json格式打印所有已使用或未使用的pc meta, 默认为true\n"
       << "dumpJPCMeta [dev [journal_id]]            | 打印pc meta\n\n"
       << "dumpLCInfo [dev lc_id [offset [length]]]      | 根据lc_id打印pc "
          "meta\n";
  cout << "example: \n" << name << " format /dev/sdz 10 false false 4194304\n"
       << name << " dumpSuperBlock /dev/sdz\n" << name
       << " dumpPCMeta /dev/sdz\n" << name << " dumpPCMeta /dev/sdz 10\n"
       << name << " dumpPCMetaJson /dev/sdz\n" << name
       << " dumpPCMetaJson /dev/sdz 10\n" << name
       << " dumpPCMetaJsonByType /dev/sdz false\n" << name
       << " dumpJPCMeta /dev/sdz\n" << name
       << " dumpJPCMeta /dev/sdz 10\n" << name << " dumpLCInfo /dev/sdz 1\n"
       << name << " dumpLCInfo /dev/sdz 1 100M\n" << name
       << " dumpLCInfo /dev/sdz 1 100M 200M\n";
}

static base::AsyncLogging* async_log = nullptr;
static const char* format_path = "/root/udisk/format_log/";

static void async_log_put(const char* msg, int len) {
  async_log->append(msg, len);
}

static void init_format_path() {
  DIR* dir = opendir(format_path);
  if (dir == NULL) {
    mkdir(format_path, 0777);
    return;
  }

  closedir(dir);
}

static void init_logging(const string& dev_name) {
  init_format_path();
  std::string name_str(format_path);
  name_str.append(basename(dev_name.c_str()));
  base::Logger::setLogLevel("trace");
  async_log = new base::AsyncLogging(name_str, 100 << 20, 1, false, false);
  async_log->start();
  base::Logger::setOutput(async_log_put);
}

static uint64_t convert_to_byte(const char* value) {
  uint64_t byte = 0;
  char* end_ptr = nullptr;
  byte = strtoull(value, &end_ptr, 10);
  if (end_ptr == nullptr) {
    cout << "invalid value:" << value << endl;
    return byte;
  }

  switch (end_ptr[0]) {
    case 'k':
    case 'K':
      return byte << 10;
    case 'm':
    case 'M':
      return byte << 20;
      break;
    case 'g':
    case 'G':
      return byte << 30;
    case 't':
    case 'T':
      return byte << 40;
  }

  return byte;
}

std::vector<uint32_t> g_own_pgs;
std::mutex g_mutex;
std::condition_variable g_cv;

using namespace std::placeholders;
using namespace ucloud::umgogate;
using namespace ucloud::udisk;
using namespace uevent;

class MongoHandle {
 public:
  MongoHandle(std::string ip, uint32_t port, uint32_t chunk_id) 
    : ip_(ip), port_(port), chunk_id_(chunk_id) {
    ULOG_DEBUG << "Construct...";
  }
  ~MongoHandle() {
    ULOG_DEBUG << "Destruct...";
  }
  void Start() {
    uevent::Option option;
    option.enable_aio = true;
    mongo_thread_ = new uevent::WorkerThread("MongoThread", nullptr, option);
    mongo_loop_ = mongo_thread_->StartWorker()->eventloop();
    mongo_loop_->RunInLoop(std::bind(&MongoHandle::StartConnect, this));
  }

  void StartConnect() {
    // new connection
    std::stringstream ss;
    ss << "ctor-" << ip_ << ":" << port_;
    UsockAddress addr(ip_, port_, false);
    ctor_ = std::make_shared<uevent::ConnectorLibevent>(
          static_cast<uevent::PosixWorker*>(mongo_loop_->worker()), addr, ss.str());
    ctor_->SetConnectionSuccessCb(std::bind(&MongoHandle::OnConnSuccess, this, _1));
    ctor_->SetConnectionClosedCb(std::bind(&MongoHandle::OnConnClose, this, _1));
    ctor_->SetMessageReadCb(std::bind(&uevent::MessageUtil::ProtobufReadCallBack, _1));
    ctor_->Connect();
    ULOG_INFO << "Start connect to " << ss.str() << ", addr=" << addr.ToString();
  }

  void OnConnSuccess(const uevent::ConnectionUeventPtr& conn) {
    ULOG_DEBUG << "conn success...";
    ucloud::UMessage msg;
    uint32_t objid = uevent::MessageUtil::ObjId();
    uint32_t flowno = uevent::MessageUtil::Flowno();
    NewMessage_v2(&msg, flowno, base::MyUuid::NewUuid(),
                  EXECUTE_MGO_REQUEST, 0, false, objid, 0,
                  "GetPGInfo", NULL, NULL);
    ExecuteMgoRequest *req = msg.mutable_body()->MutableExtension(execute_mgo_request);
    construct_get_pg_info_request("udisk", req);
    ULOG_INFO << msg.DebugString();
    uevent::MessageUtil::SendPbRequest(conn, msg,
        std::bind(&MongoHandle::EntryGetPGInfo, this, _1),
        std::bind(&MongoHandle::Timeout, this), 5.0);
  } 

  void Timeout() {
    ULOG_ERROR << "Mongo timeout";
  }

  void EntryGetPGInfo(const UMessagePtr& msg) {
    ULOG_INFO << msg->DebugString();
    const ExecuteMgoResponse &res = msg->body().GetExtension(execute_mgo_response);
    if (res.rc().retcode() != 0) {
      ULOG_SYSFATAL << "get pg info from umgogate error, error msg: "
                   << res.rc().error_message();
    }
    std::vector<PGInfoPb> pginfos;
    if (!parse_get_pg_info_response(&res, pginfos)) {
      ULOG_SYSFATAL << "parse pg info error";
    }
    std::set<uint32_t> tmp_pgs;
    for (auto info : pginfos) {
      for (auto i = 0; i < info.chunk_id_size(); ++ i) {
        if (chunk_id_ == info.chunk_id(i)) {
          tmp_pgs.insert(info.id());
        }
      }
    }
    {
      std::unique_lock<std::mutex> lck(g_mutex);
      g_own_pgs.assign(tmp_pgs.begin(), tmp_pgs.end());
    }
    g_cv.notify_one();
  }

  void OnConnClose(const uevent::ConnectionUeventPtr& conn) {
    ULOG_DEBUG << "conn close...";
  }

 private:
  uevent::ConnectorUeventPtr ctor_;
  uevent::WorkerThread* mongo_thread_;
  uevent::EventLoop* mongo_loop_;
  std::string ip_;
  uint32_t port_;
  uint32_t chunk_id_;
};

int main(int argc, char** argv) {
  if (argc < 2) {
    print_help(argv[0]);
    return -1;
  }
  string operation(argv[1]);
  KernelRawDeviceManager krd_man;
  if (operation == "format") {
    if (argc < 8) {
      print_help(argv[0]);
      return -1;
    }
    string dev_name(argv[2]);
    int chunk_id = atoi(argv[3]);
    string is_reset(argv[4]);
    string has_journal(argv[5]);
    int pc_size = atoi(argv[6]);
    string force("false");
    if (argc > 7) {
      force.assign(argv[7]);
    }
    int worker_num = 4;
    if (argc >= 8) {
      worker_num = atoi(argv[8]);
    }
    cout << "log is in " << format_path << ", dev_name=" << dev_name 
        << ", chunk_id=" << chunk_id << ", is_reset=" << is_reset 
        << ", has_journal=" << has_journal << ", force=" << force 
        << ", worker_num=" << worker_num << endl;

    bool is_has_journal = false;
    string mongo_ip;
    uint32_t mongo_port;
    if (has_journal == "true") {
      assert(argc > 8);
      string mongo_addr(argv[8]);
      vector<string> tmp_vec;
      udisk::common::get_str_vec(mongo_addr, ":", tmp_vec);
      assert(tmp_vec.size() == 2);
      mongo_ip = tmp_vec[0];
      mongo_port = atoi(tmp_vec[1].c_str());
      is_has_journal = true;
    }
    init_logging(dev_name);
    ULOG_INFO << "begin format " << dev_name;
    ULOG_INFO << "chunk_id: " << chunk_id;
    ULOG_INFO << "is_reset: " << is_reset;
    ULOG_INFO << "has_journal: " << has_journal;
    ULOG_INFO << "force: " << force;
    ULOG_INFO << "worker num: " << worker_num;
    int ret = 0;
    if (force != "true") {
      ret = krd_man.Open(dev_name);
      if (ret < 0) {
        cout << "open dev error" << endl;
        return -1;
      }
      ret = krd_man.ReadSuperBlock();
      if (ret == 0) {
        cout << "the dev has been formated, please use force option!" << endl;
        krd_man.Close();
        //print_help(argv[0]);
        return -1;
      }
      FILE* fp;
      char buf[256];
      std::string cmd = "blkid " + dev_name;
      fp = popen(cmd.c_str(), "r");
      if (!fp) {
        cout << "exec cmd blkid fail" << endl;
        krd_man.Close();
        return -1;
      }
      fgets(buf, sizeof(buf), fp);
      pclose(fp);
      if (string(buf).size() > 3) {
        cout << "the dev has file system, please use force option!" << endl;
        krd_man.Close();
        //print_help(argv[0]);
        return -1;
      }
      krd_man.Close();
    }

    MongoHandle* mongo_handle = new MongoHandle(mongo_ip, mongo_port, chunk_id);
    mongo_handle->Start();

    ULOG_DEBUG << "Main thread wait for mongo response..."; 
    std::unique_lock<std::mutex> lck(g_mutex);
    g_cv.wait(lck, []{return !g_own_pgs.empty();});

    if (is_reset == "true") {
      ret = krd_man.Format(dev_name, chunk_id, true, is_has_journal, pc_size, g_own_pgs, worker_num);
    } else {
      ret = krd_man.Format(dev_name, chunk_id, false, is_has_journal, pc_size, g_own_pgs, worker_num);
    }
    if (ret != 0) {
      ULOG_ERROR << "format disk error " << dev_name;
      return -1;
    }
    ULOG_INFO << "format disk success " << dev_name;
    // 等待将日志刷入文件
    sleep(2);
    exit(0);
    return 0;

  } else if (operation == "dumpSuperBlock") {
    if (argc < 3) {
      print_help(argv[0]);
      return -1;
    }
    string dev_name(argv[2]);
    int ret = krd_man.Open(dev_name);
    if (ret < 0) {
      cout << "open dev error" << endl;
      return -1;
    }
    ret = krd_man.ReadSuperBlock();
    if (ret < 0) {
      cout << "read super block error" << endl;
      krd_man.Close();
      return -1;
    }
    cout << "dev name: " << krd_man.dev_name() << endl;
    cout << "dev size: " << krd_man.size() << endl;
    cout << "dev block size: " << krd_man.dev_block_size() << endl;
    cout << DumpSuperBlock(krd_man.super_block()) << endl;
    krd_man.Close();
    return 0;
  } else if (operation == "dumpPCMeta") {
    if (argc < 3) {
      print_help(argv[0]);
      return -1;
    }
    string dev_name(argv[2]);
    int pc_id = -1;
    if (argc == 4) {
      pc_id = atoi(argv[3]);
    }
    int ret = krd_man.Open(dev_name);
    if (ret < 0) {
      cout << "open dev error" << endl;
      return -1;
    }
    ret = krd_man.ReadSuperBlock();
    if (ret < 0) {
      cout << "read super block error" << endl;
      krd_man.Close();
      return -1;
    }
    cout << "dev name: " << krd_man.dev_name() << endl;
    cout << "dev size: " << krd_man.size() << endl;
    cout << "dev block size: " << krd_man.dev_block_size() << endl;
    std::vector<struct PCMeta*> pc_meta;
    ret = krd_man.ReadAllPCMeta(pc_meta);
    cout << "pc num: " << pc_meta.size() << endl;
    if (ret < 0) {
      cout << "read pc meta error" << endl;
      krd_man.Close();
      return -1;
    }
    if (pc_id >= 0) {
      cout << DumpPCMeta(*(pc_meta.at(pc_id))) << endl;
      // cout << krd_man.CheckDetectionData(pc_meta.at(pc_id).offset +
      //    krd_man.super_block().pc_size) << endl;
    } else {
      for (auto it = pc_meta.begin(); it != pc_meta.end(); it++) {
        cout << DumpPCMeta(**it) << endl;
      }
    }
    krd_man.Close();
    return 0;
  } else if (operation == "dumpPCMetaJsonByType") {
    if (argc < 3) {
      print_help(argv[0]);
      return -1;
    }
    string dev_name(argv[2]);
    bool is_used = true;
    if (argc == 4) {
      if (strcmp(argv[3], "false") == 0) {
        is_used = false;
      }
    }
    int ret = krd_man.Open(dev_name);
    if (ret < 0) {
      cout << "open dev error" << endl;
      return -1;
    }
    ret = krd_man.ReadSuperBlock();
    if (ret < 0) {
      cout << "read super block error" << endl;
      krd_man.Close();
      return -1;
    }
    std::vector<struct PCMeta*> pc_meta;
    ret = krd_man.ReadAllPCMeta(pc_meta);
    if (ret < 0) {
      cout << "read pc meta error" << endl;
      krd_man.Close();
      return -1;
    }

    cout << "[";
    uint32_t i = 0;
    for (auto it = pc_meta.begin(); it != pc_meta.end(); it++) {
      if ((*it)->is_used == is_used) {
        if (i != 0) {
          cout << "," << endl;
        }
        cout << DumpPCMetaJson(**it);
        i++;
      }
    }
    cout << "]";
    krd_man.Close();
    return 0;
  } else if (operation == "dumpPCMetaJson") {
    if (argc < 3) {
      print_help(argv[0]);
      return -1;
    }
    string dev_name(argv[2]);
    int pc_id = -1;
    if (argc == 4) {
      pc_id = atoi(argv[3]);
    }
    int ret = krd_man.Open(dev_name);
    if (ret < 0) {
      cout << "open dev error" << endl;
      return -1;
    }
    ret = krd_man.ReadSuperBlock();
    if (ret < 0) {
      cout << "read super block error" << endl;
      krd_man.Close();
      return -1;
    }
    std::vector<struct PCMeta*> pc_meta;
    ret = krd_man.ReadAllPCMeta(pc_meta);
    if (ret < 0) {
      cout << "read pc meta error" << endl;
      krd_man.Close();
      return -1;
    }
    if (pc_id >= 0) {
      cout << DumpPCMetaJson(*(pc_meta.at(pc_id)));
      // cout << krd_man.CheckDetectionData(pc_meta.at(pc_id).offset +
      //    krd_man.super_block().pc_size) << endl;
    } else {
      cout << "[";
      uint32_t i = 0;
      for (auto it = pc_meta.begin(); it != pc_meta.end(); it++) {
        cout << DumpPCMetaJson(**it);
        if (i < pc_meta.size() - 1) {
          cout << "," << endl;
        }
        i++;
      }
      cout << "]";
    }
    krd_man.Close();
    return 0;
  } else if (operation == "dumpJPCMeta") {
    if (argc < 3) {
      print_help(argv[0]);
      return -1;
    }
    string dev_name(argv[2]);
    int chunk_id = atoi(argv[3]);
    string mongo_ip;
    uint32_t mongo_port;
    assert(argc > 4);
    string mongo_addr(argv[4]);
    vector<string> tmp_vec;
    udisk::common::get_str_vec(mongo_addr, ":", tmp_vec);
    assert(tmp_vec.size() == 2);
    mongo_ip = tmp_vec[0];
    mongo_port = atoi(tmp_vec[1].c_str());

    int journal_id = -1;
    if (argc > 5) {
      journal_id = atoi(argv[5]);
    }
    int ret = krd_man.Open(dev_name);
    if (ret < 0) {
      cout << "open dev error" << endl;
      return -1;
    }
    ret = krd_man.ReadSuperBlock();
    if (ret < 0) {
      cout << "read super block error" << endl;
      krd_man.Close();
      return -1;
    }

    MongoHandle* mongo_handle = new MongoHandle(mongo_ip, mongo_port, chunk_id);
    mongo_handle->Start();

    ULOG_DEBUG << "Main thread wait for mongo response..."; 
    std::unique_lock<std::mutex> lck(g_mutex);
    g_cv.wait(lck, []{return !g_own_pgs.empty();});

    std::map<uint32_t, std::vector<JPCMeta*>> jpc_metas; // pg_id <==> jpcs
    ret = krd_man.ReadAllJPCMeta(&jpc_metas, g_own_pgs.size());
    if (ret < 0) {
      cout << "read journal meta error" << endl;
      krd_man.Close();
      return -1;
    }
    if (journal_id >= 0) {
      //cout << DumpJPCMeta(journal_metas.at(journal_id)) << endl;
    } else {
      for (auto it = jpc_metas.begin(); it != jpc_metas.end(); it++) {
        for(auto iter = it->second.begin(); iter != it->second.end(); iter++) {
          cout << DumpJPCMeta(**iter) << endl;
        }
      }
    }
    krd_man.Close();
    return 0;
  } else if (operation == "dumpLCInfo") {
    if (argc < 4) {
      print_help(argv[0]);
      return -1;
    }

    string dev_name(argv[2]);
    uint32_t lc_id = atoi(argv[3]);
    int ret = krd_man.Open(dev_name);
    if (ret < 0) {
      cout << "open dev error" << endl;
      return -1;
    }

    ret = krd_man.ReadSuperBlock();
    if (ret < 0) {
      cout << "read super block error" << endl;
      krd_man.Close();
      return -1;
    }

    std::vector<struct PCMeta*> pc_meta;
    ret = krd_man.ReadAllPCMeta(pc_meta);
    if (ret < 0) {
      cout << "read pc meta error" << endl;
      krd_man.Close();
      return -1;
    }

    uint32_t start_pc_no = 0;
    uint32_t end_pc_no = -1;
    uint64_t offset = 0;
    if (argc >= 5) {
      offset = convert_to_byte(argv[4]);
      start_pc_no = offset / krd_man.super_block().pc_size;
    }

    if (argc >= 6) {
      uint64_t length = convert_to_byte(argv[5]);
      end_pc_no = (offset + length) / krd_man.super_block().pc_size;
    }

    cout << "[";
    uint32_t i = 0;
    for (auto& it : pc_meta) {
      // 加上use判断，防止lc_id为0时，获取到错误meta
      if (it->lc_id == lc_id && it->pc_no >= start_pc_no &&
          it->pc_no <= end_pc_no && it->is_used == 1) {
        if (i != 0) {
          cout << "," << endl;
        }
        cout << DumpPCMetaJson(*it);
        i++;
      }
    }
    cout << "]";
  } else {
    print_help(argv[0]);
  }
  return 0;
}
