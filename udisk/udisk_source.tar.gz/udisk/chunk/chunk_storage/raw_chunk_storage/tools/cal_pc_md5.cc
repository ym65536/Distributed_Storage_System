#include <iostream>
#include <string>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/mount.h>
#include "md5_digest.h"

using namespace std;

int main(int argc, char** argv) {
  if (argc < 4) {
    cout << argv[0] << " dev_name offset length" << endl;
    cout << argv[0] << " /dev/adz 0 1024" << endl;
    return -1;
  }
  string dev_name(argv[1]);
  uint64_t offset = atol(argv[2]);
  uint64_t length = atoi(argv[3]);
  uint64_t dev_block_size = 0;
  int flags = O_RDWR | O_LARGEFILE | O_DIRECT;
  int fd = open(dev_name.c_str(), flags);
  if (fd < 0) {
    cout << "open dev error, " << dev_name << endl;
    return -1;
  }
  off_t size = lseek(fd, 0, SEEK_END);
  if (size <= 0) {
    cout << "get dev size error, " << dev_name << endl;
    close(fd) ;
    return -1;
  }
  if (ioctl(fd, BLKSSZGET, &dev_block_size) < 0) {
    cout << "get dev block size error" << endl;
    close(fd);
    return -1;
  }
  if ((offset + length) > (uint64_t)size) {
    cout << "size is less than (offset + length), "
         << "offset: " << offset
         << "length: " << length
         << "size: " << size << endl;
    close(fd);
    return -1;
  }
  void* buf = nullptr;
  posix_memalign(&buf, dev_block_size, length);
  memset(buf, 0, length); 
  int64_t ret = pread(fd, buf, length, offset);
  if (ret != (int64_t)length) {
    cout << "read dev error" << endl;
    free(buf);
    close(fd);
    return -1;
  }
  udisk::common::md5digest md5_result;
  udisk::common::md5(buf, length, md5_result);
  cout << udisk::common::digest2string(md5_result) << endl;
  free(buf);
  close(fd);
  return 0;
}
