#include <iostream>
#include <string>
#include <stdlib.h>
#include "kernel_raw_device_manager.h"
#include "raw_chunk_storage_type.h"

using namespace std;

int main(int argc, char** argv) {
  if (argc < 5) {
    cout << argv[0] << " option dev_name offset length" << endl;
    cout << "option: format --格式化detection区" << endl;
    cout << "        reset --清零detection区" << endl;
    cout << argv[0] << " reset /dev/adz 0 1024" << endl;
    return -1;
  }
  string option(argv[1]);
  string dev_name(argv[2]);
  uint64_t offset = atol(argv[3]);
  uint64_t length = atoi(argv[4]);
  udisk::chunk::KernelRawDeviceManager krd_man;
  if (krd_man.Open(dev_name) < 0) {
    cout << "open device error" << endl;
    return -1;
  }
  if (krd_man.ReadSuperBlock() < 0) {
    cout << "read superblock error" << endl;
    krd_man.Close();
    return -1;
  }
  int ret = 0;
  if (option == "format") {
    ret = krd_man.WriteDetectionData(offset);
    if (ret != 0) {
     cout << "format error" << endl;
    }
  } else if (option == "reset") {
    ret = krd_man.ResetZoneData(offset, length);
    if (ret != 0) {
     cout << "reset error" << endl;
    }
  } else {
    cout << "option not support" << endl;
  }
  krd_man.Close();
  return 0;
}
