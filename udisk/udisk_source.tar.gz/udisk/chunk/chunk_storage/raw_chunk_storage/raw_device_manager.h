#ifndef UDISK_CHUNK_RAW_DEVICE_MANAGER_H_
#define UDISK_CHUNK_RAW_DEVICE_MANAGER_H_

#include <string>
#include <vector>
#include <map>
#include <ustevent/callbacks.h>
#include <stdlib.h>
#include "raw_chunk_storage_type.h"

namespace uevent {
class UeventLoop;
};

namespace udisk {
namespace chunk {

class RawDeviceManager {
 public:
  RawDeviceManager(): pc_metas_buf_(nullptr) {}
  virtual ~RawDeviceManager() {
    if (pc_metas_buf_) {
      ::free(pc_metas_buf_);
    }
  }
  RawDeviceManager(const RawDeviceManager &) = delete;
  RawDeviceManager &operator=(const RawDeviceManager &) = delete;

  // 格式化一块设备
  virtual int Format(const std::string &dev_name, uint32_t chunk_id,
                     bool is_reset, bool has_journal, uint32_t pc_size,
                     const std::vector<uint32_t>& own_pgs, uint32_t worker_num) = 0;

  virtual int Open(uint64_t chunk_id, const std::string &dev_uuid, const std::string &dev_prefix) = 0;
  virtual int Open(const std::string &dev_name) = 0;
  virtual void Close() = 0;
  virtual int ReadSuperBlock() = 0;

  // PC zone
  virtual int ReadAllPCMeta(std::vector<struct PCMeta*> &pc_metas) = 0;
  virtual int WritePCMeta(struct PCMeta* pc_meta) = 0;
  virtual int WritePCMeta(uevent::EventLoop* loop, struct PCMeta* pc_meta,
                        uevent::DiskIOCb cb, void* arg) = 0;

  // detection zone
  virtual int WriteDetectionData(uint64_t offset) = 0;
  virtual int CheckDetectionData(uint64_t offset) = 0;

  // journal zone
  virtual int ReadSuperJPCMeta(JPCMeta** jpc_superblock) = 0;
  virtual int ReadAllJPCMeta(std::map<uint32_t, std::vector<JPCMeta*>>* jms,
                             uint32_t pg_size) = 0;
  virtual int WriteAllJPCMeta(const std::vector<uint32_t>& own_pgs,
                              bool is_reset,
                              uint32_t worker_num) = 0;

  const struct SuperBlock &super_block() const { return super_block_; }
  const std::string &dev_name() const { return dev_name_; }
  const uint32_t dev_block_size() const { return dev_block_size_; }
  const uint64_t size() const { return size_; }
  // 将一块区域抹零, 只有在格式化时才会使用
  virtual int ResetZoneData(uint64_t offset, uint64_t length) = 0;
  virtual int ResetJournalData(uint64_t offset, uint64_t length, bool is_reset) = 0;

 protected:
  virtual int WriteSuperBlock(bool has_journal, uint32_t pc_size) = 0;
  virtual int WriteAllPCMeta(bool is_reset) = 0;
  virtual void ConstructSuperBlock(bool has_journal, uint32_t pc_size) = 0;

  uint32_t chunk_id_;
  uint32_t dev_block_size_;
  uint64_t size_;
  std::string dev_name_;
  struct SuperBlock super_block_;
  void* pc_metas_buf_;
};

};  // end of ns chunk
};  // end of ns udisk

#endif
