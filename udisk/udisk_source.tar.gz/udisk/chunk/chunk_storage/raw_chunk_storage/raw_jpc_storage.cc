 #include "raw_jpc_storage.h"
#include <fcntl.h>
#include <unistd.h>
#include "chunk_context.h"
#include "chunk_storage_type.h"
#include "likely.h"

using namespace udisk::journal;
using namespace udisk::chunk;

void RawJPCStorage::Init(int fd, uint32_t pg_id) {
  ULOG_ERROR << "fd=" << fd << ",pg_id=" << pg_id << " not implement.";
  return;
}

void RawJPCStorage::Init(int fd, uint32_t pg_id, const std::vector<JPCMeta*>& jms) {
  fd_ = fd;
  pg_id_ = pg_id;
  for (auto item : jms) {
    if (item->jpc_type == kJPCCompact) {
      compact_pool_[item->jpc_id] = new RawJPCHandle(fd, item->jpc_id, item->offset);
      ULOG_DEBUG << "pg_id=" << pg_id_ << ", Init compact pool. jpc_id=" 
          << item->jpc_id << ", fd=" << fd << ", offset=" << item->offset;
    } else if (item->jpc_type == kJPCPlain) {
      if (item->jpc_id & 1) {
        active_pool_[item->jpc_id] = new RawJPCHandle(fd, item->jpc_id, item->offset);
        active_free_list_.push_back(item->jpc_id);
        ULOG_DEBUG << "pg_id=" << pg_id_ << ",Init active pool. jpc_id=" 
            << item->jpc_id << ", fd=" << fd << ", offset=" << item->offset;
      } else {
        inactive_pool_[item->jpc_id] = new RawJPCHandle(fd, item->jpc_id, item->offset);
        inactive_free_list_.push_back(item->jpc_id);
        ULOG_DEBUG << "pg_id=" << pg_id_ << ",Init inactive pool. jpc_id=" 
            << item->jpc_id << ", fd=" << fd << ", offset=" << item->offset;
      }
    }
  }
  if (compact_pool_.size() != kPGCompactJPCCount) {
    ULOG_FATAL << "pg_id=" << pg_id_ << " journal compact num error";
  }
  ULOG_DEBUG << "pg_id=" << pg_id_ << " Init Raw JPC Storage Success.";
}

RawJPCStorage::RawJPCStorage() : fd_(-1), pg_id_(UINT_MAX), init_swap_(true) {
}

RawJPCStorage::~RawJPCStorage() {
  for (auto item : compact_pool_) {
    delete item.second;
  }
  for (auto item : active_pool_) {
    delete item.second;
  }
  for (auto item : inactive_pool_) {
    delete item.second;
  }
}

JPCHandle* RawJPCStorage::AcquireCompactJPC(uint32_t jpc_id) {
  ULOG_DEBUG << "pg_id=" << pg_id_ << " access compact jpc_id=" << jpc_id;
  if (compact_pool_.count(jpc_id) == 0) {
    ULOG_ERROR << "Can not find compact jpc_id=" << jpc_id;
    return nullptr;
  }
  return compact_pool_[jpc_id];
}

JPCHandle* RawJPCStorage::AcquireActiveJPC(uint32_t jpc_id) {
  ULOG_DEBUG << "pg_id=" << pg_id_ << " access active jpc_id=" << jpc_id 
      << ", free list_size=" << active_free_list_.size();
  if (active_pool_.count(jpc_id) == 0) {
    ULOG_ERROR << "Can not find active jpc_id=" << jpc_id;
    return nullptr;
  }
  auto iter = std::find(active_free_list_.begin(), active_free_list_.end(), jpc_id);
  assert(iter == active_free_list_.end()); // exist必然已经分配过了
  return active_pool_[jpc_id];
}

JPCHandle* RawJPCStorage::AcquireInActiveJPC(uint32_t jpc_id) {
  ULOG_DEBUG << "pg_id=" << pg_id_ << " access inactive jpc_id=" << jpc_id 
      << ", free list_size=" << inactive_free_list_.size();
  if (inactive_pool_.count(jpc_id) == 0) {
    ULOG_ERROR << "Can not find inactive jpc_id=" << jpc_id;
    return nullptr;
  }
  auto iter = std::find(inactive_free_list_.begin(), inactive_free_list_.end(), jpc_id);
  assert(iter == inactive_free_list_.end()); // exist必然还未释放
  return inactive_pool_[jpc_id];
}

JPCHandle* RawJPCStorage::AcquireFreeJPC() {
  if (active_free_list_.empty()) {
    ULOG_DEBUG << "pg_id=" << pg_id_ << " No free jpc left.";
    return nullptr;
  }
  uint32_t jpc_id = active_free_list_.front();
  active_free_list_.pop_front();
  ULOG_DEBUG << "pg_id=" << pg_id_ << " access free jpc_id=" << jpc_id 
      << ", free list_size=" << active_free_list_.size() << ", inactive_free_list=" 
      << inactive_free_list_.size();
  return active_pool_[jpc_id];
}

void RawJPCStorage::UpdateFreeJPC(const uint32_t active_zone[], 
                                  uint32_t active_num,
                                  const uint32_t inactive_zone[],
                                  uint32_t inactive_num) {
  ULOG_DEBUG << "pg_id=" << pg_id_ << " Recv update jpc. active_num=" << active_num;
  for (uint32_t i = 0; i < active_num; ++ i) {
    uint32_t jpc_id = active_zone[i];
    if (init_swap_ && (active_pool_.count(jpc_id) == 0)) {
      init_swap_ = false;
      ULOG_WARN << "pg_id=" << pg_id_ << " Maybe active and inactive swap. reschedule";
      JPCSwap();
    }
    assert(active_pool_.count(jpc_id));
    auto iter = std::find(active_free_list_.begin(), active_free_list_.end(), jpc_id);
    assert(iter != active_free_list_.end());
    ULOG_DEBUG << "pg_id=" << pg_id_ << " Update Free active jpc_id=" << jpc_id;
    active_free_list_.erase(iter);
  }
  ULOG_DEBUG << "pg_id=" << pg_id_ << " Recv update jpc. inactive_num=" << active_num;
  for (uint32_t i = 0; i < inactive_num; ++ i) {
    uint32_t jpc_id = inactive_zone[i];
    assert(inactive_pool_.count(jpc_id));
    auto iter = std::find(inactive_free_list_.begin(), inactive_free_list_.end(), jpc_id);
    assert(iter != inactive_free_list_.end());
    ULOG_DEBUG << "pg_id=" << pg_id_ << " Update Free inactive jpc_id=" << jpc_id;
    inactive_free_list_.erase(iter);
  }
}

void RawJPCStorage::ReleaseJPC(const std::vector<uint32_t>& jpc_ids) {
  for (auto jpc_id : jpc_ids) {
    assert(inactive_pool_.count(jpc_id));
    auto iter = std::find(inactive_free_list_.begin(), inactive_free_list_.end(), jpc_id);
    assert(iter == inactive_free_list_.end());
    inactive_free_list_.push_back(jpc_id);
    auto ret = inactive_pool_[jpc_id]->ResetData();
    assert(ret == UDISK_OK);
    ULOG_DEBUG << "pg_id=" << pg_id_ << " release jpc_id=" << jpc_id << ", free list_size=" 
      << active_free_list_.size() << ", inactive_free_list=" 
      << inactive_free_list_.size();
  }
}

void RawJPCStorage::JPCSwap() {
  active_pool_.swap(inactive_pool_);
  active_free_list_.swap(inactive_free_list_);
  ULOG_DEBUG << "pg_id=" << pg_id_ << " jpc swap. free list_size=" << active_free_list_.size() 
    << ", inactive_free_list=" << inactive_free_list_.size();
}
