#ifndef UDISK_CHUNK_STORAGE_RAW_CHUNK_STORAGE_H_
#define UDISK_CHUNK_STORAGE_RAW_CHUNK_STORAGE_H_

#include <vector>

#include "chunk_storage_type.h"
#include "chunk_pool.h"
#include "raw_chunk_handle.h"
#include "chunk_handle_vec_type.h"

namespace udisk {
namespace chunk {

class RawChunkHandle;

typedef std::vector<ChunkHandleVecType> UDiskRawChunkHandleVec;

class RawChunkStorage : public ChunkStorage {
 public:
  explicit RawChunkStorage();
  virtual ~RawChunkStorage();

  virtual int32_t Init(ChunkPool* chunkPool, uevent::EventLoop *loop);
  // 打开chunk对应的文件fd，并缓存该fd，如果在缓存中没有的话
  virtual int32_t OpenChunk(const ChunkID& id, bool is_create, 
                             OpenChunkCb done);

  virtual int32_t CloseChunk(ChunkHandle* chunkHandle);
  virtual int32_t CreateChunk(const ChunkID& id);
  virtual int32_t DeleteChunk(const ChunkID& id);

 private:
  void GetChunkResCb(int retcode, const ChunkID& chunkID,
                       OpenChunkCb done);
  UDiskRawChunkHandleVec udisk_chunk_handles_;
  bool is_init_;
};

};  // end of namespace chunk
};  // end of namespace udisk

#endif  // UDISK_CHUNK_STORAGE_RAW_CHUNK_STORAGE_H_
