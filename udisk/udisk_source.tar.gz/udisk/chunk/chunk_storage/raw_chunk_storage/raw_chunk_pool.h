#ifndef UDISK_CHUNK_STORAGE_RAW_CHUNK_POOL_H_
#define UDISK_CHUNK_STORAGE_RAW_CHUNK_POOL_H_

#include <deque>
#include <string>
#include <mutex>
#include <unordered_map>
#include <set>

#include "raw_device_manager.h"
#include "raw_chunk_storage_type.h"

#include "chunk_storage_type.h"
#include "chunk_pool.h"
#include "chunk_storage_errorcode.h"

namespace udisk {
namespace chunk {

class RawChunkPool : public ChunkPool {
 public:
  explicit RawChunkPool();
  virtual ~RawChunkPool();
  virtual int32_t Init() override;
  virtual int32_t PutChunk(const ChunkID& chunkID) override;
  virtual int32_t PutChunk(const ChunkID& chunkID, ChunkOpCb done,
                           uevent::EventLoop* loop) override;
  virtual int32_t GetChunk(const ChunkID& chunkID) override;
  // 该方法会判断chunkID是否分配过, 使用前不需要调用Access方法
  virtual int32_t GetChunk(const ChunkID& chunkID, ChunkOpCb done,
                           uevent::EventLoop* loop) override;
  virtual int32_t GetExistChunkByPG(uint32_t pg_id, ChunkIDList* list) override;
  virtual uint64_t GetPoolRemainderCap() override;
  virtual int32_t FormatChunk(const ChunkID& chunkID) override;
  virtual uint32_t dev_block_size() const override;
  virtual uint32_t pc_size() const override;

  virtual bool Access(const ChunkID& chunkID) override;
  virtual int Open(const ChunkID& chunkID, uint64_t* offset) override;
  virtual std::string DumpChunkPoolInfo() override;
  
  RawDeviceManager* dev_manager() const {
    return dev_manager_;
  } 

 private:
  typedef std::unordered_map<ChunkID, struct PCMeta*, ChunkIDHash> ChunkPCMap;

  struct PCMetaArgs {
    uint64_t seq_no;      // -1 表示put_cb
    ChunkID chunk_id;
    PCMeta* pc;
    ChunkOpCb done;
    uevent::EventLoop* loop;
    RawChunkPool* pobj;
  };

  bool AccessNoLock(const ChunkID& chunkID);
  bool FindPCNoLock(struct PCMeta** pc);
  static void WritePCMetaResCb(int retcode, void* arg);
  int32_t DispatchPCPendingList();
  void SetUsePCMeta(const ChunkID& chunk_id, uint64_t seq_no, PCMeta* pc);
  void SetFreePCMeta(PCMeta* pc);
  bool IsNeedPendingPC(uint64_t pc_id);
  bool IsNeedPendingChunk(const ChunkID& chunk_id);
  bool IsNeedPendingPCAgain(uint64_t pc_id);
  int32_t AddFreePCNoLock(PCMeta* pc, const ChunkID& chunk_id);
  int32_t AddUsePCNoLock(PCMeta* pc, const ChunkID& chunk_id);
  void SendChunkPendingListResult(const ChunkID& chunk_id, int32_t retcode);
  int32_t UpdatePCMeta(PCMetaArgs* meta);

  RawDeviceManager* dev_manager_;

  // 相同的chunkID只允许一个写元数据
  struct ChunkPendingArgs {
    ChunkOpCb done;
    uevent::EventLoop* loop;
  };
  std::unordered_multimap<ChunkID, ChunkPendingArgs, ChunkIDHash> chunk_pending_list_;

  std::deque<PCMetaArgs*> pc_pending_list_;
  std::unordered_map<uint64_t, ChunkID> pc_inflying_list_;
  struct FreePCCompare {
    bool operator() (const PCMeta* lpc, const PCMeta* rpc) const {
      return lpc->pc_id < rpc->pc_id;
    }
  };

  // 空闲pc的集合
  std::set<struct PCMeta*, FreePCCompare> free_pcs_;
  uint64_t find_next_pc_id_;
  // 使用中的pc集合
  // key 为pg id
  // 6T的块设备该结构大小大约为10M
  std::unordered_map<uint32_t, ChunkPCMap> used_pcs_;

  uint64_t cur_seq_no_;
  int fd_;
  std::mutex mtx_;
  bool is_init_;
};

};  // end of namespace chunk
};  // end of namespace udisk

#endif  // UDISK_CHUNK_STORAGE_RAW_CHUNK_POOL_H_
