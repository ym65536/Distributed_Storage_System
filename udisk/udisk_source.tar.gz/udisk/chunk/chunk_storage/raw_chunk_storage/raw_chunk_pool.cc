#include "raw_chunk_pool.h"

#include <unistd.h>
#include <dirent.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <stdio.h>
#include <string.h>
#include <algorithm>

#include <ustevent/base/logging.h>
#include <ustevent/disk_io_util.h>
#include <ustevent/base/my_uuid.h>
#include "udisk_types.h"
#include "chunk_storage_type.h"
#include "str_list.h"
#include "chunk_context.h"
#include "kernel_raw_device_manager.h"

namespace udisk {
namespace chunk {

static const uint64_t kPutChunkSeqNo = 0xFFFFFFFFFFFFFFFF;

RawChunkPool::RawChunkPool()
    : find_next_pc_id_(0),
      cur_seq_no_(0),
      fd_(-1),
      is_init_(false) {
  // TODO(alan.ding) 根据输入类型创建对应设备管理类
  dev_manager_ = new KernelRawDeviceManager();
}

RawChunkPool::~RawChunkPool() {
  if (dev_manager_) {
    delete dev_manager_;
  }
}

int32_t RawChunkPool::Init() {
  if (is_init_) {
    ULOG_ERROR << "raw chunk pool has inited";
    return UDISK_ALREADY_INIT;
  }
  fd_ = dev_manager_->Open(g_context->config().my_id(),
                           g_context->config().device_uuid(),
                           g_context->config().device_prefix());
  if (fd_ < 0) {
    ULOG_SYSERR << "open dev error";
    return UDISK_DISK_ERROR;
  }
  std::vector<struct PCMeta*> pcs;
  if (dev_manager_->ReadAllPCMeta(pcs) != 0) {
    ULOG_ERROR << "read all pc meta error";
    return UDISK_DISK_ERROR;
  }
  ULOG_INFO << DumpSuperBlock(dev_manager_->super_block());
  ULOG_INFO << "total pc num: " << pcs.size();
  for (auto it = pcs.begin(); it != pcs.end(); it++) {
    if ((*it)->is_used == 0) {
      auto ret = free_pcs_.emplace(*it);
      if (!ret.second) {
        ULOG_WARN << "there are two same pc metas in free pcs"
                  << " pc_id: " << (*it)->pc_id
                  << " seq_no: " << (*it)->seq_no
                  << " pc_id: " << (*ret.first)->pc_id
                  << " sqe_no: " << (*ret.first)->seq_no;
      }
    } else {
      ChunkID chunkid((*it)->pg_id, (*it)->lc_id,
                      (*it)->pc_no, (*it)->lc_random_id);
      if (cur_seq_no_ < (*it)->seq_no) {
        cur_seq_no_ = (*it)->seq_no;
      }
      auto used_pcs_it = used_pcs_.find((*it)->pg_id);
      if (used_pcs_it == used_pcs_.end()) {
        ChunkPCMap chunk_pc;
        chunk_pc.insert(std::make_pair(chunkid, *it));
        used_pcs_.insert(std::make_pair((uint32_t)(*it)->pg_id, chunk_pc));
      } else {
        auto result = used_pcs_it->second.insert(std::make_pair(chunkid, *it));
        if (!result.second) {
          ULOG_WARN << "there are two same pc metas"
                    << " pc_id: " << (*it)->pc_id
                    << " seq_no: " << (*it)->seq_no
                    << " pc_id: " << result.first->second->pc_id
                    << " sqe_no: " << result.first->second->seq_no
                    << " will use sqe_no bigger";
          // 同一个chunkID对应的多个PC，seq_no最大的PC有效
          if ((*it)->seq_no > result.first->second->seq_no) {
            (used_pcs_it->second)[chunkid] = *it;
          }
        }
      }
    }
  }
  cur_seq_no_++;
  ULOG_INFO << "free pc num: " << free_pcs_.size();
  is_init_ = true;
  return UDISK_OK;
}

int32_t RawChunkPool::PutChunk(const ChunkID& chunkID, ChunkOpCb done,
                               uevent::EventLoop* loop) {
  ULOG_TRACE << "PutChunk" << DumpChunkID(chunkID);
  if (!is_init_) {
    ULOG_ERROR << "pc pool is not inited";
    return UDISK_NOT_INIT;
  }

  PCMetaArgs* meta_args = nullptr;
  {
    ULOG_TRACE << "PutChunk lock. before " << DumpChunkID(chunkID);
    std::lock_guard<std::mutex> lck(mtx_);
    ULOG_TRACE << "PutChunk lock. after" << DumpChunkID(chunkID);
    auto used_pcs_it = used_pcs_.find(chunkID.pg_id);
    if (used_pcs_it == used_pcs_.end()) {
      ULOG_TRACE << "PutChunk unlock. " << DumpChunkID(chunkID);
      return UDISK_PC_NOT_EXIST_ERROR;
    }
    auto it = used_pcs_it->second.find(chunkID);
    if (it == used_pcs_it->second.end()) {
      ULOG_TRACE << "PutChunk unlock. " << DumpChunkID(chunkID);
      return UDISK_PC_NOT_EXIST_ERROR;
    }

    ULOG_TRACE << "chunkID: " << DumpChunkID(chunkID)
               << " put pc, pc id: " << it->second->pc_id;
    meta_args = new PCMetaArgs();
    meta_args->pc = it->second;
    meta_args->chunk_id = chunkID; // 从删除used_pcs时，需要pg_id
    meta_args->seq_no = kPutChunkSeqNo;
    meta_args->loop = loop;
    meta_args->pobj = this;
    meta_args->done = std::move(done);
    if (IsNeedPendingPC(meta_args->pc->pc_id)) {
      ULOG_TRACE << "PutChunk put into pc pending list. "
                 << DumpChunkID(chunkID)
                 << " pc_id:" << meta_args->pc->pc_id;
      pc_pending_list_.push_back(meta_args);
      ULOG_TRACE << "PutChunk unlock. " << DumpChunkID(chunkID);
      return UDISK_OK;
    }

    // 由于pc_id在PCMeta中使用了字节对齐属性，不强转转换类型,
    // 直接作为unordered_map 的key, 编译不能通过
    pc_inflying_list_.insert(std::make_pair((uint64_t)meta_args->pc->pc_id,
                                            chunkID));
    ULOG_TRACE << "PutChunk unlock. " << DumpChunkID(chunkID);
  }

  return UpdatePCMeta(meta_args);
}

int32_t RawChunkPool::PutChunk(const ChunkID& chunkID) {
  return UDISK_NOT_IMPLEMENTED;
}

int32_t RawChunkPool::GetChunk(const ChunkID& chunkID) {
  return UDISK_NOT_IMPLEMENTED;
}

bool RawChunkPool::IsNeedPendingPC(uint64_t pc_id) {
  uint32_t pc_meta_size = dev_manager_->super_block().pc_meta_size;
  uint32_t pc_num_per_dev_block = dev_block_size() / pc_meta_size;
  uint32_t start_pc_id = pc_id - (pc_id % pc_num_per_dev_block);
  uint32_t end_pc_id = start_pc_id + pc_num_per_dev_block;
  for (; start_pc_id < end_pc_id; ++start_pc_id) {
    if (pc_inflying_list_.find(start_pc_id) != pc_inflying_list_.end()) {
      ULOG_TRACE << "Exist pc_id in write_inflying_list, pc_id:"
                 << start_pc_id;
      return true;
    }

    for (auto it : pc_pending_list_) {
      if (start_pc_id == it->pc->pc_id) {
        ULOG_TRACE << "Exist pc_id in write_pending_list, pc_id:"
                   << start_pc_id;
        return true;
      }
    }
  }

  return false;
}

bool RawChunkPool::IsNeedPendingPCAgain(uint64_t pc_id) {
  uint32_t pc_meta_size = dev_manager_->super_block().pc_meta_size;
  uint32_t pc_num_per_dev_block = dev_block_size() / pc_meta_size;
  uint32_t start_pc_id = pc_id - (pc_id % pc_num_per_dev_block);
  uint32_t end_pc_id = start_pc_id + pc_num_per_dev_block;
  for (; start_pc_id < end_pc_id; ++start_pc_id) {
    if (pc_inflying_list_.find(start_pc_id) != pc_inflying_list_.end()) {
      ULOG_TRACE << "Exist pc_id in write_inflying_list, pc_id:"
                 << start_pc_id;
      return true;
    }
  }

  return false;
}

void RawChunkPool::SetFreePCMeta(PCMeta* pc) {
  pc->is_used = 0;
  pc->seq_no = 0;
  pc->pg_id = 0;
  pc->lc_id = 0;
  pc->pc_no = 0;
  pc->lc_random_id = 0;
  pc->allocate_time = 0;
}

void RawChunkPool::SetUsePCMeta(const ChunkID& chunk_id,
                                uint64_t seq_no, PCMeta* pc) {
  pc->is_used = 1;
  pc->seq_no = seq_no;
  pc->pg_id = chunk_id.pg_id;
  pc->lc_id = chunk_id.lc_id;
  pc->pc_no = chunk_id.pc_no;
  pc->lc_random_id = chunk_id.lc_random_id;
  pc->allocate_time = base::Timestamp::now().secondsSinceEpoch();
}

bool RawChunkPool::IsNeedPendingChunk(const ChunkID& chunk_id) {
  for (auto it : pc_inflying_list_) {
    if (chunk_id == it.second) {
      ULOG_TRACE << "Exist chunk_id is in write_inflying_list";
      return true;
    }
  }

  for (auto it : pc_pending_list_) {
    if (chunk_id == it->chunk_id) {
      ULOG_TRACE << "Exist chunk_id is in write_pending_list";
      return true;
    }
  }

  return false;
}

int32_t RawChunkPool::GetChunk(const ChunkID& chunkID, ChunkOpCb done,
                               uevent::EventLoop* loop) {
  ULOG_TRACE << "GetChunk" << DumpChunkID(chunkID);
  if (!is_init_) {
    ULOG_ERROR << "pc pool is not inited";
    return UDISK_NOT_INIT;
  }

  PCMetaArgs* meta_args = nullptr;
  {
    ULOG_TRACE << "GetChunk lock. before" << DumpChunkID(chunkID);
    std::lock_guard<std::mutex> lck(mtx_);
    if (AccessNoLock(chunkID) == true) {
      return UDISK_CHUNKID_IS_USED;
    }

    // 对于同一个chunkID的多个请求，只有个一个请求会分配PC
    if (IsNeedPendingChunk(chunkID)) {
      ULOG_TRACE << "GetChunk put into chunkID pending list" << DumpChunkID(chunkID);
      ChunkPendingArgs chunk_args = {done, loop};
      chunk_pending_list_.insert(std::make_pair(chunkID, chunk_args));
      ULOG_TRACE << "GetChunk unlock." << DumpChunkID(chunkID);
      return UDISK_OK;
    }

    meta_args = new PCMetaArgs();
    if (!FindPCNoLock(&meta_args->pc)) {
      delete meta_args;
      ULOG_TRACE << "GetChunk unlock." << DumpChunkID(chunkID);
      return UDISK_ZERO_PC_ERROR;
    }

    ULOG_TRACE << "chunkID: " << DumpChunkID(chunkID)
              << " get pc, pc id: " << meta_args->pc->pc_id 
              << " free pc size:" << free_pcs_.size();
    meta_args->chunk_id = chunkID;
    meta_args->seq_no = cur_seq_no_;
    meta_args->loop = loop;
    meta_args->pobj = this;
    meta_args->done = std::move(done);
    cur_seq_no_++;
    // 对于元数据同属于一个dev_block的PC，写元数据时需要排队
    if (IsNeedPendingPC(meta_args->pc->pc_id)) {
      ULOG_TRACE << "GetChunk put into pc pending list. "
                 << DumpChunkID(chunkID)
                 << " pc_id:" << meta_args->pc->pc_id;
      pc_pending_list_.push_back(meta_args);
      ULOG_TRACE << "GetChunk unlock." << DumpChunkID(chunkID);
      return UDISK_OK;
    }

    pc_inflying_list_.insert(std::make_pair((uint64_t)meta_args->pc->pc_id, chunkID));
    ULOG_TRACE << "GetChunk unlock." << DumpChunkID(chunkID);
  }

  return UpdatePCMeta(meta_args);
}

int32_t RawChunkPool::FormatChunk(const ChunkID& chunkID) {
  return UDISK_NOT_IMPLEMENTED;
}

int32_t RawChunkPool::GetExistChunkByPG(uint32_t pg_id, ChunkIDList* list) {
  list->clear();
  ULOG_TRACE << "GetExistChunkByPG lock before. pg_id:" << pg_id;
  std::lock_guard<std::mutex> lck(mtx_);
  ULOG_TRACE << "GetExistChunkByPG lock after. pg_id:" << pg_id;
  auto used_pcs_it = used_pcs_.find(pg_id);
  // pg 内 pc 为空不是错误
  if (used_pcs_it == used_pcs_.end()) {
    ULOG_TRACE << "GetExistChunkByPG unlock. pg_id:" << pg_id;
    return UDISK_OK;
  }
  for (auto it = used_pcs_it->second.begin(); it != used_pcs_it->second.end();
       it++) {
    list->push_back(it->first);
  }
  ULOG_TRACE << "GetExistChunkByPG unlock. pg_id:" << pg_id;
  return UDISK_OK;
}

bool RawChunkPool::AccessNoLock(const ChunkID& chunkID) {
  auto used_pcs_it = used_pcs_.find(chunkID.pg_id);
  if (used_pcs_it == used_pcs_.end()) {
    ULOG_TRACE << "Access unlock" << DumpChunkID(chunkID);
    return false;
  }
  auto it = used_pcs_it->second.find(chunkID);
  if (it == used_pcs_it->second.end()) {
    ULOG_TRACE << "Access unlock" << DumpChunkID(chunkID) << "used_pcs chunk size :" << used_pcs_it->second.size();
    return false;
  }
  if (UNLIKELY(it->first.lc_random_id != chunkID.lc_random_id)) {
    ULOG_FATAL << "two random_ids are different";
    return false;
  }

  return true;
}

bool RawChunkPool::Access(const ChunkID& chunkID) {
  std::lock_guard<std::mutex> lck(mtx_);
  return AccessNoLock(chunkID);
}

int RawChunkPool::Open(const ChunkID& chunkID, uint64_t* offset) {
  ULOG_TRACE << "Open lock before." << DumpChunkID(chunkID);
  std::lock_guard<std::mutex> lck(mtx_);
  ULOG_TRACE << "Open lock after." << DumpChunkID(chunkID);
  auto used_pcs_it = used_pcs_.find(chunkID.pg_id);
  if (used_pcs_it == used_pcs_.end()) {
    ULOG_TRACE << "Open unlock" << DumpChunkID(chunkID);
    return UDISK_PC_NOT_EXIST_ERROR;
  }
  auto it = used_pcs_it->second.find(chunkID);
  if (it == used_pcs_it->second.end()) {
    ULOG_TRACE << "Open unlock" << DumpChunkID(chunkID);
    return UDISK_PC_NOT_EXIST_ERROR;
  }

  *offset = it->second->offset;
  ULOG_TRACE << "Open unlock" << DumpChunkID(chunkID);
  return fd_;
}

bool RawChunkPool::FindPCNoLock(struct PCMeta** pc) {
  if (free_pcs_.empty()) {
    ULOG_ERROR << "pc pool is empty";
    return false;
  }

  struct PCMeta fpc;
  fpc.pc_id = find_next_pc_id_;
  auto it = free_pcs_.lower_bound(&fpc);
  if (it == free_pcs_.end()) {
    fpc.pc_id = 0;
    it = free_pcs_.lower_bound(&fpc);
  }

  if (it == free_pcs_.end()) {
    ULOG_ERROR << "impossible, free_pcs is not empty, but cann't find."
               << "find_next_pc_id:" << fpc.pc_id;
    return false;
  }

  uint32_t pc_meta_size = dev_manager_->super_block().pc_meta_size;
  uint32_t pc_num_per_dev_block = std::max(dev_block_size(), kAlignmentSize)
                                                   / pc_meta_size;
  uint32_t next_pc_index = (*it)->pc_id + pc_num_per_dev_block;
  find_next_pc_id_ = next_pc_index - (next_pc_index) % pc_num_per_dev_block;
  *pc = *it;
  free_pcs_.erase(it);
  return true;
}

// 不要求精确，无需加锁
uint64_t RawChunkPool::GetPoolRemainderCap() {
  uint64_t cap = 0;
  cap = free_pcs_.size() * pc_size();
  return cap;
}

int32_t RawChunkPool::UpdatePCMeta(PCMetaArgs* meta) {
  if (meta->seq_no == kPutChunkSeqNo) {
    SetFreePCMeta(meta->pc);
  } else {
    SetUsePCMeta(meta->chunk_id, meta->seq_no, meta->pc);
  }

  if (dev_manager_->WritePCMeta(meta->loop, meta->pc,
                                WritePCMetaResCb, meta) != 0) {
    {
      ULOG_TRACE << "UpdatePCMeta lock before." << DumpChunkID(meta->chunk_id);
      std::lock_guard<std::mutex> lck(mtx_);
      ULOG_TRACE << "UpdatePCMeta lock after." << DumpChunkID(meta->chunk_id);
      pc_inflying_list_.erase(meta->pc->pc_id);
      ULOG_TRACE << "UpdatePCMeta unlock." << DumpChunkID(meta->chunk_id);
    }

    meta->done(UDISK_DISK_ERROR);
    delete meta;
    DispatchPCPendingList();
    return UDISK_DISK_ERROR;
  }

  return UDISK_OK;
}

int32_t RawChunkPool::DispatchPCPendingList() {
  vector<PCMetaArgs*> meta_args;
  {
    ULOG_TRACE << "DispatchPCPendingList lock before.";
    std::lock_guard<std::mutex> lck(mtx_);
    ULOG_TRACE << "DispatchPCPendingList lock after.";
    if (pc_pending_list_.empty()) {
      ULOG_TRACE << "DispatchPCPendingList unlock";
      return UDISK_OK;
    }

    ULOG_TRACE << "The number of pc pending list:" << pc_pending_list_.size();
    for (auto it = pc_pending_list_.begin(); it != pc_pending_list_.end();) {
      if (!IsNeedPendingPCAgain((*it)->pc->pc_id)) {
        pc_inflying_list_.insert(std::make_pair((uint64_t)(*it)->pc->pc_id,
                                                (*it)->chunk_id));
        meta_args.push_back(*it);
        it = pc_pending_list_.erase(it);
        continue;
      }

      ++it;
    }
    ULOG_TRACE << "DispatchPCPendingList unlock";
  }

  if (meta_args.empty()) {
    return UDISK_OK;
  }

  for (auto meta : meta_args) {
    ULOG_TRACE << "Dispatch pending pc:" << meta->pc->pc_id;
    meta->loop->RunInLoop(
        std::bind(&RawChunkPool::UpdatePCMeta, this, meta));
  }

  return UDISK_OK;
}

int32_t RawChunkPool::AddFreePCNoLock(PCMeta* pc, const ChunkID& chunk_id) {
  auto used_pcs_it = used_pcs_.find(chunk_id.pg_id);
  if (used_pcs_it == used_pcs_.end()) {
    ULOG_ERROR << "can't find pg in used, pg_id:"
               << chunk_id.pg_id;
    if (free_pcs_.find(pc) != free_pcs_.end()) {
      ULOG_WARN << "pc is in free pcs. pc_id:" << pc->pc_id;
      return UDISK_OK;
    }

    return UDISK_DISK_ERROR;
  }

  auto it = used_pcs_it->second.find(chunk_id);
  if (it == used_pcs_it->second.end()) {
    ULOG_ERROR << "can't find pg in used, pg_id:"
               << chunk_id.pg_id;
    if (free_pcs_.find(pc) != free_pcs_.end()) {
      ULOG_WARN << "pc is in free pcs. pc_id:" << pc->pc_id;
      return UDISK_OK;
    }

    return UDISK_DISK_ERROR;
  }

  used_pcs_it->second.erase(it);
  auto ret = free_pcs_.emplace(pc);
  if (!ret.second) {
    ULOG_WARN << "there are two same pc metas in free pcs"
              << " pc_id: " << pc->pc_id
              << " seq_no: " << pc->seq_no
              << " pc_id: " << (*ret.first)->pc_id
              << " sqe_no: " << (*ret.first)->seq_no;
  }

  return UDISK_OK;
}

int32_t RawChunkPool::AddUsePCNoLock(PCMeta* pc, const ChunkID& chunk_id) {
  ULOG_INFO << "Add use pc. chunkid: " << DumpChunkID(chunk_id)
            << "; pc meta:" << DumpPCMeta(*pc);
  auto used_pcs_it = used_pcs_.find(pc->pg_id);
  if (used_pcs_it == used_pcs_.end()) {
    ChunkPCMap chunk_pc;
    chunk_pc.insert(std::make_pair(chunk_id, pc));
    used_pcs_.insert(std::make_pair((uint32_t)(pc->pg_id), chunk_pc));
  } else {
    auto result = used_pcs_it->second.insert(std::make_pair(chunk_id, pc));
    if (!result.second) {
      ULOG_FATAL << "insert chunkid error" << DumpChunkID(chunk_id);
      return UDISK_DISK_ERROR;
    }
  }

  return UDISK_OK;
}

void RawChunkPool::SendChunkPendingListResult(const ChunkID& chunk_id,
                                              int32_t retcode) {
  bool is_same_loop = true;
  std::list<ChunkPendingArgs> args;
  {
    uevent::EventLoop* loop = nullptr;
    ULOG_TRACE << "SendChunkPendingListResult lock before." << DumpChunkID(chunk_id);
    std::lock_guard<std::mutex> lck(mtx_);
    ULOG_TRACE << "SendChunkPendingListResult lock after." << DumpChunkID(chunk_id);
    auto it2 = chunk_pending_list_.find(chunk_id);
    while (it2 != chunk_pending_list_.end()) {
      if (loop == nullptr) {
        loop = it2->second.loop;
      } else if (loop->thread_id() != it2->second.loop->thread_id()){
        is_same_loop = false;
      }
      args.push_back(it2->second);
      chunk_pending_list_.erase(it2);
      it2 = chunk_pending_list_.find(chunk_id);
    }
    ULOG_TRACE << "SendChunkPendingListResult unlock." << DumpChunkID(chunk_id);
  }

  if (UNLIKELY(!args.empty())) {
    ULOG_TRACE << "GetChunk put into pending list" << DumpChunkID(chunk_id)
               << "; size:" << args.size() << "; is_same_loop:" << is_same_loop;
  }

  // 同一ChunkID业务逻辑确保在一个线程中，其loop是相同的，可直接回调
  // 如果在udisk连接线程发生切换的瞬间进入此逻辑，可能存在不同loop，
  // 由于高性能存在两个线程操作同一个chunkID的逻辑，所以都返回实际结果
  //if (UNLIKELY(is_same_loop == false)) {
  //  ULOG_ERROR << "There are different loop to open chunk:" << DumpChunkID(chunk_id)
  //             << "; will return error";
  //  retcode = UDISK_DISK_ERROR;
  //}

  for (auto it3 = args.begin(); it3 != args.end(); it3++) {
    it3->loop->RunInLoop(
        std::bind(it3->done, retcode));
  }
}

void RawChunkPool::WritePCMetaResCb(int retcode, void* arg) {
  auto meta_args = std::unique_ptr<PCMetaArgs>(reinterpret_cast<PCMetaArgs*>(arg));
  bool put_pc = (meta_args->seq_no == kPutChunkSeqNo);
  ULOG_TRACE << DumpChunkID(meta_args->chunk_id);
  if (retcode != (int32_t)meta_args->pobj->dev_block_size()) {
    ULOG_ERROR << "write pc meta error"
              << "pc id: " << meta_args->pc->pc_id
              << "lc id: " << meta_args->pc->lc_id
              << "pc no: " << meta_args->pc->pc_no;
    {
      ULOG_TRACE << "WritePCMetaResCb lock before.";
      std::lock_guard<std::mutex> lck(meta_args->pobj->mtx_);
      ULOG_TRACE << "WritePCMetaResCb lock after.";
      meta_args->pobj->pc_inflying_list_.erase(meta_args->pc->pc_id);
      ULOG_TRACE << "WritePCMetaResCb unlock.";
    }

    meta_args->done(UDISK_DISK_ERROR);
    if (!put_pc) {
      meta_args->pobj->SendChunkPendingListResult(meta_args->chunk_id,
                                                  UDISK_DISK_ERROR);
    }

    meta_args->pobj->DispatchPCPendingList();
    return;
  }

  int32_t ret = UDISK_OK;
  {
    ULOG_TRACE << "WritePCMetaResCb lock before.";
    std::lock_guard<std::mutex> lck(meta_args->pobj->mtx_);
    ULOG_TRACE << "WritePCMetaResCb lock after.";
    meta_args->pobj->pc_inflying_list_.erase(meta_args->pc->pc_id);
    if (put_pc) {
      ret = meta_args->pobj->AddFreePCNoLock(meta_args->pc,
                                             meta_args->chunk_id);
    } else {
      ret = meta_args->pobj->AddUsePCNoLock(meta_args->pc,
                                            meta_args->chunk_id);
    }
    ULOG_TRACE << "WritePCMetaResCb unlock.";
  }

  meta_args->done(ret);
  ULOG_TRACE << "WritePCMetaResCb, chunkID: " << DumpChunkID(meta_args->chunk_id)
             << " pc id: " << meta_args->pc->pc_id;
  if (!put_pc) {
    meta_args->pobj->SendChunkPendingListResult(meta_args->chunk_id, ret);
  }

  meta_args->pobj->DispatchPCPendingList();
}
uint32_t RawChunkPool::dev_block_size() const {
  if (!is_init_) {
    ULOG_ERROR << "pc pool is not inited";
    return kErrorDevBlockSize;
  }
  return dev_manager_->dev_block_size();
}

uint32_t RawChunkPool::pc_size() const {
  if (!is_init_) {
    ULOG_ERROR << "pc pool is not inited";
    return kErrorPCSize;
  }
  return dev_manager_->super_block().pc_size;
}

std::string RawChunkPool::DumpChunkPoolInfo() {
  if (!is_init_) {
    ULOG_ERROR << "pc pool is not inited";
    return "";
  }
  std::stringstream ss;
  ULOG_TRACE << "DumpChunkPoolInfo lock before.";
  std::lock_guard<std::mutex> lck(mtx_);
  ULOG_TRACE << "DumpChunkPoolInfo lock after.";
  ss << "{\n";
  ss << "\"free_pc_size\" : " << free_pcs_.size() << ",\n";
  ss << "\"chunkid_pc_map\" : [\n";
  size_t i = 0;
  size_t j = 0;
  ULOG_INFO << used_pcs_.size();
  for (auto it1 = used_pcs_.begin(); it1 != used_pcs_.end(); it1++) {
    j = 0;
    for (auto it2 = it1->second.begin(); it2 != it1->second.end(); it2++) {
      ss << "{\n";
      ss << "\"lc_id\" : " << it2->first.lc_id << ",\n";
      ss << "\"lc_random_id\" : " << it2->first.lc_random_id << ",\n";
      ss << "\"pc_no\" : " << it2->first.pc_no << ",\n";
      ss << "\"pc_id\" : " << it2->second->pc_id << "\n";
      ULOG_INFO << it1->second.size();
      ULOG_INFO << i << " " << j;
      if ((i == used_pcs_.size() - 1) && (j == it1->second.size() - 1)) {
        ss << "}\n";
      }
      else {
        ss << "},\n";
      }
      j++;
    }
    i++;
  }
  ss << "]\n";
  ss << "}\n";
  ULOG_TRACE << "DumpChunkPoolInfo unlock.";
  return ss.str();
}

};  // end of namespace chunk
};  // end of namespace udisk

