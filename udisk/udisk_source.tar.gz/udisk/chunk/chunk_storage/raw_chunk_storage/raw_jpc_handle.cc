#include <errno.h>
#include <ustevent/base/logging.h>
#include "chunk_storage_errorcode.h"
#include "udisk_types.h"
#include "likely.h"
#include "raw_jpc_handle.h"
#include "raw_chunk_storage_type.h"
#include "journal_format.h"

using namespace udisk::journal;
using namespace udisk::chunk;

RawJPCHandle::RawJPCHandle(int fd, uint32_t jpc_id, uint64_t offset): 
    fd_(fd), jpc_id_(jpc_id), base_offset_(offset) {
}

uint32_t RawJPCHandle::JPCSize() const {
  return kJPCSize;
}

uint32_t RawJPCHandle::GetID() const {
  return jpc_id_;
}

int32_t RawJPCHandle::PRead(void* data, uint64_t offset, uint64_t len, 
                            uevent::DiskIOCb cb, void* arg, 
                            uevent::EventLoop* loop) {
  if (UNLIKELY((offset + len) > JPCSize())) {
    ULOG_FATAL << "beyond range. offset: " << offset << " length: " << len;
    return UDISK_INTERNAL_ERROR;
  }
  ULOG_TRACE << "fd=" << fd_ << ", jpc_id=" << jpc_id_ << ", base_offset=" 
      << base_offset_ << ", offset=" << offset << ", length=" << len;
  int32_t ret = 0;
  if ((cb == nullptr) || (loop == nullptr)) { // sync mode
    ret = pread(fd_, data, len, base_offset_ + offset);
    if (ret != (int32_t)len) {
      ULOG_SYSERR << "JPC READ ERROR. length: " << len << ", ret code:" << ret
          << ", fd:" << fd_ << ", offset :" << offset;
      return UDISK_IO_ERROR;
    }
  } else {
    int ret = loop->disk_io_util()->SubmitRead(
                            fd_, data, base_offset_ + offset, len, cb, arg);
    if (ret <= 0) {
      ULOG_SYSERR << "JPC READ ERROR. length: " << len << ", ret code:" << ret
          << ", fd:" << fd_ << ", offset :" << offset;
      return UDISK_IO_ERROR;
    }
  }

  return UDISK_OK;
}

int32_t RawJPCHandle::PWrite(const void* data, uint64_t offset, uint64_t len, 
                             uevent::DiskIOCb cb, void* arg, 
                             uevent::EventLoop* loop) {
  if (UNLIKELY((offset + len) > JPCSize())) {
    ULOG_FATAL << "beyond range. offset: " << offset << " length: " << len;
    return UDISK_INTERNAL_ERROR;
  }
  ULOG_TRACE << "fd_=" << fd_ << ", jpc_id=" << jpc_id_ << ", base_offset=" 
      << base_offset_ << ", offset=" << offset << ", length=" << len;
  int32_t ret;
  if ((cb == nullptr) || (loop == nullptr)) {
    ret = pwrite(fd_, data, len, base_offset_ + offset);
    if (ret != (int32_t)len) {
      ULOG_SYSERR << "JPC WRITE ERROR. length: " << len << ", ret code:" << ret
          << ", fd:" << fd_ << ", offset :" << offset;
      return UDISK_IO_ERROR;
    }
  } else {
    int ret = loop->disk_io_util()->SubmitWrite(
                        fd_, (void*)data, base_offset_ + offset, len, cb, arg);
    if (ret <= 0) {
      ULOG_ERROR << "JPC WRITE ERROR. length: " << len << ", ret code:" << ret
          << ", fd:" << fd_ << ", offset :" << offset;
      return UDISK_IO_ERROR;
    }
  }

  return UDISK_OK;
}

int RawJPCHandle::ResetData() {
  uint64_t length = BLOCK_SIZE;
  char* buffer = nullptr;
  posix_memalign((void**)&buffer, BLOCK_SIZE, length);
  assert(buffer);
  ::memset(buffer, 0, length);
  ::memcpy(buffer, kEnding, kEndingSize);
  ULOG_TRACE << "Reset data. fd_=" << fd_ << ", jpc_id=" << jpc_id_ 
      << ", base_offset=" << base_offset_ << ", length=" << length;
  int64_t ret = ::pwrite(fd_, buffer, length, base_offset_);
  if (ret != (int64_t)length) {
    ULOG_SYSERR << "Pwrite error, ret=" << ret << ", need length=" << length;
    free(buffer);
    return UDISK_DISK_ERROR;
  }
  free(buffer);
  return UDISK_OK;
}

