#ifndef UDISK_CHUNK_RAW_CHUNK_STORAGE_TYPE_H_
#define UDISK_CHUNK_RAW_CHUNK_STORAGE_TYPE_H_

#include <iostream>
#include <sstream>
#include <string>

namespace udisk {
namespace chunk {

const uint32_t kSuperBlockSize = 4096;
const uint32_t kPCMetaSize = 64;
const uint32_t kRawMagic = 0xa1b2c3d4;
const uint64_t kRawVersion = 1;

const uint32_t kDetectionSize = 4096;
// 每多大的PC拥有一个detection，该值应为PC size的整数倍
const uint64_t kDetectionPerPCSize = (32 << 20);
const char kMagicChar = '8';

// 所有pc的offset应该是max(kAlignmentSize, dev_block_size)的整数倍
const uint32_t kAlignmentSize = 4096;

// journal zone
const uint32_t kJPCNum = 1320;
const uint32_t kPGCompactJPCCount = 2;
const uint64_t kJPCSize = (128 << 20);
const uint32_t kJournalSuperBlockID = 0;
enum JPCType {
  kJPCPlain = 1,
  kJPCCompact = 2,
  kJPCSuperBlock = 3,
};

// SuperBlock: 用于存储裸盘的元数据
// 所有offset和length都是字节为单位
// CRC 在磁盘上位于该结构前
// 加上CRC后，大小为4k(CRC是4byte)
struct SuperBlock {
  char uuid[64];                    // uuid
  uint64_t version;                 // 版本号
  uint32_t magic;                   // 魔法数 kRawMagic
  uint64_t chunk_id;                // chunk id
  uint64_t pc_zone_offset;          // pc区的起始偏移
  uint64_t pc_zone_length;          // pc区的长度(包括pc元数据,数据和探测区域)
  uint64_t pc_num;                  // pc分片的数目
  uint64_t pc_meta_size;            // 每个pc元数据的大小
  uint64_t pc_size;                 // 每个pc的大小
  uint64_t detection_size;          // 每个探测区域的大小
  uint64_t detection_per_pc_num;    // 每多少PC拥有一个detection
  uint64_t jpc_zone_offset;     // journal区的起始偏移
  uint64_t jpc_zone_length;     // journal区的长度(包括元数据和数据)
  uint64_t jpc_meta_size;       // 每个journal元数据的大小, 和dev_block_size一致
  uint64_t jpc_num;             // journal 分片的数目
  uint64_t jpc_size;            // journal 分片的大小
  char reserve[3912];               // 保留字段
} __attribute__((packed));

// CRC 在磁盘上位于该结构前
// 加上CRC后，大小为64byte(CRC是4byte)
struct PCMeta {
  uint8_t is_used;        // 该pc是否使用
  uint8_t has_detection;  // 该pc后是否有detection
  uint64_t pc_id;         // pc编号
  uint64_t seq_no;        // pc的使用编号,全局唯一,从1开始
  uint64_t offset;        // 该pc的偏移
  uint32_t pg_id;         // 所属pg的编号
  uint32_t lc_id;         // 所属lc的编号
  uint32_t pc_no;         // 所属lc的分片的编号
  uint32_t lc_random_id;  // 所属lc的random id
  uint64_t allocate_time; // 申请分配时间戳
  char reserve[10];       // 保留字段
} __attribute__((packed));

// CRC 在磁盘上位于该结构前
// CRC + JPCMeta 独占一个扇区。
struct JPCMeta {
  uint8_t jpc_type;        // 类型，compact or plain
  uint32_t jpc_id;         // jpc 分片编号
  uint32_t pg_id;          // jpc 所属pg_id
  uint64_t offset;         // 该jpc在物理盘上的偏移
  uint64_t allocate_time;  // 申请分配时间戳
  uint64_t reserverd0;
  uint64_t reserverd1;
  uint64_t reserverd2;
  uint64_t reserverd3;
} __attribute__((packed));

inline std::string DumpSuperBlock(const struct SuperBlock& sb) {
  std::ostringstream oss;
  oss << "\nsuper block: "
      << "\nuuid: " << sb.uuid << "\nversion: " << sb.version
      << "\nmagic: " << sb.magic << "\nchunk_id: " << sb.chunk_id
      << "\npc_zone_offset: " << sb.pc_zone_offset
      << "\npc_zone_length: " << sb.pc_zone_length << "\npc_num: " << sb.pc_num
      << "\npc_meta_size: " << sb.pc_meta_size << "\npc_size: " << sb.pc_size
      << "\ndetection_size: " << sb.detection_size
      << "\ndetection_per_pc_num: " << sb.detection_per_pc_num
      << "\njpc_zone_offset: " << sb.jpc_zone_offset
      << "\njpc_zone_length: " << sb.jpc_zone_length
      << "\njpc_meta_size: " << sb.jpc_meta_size 
      << "\njpc_num: " << sb.jpc_num
      << "\njpc_size: " << sb.jpc_size;
  return oss.str();
}

inline std::string DumpPCMeta(const struct PCMeta& pm) {
  std::ostringstream oss;
  oss << "\npc meta: "
      << "\nis_used: " << (uint32_t)pm.is_used
      << "\nhas_detection: " << (uint32_t)pm.has_detection
      << "\nseq_no: " << pm.seq_no << "\npc_id: " << pm.pc_id
      << "\noffset: " << pm.offset << "\npg_id: " << pm.pg_id
      << "\nlc_id: " << pm.lc_id << "\npc_no: " << pm.pc_no
      << "\nlc_random_id: " << pm.lc_random_id
      << "\nallocate_time: " << pm.allocate_time;
  return oss.str();
}

inline std::string DumpPCMetaJson(const struct PCMeta& pm) {
  std::ostringstream oss;
  oss << "{\n"
      << "\"is_used\" : " << (uint32_t)pm.is_used << ",\n"
      << "\"has_detection\" : " << (uint32_t)pm.has_detection << ",\n"
      << "\"seq_no\" : " << pm.seq_no << ",\n"
      << "\"pc_id\" : " << pm.pc_id << ",\n"
      << "\"offset\" : " << pm.offset << ",\n"
      << "\"pg_id\" : " << pm.pg_id << ",\n"
      << "\"lc_id\" : " << pm.lc_id << ",\n"
      << "\"pc_no\" : " << pm.pc_no << ",\n"
      << "\"lc_random_id\" : " << pm.lc_random_id << ",\n"
      << "\"allocate_time\" : " << pm.allocate_time<< "\n"
      << "}\n";
  return oss.str();
}

inline std::string DumpJPCMeta(const struct JPCMeta& jm) {
  std::ostringstream oss;
  oss << "\njpc meta: "
      << "\njpc_id: " << jm.jpc_id
      << "\npg_id: " << jm.pg_id
      << "\noffset: " << jm.offset
      << "\nallocate_time: " << jm.allocate_time;
  return oss.str();
}

inline std::string DumpJPCMetaJson(const struct JPCMeta& jm) {
  std::ostringstream oss;
  oss << "{\n"
      << "\"jpc_id\" : " << jm.jpc_id << ",\n"
      << "\"pg_id\" : " << jm.pg_id << ",\n"
      << "\"offset\" : " << jm.offset << ",\n"
      << "\"allocate_time\" : " << jm.allocate_time<< "\n"
      << "}\n";
  return oss.str();
}

};  // end of ns chunk
};  // end of ns udisk
#endif
