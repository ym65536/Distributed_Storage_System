#include "kernel_raw_device_manager.h"

#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/mount.h>
#include <algorithm>

#include <ustevent/base/my_uuid.h>
#include <ustevent/base/logging.h>
#include <ustevent/base/timestamp.h>
#include <ustevent/eventloop.h>
#include "crc32c.h"
#include "udisk_types.h"
#include "str_list.h"
#include "chunk_storage_errorcode.h"
#include "journal_format.h"
#include "journal_meta.h"

namespace udisk {
namespace chunk {

KernelRawDeviceManager::KernelRawDeviceManager() {}

KernelRawDeviceManager::~KernelRawDeviceManager() {}

int KernelRawDeviceManager::Open(const std::string& dev_name) {
  if (dev_name.find("sda") != std::string::npos) {
    ULOG_ERROR << "sda can not open";
    return UDISK_DISK_ERROR;
  }
  int flags = O_RDWR | O_LARGEFILE | O_DIRECT;
  fd_ = ::open(dev_name.c_str(), flags);
  if (fd_ < 0) {
    ULOG_ERROR << "open dev error, "
              << "dev_name: " << dev_name;
    return UDISK_DISK_ERROR;
  }
  off_t s = lseek(fd_, 0, SEEK_END);
  if (s <= 0) {
    Close();
    ULOG_ERROR << "get dev size error";
    return UDISK_DISK_ERROR;
  }
  size_ = static_cast<uint64_t>(s);
  if (ioctl(fd_, BLKSSZGET, &dev_block_size_) < 0) {
    Close();
    ULOG_ERROR << "get dev block size error";
    return UDISK_DISK_ERROR;
  }
  dev_name_ = dev_name;
  //ULOG_INFO << "dev size: " << size_;
  //ULOG_INFO << "dev block size: " << dev_block_size_;
  return fd_;
}

int KernelRawDeviceManager::Open(uint64_t chunk_id, const std::string& dev_uuid,
                                 const std::string& dev_prefix) {
  FILE* fp;
  char buf[256];
  std::string cmd =
      "lsblk | grep " + dev_prefix + " | grep -v sda | awk '{print $1}'| xargs";
  ULOG_INFO << cmd;
  fp = popen(cmd.c_str(), "r");
  if (!fp) {
    ULOG_ERROR << "exec cmd fail";
    return UDISK_DISK_ERROR;
  }
  fgets(buf, sizeof(buf), fp);
  // 去除回车
  for (int i = 0; buf[i] != '\0'; i++) {
    if (buf[i] == '\n') {
      buf[i] = '\0';
      break;
    }
  }
  pclose(fp);
  std::list<std::string> dev_list;
  common::get_str_list(buf, dev_list);
  auto it = dev_list.begin();
  for (; it != dev_list.end(); it++) {
    ULOG_INFO << *it;
    if (Open("/dev/" + *it) < 0) {
      continue;
    }
    if (ReadSuperBlock() < 0) {
      Close();
      continue;
    }
    if (super_block_.chunk_id == chunk_id &&
        strncmp(super_block_.uuid, dev_uuid.c_str(), sizeof(super_block_.uuid)) == 0) {
      dev_name_ = "/dev/" + *it;
      break;
    } else {
      Close();
    }
  }
  if (it == dev_list.end()) {
    return UDISK_DISK_ERROR;
  }
  ULOG_DEBUG << "chunk_id=" << chunk_id << ",dev_name=" << dev_name_ 
      << ", fd=" << fd_;
  return fd_;
}

void KernelRawDeviceManager::Close() {
  if (fd_ >= 0) {
    ::close(fd_);
  }
}

int KernelRawDeviceManager::Format(const std::string& dev_name, 
                                   uint32_t chunk_id, 
                                  bool is_reset, 
                                  bool has_journal, 
                                  uint32_t pc_size,
                                  const std::vector<uint32_t>& own_pgs,
                                  uint32_t worker_num) {
  if (Open(dev_name) < 0) {
    ULOG_ERROR << "open dev error";
    return UDISK_DISK_ERROR;
  }
  chunk_id_ = chunk_id;
  if (WriteSuperBlock(has_journal, pc_size) < 0) {
    ULOG_ERROR << "write superblock error";
    return UDISK_DISK_ERROR;
  }
  if (WriteAllPCMeta(is_reset) < 0) {
    ULOG_ERROR << "write all pc meta error";
    return UDISK_DISK_ERROR;
  }
  if (has_journal) {
    if (WriteAllJPCMeta(own_pgs, is_reset, worker_num) < 0) {
      ULOG_ERROR << "write all journal meta error";
      return UDISK_DISK_ERROR;
    }
  }
  Close();
  return UDISK_OK;
}

// 首尾的SuperBlock都验证通过才返回正确
int KernelRawDeviceManager::ReadSuperBlock() {
  void* buf = nullptr;
  ::posix_memalign(&buf, dev_block_size_, kSuperBlockSize);
  // 从头部SuperBlock区读取SuperBlock
  ::memset(buf, 0, kSuperBlockSize);
  int64_t ret = 0;
  ret = ::pread(fd_, buf, kSuperBlockSize, 0);
  if (ret != kSuperBlockSize) {
    free(buf);
    return UDISK_DISK_ERROR;
  }
  uint32_t expect_crc = 0;
  ::memcpy(&expect_crc, buf, sizeof(uint32_t));
  ::memcpy(&super_block_, (char*)buf + sizeof(expect_crc), sizeof(struct SuperBlock));
  if (super_block_.magic != kRawMagic) {
    free(buf);
    ULOG_ERROR << "read superblock from head error;"
               << " magic:" << super_block_.magic;
    return UDISK_DISK_ERROR;
  }

  uint32_t cal_crc = common::CalCRC32C(reinterpret_cast<char*>(&super_block_),
                                       sizeof(struct SuperBlock));
  if (expect_crc != cal_crc) {
    free(buf);
    ULOG_ERROR << "read superblock from head error";
    return UDISK_DISK_ERROR;
  }
  ULOG_TRACE << "read superblock from head success";
  // 从尾部SuperBlock区读取SuperBlock
  ::memset(buf, 0, kSuperBlockSize);
  ret = ::pread(fd_, buf, kSuperBlockSize, size_ - kSuperBlockSize);
  if (ret != kSuperBlockSize) {
    free(buf);
    return UDISK_DISK_ERROR;
  }
  ::memcpy(&expect_crc, buf, sizeof(uint32_t));
  ::memcpy(&super_block_, (char*)buf + sizeof(expect_crc), 
                                        sizeof(struct SuperBlock));
  cal_crc = common::CalCRC32C(reinterpret_cast<char*>(&super_block_),
                              sizeof(struct SuperBlock));
  free(buf);
  if (expect_crc == cal_crc) {
    ULOG_TRACE << "read superblock from tail success";
    return UDISK_OK;
  } else {
    ULOG_ERROR << "read superblock from tail error";
    return UDISK_DISK_ERROR;
  }
}

int KernelRawDeviceManager::WriteSuperBlock(bool has_journal, uint32_t pc_size) {
  ConstructSuperBlock(has_journal, pc_size);
  ULOG_INFO << DumpSuperBlock(super_block_);
  void* buf = nullptr;
  ::posix_memalign(&buf, dev_block_size_, kSuperBlockSize);
  ::memset(buf, 0, kSuperBlockSize);
  uint32_t crc = common::CalCRC32C(reinterpret_cast<char*>(&super_block_),
                                   sizeof(struct SuperBlock));
  // CRC 在实际数据前
  ULOG_INFO << "WriteSuperBlock crc: " << crc;
  ::memcpy(buf, &crc, sizeof(uint32_t));
  ::memcpy((char*)buf + sizeof(crc), &super_block_, sizeof(struct SuperBlock));

  int64_t ret;
  // 写设备头部的SuperBlock
  ret = ::pwrite(fd_, buf, kSuperBlockSize, 0);
  if (ret != kSuperBlockSize) {
    free(buf);
    return UDISK_DISK_ERROR;
  }
  // 写设备尾部的SuperBlock
  ret = ::pwrite(fd_, buf, kSuperBlockSize, size_ - kSuperBlockSize);
  if (ret != kSuperBlockSize) {
    free(buf);
    return UDISK_DISK_ERROR;
  }

  free(buf);
  return UDISK_OK;
}

int KernelRawDeviceManager::ReadAllPCMeta(
                               std::vector<struct PCMeta*>& pc_metas) {
  uint64_t pc_meta_total_size = super_block_.pc_num * super_block_.pc_meta_size;
  if (pc_metas_buf_ == nullptr) {
    ::posix_memalign(&pc_metas_buf_, dev_block_size_, pc_meta_total_size);
  }
  // 不需要置为0，因为读盘的时候会全部覆盖
  // ::memset(pc_metas_buf_, 0, pc_meta_total_size);
  int64_t ret;
  ret = ::pread(fd_, pc_metas_buf_, pc_meta_total_size, super_block_.pc_zone_offset);
  if (ret != (int64_t)pc_meta_total_size) {
    return UDISK_DISK_ERROR;
  }
  uint64_t buf_offset = 0;
  uint32_t cal_crc;
  for (uint64_t i = 0; i < super_block_.pc_num; i++) {
    cal_crc = common::CalCRC32C((char*)pc_metas_buf_ + buf_offset + sizeof(uint32_t),
                                       sizeof(struct PCMeta));
    if (*((uint32_t*)((char*)pc_metas_buf_ + buf_offset)) != cal_crc) {
      // TODO (alan.ding) 元数据校验失败如何处理
      //continue;
      return UDISK_DISK_ERROR;
    }
    pc_metas.push_back((struct PCMeta*)((char*)pc_metas_buf_ + buf_offset 
                                + sizeof(uint32_t)));
    buf_offset += super_block_.pc_meta_size;
  }
  //::fcntl(fd_, F_SETFL, fcntl(fd_, F_GETFL) | O_NONBLOCK);
  return UDISK_OK;
}

int KernelRawDeviceManager::WriteAllPCMeta(bool is_reset) {
  void* buf = nullptr;
  uint64_t pc_meta_total_size = super_block_.pc_num * super_block_.pc_meta_size;
  ::posix_memalign(&buf, dev_block_size_, pc_meta_total_size);
  ::memset(buf, 0, pc_meta_total_size);
  uint64_t pc_data_offset = super_block_.pc_zone_offset + pc_meta_total_size;
  uint64_t buf_offset = 0;
  uint32_t crc = 0;
  int64_t ret = 0;
  struct PCMeta pc_meta;
  ::memset(&pc_meta, 0, sizeof(pc_meta));
  for (uint64_t i = 0; i < super_block_.pc_num; i++) {
    ULOG_INFO << "begin format " << i
              << " pc, total num: " << super_block_.pc_num;
    if (i % 100 == 0) {
      ULOG_INFO << "current complete percent: "
               << i * 100.0 / super_block_.pc_num << "%";
    }
    pc_meta.is_used = 0;
    if (i % super_block_.detection_per_pc_num == 0) {
      pc_meta.has_detection = 1;
    } else {
      pc_meta.has_detection = 0;
    }
    pc_meta.pc_id = i;
    pc_meta.seq_no = 0;
    pc_meta.offset = pc_data_offset;
    pc_meta.pg_id = 0;
    pc_meta.lc_id = 0;
    pc_meta.pc_no = 0;
    pc_meta.lc_random_id = 0;
    pc_meta.allocate_time = 0;
    // CRC 在实际数据前
    crc = common::CalCRC32C(reinterpret_cast<char*>(&pc_meta),
                            sizeof(struct PCMeta));
    ::memcpy((char*)buf + buf_offset, &crc, sizeof(uint32_t));
    ::memcpy((char*)buf + buf_offset + sizeof(crc), &pc_meta, sizeof(struct PCMeta));
    if (is_reset) {
      if (ResetZoneData(pc_data_offset, super_block_.pc_size) < 0) {
        ULOG_ERROR << "reset pc error" << pc_meta.pc_id;
        free(buf);
        return UDISK_DISK_ERROR;
      }
      if (pc_meta.has_detection) {
        if (WriteDetectionData(pc_data_offset + super_block_.pc_size) < 0) {
          ULOG_ERROR << "write detection data error" << pc_meta.pc_id;
          free(buf);
          return UDISK_DISK_ERROR;
        }
      }
    }
    buf_offset += super_block_.pc_meta_size;
    pc_data_offset += super_block_.pc_size;
    if (pc_meta.has_detection) {
      pc_data_offset += super_block_.detection_size;
    }
  }
  ret = ::pwrite(fd_, buf, pc_meta_total_size, super_block_.pc_zone_offset);
  if (ret != (int64_t)pc_meta_total_size) {
    free(buf);
    return UDISK_DISK_ERROR;
  }
  free(buf);
  return UDISK_OK;
}

int KernelRawDeviceManager::WritePCMeta(struct PCMeta* pc_meta) {
  uint32_t pc_num_per_dev_block = dev_block_size_ / kPCMetaSize;
  uint32_t pc_block_index = pc_meta->pc_id / pc_num_per_dev_block;
  uint32_t crc = common::CalCRC32C(reinterpret_cast<const char*>(pc_meta),
                                   sizeof(struct PCMeta));
  ::memcpy((char*)pc_meta - sizeof(crc), &crc, sizeof(crc));
  int64_t ret = 0;
  ret = ::pwrite(
      fd_, (char*)pc_metas_buf_ + pc_block_index * dev_block_size_, dev_block_size_,
      super_block_.pc_zone_offset + pc_block_index * dev_block_size_);
  if (ret != (int64_t)(dev_block_size_)) {
    return UDISK_DISK_ERROR;
  }
  return UDISK_OK;
}

int KernelRawDeviceManager::WritePCMeta(uevent::EventLoop* loop,
                                        struct PCMeta* pc_meta, 
                                          uevent::DiskIOCb cb, 
                                                      void* arg) {
  uint32_t pc_num_per_dev_block = dev_block_size_ / kPCMetaSize;
  uint32_t pc_block_index = pc_meta->pc_id / pc_num_per_dev_block;
  uint32_t crc = common::CalCRC32C(reinterpret_cast<const char*>(pc_meta),
                                   sizeof(struct PCMeta));
  ::memcpy((char*)pc_meta - sizeof(crc), &crc, sizeof(crc));
  int ret = loop->disk_io_util()->SubmitWrite(fd_, 
      (char*)pc_metas_buf_ + pc_block_index * dev_block_size_, 
      super_block_.pc_zone_offset + pc_block_index * dev_block_size_, 
              dev_block_size_, cb, arg);
  if (ret >= 0) {
    ULOG_TRACE << "WritePCMeta";
    return UDISK_OK;
  }
  else {
    return UDISK_DISK_ERROR;
  }
}

void KernelRawDeviceManager::ConstructSuperBlock(bool has_journal, uint32_t pc_size) {
  uint64_t jpc_zone_length = 0;
  if (has_journal) {
    jpc_zone_length = kJPCNum * (dev_block_size_ + kJPCSize);
  }
  uint64_t pc_zone_length = size_ - jpc_zone_length - 2 * kSuperBlockSize;
  uint64_t detection_per_pc_num = kDetectionPerPCSize / pc_size;
  // kDetectionPerPCSize 小于 pc_size
  if (detection_per_pc_num == 0) {
    detection_per_pc_num = 1;
  }
  // 可能会有一些空余空间没有使用
  uint64_t pc_num = pc_zone_length * detection_per_pc_num /
                    ((pc_size + kPCMetaSize) * detection_per_pc_num +
                     kDetectionSize);
  // 保证pc offset 至少是kAlignmentSize的整数倍
  uint32_t pc_num_per_size = 
                    std::max(dev_block_size_, kAlignmentSize) / kPCMetaSize;
  pc_num = (pc_num / pc_num_per_size) * pc_num_per_size;
  ::memset(&super_block_, 0, sizeof(super_block_));
  strncpy(super_block_.uuid, base::MyUuid::NewUuid().c_str(), sizeof(super_block_.uuid));
  super_block_.version = kRawVersion;
  super_block_.magic = kRawMagic;
  super_block_.chunk_id = chunk_id_;
  super_block_.pc_zone_offset = kSuperBlockSize;
  super_block_.pc_zone_length = pc_zone_length;
  super_block_.pc_num = pc_num;
  super_block_.pc_meta_size = kPCMetaSize;
  super_block_.pc_size = pc_size;
  super_block_.detection_size = kDetectionSize;
  super_block_.detection_per_pc_num = detection_per_pc_num;
  super_block_.jpc_zone_offset = size_ - kSuperBlockSize - jpc_zone_length;
  super_block_.jpc_zone_length = jpc_zone_length;
  super_block_.jpc_meta_size = dev_block_size_;
  if (has_journal) {
    super_block_.jpc_num = kJPCNum;
  } else {
    super_block_.jpc_num = 0;
  }
  super_block_.jpc_size = kJPCSize;
}

// detection 填充内容如下（每一个dev_block_size内容一样）
// |--timestamp--|---------------------magic
// char----------------------|---CRC---|
//    uint64_t    dev_block_size - sizeof(uint64_t)
//         - sizeof(uint32_t)  uint32_t
int KernelRawDeviceManager::WriteDetectionData(uint64_t offset) {
  uint32_t detection_num = super_block_.detection_size / dev_block_size_;
  uint64_t nowtime = base::Timestamp::now().secondsSinceEpoch();
  char data[dev_block_size_ - sizeof(uint32_t)];
  void* buf = nullptr;
  ::posix_memalign(&buf, dev_block_size_, super_block_.detection_size);
  ::memset(buf, 0, super_block_.detection_size);
  ::memcpy(data, &nowtime, sizeof(uint64_t));
  ::memset(data + sizeof(uint64_t), kMagicChar,
           sizeof(data) - sizeof(uint64_t));
  uint32_t crc = common::CalCRC32C(data, sizeof(data));
  for (uint32_t i = 0; i < detection_num; i++) {
    ::memcpy((char*)buf + i * dev_block_size_, data, sizeof(data));
    ::memcpy((char*)buf + i * dev_block_size_ + sizeof(data), &crc,
             sizeof(uint32_t));
  }
  int64_t ret = 0;
  ret = ::pwrite(fd_, buf, super_block_.detection_size, offset);
  if (ret != (int64_t)(super_block_.detection_size)) {
    free(buf);
    ULOG_ERROR << "write disk error";
    return UDISK_DISK_ERROR;
  }
  free(buf);
  return UDISK_OK;
}

int KernelRawDeviceManager::CheckDetectionData(uint64_t offset) {
  uint32_t detection_num = super_block_.detection_size / dev_block_size_;
  char data[dev_block_size_ - sizeof(uint32_t)];
  void* buf = nullptr;
  ::posix_memalign(&buf, dev_block_size_, super_block_.detection_size);
  ::memset(buf, 0, super_block_.detection_size);
  int64_t ret = 0;
  ret = ::pread(fd_, buf, super_block_.detection_size, offset);
  if (ret != (int64_t)(super_block_.detection_size)) {
    free(buf);
    ULOG_ERROR << "read disk error";
    return UDISK_DISK_ERROR;
  }
  uint32_t expect_crc, cal_crc;
  for (uint32_t i = 0; i < detection_num; i++) {
    ::memcpy(data, (char*)buf + i * dev_block_size_, sizeof(data));
    ::memcpy(&expect_crc, (char*)buf + i * dev_block_size_ + sizeof(data),
             sizeof(uint32_t));
    cal_crc = common::CalCRC32C(data, sizeof(data));
    if (expect_crc != cal_crc) {
      free(buf);
      ULOG_ERROR << "check crc error";
      return UDISK_DISK_ERROR;
    }
  }
  free(buf);
  return UDISK_OK;
}

int KernelRawDeviceManager::ReadSuperJPCMeta(JPCMeta** jpc_superblock) {
  if (super_block_.jpc_zone_length == 0) {
    ULOG_ERROR << "this device has no journal zone";
    return UDISK_DISK_ERROR;
  }
  void* buf = nullptr;
  ::posix_memalign(&buf, dev_block_size_, super_block_.jpc_meta_size);
  ::memset(buf, 0, super_block_.jpc_meta_size);
  int64_t ret;
  ret = ::pread(fd_, buf, super_block_.jpc_meta_size, super_block_.jpc_zone_offset);
  if (ret != (int64_t)super_block_.jpc_meta_size) {
    free(buf);
    return UDISK_DISK_ERROR;
  }
  struct JPCMeta* jm;
  uint32_t expect_crc = 0;
  uint32_t cal_crc = 0;
  ::memcpy(&expect_crc, (char*)buf, sizeof(uint32_t));
  jm = (JPCMeta*)((char*)buf + sizeof(uint32_t));
  cal_crc = common::CalCRC32C(reinterpret_cast<char*>(jm), 
                              sizeof(struct JPCMeta));
  if (expect_crc != cal_crc) {
    ULOG_FATAL << "Journal crc check fail. actual_crc=" << cal_crc 
        << ", expect_crc=" << expect_crc << ", meta=" << DumpJPCMeta(*jm);
    free(buf);
    return UDISK_DISK_ERROR;
  }
  assert(kJournalSuperBlockID == jm->jpc_id);
  ULOG_DEBUG << "read super jpc_id=" << jm->jpc_id << ", type=" << jm->jpc_type
      << ", offset=" << jm->offset;
  *jpc_superblock = jm;
  // buffer 不释放
  return UDISK_OK;
}

int KernelRawDeviceManager::ReadAllJPCMeta(
                                std::map<uint32_t, std::vector<JPCMeta*>>* jms,
                                uint32_t pg_size) {
  if (super_block_.jpc_zone_length == 0) {
    ULOG_ERROR << "this device has no journal zone";
    return UDISK_DISK_ERROR;
  }
  void* buf = nullptr;
  uint64_t jpc_meta_total_size = super_block_.jpc_meta_size * 
                   super_block_.jpc_num;
  ::posix_memalign(&buf, dev_block_size_, jpc_meta_total_size);
  ::memset(buf, 0, jpc_meta_total_size);
  int64_t ret;
  ret = ::pread(fd_, buf, jpc_meta_total_size, super_block_.jpc_zone_offset);
  if (ret != (int64_t)jpc_meta_total_size) {
    free(buf);
    return UDISK_DISK_ERROR;
  }
  struct JPCMeta* jm;
  uint64_t buf_offset = 0;
  uint32_t expect_crc = 0;
  uint32_t cal_crc = 0;
  uint32_t jpc_count = (super_block_.jpc_num - 1) / pg_size * pg_size + 1;
  ULOG_DEBUG << "pg_size=" << pg_size << ", jpc_num=" << super_block_.jpc_num 
      << ", jpc_count=" << jpc_count;
  for (uint64_t i = kJournalSuperBlockID; i < jpc_count; ++ i) {
    ::memcpy(&expect_crc, (char*)buf + buf_offset, sizeof(uint32_t));
    jm = (JPCMeta*)((char*)buf + buf_offset + sizeof(uint32_t));
    cal_crc = common::CalCRC32C(reinterpret_cast<char*>(jm), 
                                sizeof(struct JPCMeta));
    if (expect_crc != cal_crc) {
      ULOG_FATAL << "Journal crc check fail. actual_crc=" << cal_crc 
          << ", expect_crc=" << expect_crc << ", meta=" << DumpJPCMeta(*jm);
      free(buf);
      return UDISK_DISK_ERROR;
    }
    assert(i == jm->jpc_id);
    ULOG_DEBUG << "read jpc_id=" << jm->jpc_id << ", type=" << jm->jpc_type
        << ", offset=" << jm->offset;
    if (i == kJournalSuperBlockID) {
      // must be superblock, do nothing;
    } else {
      (*jms)[jm->pg_id].push_back(jm);
    }
    buf_offset += super_block_.jpc_meta_size;
  }
  // buffer 不释放
  return UDISK_OK;
}

int KernelRawDeviceManager::WriteAllJPCMeta(const std::vector<uint32_t>& own_pgs, 
                                            bool is_reset,
                                            uint32_t worker_num) {
  ULOG_INFO << "Start Write JPC Meta. is_reset=" << is_reset;
  assert(!own_pgs.empty());
  void* buf = nullptr;
  uint64_t jpc_meta_total_size = super_block_.jpc_meta_size * 
              super_block_.jpc_num;
  ::posix_memalign(&buf, dev_block_size_, jpc_meta_total_size); 
  ::memset(buf, 0, jpc_meta_total_size);
  uint64_t buf_offset = 0;
  uint64_t data_offset = super_block_.jpc_zone_offset + jpc_meta_total_size;
  uint32_t crc = 0;
  struct JPCMeta jm;
  memset(&jm, 0, sizeof(jm));

  // 初始化journal super block
  uint32_t id_seq = kJournalSuperBlockID;
  uint32_t pg_jpc_count = (super_block_.jpc_num - 1) / own_pgs.size();
  jm.jpc_type = kJPCSuperBlock;
  jm.jpc_id = id_seq;
  jm.offset = data_offset;
  jm.pg_id = (uint32_t)-1;
  jm.allocate_time = 0;
  crc = common::CalCRC32C(reinterpret_cast<char*>(&jm), sizeof(struct JPCMeta));
  memcpy((char*)buf + buf_offset, &crc, sizeof(uint32_t));
  memcpy((char*)buf + buf_offset + sizeof(crc), &jm, sizeof(struct JPCMeta)); 
  buf_offset += super_block_.jpc_meta_size;
  data_offset += super_block_.jpc_size;
  id_seq += 1;
  ULOG_INFO << "begin format journal superblock pg_count:" << own_pgs.size()
      << " jpc_count:" << (super_block_.jpc_num - 1) << ", super_block id=" 
      << jm.jpc_id << ", offset=" << jm.offset;
  
  // 初始化compact和active/inactive
  std::map<uint32_t, std::vector<uint32_t>> compact_jpc_map;
  assert(pg_jpc_count >= kPGCompactJPCCount + own_pgs.size());
  for (uint32_t i = 0; i < own_pgs.size(); ++ i) {
    for (uint32_t j = 0; j < pg_jpc_count; ++ j) {
      if (j < kPGCompactJPCCount) {
        jm.jpc_type = kJPCCompact;
        compact_jpc_map[own_pgs[i]].push_back(id_seq);
      } else {
        jm.jpc_type = kJPCPlain;
      }
      jm.jpc_id = id_seq;
      jm.pg_id = own_pgs[i];
      jm.offset = data_offset;
      jm.allocate_time = 0;
      crc = common::CalCRC32C(reinterpret_cast<char*>(&jm), 
                              sizeof(struct JPCMeta));
      ::memcpy((char*)buf + buf_offset, &crc, sizeof(uint32_t));
      ::memcpy((char*)buf + buf_offset + sizeof(crc), &jm, 
                                        sizeof(struct JPCMeta)); 
      if (ResetJournalData(jm.offset, super_block_.jpc_size, is_reset) < 0) {
        ULOG_ERROR << "reset journal error" << jm.jpc_id;
        free(buf);
        return UDISK_DISK_ERROR;
      }
      ULOG_INFO << "format jpc meta jpc_id:" << jm.jpc_id 
          << " jpc_type:" << jm.jpc_type << " pg_id:" << jm.pg_id
          << " jpc_offset:" << jm.offset;
      buf_offset += super_block_.jpc_meta_size;
      data_offset += super_block_.jpc_size;
      id_seq += 1;
    }
  }
  int64_t ret = ::pwrite(fd_, buf, jpc_meta_total_size, 
                      super_block_.jpc_zone_offset);
  if (ret != (int64_t)jpc_meta_total_size) {
    free(buf);
    return UDISK_DISK_ERROR;
  }
  free(buf);

  // 初始化journal元信息
  uint64_t jpc_offset = super_block_.jpc_zone_offset + jpc_meta_total_size;
  uint64_t offset = 0;

  char* buffer = nullptr;
  posix_memalign((void**)&buffer, BLOCK_SIZE, journal::kBlockSize);
  assert(buffer);
  memset(buffer, 0, journal::kBlockSize);

  journal::UDiskJournalMeta* journal_meta = (journal::UDiskJournalMeta*)buffer;
  journal_meta->worker_num = worker_num; // 初始化模式下，thread_num置4
  journal_meta->pg_num = own_pgs.size();
  for (size_t i = 0; i < own_pgs.size(); i++) {
    journal_meta->pg_ids[i] = own_pgs[i];
  }
  journal_meta->crc = common::CalCRC32C(buffer + sizeof(uint32_t), 
      sizeof(journal::UDiskJournalMeta) - sizeof(uint32_t) 
      + journal_meta->pg_num * sizeof(uint32_t));
  offset += BLOCK_SIZE;
  ULOG_INFO << "begin format journal worker_num:" << journal_meta->worker_num
      << " pg_num:" << journal_meta->pg_num << ", crc=" << journal_meta->crc  
      << " jpc_offset:" << jpc_offset << " offset:" << offset;

  //初始化compact meta
  for (uint32_t i = 0; i < journal_meta->pg_num; ++ i) {
    journal::PGCompactMeta* pgc_meta = new (buffer + offset) journal::PGCompactMeta();
    pgc_meta->pg_id = journal_meta->pg_ids[i];
    pgc_meta->active_offset = 0;
    pgc_meta->active_id = 0;
    assert(compact_jpc_map[pgc_meta->pg_id].size() == kPGCompactJPCCount);
    for (uint32_t i = 0; i < kPGCompactJPCCount; ++ i) {
      pgc_meta->zone[i].jpc_id = compact_jpc_map[pgc_meta->pg_id][i];
    }
    pgc_meta->crc = common::CalCRC32C(buffer + offset + sizeof(uint32_t), 
        sizeof(journal::PGCompactMeta) - sizeof(uint32_t));
    offset += BLOCK_SIZE;
  }
  uint32_t length = BLOCK_SIZE * (1 + journal_meta->pg_num);
  ret = ::pwrite(fd_, buffer, length, jpc_offset);
  ULOG_INFO << "begin format compact_meta:" << " jpc_offset:" << jpc_offset 
      << " offset:" << offset;
  if (ret != (int64_t)length) {
    ULOG_FATAL << "Format super block data fail. ret=" << ret << ", need=" << length; 
    free(buffer);
    return UDISK_DISK_ERROR;
  }
  jpc_offset += journal::kBlockSize;

  //初始化pg中的线程数据
  char* buff = nullptr;
  posix_memalign((void**)&buff, BLOCK_SIZE, journal::kBlockSize);
  assert(buff);
  for (uint32_t i = 0; i < journal_meta->pg_num; ++ i) {
    memset(buff, 0, journal::kBlockSize);
    uint32_t offset = 0;
    for (size_t j = 0; j < journal_meta->worker_num; j++) {
      journal::PGJournalMeta* pgj_meta = new (buff + offset) journal::PGJournalMeta();
      pgj_meta->pg_id = journal_meta->pg_ids[i];
      pgj_meta->active_num = 0;
      pgj_meta->inactive_num = 0;
      pgj_meta->crc = common::CalCRC32C(buff + offset + sizeof(uint32_t), 
          sizeof(journal::PGJournalMeta) - sizeof(uint32_t));
      ULOG_DEBUG << "pg_id=" << pgj_meta->pg_id << ", worker_id=" << j << 
          ", crc=" << pgj_meta->crc;
      offset += BLOCK_SIZE;
    }
    length = BLOCK_SIZE * journal_meta->worker_num;
    int64_t ret = ::pwrite(fd_, buff, length, jpc_offset);
    ULOG_INFO << "begin format pg_journal_meta:" << journal_meta->pg_ids[i] << " jpc_offset:" 
        << jpc_offset << " offset:" << offset;
    if (ret != (int64_t)length) {
      ULOG_FATAL << "Format super block data fail. ret=" << ret << ", need=" << length; 
      free(buff);
      return UDISK_DISK_ERROR;
    }
    jpc_offset += journal::kBlockSize;
  }
  free(buff);
  free(buffer);
  return UDISK_OK;
}

int KernelRawDeviceManager::ResetZoneData(uint64_t offset, 
                                          uint64_t length) {
  void* buf = nullptr;
  ::posix_memalign(&buf, dev_block_size_, length);
  ::memset(buf, 0, length);
  int64_t ret = 0;
  ret = ::pwrite(fd_, buf, length, offset);
  if (ret != (int64_t)(length)) {
    free(buf);
    return UDISK_DISK_ERROR;
  }
  free(buf);
  return UDISK_OK;
}

int KernelRawDeviceManager::ResetJournalData(uint64_t offset, 
                                             uint64_t length,
                                             bool is_reset) {
  void* buf = nullptr;
  ::posix_memalign(&buf, dev_block_size_, length);
  ::memset(buf, 0, length);
  ::memcpy(buf, journal::kEnding, journal::kEndingSize);
  int64_t ret = 0;
  if (is_reset == false) {
    length = dev_block_size_;
  }
  ret = ::pwrite(fd_, buf, length, offset);
  if (ret != (int64_t)(length)) {
    ULOG_SYSERR << "Pwrite error, ret=" << ret << ", need length=" << length;
    free(buf);
    return UDISK_DISK_ERROR;
  }
  free(buf);
  return UDISK_OK;
}

};
};
