#ifndef UDISK_CHUNK_KERNEL_RAW_DEVICE_MANAGER_H_
#define UDISK_CHUNK_KERNEL_RAW_DEVICE_MANAGER_H_

#include <string>
#include <vector>
#include "raw_device_manager.h"
#include "raw_chunk_storage_type.h"

namespace udisk {
namespace chunk {

class KernelRawDeviceManager : public RawDeviceManager {
 public:
  KernelRawDeviceManager();
  virtual ~KernelRawDeviceManager();
  KernelRawDeviceManager(const KernelRawDeviceManager &) = delete;
  KernelRawDeviceManager &operator=(const KernelRawDeviceManager &) = delete;

  virtual int Open(uint64_t chunk_id, const std::string &dev_uuid, const std::string &dev_prefix) override;
  virtual int Open(const std::string &dev_name) override;
  virtual void Close() override;

  virtual int Format(const std::string &dev_name, uint32_t chunk_id,
                     bool is_reset, bool has_journal, uint32_t pc_size,
                     const std::vector<uint32_t>& own_pgs, uint32_t worker_num) override;
  virtual int ReadSuperBlock() override;

  // PC zone
  virtual int ReadAllPCMeta(std::vector<struct PCMeta*> &pc_metas) override;
  virtual int WritePCMeta(struct PCMeta* pc_meta) override;
  virtual int WritePCMeta(uevent::EventLoop* loop, struct PCMeta* pc_meta,
                     uevent::DiskIOCb cb, void* arg) override;

  // detection zone
  virtual int WriteDetectionData(uint64_t offset) override;
  virtual int CheckDetectionData(uint64_t offset) override;

  // journal zone
  virtual int ReadSuperJPCMeta(JPCMeta** jpc_superblock);
  virtual int ReadAllJPCMeta(std::map<uint32_t, std::vector<JPCMeta*>>* jms,
                             uint32_t pg_size);
  virtual int WriteAllJPCMeta(const std::vector<uint32_t>& own_pgs,
                              bool is_reset,
                              uint32_t worker_num);

  // 将一块区域抹零, 只有在格式化时才会使用
  virtual int ResetZoneData(uint64_t offset, uint64_t length) override;

  virtual int ResetJournalData(uint64_t offset, uint64_t length, bool is_reset) override;

  inline int fd() const { return fd_; }

 private:
  virtual int WriteSuperBlock(bool has_journal, uint32_t pc_size) override;
  virtual int WriteAllPCMeta(bool is_reset) override;
  virtual void ConstructSuperBlock(bool has_journal, uint32_t pc_size) override;

  int fd_;
};

};  // end of ns chunk
};  // end of ns udisk

#endif
