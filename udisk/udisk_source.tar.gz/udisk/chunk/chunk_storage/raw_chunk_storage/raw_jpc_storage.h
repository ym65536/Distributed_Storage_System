#ifndef UDISK_CHUNK_STORAGE_RAW_JPC_STORAGE_H_
#define UDISK_CHUNK_STORAGE_RAW_JPC_STORAGE_H_

#include <vector>
#include "chunk_storage_type.h"
#include "raw_jpc_handle.h"
#include "jpc_storage.h"

namespace udisk {
namespace journal {

class RawJPCStorage : public JPCStorage {
 public:
  RawJPCStorage();
  virtual ~RawJPCStorage();

  virtual void Init(int fd, uint32_t pg_id, const std::vector<chunk::JPCMeta*>& jms);
  virtual void Init(int fd, uint32_t pg_id);

  virtual JPCHandle* AcquireCompactJPC(uint32_t jpc_id);
  
  virtual JPCHandle* AcquireActiveJPC(uint32_t jpc_id);

  virtual JPCHandle* AcquireInActiveJPC(uint32_t jpc_id);

  virtual JPCHandle* AcquireFreeJPC();

  virtual void ReleaseJPC(const std::vector<uint32_t>& jpc_ids);

  void UpdateFreeJPC(const uint32_t active_zone[], uint32_t active_num,
                     const uint32_t inactive_zone[], uint32_t inactive_num);

  virtual void JPCSwap();

 private:
  int32_t fd_;
  uint32_t pg_id_;
  bool init_swap_;
  JPCPool compact_pool_;
  JPCPool active_pool_;
  JPCPool inactive_pool_;
  JPCFreeList active_free_list_;
  JPCFreeList inactive_free_list_;
};

};  // end of namespace chunk
};  // end of namespace udisk

#endif  // UDISK_CHUNK_STORAGE_RAW_CHUNK_STORAGE_H_
