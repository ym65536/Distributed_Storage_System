#ifndef UDISK_CHUNK_STORAGE_RAW_JOURNAL_HANDLE_H_
#define UDISK_CHUNK_STORAGE_RAW_JOURNAL_HANDLE_H_

#include <ustevent/callbacks.h>
#include <vector>
#include "jpc_handle.h"
#include "raw_chunk_storage_type.h"

using namespace udisk::journal;
using namespace udisk::chunk;

class RawJPCHandle : public JPCHandle {
public:
  RawJPCHandle(int fd, uint32_t jpc_id, uint64_t offset);
  virtual ~RawJPCHandle() {}
  virtual int PRead(void* data, uint64_t offset, uint64_t len, 
                   uevent::DiskIOCb cb, void* arg, uevent::EventLoop* loop) override;
  virtual int PWrite(const void* data, uint64_t offset, uint64_t len, 
                    uevent::DiskIOCb cb, void* arg, uevent::EventLoop* loop) override;
  virtual int ResetData() override;
  virtual uint32_t JPCSize() const override;
  virtual uint32_t GetID() const override;

private:
  int fd_;
  uint32_t jpc_id_;
  uint64_t base_offset_;  // 当前jpc在块设备上的偏移
};

#endif
