#include "raw_chunk_storage.h"

#include <fcntl.h>
#include <unistd.h>

#include "chunk_context.h"
#include "chunk_storage_type.h"
#include "raw_chunk_pool.h"
#include "likely.h"

namespace udisk {
namespace chunk {

RawChunkStorage::RawChunkStorage() : is_init_(false) {
  udisk_chunk_handles_.resize(g_context->config().max_udisk_num());
}

RawChunkStorage::~RawChunkStorage() {}

int32_t RawChunkStorage::Init(ChunkPool* chunkPool,
                              uevent::EventLoop *loop) {
  if (is_init_) {
    return UDISK_ALREADY_INIT;
  }
  chunk_pool_ = chunkPool;
  loop_ = loop;
  is_init_ = true;
  return 0;
}

int32_t RawChunkStorage::CloseChunk(ChunkHandle* chunkHandle) {
  // assert(chunkHandle->chunk_id_.pc_no < (int)fds_.size() && fd == fds_[idx]);
  udisk_chunk_handles_[chunkHandle->chunk_id_.lc_id].Set(
      chunkHandle->chunk_id_.pc_no, nullptr);
  delete chunkHandle;
  return 0;
}

int32_t RawChunkStorage::CreateChunk(const ChunkID& id) {
  return UDISK_NOT_IMPLEMENTED;
}

int32_t RawChunkStorage::DeleteChunk(const ChunkID& id) {
  return UDISK_NOT_IMPLEMENTED;
}

int32_t RawChunkStorage::OpenChunk(const ChunkID& chunkID, bool is_create,
                                     OpenChunkCb done) {
  ULOG_TRACE << "OpenChunk" << DumpChunkID(chunkID);
  if (!is_init_) {
    return UDISK_NOT_INIT;
  }

  ChunkHandle* chunkHandle = nullptr;

  ChunkHandleVecType* chunk_handles = &(udisk_chunk_handles_[chunkID.lc_id]);
  if (chunk_handles->IsNeedResize(chunkID.pc_no)) {
    ULOG_TRACE << "OpenChunk is need resize";
    chunk_handles->Resize(chunkID.pc_no, nullptr);
  } else if (chunk_handles->Get(chunkID.pc_no)) {
    ULOG_TRACE << "OpenChunk is get";
    chunkHandle = chunk_handles->Get(chunkID.pc_no);
    done(UDISK_OK, chunkHandle);
    return UDISK_OK;
  }

  if (UNLIKELY(is_create == false)) {
    if (!(chunk_pool_->Access(chunkID))) {
      return UDISK_PC_NOT_EXIST_ERROR;
    }
  } else {
     ChunkOpCb cb = std::bind(&RawChunkStorage::GetChunkResCb, this,
                              std::placeholders::_1, chunkID, done);
    int32_t ret = chunk_pool_->GetChunk(chunkID, cb, loop_);
    if (ret == UDISK_OK) {
      ULOG_TRACE << "OpenChunk";
      return UDISK_OK;
    } else if (ret != UDISK_CHUNKID_IS_USED) {
      ULOG_SYSERR << "Get chunk error";
      return UDISK_GET_PC_ERROR;
    }
  }

  uint64_t offset;
  int fd = chunk_pool_->Open(chunkID, &offset);
  if (fd < 0) {
    ULOG_ERROR << "open chunk error";
    return UDISK_INTERNAL_ERROR;
  }
  RawChunkHandle* ret = new RawChunkHandle(this);
  ret->Init(chunkID, fd, offset);
  chunk_handles->Set(chunkID.pc_no, ret);
  done(UDISK_OK, ret);
  ULOG_TRACE << "OpenChunk";  
  return UDISK_OK;
}

void RawChunkStorage::GetChunkResCb(int retcode, const ChunkID& chunkID,
                                     OpenChunkCb done) {
  ULOG_TRACE << "GetChunkResCb begin";
  if (retcode != UDISK_OK) {
    ULOG_ERROR << "get chunk error";
    done(UDISK_GET_PC_ERROR, nullptr);
    return;
  }

  ChunkHandleVecType* chunk_handles = &(udisk_chunk_handles_[chunkID.lc_id]);
  ChunkHandle* chunkHandle = chunk_handles->Get(chunkID.pc_no);
  if (chunkHandle) {
    done(UDISK_OK, chunkHandle);
    return;
  }

  uint64_t offset;
  int fd = chunk_pool_->Open(chunkID, &offset);
  if (fd < 0) {
    ULOG_ERROR << "open chunk error";
    done(UDISK_OPEN_PC_ERROR, nullptr);
    return;
  }
  RawChunkHandle* ret = new RawChunkHandle(this);
  ret->Init(chunkID, fd, offset);
  udisk_chunk_handles_[chunkID.lc_id].Set(chunkID.pc_no, ret);
  ULOG_TRACE << "GetChunkResCb end";
  done(UDISK_OK, ret);
}

};  // end of namespace chunk
};  // end of namespace udisk
