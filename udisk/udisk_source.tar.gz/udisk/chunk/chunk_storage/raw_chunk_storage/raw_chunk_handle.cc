#include <unistd.h>
#include <errno.h>
#include "udisk_types.h"
#include "likely.h"
#include "raw_chunk_handle.h"
#include "chunk_context.h"

namespace udisk {
namespace chunk {

RawChunkHandle::RawChunkHandle(ChunkStorage* chunk_storage)
    : fd_(-1), offset_(0) {
  chunk_storage_ = chunk_storage;
}

int32_t RawChunkHandle::Init(const ChunkID& chunkID, int fd, uint64_t offset) {
  // TODO(fangran.fr) only init once
  chunk_id_ = chunkID;
  fd_ = fd;
  offset_ = offset;
  return UDISK_OK;
}

RawChunkHandle::~RawChunkHandle() {}

int32_t RawChunkHandle::PRead(void* data, uint64_t len, uint64_t offset,
    uevent::DiskIOCb cb, void* arg) {
  if (UNLIKELY((offset + len) > g_context->chunk_pool()->pc_size())) {
    ULOG_FATAL << "offset + len is beyond range,"
              << " offset: " << offset << " length: " << len;
  }
  int ret = chunk_storage_->loop_->disk_io_util()->SubmitRead(
      fd_, (void*)data, offset_ + offset, len, cb, arg);

  if (ret >= 0) {
    ULOG_TRACE << "READ SUCCESS. length: " << len << ", retcode: " << ret
        << ", offset :" << offset << ", fd=" << fd_;
    return UDISK_OK;
  }
  ULOG_ERROR << "IO WRITE ERROR. length: " << len << "ret code: " << ret
            << "fd: " << fd_ << "offset :" << offset;

  return UDISK_IO_ERROR;
}

int32_t RawChunkHandle::PRead(void* data, uint64_t len, uint64_t offset) {
  if (UNLIKELY((offset + len) > g_context->chunk_pool()->pc_size())) {
    ULOG_FATAL << "offset + len is beyond range,"
              << " offset: " << offset << " length: " << len;
  }
  // sync pread
  int32_t size = pread(fd_, data, len, offset_ + offset);
  if (size == (int32_t)len) {
    ULOG_TRACE << "READ SUCCESS. length: " << len << ", retcode: " << size
        << ", offset :" << offset << ", fd=" << fd_;
    return UDISK_OK;
  }
  ULOG_SYSERR << "IO READ ERROR. length: " << len << "ret size: " << size
             << "fd: " << fd_ << "offset :" << offset;
  return UDISK_IO_ERROR;
}

int32_t RawChunkHandle::PWrite(const void* data, uint64_t len, uint64_t offset,
     uevent::DiskIOCb cb, void* arg) {
  if (UNLIKELY((offset + len) > g_context->chunk_pool()->pc_size())) {
    ULOG_FATAL << "offset + len is beyond range,"
              << " offset: " << offset << " length: " << len;
  }
  int ret = chunk_storage_->loop_->disk_io_util()->SubmitWrite(
      fd_, (void*)data, offset_ + offset, len, cb, arg);

  if (ret >= 0) {
    ULOG_TRACE << "WRITE SUCCESS. length: " << len << ", retcode: " << ret
        << ", offset :" << offset << ", fd=" << fd_;
    return UDISK_OK;
  }
  ULOG_SYSERR << "IO WRITE ERROR. length: " << len << "ret code: " << ret
             << "fd: " << fd_ << "offset :" << offset;

  return UDISK_IO_ERROR;
}

int32_t RawChunkHandle::PWrite(const void* data, uint64_t len, uint64_t offset) {
  if (UNLIKELY((offset + len) > g_context->chunk_pool()->pc_size())) {
    ULOG_FATAL << "offset + len is beyond range,"
              << " offset: " << offset << " length: " << len;
  }
  // sync pwrite
  int32_t size = pwrite(fd_, data, len, offset_ + offset);
  if (size == (int32_t)len) {
    return UDISK_OK;
  }
  ULOG_SYSERR << "IO WRITE ERROR. length: " << len << "ret size: " << size
             << "fd: " << fd_ << "offset :" << offset;
  return UDISK_IO_ERROR;
}

}  // end of namespace chunk
}  // end of namespace udisk
