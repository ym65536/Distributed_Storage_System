#ifndef UDISK_CHUNK_STOREAGE_CHUNK_STORAGE_TYPE_H_
#define UDISK_CHUNK_STOREAGE_CHUNK_STORAGE_TYPE_H_

#include <list>
#include <sstream>

#include "bind_callback.h"
#include "likely.h"
#include <functional>

#define UDISK_FOREACH(iter, container)                           \
  for (decltype((container).begin()) iter = (container).begin(); \
       iter != (container).end(); ++iter)

namespace udisk {
namespace chunk {
class ChunkHandle;

enum ChunkStorageType {
  CHUNK_STORAGE_TYPE_MOCK = 0,
  CHUNK_STORAGE_TYPE_FILE = 1,
  CHUNK_STORAGE_TYPE_RAW = 2,
  CHUNK_STORAGE_TYPE_SPDK = 3,
};

struct ChunkID {
  uint32_t pg_id;         //
  uint32_t lc_id;         // udisk id
  uint32_t pc_no;         // pcg index in an udisk
  uint32_t lc_random_id;  // one hash random id for one udisk id
  ChunkID(const ChunkID& chunkID) {
    pg_id = chunkID.pg_id;
    lc_id = chunkID.lc_id;
    pc_no = chunkID.pc_no;
    lc_random_id = chunkID.lc_random_id;
  }
  ChunkID() {
    pg_id = 0;
    lc_id = 0;
    pc_no = 0;
    lc_random_id = 0;
  }
  ChunkID(uint32_t pg_id_, uint32_t lc_id_, uint32_t pc_no_,
          uint32_t lc_random_id_) {
    pg_id = pg_id_;
    lc_id = lc_id_;
    pc_no = pc_no_;
    lc_random_id = lc_random_id_;
  }
  inline std::string to_string() const {
    char buffer[64];
    sprintf(buffer, "%u_%u_%u_%u_", pg_id, lc_id, pc_no, lc_random_id);
    return buffer;
  }
  bool operator<(const ChunkID& chunkId) const {
    if (lc_id != chunkId.lc_id) {
      return lc_id < chunkId.lc_id;
    }
    if (pc_no != chunkId.pc_no) {
      return pc_no < chunkId.pc_no;
    }
    return pg_id < chunkId.pg_id;
  }

  bool operator==(const ChunkID& chunkId) const {
    return pg_id == chunkId.pg_id && lc_id == chunkId.lc_id &&
           pc_no == chunkId.pc_no &&
           (LIKELY(lc_random_id == chunkId.lc_random_id));
  }

  bool operator!=(const ChunkID& chunkId) const { return !(*this == chunkId); }
};

struct ChunkIDHash {
  std::size_t operator()(ChunkID const& item) const {
    uint64_t key = ((uint64_t)(item.lc_id) << 32) ^ (uint64_t)item.pc_no;
    return std::hash<uint64_t>()(key);
  }
};

inline std::string DumpChunkID(const ChunkID& chunkId) {
  std::ostringstream oss;
  oss << "\nchunk id: "
      << "\npg_id: " << chunkId.pg_id
      << "\nlc_id: " << chunkId.lc_id
      << "\npc_no: " << chunkId.pc_no
      << "\nlc_random_id: " << chunkId.lc_random_id;
  return oss.str();
}

typedef udisk::chunk::BindCallbackR1<int32_t> ChunkIoCallback;

typedef std::list<ChunkID> ChunkIDList;

typedef std::function<void(int)> ChunkOpCb;
typedef std::function<void(int, ChunkHandle*)> OpenChunkCb;

const uint32_t kErrorDevBlockSize = 0;
const uint32_t kErrorPCSize = 0;
const uint32_t kDefaultDevBlockSize = (4 << 10);
const uint32_t kDefaultPCSize = (32 << 20);

};  // end of namespace udisk
};  // end of namespace chunk


namespace udisk {
namespace journal {
// Journal PC ID
struct JPCID {
  uint32_t pg_id; // JS 所属
  uint32_t js_no;
  JPCID(const JPCID& js) {
    pg_id = js.pg_id;
    js_no = js.js_no;
  }

  JPCID() {
    pg_id = -1;
    js_no = -1;
  }

  JPCID(uint32_t pg_id, uint32_t js_no) {
    this->pg_id = pg_id;
    this->js_no = js_no;
  }

  inline const std::string ToString() {
    char buffer[100];
    snprintf(buffer, 100, "pg_id=%u,js_no=%u\n", pg_id, js_no);
    return std::string(buffer);
  } 
};

}; // end of namespace udisk
}; // end of namespace journal
#endif  // UDISK_CHUNK_STOREAGE_CHUNK_STORAGE_TYPE_H_
