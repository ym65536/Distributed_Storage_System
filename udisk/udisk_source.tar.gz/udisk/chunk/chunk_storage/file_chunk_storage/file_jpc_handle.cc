#include <errno.h>
#include <ustevent/base/logging.h>
#include "chunk_storage_errorcode.h"
#include "udisk_types.h"
#include "likely.h"
#include "file_jpc_handle.h"
#include "journal_format.h"

using namespace udisk::journal;
using namespace udisk::chunk;

FileJPCHandle::FileJPCHandle(int fd, uint32_t jpc_id): 
    fd_(fd), jpc_id_(jpc_id), base_offset_(0) {
}

uint32_t FileJPCHandle::JPCSize() const {
  return kJPCSize;
}

uint32_t FileJPCHandle::GetID() const {
  //return fd_;
  return jpc_id_;
}

int32_t FileJPCHandle::PRead(void* data, uint64_t offset, uint64_t len, 
                            uevent::DiskIOCb cb, void* arg, 
                            uevent::EventLoop* loop) {
  if (UNLIKELY((offset + len) > JPCSize())) {
    ULOG_FATAL << "beyond range. offset: " << offset << " length: " << len;
    return UDISK_INTERNAL_ERROR;
  }
  ULOG_DEBUG << "offset=" << offset << ", length=" << len;
  int32_t ret = 0;
  if ((cb == nullptr) || (loop == nullptr)) { // sync mode
    ret = pread(fd_, data, len, offset);
    if (ret != (int32_t)len) {
      ULOG_ERROR << "JPC READ ERROR. length: " << len << ", ret code:" << ret
          << ", fd:" << fd_ << ", offset :" << offset;
      return UDISK_IO_ERROR;
    }
  } else {
    int ret = loop->disk_io_util()->SubmitRead(
                            fd_, data, offset, len, cb, arg);
    if (ret > 0) {
      ULOG_ERROR << "JPC READ ERROR. length: " << len << ", ret code:" << ret
          << ", fd:" << fd_ << ", offset :" << offset;
      return UDISK_IO_ERROR;
    }
  }

  return UDISK_OK;
}

int32_t FileJPCHandle::PWrite(const void* data, uint64_t offset, uint64_t len, 
                             uevent::DiskIOCb cb, void* arg, 
                             uevent::EventLoop* loop) {
  if (UNLIKELY((offset + len) > JPCSize())) {
    ULOG_FATAL << "beyond range. offset: " << offset << " length: " << len;
    return UDISK_INTERNAL_ERROR;
  }
  ULOG_TRACE << "fd_=" << fd_ << ", offset=" << offset << ", length=" << len;
  int32_t ret;
  if ((cb == nullptr) || (loop == nullptr)) {
    ret = pwrite(fd_, data, len, offset);
    if (ret != (int32_t)len) {
      ULOG_ERROR << "JPC WRITE ERROR. length: " << len << ", ret code:" << ret
          << ", fd:" << fd_ << ", offset :" << offset;
      return UDISK_IO_ERROR;
    }
  } else {
    int ret = loop->disk_io_util()->SubmitWrite(
                        fd_, (void*)data, offset, len, cb, arg);
    if (ret <= 0) {
      ULOG_ERROR << "JPC WRITE ERROR. length: " << len << ", ret code:" << ret
          << ", fd:" << fd_ << ", offset :" << offset;
      return UDISK_IO_ERROR;
    }
  }

  return UDISK_OK;
}

int FileJPCHandle::ResetData() {
  uint64_t length = BLOCK_SIZE;
  char* buffer = nullptr;
  posix_memalign((void**)&buffer, BLOCK_SIZE, length);
  assert(buffer);
  ::memset(buffer, 0, length);
  ::memcpy(buffer, kEnding, kEndingSize);
  ULOG_TRACE << "Reset data. fd_=" << fd_ << ", jpc_id=" << jpc_id_ << ", length=" << length;
  int64_t ret = ::pwrite(fd_, buffer, length, base_offset_);
  if (ret != (int64_t)length) {
    ULOG_SYSERR << "Pwrite error, ret=" << ret << ", need length=" << length;
    free(buffer);
    return UDISK_DISK_ERROR;
  }
  free(buffer);
  return UDISK_OK;
}
