#include "file_chunk_handle.h"

#include <unistd.h>
#include <errno.h>

#include "likely.h"

namespace udisk {
namespace chunk {

FileChunkHandle::FileChunkHandle(ChunkStorage* chunk_storage)
    : fd_(-1), prev_(nullptr), next_(nullptr) {
  chunk_storage_ = chunk_storage;
}

int32_t FileChunkHandle::Init(const ChunkID& chunkID, int fd) {
  // TODO(fangran.fr) only init once
  chunk_id_ = chunkID;
  fd_ = fd;
  return UDISK_OK;
}

FileChunkHandle::~FileChunkHandle() {
  if (fd_ > 0) {
    close(fd_);
  }
}

int32_t FileChunkHandle::PRead(void* data, uint64_t len,
    uint64_t offset, uevent::DiskIOCb cb, void* arg) {
  int ret = chunk_storage_->loop_->disk_io_util()->SubmitRead(
      fd_, (void*)data, offset, len, cb, arg);
  if (ret >= 0) {
    ULOG_TRACE << "IO READ. length: " << len << "ret code: " << ret
            << "fd: " << fd_ << "offset :" << offset;
    return UDISK_OK;
  }
  ULOG_ERROR << "IO READ ERROR. length: " << len << "ret code: " << ret
            << "fd: " << fd_ << "offset :" << offset;
  return UDISK_IO_ERROR;
}

int32_t FileChunkHandle::PRead(void* data, uint64_t len, uint64_t offset) {
  int32_t size = pread(fd_, data, len, offset);
  if (size == (int32_t)len) {
    return UDISK_OK;
  }
  ULOG_SYSERR << "IO READ ERROR. length: " << len << "ret size: " << size
            << "fd: " << fd_ << "offset :" << offset;
  return UDISK_IO_ERROR;
}

int32_t FileChunkHandle::PWrite(const void* data, uint64_t len,
    uint64_t offset, uevent::DiskIOCb cb, void* arg) {
  int ret = chunk_storage_->loop_->disk_io_util()->SubmitWrite(
      fd_, (void*)data, offset, len, cb, arg);

  if (ret >= 0) {
    ULOG_TRACE << "IO WRITE. length: " << len << "ret code: " << ret
            << "fd: " << fd_ << "offset :" << offset;
    return UDISK_OK;
  }
  ULOG_ERROR << "IO WRITE ERROR. length: " << len << "ret code: " << ret
            << "fd: " << fd_ << "offset :" << offset;

  return UDISK_IO_ERROR;
}

int32_t FileChunkHandle::PWrite(const void* data, uint64_t len, uint64_t offset) {
  // sync pwrite
  int32_t size = pwrite(fd_, data, len, offset);
  if (size == (int32_t)len) {
    return UDISK_OK;
  }
  ULOG_SYSERR << "IO WRITE ERROR. length: " << len << "ret size: " << size
             << "fd: " << fd_ << "offset :" << offset;
  return UDISK_IO_ERROR;
}

};  // end of namespace chunk
};  // end of namespace udisk
