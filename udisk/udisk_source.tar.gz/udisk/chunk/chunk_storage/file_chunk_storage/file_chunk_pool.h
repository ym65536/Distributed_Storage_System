#ifndef UDISK_CHUNK_STORAGE_FILE_CHUNK_POOL_H_
#define UDISK_CHUNK_STORAGE_FILE_CHUNK_POOL_H_

#include <deque>
#include <string>
#include <mutex>
#include <vector>
#include <sstream>

#include "chunk_storage_type.h"
#include "chunk_pool.h"
#include "chunk_storage_errorcode.h"

namespace udisk {
namespace chunk {

class FileChunkPool : public ChunkPool {
 public:
  explicit FileChunkPool(const std::string& chunkdir);
  virtual ~FileChunkPool();
  virtual int32_t Init();
  virtual int32_t PutChunk(const ChunkID& chunkID);
  virtual int32_t PutChunk(const ChunkID& chunkID, ChunkOpCb done,
                              uevent::EventLoop* loop);
  virtual int32_t GetChunk(const ChunkID& chunkID);
  virtual int32_t GetChunk(const ChunkID& chunk_id, ChunkOpCb done,
                              uevent::EventLoop* loop);
  virtual int32_t GetExistChunkByPG(uint32_t pg_id, ChunkIDList* list);
  virtual uint64_t GetPoolRemainderCap();
  virtual int32_t FormatChunk(const ChunkID& chunkID);
  virtual bool Access(const ChunkID& chunkID);
  virtual int Open(const ChunkID& chunkID, uint64_t* offset);
  virtual std::string DumpChunkPoolInfo() {
    return "";
  }

  virtual uint32_t dev_block_size() const {
    return kDefaultDevBlockSize;
  }
  virtual uint32_t pc_size() const {
    return kDefaultPCSize;
  }

 private:
  std::string GetPath(const ChunkID& chunkid);

  bool FindPC(std::string* pc);
  bool FindPCNoLock(std::string* pc);

  bool ModifyPC(const std::string& dst, const std::string& src);

  bool CheckChunkSize(const std::string& filepath);

  // 只能由Init函数调用
  // 在chunk初始化时调用，所以不用加锁
  bool GetAllFileInDir();

  std::deque<std::string> pcs_;
  std::string pool_dir_;
  std::string chunk_dir_;
  std::mutex mtx_;
  bool is_init_;
};

};  // end of namespace chunk
};  // end of namespace udisk

#endif  // UDISK_CHUNK_STORAGE_FILE_CHUNK_POOL_H_
