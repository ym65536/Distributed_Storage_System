#ifndef UDISK_CHUNK_STORAGE_FILE_JPC_STORAGE_H_
#define UDISK_CHUNK_STORAGE_FILE_JPC_STORAGE_H_

#include <vector>
#include <deque>
#include <string>
#include "chunk_storage_type.h"
#include "file_jpc_handle.h"
#include "chunk_handle_vec_type.h"
#include "jpc_storage.h"

namespace udisk {
namespace journal {

class FileJPCStorage : public JPCStorage {
 public:
  FileJPCStorage(const std::string& chunk_dir);

  virtual ~FileJPCStorage();

  virtual void Init(int fd, uint32_t pg_id, const std::vector<chunk::JPCMeta*>& jms);
  virtual void Init(int fd, uint32_t pg_id);

  virtual JPCHandle* AcquireCompactJPC(uint32_t jpc_id);

  virtual JPCHandle* AcquireActiveJPC(uint32_t jpc_id);

  virtual JPCHandle* AcquireInActiveJPC(uint32_t jpc_id);

  virtual JPCHandle* AcquireFreeJPC();

  virtual void ReleaseJPC(const std::vector<uint32_t>& jpc_ids);

  void UpdateFreeJPC(const uint32_t active_zone[], uint32_t active_num,
                     const uint32_t inactive_zone[], uint32_t inactive_num);

  void JPCSwap();

 private:
  std::string GetPgPath(uint32_t pg_id);
  uint32_t GetPGJPCCount(const std::string& pg_dir);
  bool CheckJPCSize(const std::string& filepath);

  std::string chunk_dir_;
  std::string journal_dir_;
  uint32_t pg_id_;
  bool init_swap_;
  JPCPool compact_pool_;
  JPCPool active_pool_;
  JPCPool inactive_pool_;
  JPCFreeList active_free_list_;
  JPCFreeList inactive_free_list_;
};

};  // end of namespace chunk
};  // end of namespace udisk

#endif  // UDISK_CHUNK_STORAGE_FILE_CHUNK_STORAGE_H_
