#ifndef UDISK_CHUNK_STORAGE_FILE_CHUNK_HANDLE_H_
#define UDISK_CHUNK_STORAGE_FILE_CHUNK_HANDLE_H_

#include "chunk_storage_type.h"
#include "chunk_handle.h"
#include "chunk_storage.h"

namespace udisk {
namespace chunk {

class FileChunkHandle : public ChunkHandle {
 public:
  explicit FileChunkHandle(ChunkStorage* chunk_storage);
  virtual ~FileChunkHandle();
  int32_t PRead(void* data, uint64_t len, uint64_t offset,
                uevent::DiskIOCb cb, void* arg) override ;
  int32_t PRead(void* data, uint64_t len, uint64_t offset) override;
  int32_t PWrite(const void* data, uint64_t len, uint64_t offset,
                 uevent::DiskIOCb cb, void* arg) override;

  int32_t PWrite(const void* data, uint64_t len, uint64_t offset) override;
  int32_t Init(const ChunkID& chunkID, int fd);
  inline int fd() const { return fd_; }
  void removed() { chunk_storage_->CloseChunk(this); }
  friend class FileChunkHandleCache;

 private:
  int fd_;
  FileChunkHandle* prev_, *next_;
};

};  // end of namespace chunk
};  // end of namespace udisk

#endif  // UDISK_CHUNK_STORAGE_FILE_CHUNK_HANDLE_H_
