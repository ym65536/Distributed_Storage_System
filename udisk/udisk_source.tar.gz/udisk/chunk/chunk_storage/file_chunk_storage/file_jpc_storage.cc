#include "file_jpc_storage.h"
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <stdio.h>
#include <string.h>
#include "chunk_context.h"
#include "chunk_storage_type.h"
#include "likely.h"

using namespace udisk::journal;
using namespace udisk::chunk;

FileJPCStorage::FileJPCStorage(const std::string& chunk_dir) : 
                               chunk_dir_(chunk_dir), journal_dir_(chunk_dir + "/journal"), 
                               pg_id_(UINT_MAX), init_swap_(true) {

}


void FileJPCStorage::Init(int fd, uint32_t pg_id, const std::vector<JPCMeta*>& jms) {
  ULOG_ERROR << "fd=" << fd << ",pg_id=" << pg_id << " not implement.";
  return;
}

void FileJPCStorage::Init(int fd, uint32_t pg_id) {
  pg_id_ = pg_id;
  std::string pg_path = GetPgPath(pg_id);

  uint32_t jpc_cnt = GetPGJPCCount(pg_path);
  assert(jpc_cnt > kPGCompactJPCCount);

  //pg下jpc文件数不应超过最大jpc数
  uint32_t pg_jpc_cnt = jpc_cnt > kMaxJPCNumPerPG ? kMaxJPCNumPerPG : jpc_cnt;
  ULOG_INFO << "pg_path: " << pg_path << " fact jpc_cnt: " << jpc_cnt
            << " used jpc_cnt: " << pg_jpc_cnt;

  for (uint32_t i = 0; i < pg_jpc_cnt; i++) {
    std::string jpc_path = pg_path + "jpc_" + std::to_string(i);
    if (!CheckJPCSize(jpc_path)) {
      ULOG_FATAL << "journal pc file length error"
                << " jpc_path: " << jpc_path.c_str();
      assert(false);
    }

    int flags = O_RDWR | O_DIRECT | O_DSYNC;
    if (g_context->config().dsync_mode() == false) {
      flags = O_RDWR | O_DIRECT;
    }
    mode_t mode = 0644;
    int fd = ::open(jpc_path.c_str(), flags, mode);
    if (fd < 0) {
      ULOG_FATAL << "open journal pc file:" << jpc_path << " error. errno=" << errno;
    }

    if (i < kPGCompactJPCCount) {
      compact_pool_[i] = new FileJPCHandle(fd, i);
      ULOG_DEBUG << "pg_id=" << pg_id_ << ", Init compact pool. jpc_id=" 
          << i << ", fd= " << fd << ", filename = " << jpc_path;
    } else if (i > pg_jpc_cnt / 2) {
      inactive_pool_[i] = new FileJPCHandle(fd, i);
      inactive_free_list_.push_back(i);
      ULOG_DEBUG << "pg_id=" << pg_id_ << ", Init inactive pool. jpc_id=" 
          << i << ", fd= " << fd << ", filename = " << jpc_path;
    } else {
      active_pool_[i] = new FileJPCHandle(fd, i);
      active_free_list_.push_back(i);
      ULOG_DEBUG << "pg_id=" << pg_id_ << ", Init active pool. jpc_id=" 
          << i << ", fd= " << fd << ", filename = " << jpc_path;
    }
  }

  if (compact_pool_.size() != kPGCompactJPCCount) {
    ULOG_FATAL << "journal compact num error";
  }
  ULOG_DEBUG << "pg_id=" << pg_id_ << " Init File JPC Storage Success.";
}

FileJPCStorage::~FileJPCStorage() {
  for (auto item : compact_pool_) {
    delete item.second;
  }
  for (auto item : active_pool_) {
    delete item.second;
  }
  for (auto item : inactive_pool_) {
    delete item.second;
  }
}

std::string FileJPCStorage::GetPgPath(uint32_t pg_id) {
  std::stringstream ss;
  ss << journal_dir_ << "/" + to_string(pg_id) + "/";
  return ss.str();
}

JPCHandle* FileJPCStorage::AcquireCompactJPC(uint32_t jpc_id) {
  ULOG_DEBUG << "pg_id=" << pg_id_ << " access compact jpc_id=" << jpc_id;
  if (compact_pool_.count(jpc_id) == 0) {
    ULOG_ERROR << "Can not find compact jpc_id=" << jpc_id;
    return nullptr;
  }
  return compact_pool_[jpc_id];
}

JPCHandle* FileJPCStorage::AcquireActiveJPC(uint32_t jpc_id) {
  ULOG_DEBUG << "pg_id=" << pg_id_ << " access active jpc_id=" << jpc_id 
      << ", free list_size=" << active_free_list_.size();
  if (active_pool_.count(jpc_id) == 0) {
    ULOG_ERROR << "Can not find active jpc_id=" << jpc_id;
    return nullptr;
  }
  auto iter = std::find(active_free_list_.begin(), active_free_list_.end(), jpc_id);
  assert(iter == active_free_list_.end()); // exist必然已经分配过了
  return active_pool_[jpc_id];
}

JPCHandle* FileJPCStorage::AcquireInActiveJPC(uint32_t jpc_id) {
  ULOG_DEBUG << "pg_id=" << pg_id_ << " access inactive jpc_id=" << jpc_id 
      << ", free list_size=" << inactive_free_list_.size();
  if (inactive_pool_.count(jpc_id) == 0) {
    ULOG_ERROR << "Can not find inactive jpc_id=" << jpc_id;
    return nullptr;
  }
  auto iter = std::find(inactive_free_list_.begin(), inactive_free_list_.end(), jpc_id);
  assert(iter == inactive_free_list_.end()); // exist必然还未释放
  return inactive_pool_[jpc_id];
}

JPCHandle* FileJPCStorage::AcquireFreeJPC() {
  if (active_free_list_.empty()) {
    ULOG_DEBUG << "pg_id=" << pg_id_ << " No free jpc left.";
    return nullptr;
  }
  uint32_t jpc_id = active_free_list_.front();
  active_free_list_.pop_front();
  ULOG_DEBUG << "pg_id=" << pg_id_ << " access free jpc_id=" << jpc_id 
      << ", free list_size=" << active_free_list_.size() << ", inactive_free_list=" 
      << inactive_free_list_.size();
  return active_pool_[jpc_id];
}

void FileJPCStorage::UpdateFreeJPC(const uint32_t active_zone[], 
                                  uint32_t active_num,
                                  const uint32_t inactive_zone[],
                                  uint32_t inactive_num) {
  ULOG_DEBUG << "pg_id=" << pg_id_ << " Recv update jpc. active_num=" << active_num;
  for (uint32_t i = 0; i < active_num; ++ i) {
    uint32_t jpc_id = active_zone[i];
    if (init_swap_ && (active_pool_.count(jpc_id) == 0)) {
      init_swap_ = false;
      ULOG_WARN << "pg_id=" << pg_id_ << " Maybe active and inactive swap. reschedule";
      JPCSwap();
    }
    assert(active_pool_.count(jpc_id));
    auto iter = std::find(active_free_list_.begin(), active_free_list_.end(), jpc_id);
    assert(iter != active_free_list_.end());
    ULOG_DEBUG << "pg_id=" << pg_id_ << " Update Free active jpc_id=" << jpc_id;
    active_free_list_.erase(iter);
  }
  ULOG_DEBUG << "pg_id=" << pg_id_ << " Recv update jpc. inactive_num=" << inactive_num;
  for (uint32_t i = 0; i < inactive_num; ++ i) {
    uint32_t jpc_id = inactive_zone[i];
    assert(inactive_pool_.count(jpc_id));
    auto iter = std::find(inactive_free_list_.begin(), inactive_free_list_.end(), jpc_id);
    assert(iter != inactive_free_list_.end());
    ULOG_DEBUG << "pg_id=" << pg_id_ << " Update Free inactive jpc_id=" << jpc_id;
    inactive_free_list_.erase(iter);
  }
}

void FileJPCStorage::ReleaseJPC(const std::vector<uint32_t>& jpc_ids) {
  for (auto jpc_id : jpc_ids) {
    assert(inactive_pool_.count(jpc_id));
    auto iter = std::find(inactive_free_list_.begin(), inactive_free_list_.end(), jpc_id);
    assert(iter == inactive_free_list_.end());
    inactive_free_list_.push_back(jpc_id);
    auto ret = inactive_pool_[jpc_id]->ResetData();
    assert(ret == UDISK_OK);
    ULOG_DEBUG << "pg_id=" << pg_id_ << " release jpc_id=" << jpc_id << ", free list_size=" 
      << active_free_list_.size() << ", inactive_free_list=" 
      << inactive_free_list_.size();
  }
}

void FileJPCStorage::JPCSwap() {
  active_pool_.swap(inactive_pool_);
  active_free_list_.swap(inactive_free_list_);
  ULOG_DEBUG << "pg_id=" << pg_id_ << " jpc swap. free list_size=" << active_free_list_.size() 
    << ", inactive_free_list=" << inactive_free_list_.size();
}

uint32_t FileJPCStorage::GetPGJPCCount(const std::string& pg_dir) {
  if (pg_dir.empty()) {
    ULOG_SYSFATAL << "pg dir not exist, pg_dir:" << pg_dir;
    return 0;
  }

  std::string cmd = "ls " + pg_dir + " | wc -l";
  ULOG_INFO << cmd.c_str();
  FILE *fp = popen(cmd.c_str(), "r");
  char buffer[128];
  memset(buffer, 0, sizeof(buffer));
  fgets(buffer, sizeof(buffer), fp);
  pclose(fp);
  ULOG_INFO << buffer;
  uint32_t jpc_cnt = atoi(buffer);

  return jpc_cnt;
}

bool FileJPCStorage::CheckJPCSize(const std::string& filepath) {
  struct stat st;
  if (::lstat(filepath.c_str(), &st) < 0) {
    ULOG_ERROR << "lstat error, "
              << "filepath: " << filepath.c_str();
    return false;
  }
  // 判断pc文件大小
  if (st.st_size != kJPCSize) {
    ULOG_ERROR << " journal pc file length error"
               << " filepath: " << filepath.c_str()
               << " filelength: " << st.st_size;
    return false;
  }
  if (!S_ISREG(st.st_mode)) {
    return false;
  }
  return true;
}

