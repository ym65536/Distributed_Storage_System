#!/usr/bin/python
# -*- coding: utf-8 -*-

import time, sys, os, logging
import pymongo

def fetch_pg_info(db_ip, db_port, bad_chunk_id):
    '''
    查询坏盘所有的pg信息
    '''
    db = pymongo.MongoClient(db_ip, db_port)
    udisk = db["udisk"]
    t_pg_info = udisk["t_pg_info"]
    bad_pgs = t_pg_info.find({"$or": [{"chunk_0_id": bad_chunk_id}, {"chunk_1_id": bad_chunk_id}, {"chunk_2_id": bad_chunk_id}]})
    bad_pg_list = []
    for pg in bad_pgs:
        bad_pg_list.append(pg["id"])

    logging.info("fetch pg info successuflly! pg: ")
    logging.info(bad_pg_list)
    return bad_pg_list


def help():
    print "Usage: " + sys.argv[0] + " <mongo_ip> <mongo_port> <chunk_ip> <chunk_id> <uuid>"
def main():
    if len(sys.argv[1:]) != 5:
        help()
        sys.exit()
    db_ip = sys.argv[1]
    db_port = int(sys.argv[2])
    chunk_ip = sys.argv[3]
    chunk_id = int(sys.argv[4])
    uuid = sys.argv[5]

    pg_list = fetch_pg_info(db_ip, db_port, chunk_id)
    for pg in pg_list:
        cmd = "ssh root@%s 'mkdir -p /%s/chunk-%d/journal/%d'" %(chunk_ip, uuid, chunk_id, int(pg))
        print(cmd)
        os.system(cmd)

        # 创建metadata文件
        cmd = "ssh root@%s 'dd if=/dev/zero of=/%s/chunk-%d/journal/metadata bs=1048576 count=128 oflag=direct,nonblock'" %(chunk_ip, uuid, chunk_id)
        print(cmd)
        os.system(cmd)
        
        cmd = "ssh root@%s 'nohup /root/init_jpc_pool.sh 19595788288 134217728 /%s/chunk-%d/journal/%d > /dev/null 2>&1 &'" %(chunk_ip, uuid, chunk_id, int(pg))
        print(cmd)
        os.system(cmd)

if __name__ == '__main__':
    main()
