#include "umongo.h"
#include "str_list.h"
#include <string>
#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <getopt.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <ustevent/base/logging.h>
#include <ustevent/base/async_logging.h>
#include <ustevent/disk_io_util.h>
#include <ustevent/libevent/listener_libevent.h>
#include <ustevent/libevent/eventloop_libevent.h>
#include <ustevent/libevent/connector_libevent.h>
#include <ustevent/callbacks.h>
#include <ustevent/base/obj_pool.h>
#include <ustevent/worker_thread.h>
#include <ustevent/message_util.h>
#include <ustevent/base/my_uuid.h>
#include "journal_format.h"
#include "journal_meta.h"
#include "crc32c.h"


using namespace std;
using namespace udisk::chunk;

static void print_help(const char* name) {
  cout << "Usage: \n" << name << " [command] [args...] \n"
       << "help                                          | print this\n"
       << "init [uuid chunk_id umongoip port thread_num]\n";
}

static base::AsyncLogging* async_log = nullptr;
static const char* format_path = "/root/udisk/journal_init_log/";

static void async_log_put(const char* msg, int len) {
  cout << "msg:" << msg << endl;
  async_log->append(msg, len);
}

static void init_format_path() {
  DIR* dir = opendir(format_path);
  if (dir == NULL) {
    mkdir(format_path, 0777);
    return;
  }

  closedir(dir);
}

static void init_logging(const string& dev_name) {
  init_format_path();
  std::string name_str(format_path);
  name_str.append(basename(dev_name.c_str()));
  base::Logger::setLogLevel("debug");
  async_log = new base::AsyncLogging(name_str, 100 << 20, 1, false, false);
  async_log->start();
  base::Logger::setOutput(async_log_put);
}

std::vector<uint32_t> g_own_pgs;
std::mutex g_mutex;
std::condition_variable g_cv;

using namespace std::placeholders;
using namespace ucloud::umgogate;
using namespace ucloud::udisk;
using namespace uevent;

class MongoHandle {
 public:
  MongoHandle(std::string ip, uint32_t port, uint32_t chunk_id) 
    : ip_(ip), port_(port), chunk_id_(chunk_id) {
    ULOG_DEBUG << "Construct...";
  }
  ~MongoHandle() {
    ULOG_DEBUG << "Destruct...";
  }
  void Start() {
    uevent::Option option;
    option.enable_aio = true;
    mongo_thread_ = new uevent::WorkerThread("MongoThread", nullptr, option);
    mongo_loop_ = mongo_thread_->StartWorker()->eventloop();
    mongo_loop_->RunInLoop(std::bind(&MongoHandle::StartConnect, this));
  }

  void StartConnect() {
    // new connection
    std::stringstream ss;
    ss << "ctor-" << ip_ << ":" << port_;
    UsockAddress addr(ip_, port_, false);
    ctor_ = std::make_shared<uevent::ConnectorLibevent>(
          static_cast<uevent::PosixWorker*>(mongo_loop_->worker()), addr, ss.str());
    ctor_->SetConnectionSuccessCb(std::bind(&MongoHandle::OnConnSuccess, this, _1));
    ctor_->SetConnectionClosedCb(std::bind(&MongoHandle::OnConnClose, this, _1));
    ctor_->SetMessageReadCb(std::bind(&uevent::MessageUtil::ProtobufReadCallBack, _1));
    ctor_->Connect();
    ULOG_INFO << "Start connect to " << ss.str() << ", addr=" << addr.ToString();
  }

  void OnConnSuccess(const uevent::ConnectionUeventPtr& conn) {
    ULOG_DEBUG << "conn success...";
    ucloud::UMessage msg;
    uint32_t objid = uevent::MessageUtil::ObjId();
    uint32_t flowno = uevent::MessageUtil::Flowno();
    NewMessage_v2(&msg, flowno, base::MyUuid::NewUuid(),
                  EXECUTE_MGO_REQUEST, 0, false, objid, 0,
                  "GetPGInfo", NULL, NULL);
    ExecuteMgoRequest *req = msg.mutable_body()->MutableExtension(execute_mgo_request);
    construct_get_pg_info_request("udisk", req);
    ULOG_INFO << msg.DebugString();
    uevent::MessageUtil::SendPbRequest(conn, msg,
        std::bind(&MongoHandle::EntryGetPGInfo, this, _1),
        std::bind(&MongoHandle::Timeout, this), 5.0);
  } 

  void Timeout() {
    ULOG_ERROR << "Mongo timeout";
  }

  void EntryGetPGInfo(const UMessagePtr& msg) {
    ULOG_INFO << msg->DebugString();
    const ExecuteMgoResponse &res = msg->body().GetExtension(execute_mgo_response);
    if (res.rc().retcode() != 0) {
      ULOG_SYSFATAL << "get pg info from umgogate error, error msg: "
                   << res.rc().error_message();
    }
    std::vector<PGInfoPb> pginfos;
    if (!parse_get_pg_info_response(&res, pginfos)) {
      ULOG_SYSFATAL << "parse pg info error";
    }
    ULOG_DEBUG << "pginfos size : " << pginfos.size();
    std::set<uint32_t> tmp_pgs;
    for (auto info : pginfos) {
      for (auto i = 0; i < info.chunk_id_size(); ++ i) {
        if (chunk_id_ == info.chunk_id(i)) {
          tmp_pgs.insert(info.id());
        }
      }
    }
    {
      std::unique_lock<std::mutex> lck(g_mutex);
      g_own_pgs.assign(tmp_pgs.begin(), tmp_pgs.end());
    }
    ULOG_INFO << "g_own_pgs size: " << g_own_pgs.size();
    ULOG_INFO << "prase pg info complete";
    g_cv.notify_one();
  }

  void OnConnClose(const uevent::ConnectionUeventPtr& conn) {
    ULOG_DEBUG << "conn close...";
  }

 private:
  uevent::ConnectorUeventPtr ctor_;
  uevent::WorkerThread* mongo_thread_;
  uevent::EventLoop* mongo_loop_;
  std::string ip_;
  uint32_t port_;
  uint32_t chunk_id_;
};

bool GetAllFileInDir(const std::string& pg_dir) {
  if (pg_dir.empty()) {
    ULOG_ERROR << "pg dir not exist";
    return false;
  }

  struct stat s;
  if (::lstat(pg_dir.c_str(), &s) < 0) {
    ULOG_SYSERR << "lstat error, "
               << "pg_dir: " << pg_dir.c_str();
    return false;
  }
  if (!S_ISDIR(s.st_mode)) {
    ULOG_ERROR << "this path is not dir, " << pg_dir.c_str();
    return false;
  }

  struct dirent* filename;
  DIR* dir;
  dir = ::opendir(pg_dir.c_str());
  if (dir == nullptr) {
    ULOG_SYSERR << "open dir error, " << pg_dir.c_str();
    return false;
  }

  void* buf = nullptr;
  ::posix_memalign(&buf, BLOCK_SIZE, 4194304);

  while ((filename = ::readdir(dir)) != nullptr) {
    if (::strcmp(filename->d_name, ".") == 0 ||
        ::strcmp(filename->d_name, "..") == 0) {
      continue;
    }
    // filename->d_name获得是相对路径
    std::string filepath = pg_dir + "/" + std::string(filename->d_name);
    int mf_fd = open(filepath.c_str(), O_CREAT | O_RDWR, 0777);
    if (mf_fd < 0) {
      ULOG_ERROR << "open file error: " << filepath;
      return false;
    }
    ::memset(buf, 0, 4194304);
    ::memcpy(buf, udisk::journal::kEnding, udisk::journal::kEndingSize);
    int64_t ret = ::pwrite(mf_fd, buf, 4194304, 0);
    ULOG_INFO << "begin format jpc data: file: " << filepath;
    if (ret != 4194304) {
      ULOG_FATAL << "Format jpc block data fail. ret=" << ret << ", need=4194304"; 
      free(buf);
      return false;
    }

  }
  ULOG_INFO << "readdir errno: " << errno;
  ::closedir(dir);
  free(buf);
  return true;
}

int GenJournalPCFile(std::string& journal_base, std::vector<uint32_t>& own_pgs) {
  for(auto it = own_pgs.begin(); it != own_pgs.end(); it++) {
    std::string pg_path = journal_base + "/" + to_string(*it);
    std::string cmd = "/root/init_pc_pool.sh 19595788288 134217728 " + pg_path;
    ULOG_DEBUG << "pg_path: " << pg_path;
    ULOG_DEBUG << "init cmd: " << cmd;
    system(cmd.c_str());
  }
  return 0;
}

int ResetJournalData(std::string& journal_base, std::vector<uint32_t>& own_pgs) {

  for(auto it = own_pgs.begin(); it != own_pgs.end(); it++) {
    //std::deque<std::string> jpcs;
    std::string pg_path = journal_base + "/" + to_string(*it);
    if(!GetAllFileInDir(pg_path)) {
      ULOG_ERROR << pg_path << ": get journal pc file error";
      return -1;
    }
  }
  return 0;
}

int main(int argc, char** argv) {
  if (argc < 2) {
    print_help(argv[0]);
    return -1;
  }
  string operation(argv[1]);
  if (operation == "init") {
    if (argc < 3) {
      print_help(argv[0]);
      return -1;
    }
    string uuid(argv[2]);
    string chunk_id(argv[3]);
    string mongo_ip(argv[4]);
    uint32_t mongo_port = atoi(argv[5]);
    uint32_t chunkid = atoi(argv[3]);
    int thread_num = atoi(argv[6]);


    cout << "log is in " << format_path << endl;
    init_logging(uuid);
    ULOG_INFO << "begin init journal in chunk:" << chunk_id;

    string chunk_base = "/" + uuid + "/chunk-" + chunk_id;

    string journal_base = "/" + uuid  + "/chunk-" + chunk_id + "/journal";

    //创建journal base目录
    if (::access(journal_base.c_str(), F_OK) != 0) {
      ULOG_INFO << "create journal_base dir" << journal_base;
      int ret = mkdir(journal_base.c_str(), 0777);
      ULOG_INFO << "mkdir return value: " << ret;
      if (ret != 0) {
        ULOG_ERROR << "create journal_base dir failed!";
        return -1;
      }
    } else {
      ULOG_INFO << "journal_base dir existed";
    }

    MongoHandle* mongo_handle = new MongoHandle(mongo_ip, mongo_port, chunkid);
    mongo_handle->Start();

    ULOG_INFO << "Main thread wait for mongo response..."; 
    std::unique_lock<std::mutex> lck(g_mutex);
    g_cv.wait(lck, []{return !g_own_pgs.empty();});

    //创建pg目录
    for(auto it = g_own_pgs.begin(); it != g_own_pgs.end(); it++) {
      string pg_path = journal_base + "/" + to_string(*it);
      ULOG_INFO << "pg_path: " << pg_path;
      if (::access(pg_path.c_str(), F_OK) != 0) {
        if (mkdir(pg_path.c_str(), 0777) != 0) {
          ULOG_ERROR << "create pg path failed";
          return -1;
        }
      }
    }

    //todo 生成jpc文件
    //GenJournalPCFile(journal_base, g_own_pgs);
    //jpc文件初始化
    int ret = ResetJournalData(journal_base, g_own_pgs);

    assert(ret == 0);

    //初始化meta信息
    string journal_meta_path = journal_base + "/metadata";
    int mf_fd = open(journal_meta_path.c_str(), O_CREAT | O_RDWR, 0777);
    if (mf_fd < 0) {
      ULOG_ERROR << "open manifest error";
      goto err;
    }

    // 初始化journal元信息
    uint32_t jpc_offset = 0;
    uint32_t offset = 0;

    char* buffer = nullptr;
    posix_memalign((void**)&buffer, BLOCK_SIZE, udisk::journal::kBlockSize);
    assert(buffer);
    memset(buffer, 0, udisk::journal::kBlockSize);

    udisk::journal::UDiskJournalMeta* journal_meta = new (buffer) udisk::journal::UDiskJournalMeta();
    journal_meta->worker_num = thread_num;
    journal_meta->pg_num = g_own_pgs.size();

    for (size_t i = 0; i < g_own_pgs.size(); i++) {
      journal_meta->pg_ids[i] = g_own_pgs[i];
    }

    journal_meta->crc = udisk::common::CalCRC32C(buffer + sizeof(uint32_t), 
        sizeof(udisk::journal::UDiskJournalMeta) - sizeof(uint32_t) 
        + journal_meta->pg_num * sizeof(uint32_t));
    
    offset += BLOCK_SIZE;
    ULOG_INFO << "begin format journal worker_num:" << journal_meta->worker_num
        << " pg_num:" << journal_meta->pg_num << " crc:" << journal_meta->crc
        << " jpc_offset:" << jpc_offset << " offset:" << offset;

    //初始化compact meta
    for (uint32_t i = 0; i < journal_meta->pg_num; ++ i) {
      udisk::journal::PGCompactMeta* pgc_meta = new (buffer + offset) udisk::journal::PGCompactMeta();
      pgc_meta->pg_id = journal_meta->pg_ids[i];
      pgc_meta->active_offset = 0;
      pgc_meta->active_id = 0;
      for (uint32_t j = 0; j < kPGCompactJPCCount; ++ j) {
        string compact_jpc = journal_base + "/" + to_string(journal_meta->pg_ids[j]) + "/jpc_" + to_string(j);
        ULOG_DEBUG << "compact jpc: " << j << " filepath: " << compact_jpc;
        pgc_meta->zone[j].jpc_id = j;   // compact pg 对应 jpc_0  jpc_1 ... jpc_kPGCompactJPCCount-1
      }
      pgc_meta->crc = udisk::common::CalCRC32C(buffer + offset + sizeof(uint32_t), 
          sizeof(udisk::journal::PGCompactMeta) - sizeof(uint32_t));
      //int64_t ret = ::pwrite(mf_fd, pgc_meta, BLOCK_SIZE, jpc_offset + offset);
      ULOG_INFO << "begin format journal pg_compact_meta:" << pgc_meta->pg_id
          << " jpc_offset:" << jpc_offset << " offset:" << offset;

      offset += BLOCK_SIZE;
    }

    uint32_t length = BLOCK_SIZE * (1 + journal_meta->pg_num);

    ret = ::pwrite(mf_fd, buffer, length, jpc_offset);
    ULOG_INFO << "begin format compact_meta:" << " jpc_offset:" << jpc_offset 
        << " offset:" << offset << " length:" << length;
    if (ret != (int64_t)length) {
      ULOG_FATAL << "Format super block data fail. ret=" << ret << ", need=" << length; 
      free(buffer);
      return UDISK_DISK_ERROR;
    }

    jpc_offset += udisk::journal::kBlockSize;

    //初始化pg中的线程数据
    char* pg_buffer = nullptr;
    posix_memalign((void**)&pg_buffer, BLOCK_SIZE, udisk::journal::kBlockSize);
    assert(pg_buffer);
    for (uint32_t i = 0; i < journal_meta->pg_num; ++ i) {
      memset(pg_buffer, 0, udisk::journal::kBlockSize);
      uint32_t offset = 0;

      for (size_t j = 0; j < journal_meta->worker_num; j++) {
        udisk::journal::PGJournalMeta* pgj_meta = new (pg_buffer + offset) udisk::journal::PGJournalMeta();
        pgj_meta->pg_id = journal_meta->pg_ids[i];
        pgj_meta->active_num = 0;
        pgj_meta->inactive_num = 0;
        pgj_meta->crc = udisk::common::CalCRC32C(pg_buffer + offset + sizeof(uint32_t), 
            sizeof(udisk::journal::PGJournalMeta) - sizeof(uint32_t));
        offset += BLOCK_SIZE;
      }

      length = BLOCK_SIZE * journal_meta->worker_num;
      int64_t ret = ::pwrite(mf_fd, pg_buffer, length, jpc_offset);
      ULOG_INFO << "begin format pg_journal_meta:" << journal_meta->pg_ids[i] << " jpc_offset:" 
          << jpc_offset << " offset:" << offset << " length: " << length;
      if (ret != (int64_t)length) {
        ULOG_FATAL << "write pg_journal_meta data fail. ret=" << ret << ", need=" << length; 
        free(pg_buffer);
        return UDISK_DISK_ERROR;
      }
      jpc_offset += udisk::journal::kBlockSize;
    }

    free(pg_buffer);
    free(buffer);

    ULOG_INFO << "init journal success " << chunk_id;

    sleep(2);

    return 0;
  } else if (operation == "dumpsuperblock") {
    //TODO
  } 
  else {
    print_help(argv[0]);
  }
  return 0;

err:
  sleep(2);
  return -1;
}
