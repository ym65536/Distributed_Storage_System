#!/bin/bash

if [ $# -lt 3 ]
then
  echo "$0 size pc_size dir_path"
  echo "单位为B"
  exit 1
fi

log_file="/root/udisk/init_jpc_pool.log"

if [ ! -d "/root/udisk" ]
then
  mkdir /root/udisk
fi

echo "begin init pc pool" > $log_file

size=$1
pc_size=$2
dir_path=$3

begin_num=`ls -l $dir_path | grep -v total | wc -l`

pc_num=`expr $size / $pc_size`

echo "begin num: $begin_num" >> $log_file
echo "expect pc num: $pc_num" >> $log_file

block_size=1048576
count=`expr $pc_size / $block_size`

for((i = $begin_num; i < $pc_num; i++))
do
  file_name=$dir_path"/jpc_"$i
  dd if=/dev/zero of=$file_name bs=$block_size count=$count oflag=direct,nonblock
  if [ $? -ne 0 ]
  then
    echo "dd $i fail" >> $log_file
    exit 1
  fi
  echo "dd $i successfully" >> $log_file
done

total_num=`ls -l $dir_path | grep -v total | wc -l`
echo "total pc num: $total_num" >> $log_file
if [ $total_num -ne $pc_num ]
then
  echo "check pc num fail" >> $log_file
  exit 1
fi

size_invalid_num=`ls -l $dir_path | grep -v total | grep -v $pc_size | wc -l`
if [ $size_invalid_num -ne 0 ]
then
  echo "check pc size fail" >> $log_file
  exit 1
fi

echo "init jpc pool successfully" >> $log_file
