#ifndef UDISK_CHUNK_STORAGE_FILE_CHUNK_STORAGE_H_
#define UDISK_CHUNK_STORAGE_FILE_CHUNK_STORAGE_H_

#include <vector>

#include "chunk_storage_type.h"
#include "chunk_pool.h"
#include "file_chunk_handle.h"
#include "chunk_handle_vec_type.h"

namespace udisk {
namespace chunk {

class FileChunkHandle;

typedef std::vector<ChunkHandleVecType> UDiskChunkHandleVec;

class FileChunkHandleCache;

class FileChunkStorage : public ChunkStorage {
 public:
  explicit FileChunkStorage(const std::string& chunkdir);
  virtual ~FileChunkStorage();

  virtual int32_t Init(ChunkPool* chunkPool, uevent::EventLoop* loop);
  // 打开chunk对应的文件fd，并缓存该fd，如果在缓存中没有的话
  virtual int32_t OpenChunk(const ChunkID& id, bool is_create, 
                               OpenChunkCb done);

  virtual int32_t CloseChunk(ChunkHandle* chunkHandle);
  virtual int32_t CreateChunk(const ChunkID& id);
  virtual int32_t DeleteChunk(const ChunkID& id);

 private:
  std::string GetPath(const ChunkID& chunkid);

  // FileChunkHandleVec file_chunk_handles;
  UDiskChunkHandleVec udisk_chunk_handles_;
  std::string chunk_dir_;
  FileChunkHandleCache* cache_;
  bool is_init_;
};

class FileChunkHandleCache {
 public:
  explicit FileChunkHandleCache(size_t max_size)
      : max_size_(max_size), size_(0), head_(nullptr), tail_(nullptr) {
    head_.next_ = &tail_;
    tail_.prev_ = &head_;
  }

  size_t size() const { return size_; }

  friend class FileChunkHandle;
  friend class FileChunkStorage;

 private:
  void push_front(FileChunkHandle* fd) { add(&head_, head_.next_, fd); }

  void add(FileChunkHandle* prev, FileChunkHandle* next, FileChunkHandle* fd) {
    prev->next_ = fd;
    fd->prev_ = prev;
    fd->next_ = next;
    next->prev_ = fd;
    size_++;
    trim_cache();
  }

  void remove(FileChunkHandle* fd) {
    fd->prev_->next_ = fd->next_;
    fd->next_->prev_ = fd->prev_;
    fd->prev_ = nullptr;
    fd->next_ = nullptr;
    size_--;
  }

  void pin(FileChunkHandle* fd) {
    remove(fd);
    push_front(fd);
  }

  void trim_cache() {
    while (size_ > max_size_) {
      ULOG_INFO << "trim cache";
      FileChunkHandle* last_item = tail_.prev_;
      remove(last_item);
      last_item->removed();
      delete last_item;
    }
  }

 private:
  size_t max_size_;
  size_t size_;
  // 仅仅作为链表头
  FileChunkHandle head_;
  FileChunkHandle tail_;
};

};  // end of namespace chunk
};  // end of namespace udisk

#endif  // UDISK_CHUNK_STORAGE_FILE_CHUNK_STORAGE_H_
