#include "file_chunk_storage.h"

#include <fcntl.h>
#include <unistd.h>

#include "chunk_context.h"
#include "chunk_storage_type.h"
#include "chunk_pool.h"
#include "likely.h"

namespace udisk {
namespace chunk {

FileChunkStorage::FileChunkStorage(const std::string& chunkdir)
    : chunk_dir_(chunkdir), is_init_(false) {
  cache_ = new FileChunkHandleCache(
      g_context->config().fd_cache_max_size_per_loop());
  udisk_chunk_handles_.resize(g_context->config().max_udisk_num());
}

FileChunkStorage::~FileChunkStorage() {
  if (cache_ != nullptr) {
    delete cache_;
  }
}

int32_t FileChunkStorage::Init(ChunkPool* chunkPool,
                               uevent::EventLoop* loop) {
  if (is_init_) {
    return UDISK_ALREADY_INIT;
  }
  chunk_pool_ = chunkPool;
  loop_ = loop;
  is_init_ = true;
  return 0;
}

int32_t FileChunkStorage::CloseChunk(ChunkHandle* chunkHandle) {
  // assert(chunkHandle->chunk_id_.pc_no < (int)fds_.size() && fd == fds_[idx]);
  udisk_chunk_handles_[chunkHandle->chunk_id_.lc_id].Set(
      chunkHandle->chunk_id_.pc_no, nullptr);
  //delete chunkHandle;
  return 0;
}

int32_t FileChunkStorage::CreateChunk(const ChunkID& id) {
  return UDISK_NOT_IMPLEMENTED;
}

int32_t FileChunkStorage::DeleteChunk(const ChunkID& id) {
  return UDISK_NOT_IMPLEMENTED;
}

int32_t FileChunkStorage::OpenChunk(const ChunkID& chunkID, bool is_create, 
                                      OpenChunkCb done) {
  if (!is_init_) {
    return UDISK_NOT_INIT;
  }

  ChunkHandle* chunkHandle = nullptr;

  ChunkHandleVecType* file_chunk_handles =
      &(udisk_chunk_handles_[chunkID.lc_id]);
  
  if (file_chunk_handles->IsNeedResize(chunkID.pc_no)) { 
    file_chunk_handles->Resize(chunkID.pc_no, nullptr);
  } else if (file_chunk_handles->Get(chunkID.pc_no)) {
    cache_->pin(dynamic_cast<FileChunkHandle*>(file_chunk_handles->Get(chunkID.pc_no)));
    chunkHandle = file_chunk_handles->Get(chunkID.pc_no);
    done(UDISK_OK, chunkHandle);
    return UDISK_OK;
  }
  std::string chunk_path = GetPath(chunkID);
  if (::access(chunk_path.c_str(), F_OK) != 0) {
    if (UNLIKELY(is_create == false)) {
      return UDISK_PC_NOT_EXIST_ERROR;
    }
    if (chunk_pool_->GetChunk(chunkID) != UDISK_OK) {
      ULOG_SYSERR << "Get file error, "
                 << "chunk_path: " << chunk_path;
      return UDISK_GET_PC_ERROR;
    }
  }

  int flags = O_RDWR | O_DIRECT | O_DSYNC;
  if (g_context->config().dsync_mode() == false) {
    flags = O_RDWR | O_DIRECT;
  }

  mode_t mode = 0644;

  int fd = ::open(chunk_path.c_str(), flags, mode);
  if (fd < 0) {
    ULOG_ERROR << "open file error. errno=" << errno;
    return UDISK_OPEN_PC_ERROR;
  }
  FileChunkHandle* ret = new FileChunkHandle(this);
  ret->Init(chunkID, fd);
  file_chunk_handles->Set(chunkID.pc_no, ret);
  cache_->push_front(ret);
  chunkHandle = ret;

  done(UDISK_OK, chunkHandle);

  return UDISK_OK;
}

std::string FileChunkStorage::GetPath(const ChunkID& chunkID) {
  std::stringstream ss;
  ss << chunk_dir_ << "/data/" << chunkID.pg_id << "/" << chunkID.lc_id << "-"
     << chunkID.pc_no << "-" << chunkID.lc_random_id;
  return ss.str();
}

};  // end of namespace chunk
};  // end of namespace udisk
