#include "file_chunk_pool.h"

#include <unistd.h>
#include <dirent.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <stdio.h>
#include <string.h>

#include <ustevent/base/logging.h>
#include <ustevent/base/my_uuid.h>
#include "chunk_context.h"
#include "udisk_types.h"
#include "chunk_storage_type.h"
#include "str_list.h"

namespace udisk {
namespace chunk {

FileChunkPool::~FileChunkPool() {}

FileChunkPool::FileChunkPool(const std::string& chunkdir)
    : pool_dir_(chunkdir + "/pool"), chunk_dir_(chunkdir), is_init_(false) {}

bool FileChunkPool::GetAllFileInDir() {
  if (pool_dir_.empty()) {
    ULOG_ERROR << "pool dir not exist";
    return false;
  }

  struct stat s;
  if (::lstat(pool_dir_.c_str(), &s) < 0) {
    ULOG_SYSERR << "lstat error, "
               << "pool_dir: " << pool_dir_.c_str();
    return false;
  }
  if (!S_ISDIR(s.st_mode)) {
    ULOG_ERROR << "this path is not dir, " << pool_dir_.c_str();
    return false;
  }

  struct dirent* filename;
  DIR* dir;
  dir = ::opendir(pool_dir_.c_str());
  if (dir == nullptr) {
    ULOG_SYSERR << "open dir error, " << pool_dir_.c_str();
    return false;
  }

  while ((filename = ::readdir(dir)) != nullptr) {
    if (::strcmp(filename->d_name, ".") == 0 ||
        ::strcmp(filename->d_name, "..") == 0) {
      continue;
    }
    // filename->d_name获得是相对路径
    std::string filepath = pool_dir_ + "/" + std::string(filename->d_name);
    if (!CheckChunkSize(filepath)) {
      ULOG_FATAL << "pc file length error"
                << " filepath: " << filepath.c_str();
      assert(false);
      return false;
    }
    pcs_.push_back(filename->d_name);
  }
  ULOG_INFO << "readdir errno: " << errno;
  ::closedir(dir);
  return true;
}

bool FileChunkPool::CheckChunkSize(const std::string& filepath) {
  struct stat st;
  if (::lstat(filepath.c_str(), &st) < 0) {
    ULOG_ERROR << "lstat error, "
              << "filepath: " << filepath.c_str();
    return false;
  }
  // 判断pc文件大小
  if (st.st_size != pc_size()) {
    ULOG_ERROR << "pc file length error"
               << " filepath: " << filepath.c_str()
               << " filelength: " << st.st_size;
    return false;
  }
  if (!S_ISREG(st.st_mode)) {
    return false;
  }
  return true;
}

int32_t FileChunkPool::Init() {
  if (is_init_) {
    return UDISK_NOT_INIT;
  }
  if (!GetAllFileInDir()) {
    return UDISK_GET_FILE_ERROR;
  }
  ULOG_INFO << "pc pool size: " << pcs_.size();
  if (pcs_.empty()) {
    ULOG_WARN << "pc pool is empty";
  }
  is_init_ = true;
  return UDISK_OK;
}

std::string FileChunkPool::GetPath(const ChunkID& chunkID) {
  std::stringstream ss;
  ss << chunk_dir_ << "/data"
     << "/" << chunkID.pg_id << "/" << chunkID.lc_id << "-" << chunkID.pc_no
     << "-" << chunkID.lc_random_id;
  return ss.str();
}

int32_t FileChunkPool::PutChunk(const ChunkID& chunkID) {
  std::string srcpath = GetPath(chunkID);
  if (!is_init_) {
    return UDISK_NOT_INIT;
  }
  std::string pc = base::MyUuid::NewUuid();
  std::string dstpath = pool_dir_ + "/" + pc;
  if (!CheckChunkSize(srcpath)) {
    ULOG_ERROR << "PC File Size ERROR";
    return UDISK_INTERNAL_ERROR;
  }
  if (!ModifyPC(dstpath, srcpath)) {
    return UDISK_RENAME_FILE_ERROR;
  }
  std::lock_guard<std::mutex> lck(mtx_);
  pcs_.push_back(pc);
  return UDISK_OK;
}

int32_t FileChunkPool::PutChunk(const ChunkID& chunkID, ChunkOpCb done,
                                   uevent::EventLoop* loop) {
  return UDISK_NOT_IMPLEMENTED;
}

int32_t FileChunkPool::GetChunk(const ChunkID& chunkID) {
  std::string dstpath = GetPath(chunkID);
  if (!is_init_) {
    ULOG_ERROR << "pc pool is not inited";
    return UDISK_NOT_INIT;
  }
  std::string pc;
  std::lock_guard<std::mutex> lck(mtx_);
  if (::access(dstpath.c_str(), F_OK) == 0) {
    ULOG_ERROR << "this pc already allocate: "
               << dstpath;
    return UDISK_CHUNKID_IS_USED;
  }
  if (!FindPCNoLock(&pc)) {
    return UDISK_ZERO_PC_ERROR;
  }
  std::string srcpath = pool_dir_ + "/" + pc;
  if (!ModifyPC(dstpath, srcpath)) {
    return UDISK_RENAME_FILE_ERROR;
  }
  return UDISK_OK;
}

int32_t FileChunkPool::GetChunk(const ChunkID& chunk_id, ChunkOpCb done,
                                  uevent::EventLoop* loop) {
  return UDISK_NOT_IMPLEMENTED;
}

int32_t FileChunkPool::FormatChunk(const ChunkID& chunkID) {
  return UDISK_NOT_IMPLEMENTED;
}

bool FileChunkPool::Access(const ChunkID& chunkID) {
  return UDISK_NOT_IMPLEMENTED;
}

int FileChunkPool::Open(const ChunkID& chunkID, uint64_t* offset) {
  return UDISK_NOT_IMPLEMENTED;
}

int32_t FileChunkPool::GetExistChunkByPG(uint32_t pg_id, ChunkIDList* list) {
  DIR* dir;
  struct dirent* ptr;
  int ret = UDISK_OK;

  list->clear();
  std::stringstream ss;
  // 数据存储目录
  ss << chunk_dir_ << "/data"
     << "/" << pg_id;
  std::string path = ss.str();
  if (access(path.c_str(), F_OK) != 0) {
    ULOG_ERROR << "Access path=" << path << " not exist.";
    return UDISK_OK;
  }

  if ((dir = opendir(path.c_str())) == NULL) {
    ULOG_ERROR << "open dir=" << path << " fail.";
    return UDISK_OPEN_DIR_ERROR;
  }

  while ((ptr = readdir(dir)) != NULL) {
    std::string pathname = ptr->d_name;
    if (pathname == "." || pathname == "..") {  /// current dir OR parrent dir
      continue;
    }
    if (ptr->d_type == DT_REG || ptr->d_type == DT_UNKNOWN) {
      // FixMe: 部分文件系统(xfs等)不支持d_type字段，会返回DT_UNKNOWN,
      // 对这部分文件系统，读取内容当做正常文件
      std::vector<std::string> vec;
      common::get_str_vec(pathname, "-", vec);
      if (vec.size() != 3) {
        ULOG_ERROR << "Get path name error: pathname=" << pathname;
        ret = UDISK_FILE_PATH_ERROR;
        break;
      }
      ULOG_DEBUG << "pathname=" << pathname << ", " << vec[0] << ", " << vec[1]
                << ", " << vec[2];
      ChunkID id;
      id.lc_id = (uint32_t)stoul(vec[0]);
      id.pg_id = pg_id;
      id.pc_no = (uint32_t)stoul(vec[1]);
      id.lc_random_id = (uint32_t)stoul(vec[2]);
      list->push_back(id);
    } else {
      ULOG_ERROR << "get unknown type file, name=" << pathname
                << ", type=" << ptr->d_type;
      ret = UDISK_FILE_TYPE_ERROR;
      break;
    }
  }

  closedir(dir);
  return ret;
}

bool FileChunkPool::FindPC(std::string* pc) {
  if (pcs_.empty()) {
    ULOG_ERROR << "pc pool is empty";
    return false;
  }
  std::lock_guard<std::mutex> lck(mtx_);
  if (pcs_.empty()) {
    ULOG_ERROR << "pc pool is empty";
    return false;
  }
  *pc = pcs_.front();
  pcs_.pop_front();
  ULOG_DEBUG << "acquire new pc=" << *pc;
  return true;
}

bool FileChunkPool::FindPCNoLock(std::string* pc) {
  if (pcs_.empty()) {
    ULOG_ERROR << "pc pool is empty";
    return false;
  }
  *pc = pcs_.front();
  pcs_.pop_front();
  ULOG_DEBUG << "acquire new pc=" << *pc;
  return true;
}

uint64_t FileChunkPool::GetPoolRemainderCap() {
  uint64_t cap = 0;
  cap = pcs_.size() * pc_size();
  return cap;
}

bool FileChunkPool::ModifyPC(const std::string& dst, const std::string& src) {
  ULOG_DEBUG << "dst=" << dst << ",src=" << src;
  if (::rename(src.c_str(), dst.c_str()) == 0) {
    return true;
  } else {
    ULOG_SYSERR << "rename file error, "
               << "src: " << src.c_str() << "dst: " << dst.c_str();
    return false;
  }
}

};  // end of namespace chunk
};  // end of namespace udisk
