#include <gtest/gtest.h>
#include <unistd.h>
#include <sys/time.h>
#include <sstream>
#include <fstream>
#include <malloc.h>

#include "chunk_storage_type.h"
#include "mock_chunk_pool.h"
#include "mock_chunk_storage.h"
#include "file_chunk_storage.h"
#include "file_chunk_pool.h"
#include <ustevent/base/logging.h>
#include "chunk_storage_flags.h"
#include "my_uuid.h"
#include "chunk_storage_errorcode.h"
#include "simple_object_cache_pool.h"

class MyObject {
 public:
  MyObject() { sConstructorCalls++; }
  ~MyObject() { sDestructorCalls++; }

  static int sConstructorCalls;
  static int sDestructorCalls;
};

int MyObject::sConstructorCalls;
int MyObject::sDestructorCalls;

class HandleCallback {
 public:
  void AioResponseHandle(uevent::AioParam* param) {}
};

TEST(ObjectCachePool, TestNoSpace) {
  udisk::chunk::SimpleMemCacheOptions options;
  udisk::chunk::SimpleMemCache mMemCache;
  options.objectSize = sizeof(MyObject);
  options.name = "test_cache";
  options.limit = 1;
  mMemCache.Init(options);
  udisk::chunk::SimpleObjectCachePool<MyObject> pool;
  pool.Init(&mMemCache, true);
  MyObject* a = pool.Alloc();
  MyObject* b = pool.Alloc();
  EXPECT_TRUE(a != NULL);
  EXPECT_TRUE(b == NULL);
}

TEST(ObjectCachePool, TestReuse) {
  udisk::chunk::SimpleMemCacheOptions options;
  udisk::chunk::SimpleMemCache mMemCache;
  options.objectSize = sizeof(MyObject);
  options.name = "test_cache";
  // options.limit = 1;
  mMemCache.Init(options);
  MyObject* a = NULL;
  MyObject* b = NULL;
  {
    udisk::chunk::SimpleObjectCachePool<MyObject> pool;
    pool.Init(&mMemCache, true);
    a = pool.Alloc();
  }
  {
    udisk::chunk::SimpleObjectCachePool<MyObject> pool;
    pool.Init(&mMemCache, true);
    b = pool.Alloc();
  }
  EXPECT_TRUE(a != NULL);
  EXPECT_EQ(a, b);
}

TEST(ObjectCachePool, TestConstructDestruct) {
  MyObject::sConstructorCalls = 0;
  MyObject::sDestructorCalls = 0;
  {
    udisk::chunk::SimpleObjectCachePool<MyObject> pool;
    udisk::chunk::SimpleMemCacheOptions options;
    udisk::chunk::SimpleMemCache mMemCache;
    options.objectSize = sizeof(MyObject);
    options.name = "test_cache";
    // options.limit = 1;
    mMemCache.Init(options);
    pool.Init(&mMemCache, true);
    EXPECT_EQ(0, MyObject::sConstructorCalls);
    EXPECT_EQ(0, MyObject::sDestructorCalls);
    MyObject* a = pool.Alloc();
    EXPECT_NE(a, nullptr);
    EXPECT_EQ(1, MyObject::sConstructorCalls);
    EXPECT_EQ(0, MyObject::sDestructorCalls);
  }
  EXPECT_EQ(1, MyObject::sConstructorCalls);
  EXPECT_EQ(1, MyObject::sDestructorCalls);
}

TEST(FileChunkStorage, cachesize_op) {
  struct timeval tv;
  gettimeofday(&tv, NULL);
  int64_t seconds = tv.tv_sec;
  std::stringstream ss;
  ss << "./test_file_chunk_storage_cachesize" << seconds;
  std::string dir = ss.str();
  EXPECT_EQ(access(dir.c_str(), 0), -1);
  EXPECT_EQ(mkdir(dir.c_str(), 0777), 0);
  EXPECT_EQ(mkdir((dir + "/pool").c_str(), 0777), 0);
  EXPECT_EQ(mkdir((dir + "/data").c_str(), 0777), 0);
  EXPECT_EQ(mkdir((dir + "/data/0").c_str(), 0777), 0);
  EXPECT_EQ(mkdir((dir + "/data/1").c_str(), 0777), 0);
  EXPECT_EQ(mkdir((dir + "/data/2").c_str(), 0777), 0);
  google::SetCommandLineOption("udisk_chunkserver_FDCacheNum", "1");
  std::string pc;
  for (int i = 0; i < 30; ++i) {
    pc = base::MyUuid::NewUuid();
    std::ofstream o((dir + "/pool/" + pc));
    o << "test" << std::endl;
  }

  udisk::chunk::ChunkStorage* chunk_storage_ = nullptr;
  udisk::chunk::ChunkLoopHandleBase* loop_handle_ = nullptr;
  uevent::UeventLoopThread* thread_ = nullptr;
  uevent::UeventLoop* loop_ = nullptr;
  thread_ = new uevent::UeventLoopThread();
  loop_ = thread_->StartLoop();
  loop_handle_ = new udisk::chunk::ChunkLoopHandleBase();
  loop_handle_->SetLoop(loop_);
  chunk_storage_ = new udisk::chunk::FileChunkStorage(dir);
  udisk::chunk::ChunkHandle* mChunkHandle = nullptr;
  udisk::chunk::ChunkID mChunkID(0, 0, 0, 0);
  udisk::chunk::ChunkPool* mFileChunkPool = nullptr;
  mFileChunkPool = new udisk::chunk::FileChunkPool(dir);
  mFileChunkPool->Init();
  chunk_storage_->Init(mFileChunkPool, loop_handle_);
  EXPECT_EQ(chunk_storage_->OpenChunk(mChunkID, &mChunkHandle, true),
            udisk::chunk::UDISK_OK);
  void* data = ::memalign(512, 512);
  EXPECT_EQ(mChunkHandle->PWrite((void*)data, 512, 0, nullptr),
            udisk::chunk::UDISK_OK);

  HandleCallback handle_call_back;
  uevent::AioResponseCb cb =
      std::bind(&HandleCallback::AioResponseHandle, &handle_call_back,
                std::placeholders::_1);

  EXPECT_EQ(mChunkHandle->PWrite((void*)data, 512, 0, &cb),
            udisk::chunk::UDISK_OK);

  mChunkID.pc_no = 1;
  EXPECT_EQ(chunk_storage_->OpenChunk(mChunkID, &mChunkHandle, true),
            udisk::chunk::UDISK_OK);
  mChunkID.pc_no = 2;
  EXPECT_EQ(chunk_storage_->OpenChunk(mChunkID, &mChunkHandle, true),
            udisk::chunk::UDISK_OK);

  // 测试在create设置为false时打开不存在chunk是否正常返回null
  mChunkID.pc_no = 222;
  EXPECT_EQ(chunk_storage_->OpenChunk(mChunkID, &mChunkHandle, false),
            udisk::chunk::UDISK_PC_NOT_EXIST_ERROR);
  EXPECT_EQ(mChunkHandle, nullptr);

  // 测试在create设置为false时打开被cache替换出去的chunk能够正常返回
  mChunkID.pc_no = 1;
  EXPECT_EQ(chunk_storage_->OpenChunk(mChunkID, &mChunkHandle, false),
            udisk::chunk::UDISK_OK);
  EXPECT_NE(mChunkHandle, nullptr);

  free(data);
  // TODO(fangran.fr) fix remove chunk direction
  // EXPECT_EQ(remove(dir.c_str()), 0);
}

TEST(FileChunkStorage, basic_op) {
  struct timeval tv;
  gettimeofday(&tv, NULL);
  int64_t seconds = tv.tv_sec;
  std::stringstream ss;
  ss << "./test_file_chunk_storage_" << seconds;
  std::string dir = ss.str();
  EXPECT_EQ(access(dir.c_str(), 0), -1);
  EXPECT_EQ(mkdir(dir.c_str(), 0777), 0);
  EXPECT_EQ(mkdir((dir + "/pool").c_str(), 0777), 0);
  EXPECT_EQ(mkdir((dir + "/data").c_str(), 0777), 0);
  EXPECT_EQ(mkdir((dir + "/data/0").c_str(), 0777), 0);
  EXPECT_EQ(mkdir((dir + "/data/1").c_str(), 0777), 0);
  EXPECT_EQ(mkdir((dir + "/data/2").c_str(), 0777), 0);
  std::string pc;
  for (int i = 0; i < 30; ++i) {
    pc = base::MyUuid::NewUuid();
    std::ofstream o((dir + "/pool/" + pc));
    o << "test" << std::endl;
  }

  udisk::chunk::ChunkStorage* chunk_storage_ = nullptr;
  chunk_storage_ = new udisk::chunk::FileChunkStorage(dir);
  udisk::chunk::ChunkHandle* mChunkHandle = nullptr;
  udisk::chunk::ChunkID mChunkID(0, 0, 0, 0);
  udisk::chunk::ChunkPool* mFileChunkPool = nullptr;
  mFileChunkPool = new udisk::chunk::FileChunkPool(dir);
  mFileChunkPool->Init();
  chunk_storage_->Init(mFileChunkPool, nullptr);
  EXPECT_EQ(chunk_storage_->OpenChunk(mChunkID, &mChunkHandle, true),
            udisk::chunk::UDISK_OK);
  void* data = ::memalign(512, 512);
  EXPECT_EQ(mChunkHandle->PWrite((void*)data, 512, 0, nullptr),
            udisk::chunk::UDISK_OK);
  mChunkID.pc_no = 1;
  EXPECT_EQ(chunk_storage_->OpenChunk(mChunkID, &mChunkHandle, true),
            udisk::chunk::UDISK_OK);
  mChunkID.pc_no = 2;
  EXPECT_EQ(chunk_storage_->OpenChunk(mChunkID, &mChunkHandle, true),
            udisk::chunk::UDISK_OK);

  // 测试在create设置为false时打开不存在chunk是否正常返回null
  // [to #80] 且返回错误码UDISK_PC_NOT_EXIST_ERROR
  // https://gitlab.ucloudadmin.com/ucsd-udisk/udisk/issues/80
  mChunkID.pc_no = 222;
  EXPECT_EQ(chunk_storage_->OpenChunk(mChunkID, &mChunkHandle, false),
            udisk::chunk::UDISK_PC_NOT_EXIST_ERROR);
  EXPECT_EQ(mChunkHandle, nullptr);

  // 测试获取pg chunkidlist
  udisk::chunk::ChunkIDList chunkIDlist;
  EXPECT_EQ(mFileChunkPool->GetExistChunkByPG(0, &chunkIDlist),
            udisk::chunk::UDISK_OK);

  EXPECT_EQ(chunkIDlist.size(), 3);

  free(data);
  // TODO(fangran.fr) fix remove chunk direction
  // EXPECT_EQ(remove(dir.c_str()), 0);
}

TEST(FileChunkPool, basic_op) {
  struct timeval tv;
  gettimeofday(&tv, NULL);
  int64_t seconds = tv.tv_sec;
  std::stringstream ss;
  ss << "./test_file_chunk_pool_" << seconds;
  std::string dir = ss.str();
  EXPECT_EQ(access(dir.c_str(), 0), -1);
  EXPECT_EQ(mkdir(dir.c_str(), 0777), 0);
  EXPECT_EQ(mkdir((dir + "/pool").c_str(), 0777), 0);
  EXPECT_EQ(mkdir((dir + "/data").c_str(), 0777), 0);
  EXPECT_EQ(mkdir((dir + "/data/0").c_str(), 0777), 0);
  EXPECT_EQ(mkdir((dir + "/data/1").c_str(), 0777), 0);
  EXPECT_EQ(mkdir((dir + "/data/2").c_str(), 0777), 0);
  std::string pc = base::MyUuid::NewUuid();
  {
    std::ofstream o((dir + "/pool/" + pc));
    o << "test" << std::endl;
  }
  udisk::chunk::ChunkPool* mFileChunkPool = nullptr;
  mFileChunkPool = new udisk::chunk::FileChunkPool(dir);
  udisk::chunk::ChunkID mChunkID(0, 0, 0, 0);
  EXPECT_EQ(mFileChunkPool->Init(), 0);
  EXPECT_EQ(mFileChunkPool->GetChunk(mChunkID), udisk::chunk::UDISK_OK);
  EXPECT_EQ(mFileChunkPool->GetChunk(mChunkID),
            udisk::chunk::UDISK_ZERO_PC_ERROR);
  udisk::chunk::ChunkID mChunkID2(1, 1, 1, 1);
  EXPECT_EQ(mFileChunkPool->PutChunk(mChunkID2),
            udisk::chunk::UDISK_INTERNAL_ERROR);
  EXPECT_EQ(mFileChunkPool->PutChunk(mChunkID), udisk::chunk::UDISK_OK);
  EXPECT_EQ(mFileChunkPool->GetChunk(mChunkID), udisk::chunk::UDISK_OK);

  // TODO(fangran.fr) fix remove chunk direction
  // EXPECT_EQ(remove(dir.c_str()), 0);
}

TEST(MockChunkStorage, basic_op) {
  udisk::chunk::MockChunkStorage mMockChunkStorage;
  udisk::chunk::ChunkID mChunkID;
  mChunkID.pg_id = 1;
  mChunkID.lc_id = 1;
  mChunkID.pc_no = 1;
  mChunkID.lc_random_id = 1;

  void* buf = NULL;
  buf = mMockChunkStorage.NewBuffer(4 * 1024 * 1024, 4 * 1024);
  EXPECT_EQ(buf != NULL, true);
  mMockChunkStorage.FreeBuffer(buf, 4 * 1024 * 1024);

  EXPECT_EQ(mMockChunkStorage.OpenChunk(mChunkID, NULL, false),
            udisk::chunk::UDISK_OK);
  EXPECT_EQ(mMockChunkStorage.CloseChunk(NULL), udisk::chunk::UDISK_OK);
  EXPECT_EQ(mMockChunkStorage.CreateChunk(mChunkID), udisk::chunk::UDISK_OK);
  EXPECT_EQ(mMockChunkStorage.DeleteChunk(mChunkID), udisk::chunk::UDISK_OK);
}

/*
TEST(FileChunkPool, basic_op) {
    udisk::chunk::FileChunkPool mFileChunkPool("test");
    udisk::chunk::ChunkID mChunkID;
    mChunkID.pg_id = 1;
    mChunkID.lc_id = 1;
    mChunkID.pc_no = 1;
    mChunkID.lc_random_id = 1;
}
*/

TEST(MockChunkPool, basic_op) {
  udisk::chunk::MockChunkPool mMockChunkPool;
  udisk::chunk::ChunkID mChunkID;
  mChunkID.pg_id = 1;
  mChunkID.lc_id = 1;
  mChunkID.pc_no = 1;
  mChunkID.lc_random_id = 1;

  EXPECT_EQ(mMockChunkPool.Init(), udisk::chunk::UDISK_OK);
  EXPECT_EQ(mMockChunkPool.PutChunk(mChunkID), udisk::chunk::UDISK_OK);
  EXPECT_EQ(mMockChunkPool.GetChunk(mChunkID), udisk::chunk::UDISK_OK);
}

TEST(ChunkID, to_string) {
  udisk::chunk::ChunkID mChunkID;
  mChunkID.pg_id = 1;
  mChunkID.lc_id = 1;
  mChunkID.pc_no = 1;
  mChunkID.lc_random_id = 1;
  EXPECT_EQ(mChunkID.to_string(), "1_1_1_1_");
  mChunkID.pc_no = 2;
  EXPECT_EQ(mChunkID.to_string(), "1_1_2_1_");
  mChunkID.pc_no = 3;
  EXPECT_NE(mChunkID.to_string(), "1_1_2_1_");
}

int main(int argc, char** argv) {
  ::testing::InitGoogleTest(&argc, argv);
  base::Logger::setLogLevel(base::Logger::LogLevel::INFO);
  // set sector size to 5 byte to pass ut
  google::SetCommandLineOption("udisk_chunkserver_ChunkSize", "5");

  return RUN_ALL_TESTS();
}
