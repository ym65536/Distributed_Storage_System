#include "chunk_handle_vec_type.h"
#include "chunk_context.h"
#include "chunk_handle.h"


namespace udisk {
namespace chunk {

bool ChunkHandleVecType::IsNeedResize(uint32_t index) {
  uint32_t first_index = index / g_context->config().pc_max_size_in_vec();
  if (first_index >= handle_vec_.size()) {
    return true;
  }

  uint32_t second_index = index % g_context->config().pc_max_size_in_vec();
  if (second_index >= handle_vec_[first_index].size()) {
    return true;
  }

  return false;
}

void ChunkHandleVecType::Resize(uint32_t index, ChunkHandle* value) {
  uint32_t first_index = index / g_context->config().pc_max_size_in_vec();
  uint32_t second_index = index % g_context->config().pc_max_size_in_vec();
  if (first_index >= handle_vec_.size()) {
    handle_vec_.resize(first_index + 1);
  }

  handle_vec_[first_index].resize(second_index + 1, value);
}
 
ChunkHandle* ChunkHandleVecType::Get(uint32_t index) {
  uint32_t first_index = index / g_context->config().pc_max_size_in_vec();
  uint32_t second_index = index % g_context->config().pc_max_size_in_vec();
  return handle_vec_[first_index][second_index];
}

void ChunkHandleVecType::Set(uint32_t index, ChunkHandle* handle) {
  uint32_t first_index = index / g_context->config().pc_max_size_in_vec();
  uint32_t second_index = index % g_context->config().pc_max_size_in_vec();
  handle_vec_[first_index][second_index] = handle;
}

};  // end of namespace chunk
};  // end of namespace udisk

// vim: set ts=2 sw=2 sts=2 et:
