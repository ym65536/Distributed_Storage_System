#ifndef UDISK_CHUNK_STOREAGE_CHUNK_STORAGE_H_
#define UDISK_CHUNK_STOREAGE_CHUNK_STORAGE_H_

#include <ustevent/eventloop.h>
#include "chunk_storage_type.h"
#include "../chunk_loop_handle.h"
#include "chunk_handle.h"
#include "chunk_pool.h"
#include "chunk_storage_errorcode.h"

namespace udisk {
namespace chunk {

class ChunkHandle;
class ChunkPool;
class ChunkLoopHandle;

class ChunkStorage {
 public:
  ChunkStorage() : chunk_pool_(nullptr), loop_(nullptr) {}
  virtual ~ChunkStorage() {}

  virtual int32_t Init(ChunkPool* chunk_pool,
                       uevent::EventLoop* loop) = 0;
  // 当不触发PC分配时，回调会在该函数中执行。
  // 当触发PC分配时，回调由aio触发执行。
  virtual int32_t OpenChunk(const ChunkID& id, bool is_create,
                            OpenChunkCb done) = 0;
  virtual int32_t CloseChunk(ChunkHandle* chunk_handle) = 0;
  virtual int32_t CreateChunk(const ChunkID& id) = 0;
  virtual int32_t DeleteChunk(const ChunkID& id) = 0;
  ChunkPool* chunk_pool_;
  uevent::EventLoop* loop_;

 private:
};

};  // end of namespace chunk
};  // end of namespace udisk

#endif  // UDISK_CHUNK_STOREAGE_CHUNK_STORAGE_H_
