#ifndef UDISK_CHUNK_STOREAGE_CHUNK_POOL_H_
#define UDISK_CHUNK_STOREAGE_CHUNK_POOL_H_

#include "chunk_storage_type.h"

namespace uevent {
class EventLoop;
};

namespace udisk {
namespace chunk {

class ChunkPool {
 public:
  virtual ~ChunkPool() {}

  virtual int32_t Init() = 0;
  virtual int32_t PutChunk(const ChunkID& chunk_id) = 0;
  virtual int32_t PutChunk(const ChunkID& chunkID, ChunkOpCb done,
                           uevent::EventLoop* loop) = 0; 
  virtual int32_t GetChunk(const ChunkID& chunk_id) = 0;
  virtual int32_t GetChunk(const ChunkID& chunk_id, ChunkOpCb done, 
                            uevent::EventLoop* loop) = 0;
  virtual int32_t GetExistChunkByPG(uint32_t pg_id, ChunkIDList* list) = 0;
  virtual int32_t FormatChunk(const ChunkID& chunk_id) = 0;
  virtual uint64_t GetPoolRemainderCap() = 0;

  virtual bool Access(const ChunkID& chunkID) = 0;
  virtual int Open(const ChunkID& chunkID, uint64_t* offset) = 0;
  virtual std::string DumpChunkPoolInfo() = 0;

  virtual uint32_t dev_block_size() const = 0;
  virtual uint32_t pc_size() const = 0;

 protected:
  ChunkPool() {}
};

};  // end namespace chunk
};  // end namespace udisk

#endif  // UDISK_CHUNK_STOREAGE_CHUNK_POOL_H_
