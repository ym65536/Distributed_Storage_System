#ifndef UDISK_CHUNK_STOREAGE_JPC_STORAGE_H_
#define UDISK_CHUNK_STOREAGE_JPC_STORAGE_H_

#include <ustevent/eventloop.h>
#include "chunk_storage_type.h"
#include "jpc_handle.h"
#include "chunk_storage_errorcode.h"

namespace udisk {
namespace journal {

//struct chunk::JPCMeta;
typedef std::map<uint32_t, JPCHandle*> JPCPool;
typedef std::list<uint32_t> JPCFreeList;

const uint32_t kMaxJPCNumPerPG = 146;

class JPCStorage {
 public:
  JPCStorage() {}
  virtual ~JPCStorage() {}

  virtual void Init(int fd, uint32_t pg_id, 
                    const std::vector<chunk::JPCMeta*>& jms) = 0;
  virtual void Init(int fd, uint32_t pg_id) = 0;
  virtual JPCHandle* AcquireCompactJPC(uint32_t jpc_id) = 0;
  virtual JPCHandle* AcquireActiveJPC(uint32_t jpc_id) = 0;
  virtual JPCHandle* AcquireInActiveJPC(uint32_t jpc_id) = 0;
  virtual JPCHandle* AcquireFreeJPC() = 0;
  virtual void ReleaseJPC(const std::vector<uint32_t>& jpc_ids) = 0;
  virtual void UpdateFreeJPC(const uint32_t active_zone[], uint32_t active_num,
                    const uint32_t inactive_zone[], uint32_t inactive_num) = 0;
  virtual void JPCSwap() = 0;

 private:
};

};  // end of namespace journal
};  // end of namespace udisk

#endif  // UDISK_CHUNK_STOREAGE_JPC_STORAGE_H_
