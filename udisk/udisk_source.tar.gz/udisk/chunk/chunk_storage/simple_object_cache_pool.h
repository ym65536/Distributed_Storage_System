#ifndef UDISK_CHUNK_MEMORY_SIMPLE_OBJECT_CACHE_POOL_H
#define UDISK_CHUNK_MEMORY_SIMPLE_OBJECT_CACHE_POOL_H

#include <vector>

#include "simple_mem_cache.h"
#include "chunk_storage_type.h"

namespace udisk {
namespace chunk {

template <typename T>
class SimpleObjectCachePool {
 public:
  SimpleObjectCachePool() : mCache(NULL) {}

  void Init(SimpleMemCache* cache, bool reconstruct = true);

  ~SimpleObjectCachePool();

  void Reset();

  T* Alloc();

 private:
  void newBatch();

  SimpleMemCache* mCache;
  size_t mOffset;
  size_t mBatchSize;
  bool mReconstruct;
  std::vector<T*> mBatches;
};

template <typename T>
void SimpleObjectCachePool<T>::Init(SimpleMemCache* cache, bool reconstruct) {
  assert(mCache == NULL);
  mCache = cache;
  mReconstruct = reconstruct;
  SimpleMemCacheStats stats;
  cache->GetStats(&stats);
  mBatchSize = stats.objectSize / sizeof(T);
  assert(mBatchSize > 0);
}

template <typename T>
SimpleObjectCachePool<T>::~SimpleObjectCachePool() {
  Reset();
}

template <typename T>
void SimpleObjectCachePool<T>::Reset() {
  for (size_t i = 0; i < mBatches.size(); ++i) {
    if (mReconstruct) {
      for (size_t j = 0; j < (i < mBatches.size() - 1 ? mBatchSize : mOffset);
           ++j) {
        mBatches[i][j].~T();
      }
    }
    mCache->Free(mBatches[i]);
  }
}

template <typename T>
T* SimpleObjectCachePool<T>::Alloc() {
  if (UNLIKELY(mBatches.empty() || mOffset >= mBatchSize)) {
    newBatch();
    if (UNLIKELY(mOffset != 0)) {
      return NULL;
    }
  }
  T* object = NULL;
  if (!mReconstruct) {
    object = &mBatches.back()[mOffset];
  } else {
    object = new (&mBatches.back()[mOffset]) T();
  }
  ++mOffset;
  return object;
}

template <typename T>
void SimpleObjectCachePool<T>::newBatch() {
  void* batch = mCache->Alloc();
  mBatches.push_back(static_cast<T*>(batch));
  mOffset = 0;
}

}  // namespace chunk
}  // namespace udisk

#endif  // UDISK_CHUNK_MEMORY_SIMPLE_OBJECT_CACHE_POOL_H
