#include "simple_mem_cache.h"

#include "chunk_storage_type.h"

namespace udisk {
namespace chunk {

SimpleMemCache::SimpleMemCache() : mObjectCount(0), mInitFlag(false) {}

SimpleMemCache::~SimpleMemCache() {
  if (mObjectCount > 0) {
    ULOG_ERROR("There are still %lu objects not freed on destruction of %s",
              mObjectCount, mOptions.name.c_str());
  }
  UDISK_FOREACH(it, mReserveObjects) { free(*it); }
}

void SimpleMemCache::Init(const SimpleMemCacheOptions& options) {
  mOptions = options;
  for (size_t i = 0; i < mOptions.reserve; ++i) {
    mReserveObjects.push_back(malloc(mOptions.objectSize));
  }
  mInitFlag = true;
}

void SimpleMemCache::GetStats(SimpleMemCacheStats* stats) const {
  stats->name = mOptions.name;
  stats->reserve = mOptions.reserve;
  stats->limit = mOptions.limit;
  stats->objectSize = mOptions.objectSize;
  stats->objectCount = mObjectCount;
  stats->reservedObjectCount = mReserveObjects.size();
}

}  // namespace chunk
}  // namespace udisk
