#ifndef UDISK_CHUNK_STOREAGE_FLAGS_H_
#define UDISK_CHUNK_STOREAGE_FLAGS_H_

#include <gflags/gflags.h>

#endif  // UDISK_CHUNK_STOREAGE_FLAGS_H_
