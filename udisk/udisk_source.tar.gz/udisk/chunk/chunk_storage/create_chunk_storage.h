#ifndef UDISK_CHUNK_STOREAGE_CREATE_CHUNK_STORAGE_H_
#define UDISK_CHUNK_STOREAGE_CREATE_CHUNK_STORAGE_H_

#include "chunk_storage.h"
#include "file_chunk_storage.h"
#include "mock_chunk_storage.h"
#include "raw_chunk_storage.h"
#include "../chunk_context.h"

namespace udisk {
namespace chunk {

inline ChunkStorage* CreateChunkStorage() {
  ChunkStorage* chunk_storage_ = nullptr;
  if (g_context->config().storage_type() == UDiskConfig::kStorageTypeMock) {
    chunk_storage_ = new MockChunkStorage();
  } else if (g_context->config().storage_type() ==
             UDiskConfig::kStorageTypeFile) {
    chunk_storage_ = new FileChunkStorage(g_context->config().chunk_dir());
  } else if (g_context->config().storage_type() ==
             UDiskConfig::kStorageTypeRaw) {
    chunk_storage_ = new RawChunkStorage();
  } else {
    ULOG_FATAL << "unknown chunk storage type";
  }
  return chunk_storage_;
}

}  // end of namespace chunk
}  // end of namespace udisk

#endif  // UDISK_CHUNK_STOREAGE_CREATE_CHUNK_STORAGE_H_ 
