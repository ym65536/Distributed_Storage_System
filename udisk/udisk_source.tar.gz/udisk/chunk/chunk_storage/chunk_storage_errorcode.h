#ifndef UDISK_CHUNK_STOREAGE_ERRORCODE_H_
#define UDISK_CHUNK_STOREAGE_ERRORCODE_H_

namespace udisk {
namespace chunk {

#define DEFINE_UDISK_ERRORCODE(name, value, errorstr...) const int name = value;
#include "chunk_storage_errorcode_def.h"
#undef DEFINE_UDISK_ERRORCODE

};  // end of namespace chunk
};  // end of namespace udisk

#endif  // UDISK_CHUNK_STOREAGE_ERRORCODE_H_
