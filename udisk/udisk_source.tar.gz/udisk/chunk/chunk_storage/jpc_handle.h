#ifndef UDISK_CHUNK_STORAGE_JOURNAL_HANDLE_H_
#define UDISK_CHUNK_STORAGE_JOURNAL_HANDLE_H_

#include <ustevent/callbacks.h>
#include <ustevent/eventloop.h>

namespace udisk {
namespace journal {

class JPCHandle {
public:
  JPCHandle() {}
  virtual ~JPCHandle() {}

  virtual int PRead(void* data, uint64_t offset, uint64_t len, 
                    uevent::DiskIOCb cb, void* arg, 
                    uevent::EventLoop* loop) = 0;

  virtual int PWrite(const void* data, uint64_t offset, uint64_t len,
                     uevent::DiskIOCb cb, void* arg, 
                     uevent::EventLoop* loop) = 0;

  virtual int ResetData() = 0;
  virtual uint32_t JPCSize() const = 0;
  virtual uint32_t GetID() const = 0;
};

}; // end of ns chunk
}; // end of ns udisk
#endif
