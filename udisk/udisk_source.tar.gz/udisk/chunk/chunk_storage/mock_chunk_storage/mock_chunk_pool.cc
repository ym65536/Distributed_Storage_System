#include "mock_chunk_pool.h"

#include <ustevent/base/logging.h>
#include "chunk_storage_type.h"
#include "chunk_storage_errorcode.h"

namespace udisk {
namespace chunk {

MockChunkPool::MockChunkPool() { ULOG_INFO << "Get a Mock ChunkPool"; }

MockChunkPool::~MockChunkPool() { ULOG_INFO << "Get a Mock ChunkPool"; }

int32_t MockChunkPool::Init() {
  ULOG_INFO << "Mock ChunkPool Init";
  return UDISK_OK;
}

uint64_t MockChunkPool::GetPoolRemainderCap() {
  ULOG_INFO << "Mock ChunkPool GetPoolRemainderCap";
  return UDISK_OK;
}

int32_t MockChunkPool::PutChunk(const ChunkID& chunkID) {
  std::string id = chunkID.to_string();
  ULOG_INFO << "Mock ChunkPool Put Chunk" << id;
  return UDISK_OK;
}

int32_t MockChunkPool::PutChunk(const ChunkID& chunkID, ChunkOpCb done,
                      uevent::EventLoop* loop) {
  return UDISK_NOT_IMPLEMENTED;
}

int32_t MockChunkPool::GetChunk(const ChunkID& chunkID) {
  std::string id = chunkID.to_string();
  ULOG_INFO << "Mock ChunkPool Get Chunk" << id;
  return UDISK_OK;
}

int32_t MockChunkPool::GetChunk(const ChunkID& chunk_id, ChunkOpCb done, 
                     uevent::EventLoop* loop) {
  return UDISK_NOT_IMPLEMENTED;
}

int32_t MockChunkPool::FormatChunk(const ChunkID& chunkID) {
  std::string id = chunkID.to_string();
  ULOG_INFO << "Mock ChunkPool Get Chunk" << id;
  return UDISK_OK;
}

bool MockChunkPool::Access(const ChunkID& chunkID) {
  return UDISK_NOT_IMPLEMENTED;
}

int MockChunkPool::Open(const ChunkID& chunkID, uint64_t* offset) {
  return UDISK_NOT_IMPLEMENTED;
}

int32_t MockChunkPool::GetExistChunkByPG(uint32_t pg_id, ChunkIDList* list) {
  list->clear();
  ULOG_INFO << "Mock ChunkPool Get Chunk by PG" << pg_id;
  return UDISK_OK;
}

};  // end of namespace chunk
};  // end of namespace udisk
