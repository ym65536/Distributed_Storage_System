#ifndef UDISK_CHUNK_STORAGE_MOCK_CHUNK_POOL_H_
#define UDISK_CHUNK_STORAGE_MOCK_CHUNK_POOL_H_

#include "chunk_storage_type.h"
#include "chunk_pool.h"

namespace udisk {
namespace chunk {

class MockChunkPool : public ChunkPool {
 public:
  explicit MockChunkPool();
  virtual ~MockChunkPool();
  virtual int32_t Init();
  virtual int32_t PutChunk(const ChunkID& chunkID);
  virtual int32_t PutChunk(const ChunkID& chunkID, ChunkOpCb done,
                             uevent::EventLoop* loop);
  virtual int32_t GetChunk(const ChunkID& chunkID);
  virtual int32_t GetChunk(const ChunkID& chunk_id, ChunkOpCb done,
                             uevent::EventLoop* loop);
  virtual int32_t GetExistChunkByPG(uint32_t pg_id, ChunkIDList* list);
  virtual int32_t FormatChunk(const ChunkID& chunkID);
  virtual bool Access(const ChunkID& chunkID);
  virtual int Open(const ChunkID& chunkID, uint64_t* offset);
  virtual std::string DumpChunkPoolInfo() {
    return "";
  }

  virtual uint64_t GetPoolRemainderCap();
  virtual uint32_t dev_block_size() const {
    return kDefaultDevBlockSize;
  }
  virtual uint32_t pc_size() const {
    return kDefaultPCSize;
  }

 private:
};

};  // end of namespace chunk
};  // end of namespace udisk

#endif  // UDISK_CHUNK_STORAGE_MOCK_CHUNK_POOL_H_
