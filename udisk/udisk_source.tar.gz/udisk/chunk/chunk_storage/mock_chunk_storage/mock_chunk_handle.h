#ifndef UDISK_CHUNK_STORAGE_MOCK_CHUNK_HANDLE_H_
#define UDISK_CHUNK_STORAGE_MOCK_CHUNK_HANDLE_H_

#include "chunk_handle.h"

namespace udisk {
namespace chunk {

class ChunkStorage;

class MockChunkHandle : public ChunkHandle {
 public:
  explicit MockChunkHandle() { chunk_storage_ = nullptr; }
  virtual ~MockChunkHandle() {}

  int32_t PRead(void* data, uint64_t len, uint64_t offset,
                        uevent::DiskIOCb cb, void* arg) override;
  int32_t PRead(void* data, uint64_t len, uint64_t offset) override;
  int32_t PWrite(const void* data, uint64_t len, uint64_t offset,
                         uevent::DiskIOCb cb, void* arg) override;
  int32_t PWrite(const void* data, uint64_t len, uint64_t offset) override;
 private:
};

};  // end of namespace chunk
};  // end of namespace udisk

#endif  // UDISK_CHUNK_STORAGE_MOCK_CHUNK_HANDLE_H_
