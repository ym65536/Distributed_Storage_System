#include "chunk_storage_type.h"
#include "mock_chunk_storage.h"

#include <ustevent/base/logging.h>
#include "udisk_types.h"
#include "chunk_storage_errorcode.h"

namespace udisk {
namespace chunk {

MockChunkStorage::MockChunkStorage() {
  ULOG_INFO << "Get a Mock ChunkStorage";
  mMockChunkHandle = new MockChunkHandle();
}

MockChunkStorage::~MockChunkStorage() { ULOG_INFO << "Get a Mock ChunkStorage"; }

int32_t MockChunkStorage::Init(ChunkPool* chunkPool,
                               uevent::EventLoop *loop) {
  ULOG_INFO << "Chunk Storage Init";
  return UDISK_OK;
}

int32_t MockChunkStorage::OpenChunk(const ChunkID& chunkID, bool is_create, 
                                      OpenChunkCb done) {
  ULOG_INFO << "Open Chunk" << chunkID.to_string();
  done(UDISK_OK, mMockChunkHandle);
  return UDISK_OK;
}

int32_t MockChunkStorage::CloseChunk(ChunkHandle* chunkHandle) {
  ULOG_INFO << "Close Chunk";
  return UDISK_OK;
}

int32_t MockChunkStorage::CreateChunk(const ChunkID& id) {
  ULOG_INFO << "Create Chunk" << id.to_string();
  return UDISK_OK;
}

int32_t MockChunkStorage::DeleteChunk(const ChunkID& id) {
  ULOG_INFO << "Delete Chunk" << id.to_string();
  return UDISK_OK;
}


};  // end of namespace chunk
};  // end of namespace udisk
