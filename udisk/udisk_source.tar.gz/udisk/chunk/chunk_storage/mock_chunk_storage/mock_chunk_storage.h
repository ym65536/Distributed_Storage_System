#ifndef UDISK_CHUNK_STORAGE_MOCK_CHUNK_STORAGE_H_
#define UDISK_CHUNK_STORAGE_MOCK_CHUNK_STORAGE_H_

#include "chunk_storage_type.h"
#include "chunk_storage.h"
#include "chunk_pool.h"
#include "mock_chunk_handle.h"

namespace udisk {
namespace chunk {

class MockChunkStorage : public ChunkStorage {
 public:
  MockChunkStorage();
  virtual ~MockChunkStorage();
  int32_t Init(ChunkPool *chunk_pool, uevent::EventLoop *loop) override;
  virtual int32_t OpenChunk(const ChunkID& id, bool is_create,
                              OpenChunkCb done);
  virtual int32_t CloseChunk(ChunkHandle* chunkHandle);
  virtual int32_t CreateChunk(const ChunkID& id);
  virtual int32_t DeleteChunk(const ChunkID& id);

 private:
  MockChunkHandle* mMockChunkHandle;  // in mock storage always return this
                                      // handle
};

};  // end of namespace chunk
};  // end of namespace udisk

#endif  // UDISK_CHUNK_STORAGE_MOCK_CHUNK_STORAGE_H_
