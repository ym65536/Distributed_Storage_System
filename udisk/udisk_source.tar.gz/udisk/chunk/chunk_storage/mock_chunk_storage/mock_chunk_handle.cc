#include "mock_chunk_handle.h"

#include <ustevent/base/logging.h>

namespace udisk {
namespace chunk {

int32_t MockChunkHandle::PRead(void* data, uint64_t len, uint64_t offset,
                               uevent::DiskIOCb cb, void* arg) {
  return 0;
}
int32_t MockChunkHandle::PRead(void* data, uint64_t len, uint64_t offset) {
  return 0;
}
int32_t MockChunkHandle::PWrite(const void* data, uint64_t len, uint64_t offset,
                                uevent::DiskIOCb cb, void* arg) {
  return 0;
}
int32_t MockChunkHandle::PWrite(const void* data, uint64_t len, uint64_t offset) {
  return 0;
}

};  // end of namespace chunk
};  // end of namespace udisk
