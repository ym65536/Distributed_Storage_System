#ifndef UDISK_CHUNK_STOREAGE_BIND_CALLBACK_H_
#define UDISK_CHUNK_STOREAGE_BIND_CALLBACK_H_

#include <google/protobuf/stubs/common.h>
#include "call_traits.h"

namespace udisk {
namespace chunk {

template <typename Result0>
class BindCallbackR1 : public google::protobuf::Closure {
 public:
  BindCallbackR1() : mResult0(Result0()) {}
  typename call_traits<Result0>::param_type GetResult0() const {
    return mResult0;
  }
  void SetResult0(typename call_traits<Result0>::param_type r) { mResult0 = r; }
  Result0* MutableResult0() { return &mResult0; }

 protected:
  Result0 mResult0;
};

};  // end of namespace chunk
};  // end of namespace udisk

#endif  // UDISK_CHUNK_STOREAGE_BIND_CALLBACK_H_
