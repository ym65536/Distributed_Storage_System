#ifndef UDISK_CHUNK_STORAGE_CHUNK_HANDLE_H_
#define UDISK_CHUNK_STORAGE_CHUNK_HANDLE_H_

#include <ustevent/callbacks.h>
#include "chunk_storage_type.h"
#include "chunk_storage.h"

namespace udisk {
namespace chunk {

class ChunkStorage;

class ChunkHandle {
 public:
  ChunkHandle() : chunk_storage_(nullptr) {}
  virtual ~ChunkHandle() {}
  virtual int32_t PRead(void* data, uint64_t len, uint64_t offset,
      uevent::DiskIOCb cb, void* arg) = 0;
  virtual int32_t PRead(void* data, uint64_t len, uint64_t offset) = 0;
  virtual int32_t PWrite(const void* data, uint64_t len, uint64_t offset,
      uevent::DiskIOCb cb, void* arg) = 0;
  virtual int32_t PWrite(const void* data, uint64_t len, uint64_t offset) = 0;
  ChunkStorage* chunk_storage_;
  ChunkID chunk_id_;

 private:
};
};  // end of namespace chunk
};  // end of namespace udisk

#endif  // UDISK_CHUNK_STORAGE_CHUNK_HANDLE_H_
