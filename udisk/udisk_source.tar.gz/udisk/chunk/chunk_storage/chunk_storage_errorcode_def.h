//
// Format:
//      DEFINE_UDISK_ERRORCODE(ErrorSymbol, ErrorCode, ErrorString);
//      ErrorString is optional, use ErrorSymbol if no specified
//

//************************************************
// error codes for common
//************************************************

DEFINE_UDISK_ERRORCODE(UDISK_OK, 0, "OK");

DEFINE_UDISK_ERRORCODE(UDISK_NOT_IMPLEMENTED, -1, "function not implemented");
DEFINE_UDISK_ERRORCODE(UDISK_ALREADY_INIT, -2, "already init");
DEFINE_UDISK_ERRORCODE(UDISK_NOT_INIT, -3, "need init first");
DEFINE_UDISK_ERRORCODE(UDISK_INTERNAL_ERROR, -4, "udisk internal error");
DEFINE_UDISK_ERRORCODE(UDISK_IO_ERROR, -5, "udisk io error");

//************************************************
// error codes for chunk storage [-100, -500)
//************************************************

DEFINE_UDISK_ERRORCODE(UDISK_GET_PC_ERROR, -100, "get pc from pc pool fail");
DEFINE_UDISK_ERRORCODE(UDISK_OPEN_PC_ERROR, -101, "open pc fail");
DEFINE_UDISK_ERRORCODE(UDISK_GET_FILE_ERROR, -102,
                       "get all file from directory fail");
DEFINE_UDISK_ERRORCODE(UDISK_ZERO_PC_ERROR, -103, "0 pc in pc pool");
DEFINE_UDISK_ERRORCODE(UDISK_RENAME_FILE_ERROR, -104,
                       "rename file in pc pool fail");
DEFINE_UDISK_ERRORCODE(UDISK_PC_NOT_EXIST_ERROR, -105,
                       "pc not exist need to be created");
DEFINE_UDISK_ERRORCODE(UDISK_OPEN_DIR_ERROR, -106, "open dir fail");
DEFINE_UDISK_ERRORCODE(UDISK_FILE_PATH_ERROR, -107, "file path name error");
DEFINE_UDISK_ERRORCODE(UDISK_FILE_TYPE_ERROR, -108, "file d_type error");
DEFINE_UDISK_ERRORCODE(UDISK_DISK_ERROR, -109, "disk error");
DEFINE_UDISK_ERRORCODE(UDISK_CHUNKID_IS_USED, -110, "chunkid has been assigned pc already");
