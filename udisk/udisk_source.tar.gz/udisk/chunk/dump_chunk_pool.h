#ifndef UDISK_DUMP_CHUNK_POOL_INFO_H_
#define UDISK_DUMP_CHUNK_POOL_INFO_H_

#include <ustevent/pb_request_handle.h>
#include "udisk_message.h"

namespace udisk {
namespace chunk {
 
class DumpChunkPoolInfoHandle: public uevent::PbRequestHandle {
 public:
  explicit DumpChunkPoolInfoHandle(uevent::EventLoop* loop) {
  }
  virtual ~DumpChunkPoolInfoHandle() {
  }
  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         const uevent::UMessagePtr& um);
 
  MYSELF_CREATE(DumpChunkPoolInfoHandle);

 private:
  static int type_;
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage response_;
  ucloud::udisk::ChunkDumpChunkPoolInfoResponse* resp_body_;
};

} // namespace chunk
} // namespace udisk
#endif

