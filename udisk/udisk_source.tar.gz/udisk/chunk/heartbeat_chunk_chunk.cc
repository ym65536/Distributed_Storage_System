#include <ustevent/message_util.h>
#include <ustevent/connection_uevent.h>
#include <ustevent/base/logging.h>
#include "chunk_context.h"
#include "manager_handle.h"
#include "udisk_message.h"
#include "heartbeat_chunk_chunk.h"

namespace udisk {
namespace chunk {

using namespace uevent;

void HeartbeatChunkChunkHandle::EntryInit(const uevent::ConnectionUeventPtr& conn, 
                                          const uevent::UMessagePtr& msg) {
  const ucloud::udisk::HeartbeatChunkChunkRequest &req =
    msg->body().GetExtension(ucloud::udisk::heartbeat_chunk_chunk_request);
  uint32_t chunk_id = req.id();
  g_context->manager_handle()->HandleChunkHeartbeat(chunk_id);
  ULOG_INFO << "chunk_chunk_heartbeat from chunk:" << chunk_id;

  ucloud::UMessage res_msg;
  MakeResponse(msg.get(), ucloud::udisk::HEARTBEAT_CHUNK_CHUNK_RESPONSE, &res_msg);
  ucloud::udisk::HeartbeatChunkChunkResponse *res =
    res_msg.mutable_body()->MutableExtension(ucloud::udisk::heartbeat_chunk_chunk_response);
  res->mutable_rc()->set_retcode(0);

  uevent::MessageUtil::SendPbResponse(conn, res_msg);
}

}; // end of ns chunk
}; // end of ns udisk

