#ifndef UDISK_METASERVER_GET_META_DATA_HANDLE_H_
#define UDISK_METASERVER_GET_META_DATA_HANDLE_H_

#include <ustevent/pb_request_handle.h>
#include "udisk_message.h"

namespace udisk {
namespace chunk {
 
class GetMetaDataHandle: public uevent::PbRequestHandle {
 public:
  explicit GetMetaDataHandle(uevent::EventLoop* loop) {
  }
  virtual ~GetMetaDataHandle() {
  }
  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         const uevent::UMessagePtr& um);
 
  void GetMetaDataProcess(uint64_t cluster_version);

  MYSELF_CREATE(GetMetaDataHandle);

  void DestroyMyself();
   
 private:
  static int type_;
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage response_;
  ucloud::udisk::GetMetaDataResponse* resp_body_;
};

}
}
#endif

