#include "repair_loop_handle.h"

#include <unistd.h>

#include "chunk_loop_handle.h"
#include "chunk_context.h"
#include <ustevent/base/my_uuid.h>
#include "udisk_message.h"
#include "umessage_common.h"
#include "get_pg_pc.h"
#include "chunk_storage_flags.h"
#include "create_chunk_storage.h"

namespace udisk {
namespace chunk {

#define REPAIR_CHUNK_REP_NO (1)


RepairLoopHandle::RepairLoopHandle() : op_pool_(1024),
  msg_header_slab_(sizeof(common::MessageHeader) + sizeof(common::ChunkRepairHead), 2048)  {
  repair_thread_ = nullptr;
  repair_loop_ = nullptr;
  repair_listener_ = nullptr;
  last_op_seq_ = 0;
  chunk_storage_ = CreateChunkStorage();
  assert(chunk_storage_ != nullptr);
}

RepairLoopHandle::~RepairLoopHandle() {
    delete chunk_storage_;
    ULOG_INFO << "delete chunk storage";
}

void RepairLoopHandle::Start(const std::string &ip, int port) {
  uevent::Option option;
  option.enable_aio = true;
  repair_thread_ = new uevent::WorkerThread("repair_thread", nullptr, option);
  repair_loop_ = repair_thread_->StartWorker()->eventloop();
  uevent::UsockAddress repair_addr(ip, port);
  repair_listener_ = new uevent::ListenerLibevent(static_cast<uevent::PosixWorker*>(repair_loop_->worker()), repair_addr,
    "RepairListener", uevent::Option());
  repair_listener_->SetConnectionSuccessCb(
    std::bind(&RepairLoopHandle::ConnectionSuccessHandle, this, std::placeholders::_1));
  repair_listener_->SetConnectionClosedCb(
    std::bind(&RepairLoopHandle::ConnectionClosedHandle, this, std::placeholders::_1));
  repair_listener_->SetMessageReadCb(
    std::bind(&RepairLoopHandle::MessageReadHandle, this, std::placeholders::_1));
  repair_listener_->SetMessageWriteCb(
    std::bind(&RepairLoopHandle::MessageWriteHandle, this, std::placeholders::_1));

  g_context->set_repair_loop(repair_loop_);
  g_context->set_repair_listener(repair_listener_);
  g_context->set_repair_handle(this);

  repair_loop_->RunInLoop(std::bind(&uevent::ListenerUevent::Start, repair_listener_));
  repair_loop_->RunEvery(g_context->config().heartbeat_chunk_interval(),
    std::bind(&RepairLoopHandle::CheckRepairPCState, this));

  chunk_storage_->Init(g_context->chunk_pool(), repair_loop_);
}

void RepairLoopHandle::CheckRepairPCState() {
  // 上报io读写错误
  ReportLCIOError();

  base::Timestamp now_time(base::Timestamp::now());

  // 超时没有完成修复的pc, 直接从列表删除
  for (auto it = repair_pcs_.begin(); it != repair_pcs_.end();
      /*nothing*/) {
    if (timeDifference(now_time, it->second) <=
        g_context->config().repair_pc_timeout()) {
      ++it;
      continue;
    }
    uint32_t lc_id = it->first.lc_id;
    uint32_t lc_size = it->first.lc_size;
    uint32_t pc_no = it->first.pc_no;
    uint32_t lc_random_id = it->first.lc_random_id;
    ULOG_ERROR << "Repair PC Timeout, lc_id=" << lc_id << ", pc_no="
      << pc_no << ", lc_random_id=" << lc_random_id << ", lc_size=" << lc_size;
    it = repair_pcs_.erase(it);

    //清除inflying_list_中属于超时修复pc的OpRequest
    for (auto item = inflying_list_.begin(); item != inflying_list_.end(); ) {
      const common::ChunkRepairHead* chunk_hdr =
        (const common::ChunkRepairHead*)(item->second->sub_msg_hdr_offset());
      if (chunk_hdr->lc_id == lc_id &&
          chunk_hdr->pc_no == pc_no &&
          chunk_hdr->lc_random_id == lc_random_id) {
        ULOG_ERROR << "OpTimeout. op_seq=" << item->first << ", lc_id=" << lc_id
                   << ", pc_no=" << pc_no;
        item->second->DecRefs();
        item = inflying_list_.erase(item);
      } else {
        ++item;
      }
    }
  }
}

void RepairLoopHandle::SyncDataProcess(uint32_t repair_chunk, PhysicalChunkSet pcs) {
  udisk::cluster::ChunkInfoMap chunk_info_map = cluster_map_.chunks();
  udisk::cluster::ChunkInfoMap::iterator it = chunk_info_map.find(repair_chunk);
  if (it == chunk_info_map.end()) {
    ULOG_ERROR << "need repair chunk not found, chunk_id=" << repair_chunk;
    return;
  }
  if (!repair_pcs_.empty()) // 已经有正在修复的pc, 加入repair队列
  {
    base::Timestamp now_time(base::Timestamp::now());
    for (auto it = pcs.begin(); it != pcs.end(); ++it) {
      uint32_t lc_id = it->lc_id;
      uint32_t pc_no = it->pc_no;
      uint32_t pg_id = it->pg_id;
      ULOG_DEBUG << "repair list size=" << repair_pcs_.size() << ", append new size="
        << pcs.size() << ", lc_id=" << lc_id << ", pc_no=" << pc_no << ", pg_id=" << pg_id;
      repair_pcs_.push_back(std::make_pair(*it, now_time));
    }
    return;
  }

  base::Timestamp now_time(base::Timestamp::now());
  for (auto it = pcs.begin(); it != pcs.end(); ++it) {
    repair_pcs_.push_back(std::make_pair(*it, now_time));
  }
  repair_chunk_id_ = repair_chunk;
  // 把需要修复的pc信息加入待修复列表

  if (token_bucket_.get() == nullptr) {
    token_bucket_ = std::make_shared<TokenBucket>(
      g_context->config().repair_rate() * 2, g_context->config().repair_rate());
  }
  RepairPCList::iterator pc_it = repair_pcs_.begin();
  uint32_t lc_id = pc_it->first.lc_id;
  uint32_t lc_size = pc_it->first.lc_size;
  uint32_t pc_no = pc_it->first.pc_no;
  uint32_t lc_random_id = pc_it->first.lc_random_id;
  uint32_t pg_id = pc_it->first.pg_id;

  SendRepairPCRequest(pg_id, lc_id, pc_no, lc_size, lc_random_id, 0);
}

void RepairLoopHandle::SendRepairPCRequest(
    uint32_t pg_id, uint32_t lc_id, uint32_t pc_no,
    uint32_t lc_size, uint32_t lc_random_id, uint32_t offset) {
  ULOG_DEBUG << "Send Request: pg_id=" << pg_id << ", lc_id=" << lc_id
    << ", lc_random_id=" << lc_random_id << ", pc_no=" <<
    pc_no << ", offset=" << offset;
  char *msg_hdr = (char*)(msg_header_slab_.Malloc());
  uint64_t op_seq = get_next_op_seq();
  BuildChunkRepairRequest((common::MessageHeader*)msg_hdr, op_seq, offset,
                            lc_id, lc_random_id, lc_size, pc_no, pg_id);
  auto repair_hdr = reinterpret_cast<common::ChunkRepairHead*>(
      msg_hdr + sizeof(common::MessageHeader));

  OpRequest* op =
      op_pool_.Malloc(op_seq, nullptr, (common::MessageHeader*)msg_hdr, nullptr,
      (uint32_t)repair_hdr->length, repair_hdr->cmd, (uint32_t)repair_hdr->pg_id,
      op_pool_, nullptr, nullptr, &msg_header_slab_);
  while (!token_bucket_->grant(1)) {
    ULOG_TRACE << "No token left, wait for a minit...";
    usleep(2);
  }

  OpenChunkCb cb = std::bind(&RepairLoopHandle::OpenChunkResCB, this,
                 std::placeholders::_1, std::placeholders::_2, op);
  int32_t ret_code = chunk_storage_->OpenChunk(
      ChunkID(pg_id, lc_id, pc_no, lc_random_id), true, cb);
  if (ret_code != UDISK_OK) {
    ULOG_ERROR << "submit open chunk error, op: " << op->trace_tag();
    op->DecRefs();
    return;
  }

}

void RepairLoopHandle::BuildChunkRepairRequest(
    common::MessageHeader* msg_hdr,
    uint64_t op_seq, uint64_t offset, uint32_t lc_id,
    uint32_t lc_random_id, uint32_t lc_size, uint32_t pc_no, uint32_t pg_id) {
  uint64_t data_size = CHUNK_REPAIR_TINYPC_SIZE;
  msg_hdr->msg_type = common::MSG_CHUNK_REPAIR_REQ;
  // ChunkRepairHead + data
  msg_hdr->data_len = sizeof(common::ChunkRepairHead) + data_size;
  msg_hdr->version = 0; // unused now

  common::ChunkRepairHead* chunk_hdr =
    (common::ChunkRepairHead* )&(((char* )msg_hdr)[sizeof(common::MessageHeader)]);
  chunk_hdr->size = data_size;
  chunk_hdr->cmd = common::CHUNK_CMD_REPAIR_READ;
  chunk_hdr->flowno = op_seq;
  chunk_hdr->offset = offset;
  chunk_hdr->length = data_size;
  chunk_hdr->lc_id = lc_id;
  chunk_hdr->lc_random_id = lc_random_id;
  chunk_hdr->lc_size = lc_size;
  chunk_hdr->pg_id = pg_id;
  chunk_hdr->pc_no = pc_no;
  chunk_hdr->route_version = cluster_map_.GetClusterVersion();
  chunk_hdr->magic = common::CHUNK_IO_MAGIC;
  chunk_hdr->retcode = 0;
}

// tips: 修复过程中失败，由超时机制清理内存中request_handle，pending io等
bool RepairLoopHandle::DoLocal(ChunkHandle* handle, OpRequest* op) {
  const common::MessageHeader *common_hdr = op->msg_hdr();
  if (common_hdr->msg_type != common::MSG_CHUNK_REPAIR_REQ) {
    ULOG_ERROR << "Get Error msg_type=" << common_hdr->msg_type;
    return false;
  }
  const common::ChunkRepairHead *chunk_hdr =
    (const common::ChunkRepairHead*)op->sub_msg_hdr_offset();
  ULOG_TRACE << "DoLocal, request type=" << chunk_hdr->cmd
    << ", pg_id=" << chunk_hdr->pg_id << ", lc_id=" << chunk_hdr->lc_id
    << ", pc_no=" << chunk_hdr->pc_no << ", offset=" << chunk_hdr->offset;

  int ret = 0;
  IOErrorContainer::IO_OP_TYPE type;
  if (chunk_hdr->cmd == common::CHUNK_CMD_REPAIR_READ) {
    ret = SubmitReadLocal(handle, chunk_hdr->offset,
        chunk_hdr->length, op);
    type = IOErrorContainer::kIORead;
  } else {
    ret = SubmitWriteLocal(handle, chunk_hdr->offset,
        chunk_hdr->length, op);
    type = IOErrorContainer::kIOWrite;
  }
  if (ret < 0) {
    io_error_container_.Add(chunk_hdr->lc_id,
                            IOErrorContainer::kRepairIOError, type);
    ULOG_ERROR << "Req submit fail: " << DumpChunkRepairHead(*chunk_hdr);
    return false;
  }
  op->IncRefs(); // Submit使用op的read_buffer, 需要增加引用计数
  return true;
}

namespace {

struct AioCallbackArgs {
  RepairLoopHandle* loophandle;
  uint16_t op_type;
  OpRequest* op;
};
}

int RepairLoopHandle::SubmitReadLocal(ChunkHandle *handle, uint32_t offset,
                                    uint32_t len, OpRequest* op) {
  void *read_buf = nullptr;
  MemorySlab *slab = nullptr;
  std::tie(read_buf, slab) = mem_pool_.Malloc(len, kDefaultDevBlockSize);
  assert(read_buf);
  // 将read_buf的控制权交给op,当op操作完成后，
  // op被销毁的时候，会释放read_buf空间
  op->set_read_buffer((char*)read_buf, &mem_pool_, slab);

  auto cb_arg = new AioCallbackArgs;
  cb_arg->loophandle = this;
  cb_arg->op_type = 1;
  cb_arg->op = op;
  int32_t ret = handle->PRead(read_buf, len, offset,
          LocalAioCB, cb_arg);
  if (ret != UDISK_OK) {
      ULOG_ERROR << "Submit Local Read Parent Op: " << op->trace_tag()
                << " failed,"
                << " ret: " << ret;
  } else {
      ULOG_TRACE << "Submit Local Read Parent Op: " << op->trace_tag();
  }
  return ret;
}


int RepairLoopHandle::SubmitWriteLocal(ChunkHandle *handle, uint32_t offset,
                                    uint32_t len, OpRequest* op) {
  const char *msg_data = op->msg_data();
  //TODO obj pool
  auto cb_arg = new AioCallbackArgs;
  cb_arg->loophandle = this;
  cb_arg->op_type = 0;
  cb_arg->op = op;
  int32_t ret = handle->PWrite((void*)msg_data, len, offset,
          LocalAioCB, cb_arg);

  if (ret != UDISK_OK) {
    ULOG_ERROR << "Submit Local Write Parent Op: " << op->trace_tag()
              << " failed,"
              << " ret: " << ret;
  } else {
    ULOG_TRACE << "Submit Local Write Parent Op: " << op->trace_tag();
  }
  return ret;
}

void RepairLoopHandle::OpenChunkResCB(int retcode,
                                      ChunkHandle* handle,
                                      OpRequest* op) {
  if (retcode != UDISK_OK) {
    // TODO(yeheng) 打开错误是否还需要继续修
    ULOG_ERROR << "open chunk cb error for op: " << op->trace_tag();
    IOErrorContainer::IO_OP_TYPE type;
    type = IOErrorContainer::kIOWrite;
    const common::ChunkRepairHead* chunk_hdr =
          (const common::ChunkRepairHead*)op->sub_msg_hdr_offset();
    io_error_container_.Add(chunk_hdr->lc_id,
                            IOErrorContainer::kRepairIOError, type);
    op->DecRefs();
    return;
  }
  // 依赖定时器超时检查
  inflying_list_.insert(std::make_pair(op->op_seq(), op));
  DoLocal(handle, op);
}


void RepairLoopHandle::LocalAioCB(int retcode, void* arg) {
  auto cb_arg = std::unique_ptr<AioCallbackArgs>(reinterpret_cast<AioCallbackArgs*>(arg));
  uint64_t op_seq = cb_arg->op->op_seq();
  auto op_type = cb_arg->op_type;
  auto pobj = cb_arg->loophandle;

  ULOG_TRACE << "aio recv: op_seq=" << op_seq << ", op_type=" << op_type
    << ", retcode=" << retcode;
  auto found = pobj->inflying_list_.find(op_seq);
  if (found == pobj->inflying_list_.end()) {
    ULOG_ERROR << "Can not found req. seqno=" << op_seq << ", op_type="
      << op_type << ", retcode=" << retcode << ", may be timeout";
    bool del = cb_arg->op->DecRefs(); // 一定是超时后被释放
    if (del != true) {  // 生命周期结束， 一定被释放
      ULOG_FATAL << "op should be free";
    }
    if (pobj->inflying_list_.empty()) { // 继续修复其他的PC
      pobj->SendNextRepairPC();
    }
    return;
  }
  OpRequest* op = found->second;
  bool del = op->DecRefs();
  if (del != false) { // 在inflying_list_中肯定没有超时,aio回调中不可能析构
    ULOG_FATAL << "impossible";
  }
  const common::ChunkRepairHead *chunk_hdr =
        (const common::ChunkRepairHead*)op->sub_msg_hdr_offset();
  if (retcode != CHUNK_REPAIR_TINYPC_SIZE) {
    ULOG_ERROR << "AIO_ERROR: op_seq=" << op_seq << ", op_type=" << op_type
      << ", retcode=" << retcode;
    IOErrorContainer::IO_OP_TYPE type =
        (chunk_hdr->cmd == common::CHUNK_CMD_REPAIR_READ) ?
            IOErrorContainer::kIORead : IOErrorContainer::kIOWrite;
    pobj->io_error_container_.Add(chunk_hdr->lc_id,
                            IOErrorContainer::kRepairIOError, type);
    return;
  }
  ULOG_TRACE << "AIO_SUCC: op_seq=" << op_seq  << ", retcode=" << retcode;

  if (chunk_hdr->cmd == common::CHUNK_CMD_REPAIR_READ) {
    // 读请求说明是primary在修复，需要继续发送数据给secondary
    ULOG_TRACE << "Read aio resp, SyncChunkData...";
    pobj->SyncChunkDataRequest(op);
  } else {
    // 写请求正常返回
    ULOG_TRACE << "Write Op Seq " << op_seq << " finished";
    if (chunk_hdr->offset + CHUNK_REPAIR_TINYPC_SIZE == g_context->chunk_pool()->pc_size()) {
      // 本地数据同步完毕，通知chunk_loop_handle开始merge buffer
      pobj->NotifyIOLoopHandle(chunk_hdr->lc_id, chunk_hdr->lc_size, chunk_hdr->pc_no);
      ULOG_DEBUG << "Notify pc data sync finish, lc_id=" << chunk_hdr->lc_id
        << ", pc_no=" << chunk_hdr->pc_no;
    }
    pobj->EndChunkIORequest(0, found->second);
  }
}

void RepairLoopHandle::NotifyIOLoopHandle(uint32_t lc_id, uint32_t lc_size,
    uint32_t pc_no) {
  auto all_loops =  g_context->io_listener()->GetAllLoops();
  for (size_t i = 0; i < all_loops.size(); ++i) {
    ULOG_DEBUG << "==> Notify merge pending buffer. lc_id="
      << lc_id << ", pc_no=" << pc_no;
    assert(all_loops[i]);
    ChunkLoopHandle *loop_handle = (ChunkLoopHandle*)all_loops[i]->GetLoopHandle();
    all_loops[i]->RunInLoop(
      std::bind(&ChunkLoopHandle::RepairPCMergeNotify,
        loop_handle, lc_id, lc_size, pc_no));
  }
}

void RepairLoopHandle::EndChunkIORequest(int retcode, OpRequest* op) {
  const uevent::ConnectionUeventPtr& connection = op->conn();
  size_t msg_hdr_len = sizeof(common::MessageHeader) + sizeof(common::ChunkRepairHead);

  std::unique_ptr<char> msg_hdr(new char[msg_hdr_len]);
  common::MessageHeader *dst_common_hdr = (common::MessageHeader*)msg_hdr.get();
  common::ChunkRepairHead *dst_chunk_hdr =
    (common::ChunkRepairHead*)(msg_hdr.get() + sizeof(common::MessageHeader));
  common::MessageHeader *src_common_hdr = (common::MessageHeader*)op->msg_hdr();
  common::ChunkRepairHead *src_chunk_hdr =
    (common::ChunkRepairHead*)op->sub_msg_hdr_offset();

  BuildChunkRepairResponse(retcode, *src_common_hdr, dst_common_hdr,
    *src_chunk_hdr, dst_chunk_hdr);
  int rc = connection->SendData(msg_hdr.get(), msg_hdr_len);
  inflying_list_.erase(op->op_seq());
  ULOG_TRACE << "end Chunk IO op " << op->op_seq() << ", rc: " << rc;
  bool del = op->DecRefs();
  if (del != true) {  // 生命周期结束， 一定被释放
    ULOG_FATAL << "op should be free";
  }
}

void RepairLoopHandle::BuildChunkRepairResponse(int retcode,
                                       const common::MessageHeader &req_common_hdr,
                                       common::MessageHeader *res_common_hdr,
                                       const common::ChunkRepairHead &req_hdr,
                                       common::ChunkRepairHead *res_hdr) {
  size_t msg_data_len = sizeof(common::ChunkRepairHead);
  res_common_hdr->msg_type = common::MSG_CHUNK_REPAIR_RES;
  res_common_hdr->data_len = msg_data_len;
  res_common_hdr->version = req_common_hdr.version;

  memcpy(res_hdr, &req_hdr, sizeof(common::ChunkRepairHead));
  res_hdr->size = 0;
  res_hdr->retcode = retcode;
}

int RepairLoopHandle::SyncChunkDataRequest(OpRequest* op) {
  const common::MessageHeader *msg_hdr = op->msg_hdr();
  size_t msg_hdr_len = sizeof(common::MessageHeader) +
                       sizeof(common::ChunkRepairHead);
  common::ChunkRepairHead *chunk_hdr =
    (common::ChunkRepairHead*)((char* )msg_hdr + sizeof(common::MessageHeader));
  chunk_hdr->cmd = common::CHUNK_CMD_REPAIR_WRITE;

  udisk::cluster::ChunkInfoMap chunk_info_map = cluster_map_.chunks();
  udisk::cluster::ChunkInfoMap::iterator it = chunk_info_map.find(repair_chunk_id_);
  if (it == chunk_info_map.end()) {
    ULOG_ERROR << "need repair chunk not found, repair_chunk_id=" << repair_chunk_id_;
    return -1;
  }
  if (it->second.state() != ucloud::udisk::CHUNK_STATE_WRITEONLY) {
    ULOG_ERROR << "need repair chunk state error, repair_chunk_id=" << repair_chunk_id_
      << ", state=" << it->second.state();
    return -1;
  }
  ucloud::udisk::ChunkInfoPb& chunk_info = it->second;
  uint32_t chunk_id = chunk_info.id();
  const std::string ip = chunk_info.ip();
  int port = chunk_info.repair_port();
  bool rc = SendMsg((const char*)msg_hdr, msg_hdr_len, ip, port, chunk_id);
  if (!rc) {
    ULOG_ERROR << "Gate Op: " << op->op_seq()
              << " op seqno: " << chunk_hdr->flowno
              << "->Sub Op: " << DumpChunkRepairHead(*chunk_hdr)
              << " to chunk: " << chunk_id
              << " " << ip << ":" << port << " failed";
    return -1;
  }

  rc = SendMsg(op->read_buffer(), chunk_hdr->size, ip, port, chunk_id);
  if (rc) {
    op->mark_replica_waiting(0, chunk_id);
  } else {
    ULOG_ERROR << "Gate Op: " << op->op_seq()
              << " op flowno: " << chunk_hdr->flowno
              << "->Sub Op: " << DumpChunkRepairHead(*chunk_hdr)
              << " data to chunk: " << chunk_id
              << " " << ip << ":" << port << " failed";
    return -1;
  }
  ULOG_TRACE << "Gate Op: " << op->op_seq()
            << " op flowno: " << chunk_hdr->flowno
            << "->Sub Op: " << DumpChunkRepairHead(*chunk_hdr)
            << " to chunk: " << chunk_id
          << " " << ip << ":" << port;
  return 0;
}

void RepairLoopHandle::ConnectionSuccessHandle(const uevent::ConnectionUeventPtr& conn) {
  ULOG_INFO << "get a connection " << conn->GetPeerAddress().ToString()
    << ", id=" << conn->GetId();
}

void RepairLoopHandle::ConnectionClosedHandle(const uevent::ConnectionUeventPtr& conn) {
  ULOG_INFO << "repair remove a connection " << conn->GetPeerAddress().ToString()
    << ", id=" << conn->GetId();
  g_context->repair_listener()->RemoveConnection(conn);
}

void RepairLoopHandle::MessageReadHandle(const uevent::ConnectionUeventPtr& conn) {
  const size_t hdr_size = sizeof(common::MessageHeader);
  ULOG_TRACE << conn->GetPeerAddress().ToString()
    << ", before buffersize : " << conn->ReadableLength();
  while ((size_t)conn->ReadableLength() > hdr_size) {
    common::MessageHeader hdr;
    common::init_message_hdr(hdr);
    conn->ReceiveData((void*)&hdr, hdr_size);
    if ((size_t)conn->ReadableLength() >= (hdr_size + hdr.data_len)) {
      char *msg_data = nullptr;
      MemorySlab *slab = nullptr;
      common::MessageHeader *msg_hdr = nullptr;
      uint32_t data_size = 0;
      if (DecodeMsg(conn, hdr.msg_type, &msg_hdr, &msg_data, &data_size, &slab)) {
        uint8_t msg_type = msg_hdr->msg_type;
        switch (msg_type) {
          case common::MSG_CHUNK_REPAIR_REQ: {// request, create new opRequest
            uint64_t seq = get_next_op_seq();
            auto repair_hdr = reinterpret_cast<common::ChunkRepairHead*>(
                (char*)msg_hdr + sizeof(common::MessageHeader));
            OpRequest* op = op_pool_.Malloc(seq, conn, (common::MessageHeader*)msg_hdr,
                msg_data, (uint32_t)repair_hdr->length, repair_hdr->cmd, 
                (uint32_t)repair_hdr->pg_id, op_pool_, &mem_pool_, slab, &msg_header_slab_);
            ULOG_TRACE << "Get a Message: " << op->trace_tag();
            DoChunkRequest(op);
            break;
          }
          case common::MSG_CHUNK_REPAIR_RES: // response, opRequest exist
            ProcessChunkResponse(msg_hdr, msg_data);
            free(msg_hdr);
            if (msg_data) {
              mem_pool_.Free(msg_data, slab);
              msg_data = nullptr;
            }
            break;
          default:
            // 其他类型的都丢弃
            ULOG_ERROR << "unknown request type=" << msg_type;
            break;
        }
      }
    } else {
        break;
    }
  }
  ULOG_TRACE << conn->GetPeerAddress().ToString()
    << ", after buffersize : " << conn->ReadableLength();
}

bool RepairLoopHandle::DecodeMsg(const uevent::ConnectionUeventPtr &conn,
                                 uint8_t msg_type,
                                 common::MessageHeader **hdr,
                                 char **data,
                                 uint32_t *size,
                                 MemorySlab **slab) {
  switch (msg_type) {
    case common::MSG_CHUNK_REPAIR_REQ: {
      size_t msg_hdr_len = sizeof(common::MessageHeader) +
                           sizeof(common::ChunkRepairHead);
      char *msg_hdr = (char*)(msg_header_slab_.Malloc());
      conn->ReceiveData((void*)msg_hdr, msg_hdr_len);
      *hdr = (common::MessageHeader*)msg_hdr;
      common::ChunkRepairHead *chunk_hdr =
        (common::ChunkRepairHead*)(msg_hdr + sizeof(common::MessageHeader));
      assert(chunk_hdr->magic == common::CHUNK_IO_MAGIC);
      if (chunk_hdr->size) {
         if ((size_t)conn->ReadableLength() >= (msg_hdr_len + chunk_hdr->size)) {
           // 先移除消息头
           conn->DrainData(msg_hdr_len);
           *hdr = (common::MessageHeader*)msg_hdr;
           void *msg_data = nullptr;
           std::tie(msg_data, *slab) = mem_pool_.Malloc(chunk_hdr->size, kDefaultDevBlockSize);
           *size = chunk_hdr->size;
           assert(msg_data);
           conn->RemoveData(msg_data, chunk_hdr->size);
           *data = (char*)msg_data;
           return true;
        } else {
          free(msg_hdr);
          return false;
        }
      } else {
        conn->DrainData(msg_hdr_len);
        *hdr = (common::MessageHeader*)msg_hdr;
        *data = nullptr;
        return true;
      }
    }
    case common::MSG_CHUNK_REPAIR_RES: {
      size_t msg_hdr_len = sizeof(common::MessageHeader) +
                           sizeof(common::ChunkRepairHead);
      char *msg_hdr = (char*)malloc(msg_hdr_len);
      conn->ReceiveData((char*)msg_hdr, msg_hdr_len);
      *hdr = (common::MessageHeader*)msg_hdr;
      common::ChunkRepairHead *chunk_hdr =
        (common::ChunkRepairHead*)(msg_hdr + sizeof(common::MessageHeader));
      assert(chunk_hdr->magic == common::CHUNK_IO_MAGIC);
      if (chunk_hdr->size) {
         if ((size_t)conn->ReadableLength() >= (msg_hdr_len + chunk_hdr->size)) {
           // 先移除消息头
           conn->DrainData(msg_hdr_len);
           *hdr = (common::MessageHeader*)msg_hdr;
           void *msg_data = nullptr;
           std::tie(msg_data, *slab) = mem_pool_.Malloc(chunk_hdr->size, kDefaultDevBlockSize);
           *size = chunk_hdr->size;
           assert(msg_data);
           conn->RemoveData(msg_data, chunk_hdr->size);
           *data = (char*)msg_data;
           return true;
        } else {
          free(msg_hdr);
          return false;
        }
      } else {
        conn->DrainData(msg_hdr_len);
        *hdr = (common::MessageHeader*)msg_hdr;
        *data = nullptr;
        return true;
      }
    }
    default:
      return false;
  }
}

void RepairLoopHandle::DoChunkRequest(OpRequest* op) {
  const common::ChunkRepairHead* chunk_hdr =
    (const common::ChunkRepairHead*)op->sub_msg_hdr_offset();
  ULOG_TRACE << "Recv Chunk request:" << DumpChunkRepairHead(*chunk_hdr);
  OpenChunkCb cb = std::bind(&RepairLoopHandle::OpenChunkResCB, this,
                 std::placeholders::_1, std::placeholders::_2, op);
  int32_t retcode = chunk_storage_->OpenChunk(
      ChunkID(chunk_hdr->pg_id, chunk_hdr->lc_id, chunk_hdr->pc_no, chunk_hdr->lc_random_id),
      true, cb);
  if (retcode != UDISK_OK) {
    ULOG_ERROR << "Req submit fail: " << DumpChunkRepairHead(*chunk_hdr);
    op->DecRefs();
    return;
  }
}

void RepairLoopHandle::ProcessChunkResponse(
    common::MessageHeader* msg_hdr, const char* data) {
  common::ChunkRepairHead* chunk_hdr =
    (common::ChunkRepairHead* )((const char*)msg_hdr + sizeof(common::MessageHeader));
  uint64_t op_seq = chunk_hdr->flowno;
  auto found = inflying_list_.find(op_seq);
  if (found == inflying_list_.end()) {
    if (!inflying_list_.empty()) { // op超时删除后，又触发了修复
      ULOG_ERROR << "Get a Msg Type: "
            << common::msg_type_name(common::MSG_CHUNK_REPAIR_RES)
            << " Sub Cmd: " << common::chunk_cmd_name(chunk_hdr->cmd)
            << " op_seq: " << op_seq
            << ", but can found this op_seq in inflying list,Ignore!";
    } else { // inflying_list_为空，说明op已经超时被清除，需要触发修复下一个pc
      SendNextRepairPC();
    }
    return;
  }
  assert(chunk_hdr->retcode == 0); // 出错的IO不返回，依赖超时
  OpRequest* op = found->second;
  ULOG_TRACE << common::msg_type_name(common::MSG_CHUNK_REPAIR_RES)
            << " Sub Cmd: " << common::chunk_cmd_name(chunk_hdr->cmd)
            << " parent op: " << op->trace_tag();
  inflying_list_.erase(found);
  bool del = op->DecRefs();
  if (del != true) {
    ULOG_FATAL << "impossible";
  }
  uint32_t lc_id = chunk_hdr->lc_id;
  uint32_t lc_size = chunk_hdr->lc_size;
  uint32_t pc_no = chunk_hdr->pc_no;
  uint32_t lc_random_id = chunk_hdr->lc_random_id;
  uint32_t pg_id = chunk_hdr->pg_id;
  // 收到回复，开启下一个tinypc的修复
  ULOG_TRACE << "repair tpc finish lc_id=" << lc_id << ", pc_no=" << pc_no
      << ",lc_random_id=" << lc_random_id << ",offset=" << chunk_hdr->offset;
  chunk_hdr->offset += CHUNK_REPAIR_TINYPC_SIZE;
  if (chunk_hdr->offset == g_context->chunk_pool()->pc_size()) {
    // pc数据迁移完毕, 等待repair_chunk merge完前台数据，并通知manage_thread, 由manage通知loki.
    ULOG_DEBUG << "repair pc finish lc_id=" << lc_id << ", pc_no=" << pc_no;
    for (auto it = repair_pcs_.begin(); it != repair_pcs_.end(); /* nothing */) {
      if (it->first == PhysicalChunk(lc_id, lc_size, pc_no, lc_random_id, pg_id)) {
        it = repair_pcs_.erase(it);
      } else {
        ++it;
      }
    }
    SendNextRepairPC();
  } else {
    SendRepairPCRequest(pg_id, lc_id, pc_no, lc_size, lc_random_id, chunk_hdr->offset);
  }
  return;
}

void RepairLoopHandle::SendNextRepairPC() {
  RepairPCList::iterator it = repair_pcs_.begin();
  if (it == repair_pcs_.end()) {
    // 所有数据同步完毕
    ULOG_INFO << "Finish all repair pc data_sync:)";
    return;
  }
  uint32_t lc_id = it->first.lc_id;
  uint32_t lc_size = it->first.lc_size;
  uint32_t pc_no = it->first.pc_no;
  uint32_t lc_random_id = it->first.lc_random_id;
  uint32_t pg_id = it->first.pg_id;
  SendRepairPCRequest(pg_id, lc_id, pc_no, lc_size, lc_random_id, 0);
}

void RepairLoopHandle::MessageWriteHandle(const uevent::ConnectionUeventPtr& conn) {
}

void RepairLoopHandle::UpdateClusterMap(cluster::ClusterMap map) {
  ULOG_INFO << "MY ClusterMap will be updated";
  cluster_map_ = map;
}

bool RepairLoopHandle::SendMsg(const char *msg, size_t len,
    const std::string  &ip, int port, uint32_t chunk_id) {
  uevent::ConnectionUeventPtr connection = get_out_connection(ip, port, chunk_id);
  return connection->SendData(msg, len) == 0 ? true : false;
}

void RepairLoopHandle::OutConnectionSuccessHandle(const uevent::ConnectionUeventPtr& conn) {
}

void RepairLoopHandle::OutConnectionCloseHandle(uint32_t chunk_id,
    const uevent::ConnectionUeventPtr& conn) {
  chunk_connectors_[chunk_id]->DestroyConnection();
  chunk_connectors_[chunk_id] = nullptr;
}

uevent::ConnectionUeventPtr RepairLoopHandle::get_out_connection(const std::string &ip,
    int port, uint32_t chunk_id) {
  if (chunk_id >= chunk_connectors_.size()) {
    chunk_connectors_.resize(chunk_id + 1, nullptr);
  }
  if (chunk_connectors_.at(chunk_id)) {
    if (chunk_connectors_.at(chunk_id)->GetConnection()) {
      return chunk_connectors_.at(chunk_id)->GetConnection();
    } else {
      chunk_connectors_.at(chunk_id)->Connect();
      return chunk_connectors_.at(chunk_id)->GetConnection();
    }
  }

  // new connection
  std::stringstream ss;
  uevent::UsockAddress addr(ip, port, false);
  ss << "connector-" << ip << ":" << port;
  uevent::ConnectorUeventPtr connector =
    std::make_shared<uevent::ConnectorLibevent>(
        static_cast<uevent::PosixWorker*>(repair_loop_->worker()), addr, ss.str());
  connector->SetConnectionSuccessCb(
      std::bind(&RepairLoopHandle::OutConnectionSuccessHandle, this,
        std::placeholders::_1));
  connector->SetConnectionClosedCb(
      std::bind(&RepairLoopHandle::OutConnectionCloseHandle, this, chunk_id,
        std::placeholders::_1));
  connector->SetMessageReadCb(
      std::bind(&RepairLoopHandle::MessageReadHandle, this, std::placeholders::_1));
  connector->Connect();

  // save
  chunk_connectors_[chunk_id] = connector;

  return connector->GetConnection();
}

void RepairLoopHandle::ReportLCIOError() {
  if (io_error_container_.IsEmpty()) {
    return;
  }

  g_context->manager_handle()->ReportLCIOError(io_error_container_.lc_io_errors());
  io_error_container_.Clear();
}

}; // end of chunk
}; // end of udisk
