#include "dump_chunk_pool.h"

#include <sstream>
#include <ustevent/message_util.h>
#include <ustevent/connection_uevent.h>
#include <ustevent/base/logging.h>
#include "chunk_context.h"
#include "manager_handle.h"

namespace udisk {
namespace chunk {

using namespace uevent;
 
int DumpChunkPoolInfoHandle::type_ = 
                       ucloud::udisk::CHUNK_DUMP_CHUNK_POOL_INFO_REQUEST;

void DumpChunkPoolInfoHandle::EntryInit(const uevent::ConnectionUeventPtr& conn, 
                                         const uevent::UMessagePtr& um) {
  ULOG_INFO << "protobuf recv conn=" << conn->GetId() << ", msg " << um->DebugString();
  conn_ = conn;
  assert(um->head().message_type() == type_);
  assert(um->body().HasExtension(ucloud::udisk::chunk_dump_chunk_pool_info_request));

  ucloud::udisk::ChunkDumpChunkPoolInfoRequest req_body = 
    um->body().GetExtension(ucloud::udisk::chunk_dump_chunk_pool_info_request);
  MakeResponse(um.get(), ucloud::udisk::CHUNK_DUMP_CHUNK_POOL_INFO_RESPONSE, 
                                                                   &response_);
  resp_body_ = response_.mutable_body()->
    MutableExtension(ucloud::udisk::chunk_dump_chunk_pool_info_response);

  std::string chunk_pool_info = g_context->chunk_pool()->DumpChunkPoolInfo();

  resp_body_->mutable_rc()->set_retcode(0);
  resp_body_->mutable_rc()->set_error_message("success");
  resp_body_->set_chunk_pool_info(chunk_pool_info);
  MessageUtil::SendPbResponse(conn_, response_);
}

} // namespace chunk
} // namespace udisk
