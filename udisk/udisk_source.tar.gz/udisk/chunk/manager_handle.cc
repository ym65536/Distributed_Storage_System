#include <malloc.h>
#include <ustevent/message_util.h>
#include "chunk_loop_handle.h"
#include "chunk_context.h"
#include <ustevent/base/my_uuid.h>
#include "udisk_message.h"
#include "umessage_common.h"
#include "get_meta_data.h"
#include "heartbeat_chunk_chunk.h"
#include "get_pg_pc.h"
#include "dump_chunk_pool.h"
#include "add_host_blacklist.h"
#include "remove_host_blacklist.h"
#include "get_detection_state.h"
#include "repair_loop_handle.h"
#include "get_udisk_io_stats.h"
#include "set_udisk_io_depth.h"
#include "migrate_udisk.h"
#include "migrate_journal.h"
#include "uns_message.h"
#include "udisk_time.h"
#include "recycle_pc.h"
#include "manager_handle.h"
#include "get_lc_pc.h"
#include "migrate_task_finish.h"
#include "prepare_migrate.h"
#include "manual_compact.h"
#include "str_list.h"

using namespace udisk::chunk;
using namespace udisk::journal;
using namespace ucloud::udisk;
using namespace std::placeholders;
using namespace uevent;

ManagerHandle::ManagerHandle() {
  man_thread_ = nullptr;
  man_loop_ = nullptr;
  man_listener_ = nullptr;
}

void ManagerHandle::start(const std::string &ip, int port) {
  man_thread_ = new uevent::WorkerThread("Manager", nullptr);
  man_loop_ = man_thread_->StartWorker()->eventloop();
  uevent::UsockAddress man_addr(ip, port);
  man_listener_ = new uevent::ListenerLibevent(static_cast<uevent::PosixWorker*>(man_loop_->worker()), man_addr,
      "ManListener", uevent::Option());
  man_listener_->SetConnectionSuccessCb(
      std::bind(&ManagerHandle::ConnectionSuccessHandle, this, std::placeholders::_1));
  man_listener_->SetConnectionClosedCb(
      std::bind(&ManagerHandle::ConnectionClosedHandle, this, std::placeholders::_1));
  man_listener_->SetMessageReadCb(
      std::bind(&uevent::MessageUtil::ProtobufReadCallBack, std::placeholders::_1));
  man_listener_->SetMessageWriteCb(
      std::bind(&ManagerHandle::MessageWriteHandle, this, std::placeholders::_1));

  g_context->set_man_listen_loop(man_loop_);
  g_context->set_man_listener(man_listener_);
  g_context->set_manager_handle(this);
  man_listener_->Start();

  // 向metaserver请求元数据
  man_loop_->RunInLoop(std::bind(&ManagerHandle::TakeMetaDataFromMetaServer, this), true);

  RegisterService();

  man_loop_->RunEvery(g_context->config().heartbeat_metaserver_interval(),
      std::bind(&ManagerHandle::HeartbeatMetaServer, this));

  man_loop_->RunEvery(g_context->config().io_report_interval(),
      std::bind(&ManagerHandle::HeartbeatOdinServer, this));

  man_loop_->RunEvery(g_context->config().heartbeat_chunk_interval(),
      std::bind(&ManagerHandle::HeartbeatChunk, this));

  man_loop_->RunEvery(g_context->config().heartbeat_chunk_interval(),
    std::bind(&ManagerHandle::CheckRepairRequestState, this));

  man_loop_->RunEvery(g_context->config().mem_check_interval(),
    std::bind(&ManagerHandle::CheckChunkMemory, this));
}

void ManagerHandle::CheckChunkMemory() {
  ULOG_INFO << "malloc_trim is called";
  malloc_trim(0);
  ULOG_INFO << "malloc_trim complete";
}

void ManagerHandle::CheckRepairRequestState() {
  base::Timestamp now_time(base::Timestamp::now());
  // 1. pending io回包超时检查
  for (auto it = pending_io_requests_.begin(); it != pending_io_requests_.end();
      /*nothing*/) {
    if (timeDifference(now_time, it->second.start_time)
        <= g_context->config().repair_notify_timeout()) {
      ++it;
      continue;
    }

    // 超时处理
    // 通知io chunk thread, 释放pending的buffer
    std::vector<uevent::EventLoop*> all_loops = g_context->io_listener()->GetAllLoops();
    for (size_t i = 0; i < all_loops.size(); ++i) {
      assert(all_loops[i]);
      ChunkLoopHandle *loop_handle = (ChunkLoopHandle*)all_loops[i]->GetLoopHandle();
      all_loops[i]->RunInLoop(
        std::bind(&ChunkLoopHandle::RepairPCFinishNotify,
          loop_handle, it->first.first, 0, it->first.second), true);
    }

    auto pc_info = it->first;
    const std::shared_ptr<ChunkBeginRepairHandle> request_handle = it->second.begin_repair_handle;
    it = pending_io_requests_.erase(it);
    if (request_handle) {
      request_handle->SendResponse(ucloud::udisk::EC_UDISK_REPAIR_TIMEOUT,
        "notify pending io timeout");
    }
    ULOG_ERROR << "pending_io_requests_ timeout. lc_id=" << pc_info.first <<
      ", pc_no=" << pc_info.second;
  }

  // 2. 修复完毕回包超时检查
  for (auto it = repair_requests_.begin(); it != repair_requests_.end();
      /*nothing*/) {
    if (timeDifference(now_time, it->second.start_time)
        <= g_context->config().repair_pc_timeout()) {
      ++it; // 未超时，go on
      continue;
    }
    // 超时处理
    // 通知io chunk thread, 释放pending的buffer
    std::vector<uevent::EventLoop*> all_loops = g_context->io_listener()->GetAllLoops();
    for (size_t i = 0; i < all_loops.size(); ++i) {
      assert(all_loops[i]);
      ChunkLoopHandle *loop_handle = (ChunkLoopHandle*)all_loops[i]->GetLoopHandle();
      all_loops[i]->RunInLoop(
        std::bind(&ChunkLoopHandle::RepairPCFinishNotify,
          loop_handle, it->first.first, 0, it->first.second), true);
    }

    // 通知primary chunk
    auto pc_info = it->first;
    const std::shared_ptr<ChunkBeginRepairHandle> request_handle = it->second.begin_repair_handle;
    it = repair_requests_.erase(it);
    if (request_handle) {
      request_handle->SendResponse(ucloud::udisk::EC_UDISK_REPAIR_TIMEOUT,
        "notify repair_chunk timeout");
    }
    ULOG_ERROR << "PC repair timeout, release. lc_id=" << pc_info.first
      << ", pc_no=" << pc_info.second;
  }
}

int ManagerHandle::RepairRequestHandles(uint32_t lc_id, uint32_t pc_no,
  uint32_t io_thread_num, std::shared_ptr<ChunkBeginRepairHandle>& handle) {
  std::pair<uint32_t, uint32_t> pc_info = std::make_pair(lc_id, pc_no);
  if (repair_requests_.find(pc_info) == repair_requests_.end()) {
    ULOG_ERROR << "repair pc not in repair_requests_. lc_id=" << lc_id
      << ", pc_no=" << pc_no;
    return -1;
  }

  // 更新map中handle/time
  repair_requests_[pc_info] = RepairRequest(io_thread_num, handle);
  return 0;
}

void ManagerHandle::RepairResponseHandles(uint32_t lc_id, uint32_t pc_no,
    uint32_t front_io, uint32_t retcode, const std::string& errmsg) {
  std::pair<uint32_t, uint32_t> pc_info = std::make_pair(lc_id, pc_no);
  auto it = repair_requests_.find(pc_info);
  if (it == repair_requests_.end()) {
    ULOG_ERROR << "pc not exist in repair_requests_. lc_id=" << lc_id
      << ", pc_no=" << pc_no;
    return;
  }
  uint32_t left_io_thread_num = --it->second.left_io_thread_num;
  uint32_t front_io_thread_num = it->second.front_io_thread_num + front_io;
  it->second.front_io_thread_num = front_io_thread_num;
  ULOG_DEBUG << "Left io thread num=" << left_io_thread_num << ", front io thread="
    << front_io_thread_num;

  if ((left_io_thread_num == 0) ||  // 所有的都返回
      (retcode != 0) ||             // 其中一个出现错误
      (front_io_thread_num > 1)) {  // 多个线程发生pending io，即pending buffer发生切换
    const std::shared_ptr<ChunkBeginRepairHandle> request_handle = it->second.begin_repair_handle;
    repair_requests_.erase(it);

    if (front_io_thread_num > 1) {
      ULOG_ERROR << "lc_id:" << lc_id << ", pc_no=" << pc_no
          <<" ,front_io_thread_num=" << front_io_thread_num << ", must be "
        "repair_buffer change, response error";
      if (request_handle) {
        request_handle->SendResponse(ucloud::udisk::EC_UDISK_REPAIR_FAIL,
            "RepairBuffer change");
      }
    } else {
      if (retcode != 0) {
        ULOG_ERROR << "repair_requests error. lc_id=" << lc_id << ", pc_no="
          << pc_no << ", retcode=" << retcode << ", errmsg=" << errmsg;
      }
      if (request_handle) {
        request_handle->SendResponse(retcode, errmsg);
      }
    }
  }
}

int ManagerHandle::PendingIORequestHandles(uint32_t lc_id, uint32_t pc_no,
  uint32_t io_thread_count, std::shared_ptr<ChunkBeginRepairHandle>& handle) {
  std::pair<uint32_t, uint32_t> pc_info = std::make_pair(lc_id, pc_no);
  if (pending_io_requests_.find(pc_info) != pending_io_requests_.end()) {
    ULOG_ERROR << "pc already in pending_io_requests_. lc_id=" << lc_id
      << ", pc_no=" << pc_no;
    return -1;
  }
  pending_io_requests_.insert(std::make_pair(pc_info,
                                             RepairRequest(io_thread_count, handle)));
  return 0;
}

void ManagerHandle::PendingIOResponseHandles(uint32_t lc_id, uint32_t pc_no,
    uint32_t retcode, const std::string& errmsg) {
  std::pair<uint32_t, uint32_t> pc_info = std::make_pair(lc_id, pc_no);
  RepairRequestMap::iterator it = pending_io_requests_.find(pc_info);
  if (it == pending_io_requests_.end()) {
    ULOG_ERROR << "pc not exist in pending_io_requests_. lc_id=" << lc_id
      << ", pc_no=" << pc_no;
    return;
  }

  it->second.left_io_thread_num--;
  ULOG_DEBUG << "Left io thread num=" << it->second.left_io_thread_num;
  if (it->second.left_io_thread_num == 0 || (retcode != 0)) { // 所有的都返回或者其中一个出现错误，返回error
    const std::shared_ptr<ChunkBeginRepairHandle> request_handle = it->second.begin_repair_handle;
    pending_io_requests_.erase(it);
    if (request_handle) {
      request_handle->SendResponse(retcode, errmsg);
    }
    if (retcode != 0) {
      ULOG_ERROR << "pending_io_requests_ return error. lc_id=" << lc_id <<
        ", pc_no=" << pc_no << ", retcode=" << retcode << ", errmsg=" << errmsg;
    } else { // it->second.left_io_thread_num = 0说明所有线程pending io通知完毕，计入repair_map
      repair_requests_.insert(std::make_pair(pc_info, RepairRequest(0, nullptr)));
    }
  }
}

bool ManagerHandle::GetMetaServerAddress(std::string& ip, int& port) {
  ucloud::uns::NameNodeContent data;
  if (g_context->nc()->GetNNCForName(g_context->config().my_set(),
        common::ConfigParser::kMetaServerName, data, true)) {
    return false;
  }
  ip = data.ip();
  std::string reserve = data.reserved();
  ucloud::udisk::MetaserverPortPair meta_data;
  if (meta_data.ParseFromString(reserve)) {
    port = meta_data.chunk_port();
    return true;
  }
  return false;
}

void ManagerHandle::HeartbeatOdinServer() {
  std::string ip;
  int port;

  ReportOdinIOError();

  if (!GetOdinServerAddress(ip, port)) {
    ULOG_ERROR << "can not get odin address";
    return;
  }
  uevent::ConnectionUeventPtr conn = get_out_connection(ip, port);
  if (nullptr == conn) {
    ULOG_ERROR << "Get connection of odin failed";
    return;
  }
  ucloud::UMessage msg;
  uint32_t obj_id = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&msg, flowno, base::MyUuid::NewUuid(),
                ucloud::udisk::REPORT_CHUNK_ODIN_REQUEST,
                0, false, obj_id, 0, NULL, NULL, NULL);
  ucloud::udisk::ReportChunkOdinRequest* req =
    msg.mutable_body()->MutableExtension(ucloud::udisk::report_chunk_odin_request);

  BuildIOReportToOdinRequest(req);
  ULOG_DEBUG << "Heartbeat to Odin: " << ip << ":" << port
            << ", Msg: " << msg.DebugString();
  uevent::MessageUtil::SendPbRequest(conn, msg,
      std::bind(&ManagerHandle::HeartbeatOdinServerResponse, this, std::placeholders::_1),
      std::bind(&ManagerHandle::HeartbeatOdinServerTimeout, this), 2.0);
}

void ManagerHandle::BuildIOReportToOdinRequest(
    ucloud::udisk::ReportChunkOdinRequest* req) {
  req->set_chunk_id(g_context->config().my_id());
  req->set_chunk_ip(g_context->config().listen_ip());
  req->set_chunk_port(g_context->config().listen_port());
  req->set_stats_time(base::Timestamp::now().secondsSinceEpoch());
  req->set_stats_period(g_context->config().io_report_interval());
  for (auto it = thread_io_count_.begin();
      it != thread_io_count_.end(); ++it) {
    ucloud::udisk::ChunkThreadStats *thread_stats = req->add_thread_stats();
    thread_stats->set_thread_name(it->first);
    thread_stats->set_r_iops(it->second.r_iops);
    thread_stats->set_w_iops(it->second.w_iops);
    thread_stats->set_r_byteps(it->second.r_byteps);
    thread_stats->set_w_byteps(it->second.w_byteps);
    thread_stats->set_r_io_latency_max(it->second.r_io_latency_max);
    thread_stats->set_r_io_latency_avg(it->second.r_io_latency_avg);
    thread_stats->set_w_io_latency_max(it->second.w_io_latency_max);
    thread_stats->set_w_io_latency_avg(it->second.w_io_latency_avg);
  }
}

void ManagerHandle::HeartbeatOdinServerResponse(const UMessagePtr& msg) {
  const ucloud::udisk::ReportChunkOdinResponse &res =
      msg->body().GetExtension(ucloud::udisk::report_chunk_odin_response);
  if (res.rc().retcode() != 0) {
    ULOG_ERROR << "report odin fail, errcode=" << res.rc().retcode();
    return;
  }
}

void ManagerHandle::HeartbeatOdinServerTimeout() {
  ULOG_ERROR << "report odin fail timeout";
}

void ManagerHandle::ReportOdinIOError() {
  if (io_error_container_.IsEmpty()) {
    return;
  }

  std::string ip;
  int port;
  if (!GetOdinServerAddress(ip, port)) {
    ULOG_ERROR << "can not get odin address";
    return;
  }

  uevent::ConnectionUeventPtr conn = get_out_connection(ip, port);
  if (nullptr == conn) {
    ULOG_ERROR << "Get connection of odin failed";
    return;
  }

  const IOErrorContainer::LCIOErrorMap& lc_io_errors = io_error_container_.lc_io_errors();
  for (auto it = lc_io_errors.begin(); it != lc_io_errors.end(); ++it) { 
    ucloud::UMessage msg; 
    uint32_t obj_id = uevent::MessageUtil::ObjId();
    uint32_t flowno = uevent::MessageUtil::Flowno();
    NewMessage_v2(&msg, flowno, base::MyUuid::NewUuid(),
                  ucloud::udisk::ODIN_WARNING_REQUEST, 0, false,
                  obj_id, 0, "OdinWarningRequest", NULL, NULL);
    ucloud::udisk::OdinWarningRequest* req = msg.mutable_body()->
        MutableExtension(ucloud::udisk::odin_warning_request);
    // chunk_ip:port:lc_id-IO_ERROR_TYPE-IO_OP_TYPE
    std::ostringstream ss;
    ss << g_context->config().listen_ip() << ":"
       << std::to_string(g_context->config().listen_port()) << ":"
       << it->first;
    req->set_uuid(ss.str());
    req->set_item_id(common::ConfigParser::kIOReadWriteErrorItemId);
    req->set_value(it->second);
    req->set_time(base::Timestamp::now().secondsSinceEpoch());
    ULOG_DEBUG << "Report io error to Odin: " << ip << ":" << port
               << ", Msg: " << msg.DebugString();
    MessageUtil::SendPbRequest(conn, msg, 
      std::bind(&ManagerHandle::OdinWarningResponseCb, this, std::placeholders::_1),
      std::bind(&ManagerHandle::OdinWarningTimeout, this), 2.0);
  }

  io_error_container_.Clear();
}

void ManagerHandle::OdinWarningResponseCb(const UMessagePtr& msg) {
  const ucloud::udisk::OdinWarningResponse &res =
    msg->body().GetExtension(ucloud::udisk::odin_warning_response);
  if (res.rc().retcode() != 0) {
    ULOG_ERROR << "odin warning response error";
  }
}

void ManagerHandle::OdinWarningTimeout() {
  ULOG_ERROR << "odin waring request timeout";
}

bool ManagerHandle::GetOdinServerAddress(std::string &ip, int &port) {
  ucloud::uns::NameNodeContent data;
  if (g_context->nc()->GetNNCForName(g_context->config().my_set(),
        common::ConfigParser::kOdinName, data, true)) {
    return false;
  }
  ip = data.ip();
  std::string reserve = data.reserved();
  ucloud::udisk::OdinPortPair port_pair;
  if (port_pair.ParseFromString(reserve)) {
    port = port_pair.chunk_port();
    return true;
  }
  return false;
}

void ManagerHandle::FillChunkGetUDisksIOStatsResponse(
    const ucloud::udisk::ChunkGetUDisksIOStatsRequest *req,
    ucloud::udisk::ChunkGetUDisksIOStatsResponse *res) {

  if (!req->top_count() ||
      (req->type() != ucloud::udisk::GET_UDISKS_IO_STATS_TYPE_IOPS &&
      req->type() != ucloud::udisk::GET_UDISKS_IO_STATS_TYPE_BW)) {
    ULOG_ERROR << "invalid ChunkGetUDisksIOStatsRequest: " << req->DebugString();
    res->mutable_rc()->set_retcode(ucloud::udisk::EC_UDISK_PARAM_INVALID);
    res->mutable_rc()->set_error_message("invalid param");
    return;
  }

  std::function<bool (const ucloud::udisk::ChunkUDiskIOStat &l,
                      const ucloud::udisk::ChunkUDiskIOStat &r)> greater =
    [req] (const ucloud::udisk::ChunkUDiskIOStat &l,
           const ucloud::udisk::ChunkUDiskIOStat &r) {
      if (req->type() == ucloud::udisk::GET_UDISKS_IO_STATS_TYPE_IOPS) {
        if (req->inc_order()) {
          return (l.r_iops() + l.w_iops()) < (r.r_iops() + r.w_iops());
        } else {
          return (l.r_iops() + l.w_iops()) > (r.r_iops() + r.w_iops());
        }
      } else {
        if (req->inc_order()) {
          return (l.r_bw() + l.w_iops()) < (r.r_bw() + r.w_bw());
        } else {
          return (l.r_bw() + l.w_iops()) > (r.r_bw() + r.w_bw());
        }
      }
    };
  std::vector<ucloud::udisk::ChunkUDiskIOStat> udisks;
  for (auto it = thread_udisk_io_count_.begin();
       it != thread_udisk_io_count_.end(); ++it) {
    if (req->has_thread_name() && req->thread_name() != it->first) {
      continue;
    }
    for (auto jt = it->second.begin(); jt != it->second.end(); jt++) {
      if (req->io_depth_limited()) {
        if (jt->second.io_depth_limit() ==
            (size_t)g_context->config().udisk_queue_max_depth()) {
          continue;
        }
      }
      udisks.push_back(jt->second);
    }
  }
  std::sort(udisks.begin(), udisks.end(), greater);
  size_t count = 0;
  for (auto it = udisks.begin();
       count < req->top_count() && it != udisks.end();
       ++it) {
    res->add_stats()->CopyFrom(*it);
    count++;
  }

  if (g_context->config().loop_dispatch_io_depth() != 0) {
    // 由于目前所有线程的loop_dispatch_io_depth都是一样的，简化处理，取其中一个即可
    std::vector<uevent::EventLoop*> all_loops = g_context->io_listener()->GetAllLoops();
    ChunkLoopHandle *loop_handle = (ChunkLoopHandle*)all_loops[0]->GetLoopHandle();
    res->set_loop_dispatch_io_depth(loop_handle->dispatch_io_depth());
  }

  res->mutable_rc()->set_retcode(0);
}

void ManagerHandle::TakeMetaDataFromMetaServer() {
  std::string ip;
  int port;
  if (!GetMetaServerAddress(ip, port)) {
    ULOG_ERROR << "Get node of metaserver failed";
    return;
  }

  uevent::ConnectionUeventPtr conn = get_out_connection(ip, port);
  if (nullptr == conn) {
    ULOG_ERROR << "Get connection of metaserver failed";
    return;
  }

  ucloud::UMessage msg;
  uint32_t obj_id = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&msg, flowno, base::MyUuid::NewUuid(),
                ucloud::udisk::GET_META_DATA_REQUEST,
                0, false, obj_id, 0, NULL, NULL, NULL);

  ucloud::udisk::GetMetaDataRequest* req =
    msg.mutable_body()->MutableExtension(ucloud::udisk::get_meta_data_request);
  req->set_cluster_version(0);

  uevent::MessageUtil::SendPbRequest(conn, msg,
      std::bind(&ManagerHandle::GetMetaDataResponse, this, std::placeholders::_1),
      std::bind(&ManagerHandle::GetMetaDataTimeout, this, flowno), 1.0);
  ULOG_DEBUG << "Heartbeat to Metaserver: " << ip << ":" << port
            << ", Msg: " << msg.DebugString();
}

void ManagerHandle::GetMetaDataResponse(const UMessagePtr& msg) {
  ULOG_DEBUG << "Recv meta=" << msg->DebugString();
  ucloud::udisk::GetMetaDataResponse* res =
    msg->mutable_body()->MutableExtension(ucloud::udisk::get_meta_data_response);

  if (!res->rc().retcode()) {
    cluster_map_.Clear();
    UpdateClusterMap(res->cluster_info(), res->chunk_info(), res->pg_info());
    if (res->pc_size() != g_context->chunk_pool()->pc_size()) {
      ULOG_FATAL << "pc size is not same as metaserver";
    }
    // 存在黑名单主机
    if (res->blacklist_hosts_size() != 0) {
      uint32_t refuse_seconds = 20; // 默认拒绝20s
      if (res->has_refuse_seconds()) {
        refuse_seconds = res->refuse_seconds();
      }
      AddBlacklist(res->blacklist_hosts(), refuse_seconds);
    }
  } else {
    ULOG_ERROR << "MetaData Response get_meta_data_response error, retcode :"
              << res->rc().retcode();
  }
}

void ManagerHandle::GetMetaDataTimeout(uint64_t flowno) {
  ULOG_ERROR << "Get meta data timeout";
}

void ManagerHandle::RegisterService() {
  REGISTE_PROTO_HANDLER(man_loop_, HEARTBEAT_CHUNK_CHUNK_REQUEST, HeartbeatChunkChunkHandle);
  REGISTE_PROTO_HANDLER(man_loop_, GET_META_DATA_REQUEST, GetMetaDataHandle);
  REGISTE_PROTO_HANDLER(man_loop_, GET_PG_PHYSICAL_CHUNK_REQUEST, GetPGPhysicalChunkHandle);
  REGISTE_PROTO_HANDLER(man_loop_, CHUNK_BEGIN_REPAIR_REQUEST, ChunkBeginRepairHandle);
  REGISTE_PROTO_HANDLER(man_loop_, CHUNK_RECYCLE_PC_REQUEST, RecyclePCHandle);
  REGISTE_PROTO_HANDLER(man_loop_, CHUNK_GET_UDISKS_IO_STATS_REQUEST, GetUDiskIOStatsHandle);
  REGISTE_PROTO_HANDLER(man_loop_, CHUNK_SET_UDISK_IO_DEPTH_REQUEST, SetUDiskIODepthHandle);
  REGISTE_PROTO_HANDLER(man_loop_, CHUNK_MIGRATE_UDISK_REQUEST, MigrateUDiskHandle);
  REGISTE_PROTO_HANDLER(man_loop_, TYR_MIGRATE_JOURNAL_REQUEST, MigrateJournalHandle);
  REGISTE_PROTO_HANDLER(man_loop_, GET_LC_PHYSICAL_CHUNK_REQUEST, GetLCPhysicalChunkHandle);
  REGISTE_PROTO_HANDLER(man_loop_, TYR_MIGRATE_TASK_FINISH_REQUEST, MigrateTaskFinishHandle);
  REGISTE_PROTO_HANDLER(man_loop_, ucloud::udisk::CHUNK_DUMP_CHUNK_POOL_INFO_REQUEST, DumpChunkPoolInfoHandle);
  REGISTE_PROTO_HANDLER(man_loop_, TYR_CHUNK_MIGRATE_PC_REQUEST, MigratePCHandle);
  REGISTE_PROTO_HANDLER(man_loop_, ucloud::udisk::ADD_HOST_BLACKLIST_REQUEST, AddHostBlacklistHandle);
  REGISTE_PROTO_HANDLER(man_loop_, ucloud::udisk::REMOVE_HOST_BLACKLIST_REQUEST, RemoveHostBlacklistHandle);
  REGISTE_PROTO_HANDLER(man_loop_, ucloud::udisk::CHUNK_GET_DETECTION_STATE_REQUEST, GetDetectionStateHandle);
  REGISTE_PROTO_HANDLER(man_loop_, TYR_PREPARE_MIGRATE_REQUEST, PrepareMigrateHandle);
  REGISTE_PROTO_HANDLER(man_loop_, TYR_MANUAL_COMPACT_REQUEST, ManualCompactHandle);
}

void ManagerHandle::HandleChunkHeartbeat(uint32_t chunk_id) {
  ULOG_TRACE << "Heartbeat from " << chunk_id;
  // parteners_expired_[chunk_id] = udisk::common::udisk_now();
}

void ManagerHandle::ConnectionSuccessHandle(const uevent::ConnectionUeventPtr& conn) {
  ULOG_DEBUG << "get new connection " << conn->GetPeerAddress().ToString()
    << ", conn_id=" << conn->GetId();
}

void ManagerHandle::ConnectionClosedHandle(const uevent::ConnectionUeventPtr& conn) {
  ULOG_INFO << "remove a connection " << conn->GetPeerAddress().ToString()
    << ", conn_id=" << conn->GetId();
  g_context->man_listener()->RemoveConnection(conn);
}

void ManagerHandle::MessageWriteHandle(const uevent::ConnectionUeventPtr& conn) {
}

void ManagerHandle::OutConnectionSuccessHandle(const uevent::ConnectionUeventPtr& conn) {
}

void ManagerHandle::OutConnectionCloseHandle(const uevent::ConnectionUeventPtr& conn,
    uint64_t conn_id) {
  auto it = out_connectors_.find(conn_id);
  if (it != out_connectors_.end()) {
    out_connectors_.erase(it);
  }
}

void ManagerHandle::HeartbeatChunk() {
  if (partner_chunks_.empty()) {
    ULOG_INFO << "ManagerHandle partner_chunks_ is not inited, start init it";
    if (cluster_map_.IsInit()) {
      if (!cluster_map_.GetPartnerChunkInfo(g_context->config().my_id(), partner_chunks_)) {
        ULOG_WARN << "ManagerHandle partner_chunks_ init failed";
        return;
      }
      ULOG_INFO << "ManagerHandle partner_chunks_ init successfuly.partner_chunks_: ";
      for (auto it = partner_chunks_.begin(); it != partner_chunks_.end(); ++it) {
        ULOG_INFO << it->DebugString() << "\n";
      }
    } else {
      ULOG_WARN << "ManagerHandle partner_chunks_ init failed for cluster_map not inited";
    }
  }

  for (auto it = partner_chunks_.begin(); it != partner_chunks_.end(); ++it) {
    uevent::ConnectionUeventPtr conn = get_out_connection(it->ip(), it->man_port());

    if (it->id() == (uint32_t)g_context->config().my_id()) {
      continue;
    }
    ucloud::UMessage msg;
    uint32_t obj_id = uevent::MessageUtil::ObjId();
    uint32_t flowno = uevent::MessageUtil::Flowno();
    NewMessage_v2(&msg, flowno, base::MyUuid::NewUuid(),
                  ucloud::udisk::HEARTBEAT_CHUNK_CHUNK_REQUEST,
                  0, false, obj_id, 0, NULL, NULL, NULL);

    ucloud::udisk::HeartbeatChunkChunkRequest* req =
      msg.mutable_body()->MutableExtension(ucloud::udisk::heartbeat_chunk_chunk_request);
    req->set_id(g_context->config().my_id());
    uevent::MessageUtil::SendPbRequest(conn, msg,
        std::bind(&ManagerHandle::HeartbeatChunkResponse, this, std::placeholders::_1),
        std::bind(&ManagerHandle::HearbeatChunkTimeout, this, it->id()), 1.0);
    ULOG_INFO << "heartbeat to chunk: id=" << it->id();
    ULOG_DEBUG << "Heartbeat to Chunk: id=" << it->id()
              << ",ip=" << it->ip() << ",port=" << it->man_port()
              << ",Mesg: " << msg.DebugString();
  }
}

void ManagerHandle::HeartbeatChunkResponse(const UMessagePtr& msg) {
  // TODO
  const ucloud::udisk::HeartbeatChunkChunkResponse &res =
      msg->body().GetExtension(ucloud::udisk::heartbeat_chunk_chunk_response);
  if (res.rc().retcode() != 0) {
    ULOG_ERROR << "Access peer chunk fail, errcode=" << res.rc().retcode();
    return;
  }
}

void ManagerHandle::HearbeatChunkTimeout(uint32_t chunk_id) {
  // TODO
  ULOG_ERROR << "access peer chunk timeout, peer chunk_id=" << chunk_id;
  // chunk 心跳超时
  ucloud::udisk::ChunkFailureInfoPb failure_info;
  failure_info.set_id(chunk_id);
  failure_info.set_type(ucloud::udisk::CHUNK_FAILURE_PEER_HEARTBEAT_TIMEOUT);
  failure_info_.insert(std::make_pair(chunk_id, failure_info));
}

void ManagerHandle::HeartbeatMetaServer() {
  std::string ip;
  int port;
  if (!GetMetaServerAddress(ip, port)) {
    ULOG_ERROR << "Get node of metaserver failed";
    return;
  }
  //检查IO线程hang错误
  CheckThreadActive();
  uevent::ConnectionUeventPtr conn = get_out_connection(ip, port);

  ucloud::UMessage msg;
  uint32_t obj_id = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&msg, flowno, base::MyUuid::NewUuid(),
                ucloud::udisk::HEARTBEAT_CHUNK_METASERVER_REQUEST,
                0, false, obj_id, 0, NULL, NULL, NULL);
  ucloud::udisk::HeartbeatChunkMetaServerRequest* req =
    msg.mutable_body()->MutableExtension(ucloud::udisk::heartbeat_chunk_metaserver_request);
  ucloud::udisk::ChunkStatInfoPb *stat = req->mutable_stat();
  uint64_t ver = 0;
  if (cluster_map_.IsInit()) {
    ver = cluster_map_.GetClusterVersion();
  }
  stat->set_cluster_version(ver);
  stat->set_id(g_context->config().my_id());
  stat->set_available_space(g_context->chunk_pool()->GetPoolRemainderCap());
  BuildFailureReportRequest(req);
  uevent::MessageUtil::SendPbRequest(conn, msg,
      std::bind(&ManagerHandle::HeartbeatMetaServerResponse, this, std::placeholders::_1),
      std::bind(&ManagerHandle::HearbeatMetaServerTimeout, this, flowno), 1.0);
  ULOG_DEBUG << "Heartbeat to Metaserver: " << ip << ":" << port
            << ", Msg: " << msg.DebugString();
}

void ManagerHandle::HeartbeatMetaServerResponse(const UMessagePtr& msg) {
  ucloud::udisk::HeartbeatChunkMetaServerResponse* res =
    msg->mutable_body()->MutableExtension(ucloud::udisk::heartbeat_chunk_metaserver_response);

  if (res->has_cluster_version() && (!cluster_map_.IsInit() ||
      cluster_map_.GetClusterVersion() < res->cluster_version())) {
    cluster_map_.Clear();
    UpdateClusterMap(res->cluster_info(), res->chunk_info(), res->pg_info());
    // 存在黑名单主机
    if (res->blacklist_hosts_size() != 0) {
      uint32_t refuse_seconds = 20; // 默认拒绝20s
      if (res->has_refuse_seconds()) {
        refuse_seconds = res->refuse_seconds();
      }
      AddBlacklist(res->blacklist_hosts(), refuse_seconds);
    }
  }
  if (res->has_pc_size()) {
    if (res->pc_size() != g_context->chunk_pool()->pc_size()) {
      ULOG_FATAL << "pc size is not same as metaserver";
    }
  }
}

void ManagerHandle::HearbeatMetaServerTimeout(uint32_t flowno) {
  ULOG_ERROR << "HearbeatMetaServerTimeout flowno=" << flowno;
}

void ManagerHandle::MigratePgFinishRequest(uint32_t lc_id, 
                                           uint32_t pg_id,
                                           std::string tyr_ip, 
                                           uint32_t tyr_port) {
  uevent::ConnectionUeventPtr conn = get_out_connection(tyr_ip, tyr_port);
  if (conn == nullptr) {
    ULOG_ERROR << "Get connection of metaserver failed";
    return;
  }
  ucloud::UMessage msg; 
  uint32_t obj_id = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&msg, flowno, base::MyUuid::NewUuid(),
                TYR_MIGRATE_PG_FINISH_REQUEST,
                0, false, obj_id, 0, NULL, NULL, NULL);
  TyrMigratePgFinishRequest* req =
    msg.mutable_body()->MutableExtension(tyr_migrate_pg_finish_request);
  req->set_lc_id(lc_id);
  req->set_pg_id(pg_id);
  uevent::MessageUtil::SendPbRequest(conn, msg,
      std::bind(&ManagerHandle::MigratePgFinishResponse, this, _1, lc_id, pg_id),
      std::bind(&ManagerHandle::AccessTyrTimeout, this, lc_id, pg_id, "MigratePgFinish"), 
      2.0);
  ULOG_INFO << "MigratePgFinishRequest=" << msg.DebugString();
}

void ManagerHandle::MigratePgFinishResponse(const UMessagePtr& msg, 
                                            uint32_t lc_id, uint32_t pg_id) {
  ULOG_INFO << msg->DebugString();
  const TyrMigratePgFinishResponse& res =
    msg->body().GetExtension(tyr_migrate_pg_finish_response);
  if (res.rc().retcode() != 0) { 
    ULOG_ERROR << "MigratePgFinish notify fail. ret=" << res.rc().retcode()
        << ",lc_id=" << lc_id << ",pg_id=" << pg_id;
    return;
  }
  ULOG_INFO << "MigratePgFinish notify succ. ret=" << res.rc().retcode()
      << ",lc_id=" << lc_id << ",pg_id=" << pg_id;
}

void ManagerHandle::UpdateMigrateProcess(
                            const journal::MigrateUDiskInfo udisk) {
  uevent::ConnectionUeventPtr conn = get_out_connection(udisk.tyr_ip, udisk.tyr_port);
  if (conn == nullptr) {
    ULOG_ERROR << "Get connection of metaserver failed";
    return;
  }
  ucloud::UMessage msg; 
  uint32_t obj_id = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&msg, flowno, base::MyUuid::NewUuid(),
                TYR_UPDATE_MIGRATE_PROCESS_REQUEST,
                0, false, obj_id, 0, NULL, NULL, NULL);
  TyrUpdateMigrateProcessRequest* req =
    msg.mutable_body()->MutableExtension(tyr_update_migrate_process_request);
  req->set_lc_id(udisk.lc_id);
  req->set_pg_id(udisk.pg_id);
  req->mutable_compact_process()->CopyFrom(udisk.compact_process);
  req->mutable_memtable_process()->CopyFrom(udisk.memtable_process);
  req->set_seqno(udisk.last_seqno);
  uevent::MessageUtil::SendPbRequest(conn, msg,
      std::bind(&ManagerHandle::UpdateMigrateProcessResponse, this, _1, 
                udisk.lc_id, udisk.pg_id),
      std::bind(&ManagerHandle::AccessTyrTimeout, this, udisk.lc_id, 
                udisk.pg_id, "UpdateMigrateProcess"), 2.0);
  ULOG_INFO << "UpdateMigrateProcess: udisk=" << udisk.ToString()
      << ", request=" << msg.DebugString();
}

void ManagerHandle::UpdateMigrateProcessResponse(const UMessagePtr& msg, 
                                          uint32_t lc_id, uint32_t pg_id) {
  ULOG_INFO << msg->DebugString();
  const TyrUpdateMigrateProcessResponse& res =
    msg->body().GetExtension(tyr_update_migrate_process_response);
  if (res.rc().retcode() != 0) { 
    ULOG_ERROR << "UpdateMigrateProcess fail. ret=" << res.rc().retcode()
        << ",lc_id=" << lc_id << ",pg_id=" << pg_id;
    return;
  }
  ULOG_INFO << "UpdateMigrateProcess succ. ret=" << res.rc().retcode()
      << ",lc_id=" << lc_id << ",pg_id=" << pg_id;
}

void ManagerHandle::MigrateJournalFailRequest(uint32_t lc_id,
                                              uint32_t pg_id,
                                              std::string& tyr_ip,
                                              uint32_t tyr_port) {
  uevent::ConnectionUeventPtr conn = get_out_connection(tyr_ip, tyr_port);
  if (conn == nullptr) {
    ULOG_ERROR << "Get connection of metaserver failed";
    return;
  }
  ucloud::UMessage msg; 
  uint32_t obj_id = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&msg, flowno, base::MyUuid::NewUuid(),
                TYR_MIGRATE_TASK_DESTROY_REQUEST,
                0, false, obj_id, 0, NULL, NULL, NULL);
  TyrMigrateTaskDestroyRequest* req =
    msg.mutable_body()->MutableExtension(tyr_migrate_task_destroy_request);
  req->set_lc_id(lc_id);
  uevent::MessageUtil::SendPbRequest(conn, msg,
      std::bind(&ManagerHandle::MigrateJournalFailResponse, this, _1, lc_id, pg_id),
      std::bind(&ManagerHandle::AccessTyrTimeout, this, lc_id, pg_id, "MigrateJournalFail"), 
      2.0);
  ULOG_INFO << "MigrateJournalFailRequest=" << msg.DebugString();
}

void ManagerHandle::MigrateJournalFailResponse(const UMessagePtr& msg,
                                               uint32_t lc_id, 
                                               uint32_t pg_id) {
  ULOG_INFO << msg->DebugString();
  const TyrMigrateTaskDestroyResponse& res =
    msg->body().GetExtension(tyr_migrate_task_destroy_response);
  if (res.rc().retcode() != 0) { 
    ULOG_ERROR << "MigrateJournalFail notify fail. ret=" << res.rc().retcode()
        << ",lc_id=" << lc_id << ",pg_id=" << pg_id;
    return;
  }
  ULOG_INFO << "MigrateJournalFail notify succ. ret=" << res.rc().retcode()
      << ",lc_id=" << lc_id << ",pg_id=" << pg_id;
}

void ManagerHandle::AccessTyrTimeout(uint32_t lc_id, uint32_t pg_id, 
                                     const std::string& task_tag) {
  ULOG_ERROR << "lc_id=" << lc_id << ",pg_id=" << pg_id << ", tag=" 
      << task_tag << " access tyr timeout.";
}

void ManagerHandle::UpdateClusterMap(const ucloud::udisk::ClusterInfoPb &cluster_info,
    const ::google::protobuf::RepeatedPtrField<::ucloud::udisk::ChunkInfoPb> &chunk_info,
    const ::google::protobuf::RepeatedPtrField<::ucloud::udisk::PGInfoPb> &pg_info) {
  cluster_map_.Init(cluster_info);
  for (auto i = chunk_info.begin(); i != chunk_info.end(); ++i) {
    cluster_map_.ChunkAdd(*i);
    if (uint32_t(g_context->config().my_id()) == i->id()) {
      CheckChunkUuid(*i);
    }
  }
  std::set<uint32_t> owner_pgs;
  for (auto i = pg_info.begin(); i != pg_info.end(); ++i) {
    cluster_map_.PGAdd(*i);
    for (uint32_t index = 0; index < (uint32_t)i->chunk_id_size(); ++ index) {
      if (g_context->config().my_id() == (int32_t)i->chunk_id(index)) {
        owner_pgs.insert(i->id());
      }
    }
  }

  NotifyIOLoopHandle(cluster_map_);
  NotifyRepairLoopHandle(cluster_map_);

  // 请求本chunk的组内成员
  partner_chunks_.clear();
}

bool ManagerHandle::CheckChunkUuid(const ucloud::udisk::ChunkInfoPb& my_chunk_info) {
  std::string chunk_uuid;
  if (g_context->config().storage_type() ==
                          UDiskConfig::kStorageTypeFile) {
    std::vector<std::string> vec;
    common::get_str_vec(g_context->config().chunk_dir(), "/", vec);
    chunk_uuid = vec[0];
  } else if (g_context->config().storage_type() == UDiskConfig::kStorageTypeRaw) {
    chunk_uuid = g_context->config().device_uuid();
  } else {
    return true;
  }

  if (chunk_uuid != my_chunk_info.uuid()) {
    ULOG_FATAL << "chunk uuid is diffrent, config uuid:" << chunk_uuid
               << ", db uuid:" << my_chunk_info.uuid();

    return false;
  }
  return true;
}

void ManagerHandle::AddBlacklist(
    const ::google::protobuf::RepeatedPtrField<std::string> &blacklist_hosts,
    uint32_t refuse_seconds) {
  for (auto i = blacklist_hosts.begin(); i != blacklist_hosts.end(); ++i) {
    ULOG_INFO << "add blacklist, ip: " << *i;
    g_context->io_listener()->AddSrcIpBlacklist(*i, refuse_seconds);
  }
}

void ManagerHandle::NotifyIOLoopHandle(const cluster::ClusterMap &map) {
  std::vector<uevent::EventLoop*> all_loops = g_context->io_listener()->GetAllLoops();
  for (size_t i = 0; i < all_loops.size(); ++i) {
    assert(all_loops[i]);
    ChunkLoopHandle *loop_handle = (ChunkLoopHandle*)all_loops[i]->GetLoopHandle();
    all_loops[i]->RunInLoop(
        std::bind(&ChunkLoopHandle::UpdateClusterMap, loop_handle, cluster_map_), true);
  }
}

void ManagerHandle::NotifyRepairLoopHandle(const cluster::ClusterMap &map) {
  RepairLoopHandle* repair_handle = g_context->repair_handle();
  repair_handle->uevent_loop()->RunInLoop(
        std::bind(&RepairLoopHandle::UpdateClusterMap, repair_handle, cluster_map_), true);
}

void ManagerHandle::ReportChunkFailure(uint32_t chunk_id,
                                       int32_t retcode) {
  man_loop_->RunInLoop(
      std::bind(&ManagerHandle::ReportChunkFailureInLoop,
      this, chunk_id, retcode), true);
}

void ManagerHandle::ClearUDiskStats(const std::string& thread_name) {
  man_loop_->RunInLoop(
      std::bind(&ManagerHandle::ClearUDiskStatsInLoop, this, thread_name), true);
}

void ManagerHandle::ClearUDiskStatsInLoop(const std::string& thread_name) {
  auto found = thread_udisk_io_count_.find(thread_name);
  if (found != thread_udisk_io_count_.end()) {
    thread_udisk_io_count_.erase(found);
  }
}

void ManagerHandle::ReportThreadIOCount(uint64_t r_byteps, uint64_t r_iops,
                                        uint64_t r_io_latency_max, uint64_t r_io_latency_avg,
                                        uint64_t w_byteps, uint64_t w_iops,
                                        uint64_t w_io_latency_max, uint64_t w_io_latency_avg,
                                        const std::string &thread_name) {
  man_loop_->RunInLoop(
      std::bind(&ManagerHandle::ReportThreadIOCountInLoop,
      this,
      r_byteps, r_iops, r_io_latency_max, r_io_latency_avg,
      w_byteps, w_iops, w_io_latency_max, w_io_latency_avg,
      thread_name), true);
}

void ManagerHandle::ReportUDiskIOCount(uint32_t lc_id, uint32_t lc_size,
                                       uint32_t io_depth, uint32_t io_depth_limit,
                                       uint64_t r_iops, uint64_t w_iops,
                                       uint64_t r_bw, uint64_t w_bw,
                                       const std::string& thread_name) {
  man_loop_->RunInLoop(
      std::bind(&ManagerHandle::ReportUDiskIOCountInLoop,
      this, lc_id, lc_size, io_depth, io_depth_limit, r_iops, w_iops, r_bw, w_bw,
      thread_name), true);
}

void ManagerHandle::ReportUDiskIOCountInLoop(uint32_t lc_id, uint32_t lc_size,
                                             uint32_t io_depth, uint32_t io_depth_limit,
                                             uint64_t r_iops, uint64_t w_iops,
                                             uint64_t r_bw, uint64_t w_bw,
                                             const std::string& thread_name) {
  ucloud::udisk::ChunkUDiskIOStat lc_stat;
  lc_stat.set_lc_id(lc_id);
  lc_stat.set_lc_size(lc_size);
  lc_stat.set_io_depth(io_depth);
  lc_stat.set_io_depth_limit(io_depth_limit);
  lc_stat.set_thread_name(thread_name);
  lc_stat.set_r_iops(r_iops);
  lc_stat.set_w_iops(w_iops);
  lc_stat.set_r_bw(r_bw);
  lc_stat.set_w_bw(w_bw);

  std::map<uint32_t, ucloud::udisk::ChunkUDiskIOStat>& lc_stat_map =
      thread_udisk_io_count_[thread_name];
  // 在report之前已经清空过过这个线程的map, 所以这里一定能够插入成功
  lc_stat_map.insert(std::make_pair(lc_id, lc_stat));
}

void ManagerHandle::ReportThreadIOCountInLoop(uint64_t r_byteps, uint64_t r_iops,
                                              uint64_t r_io_latency_max, uint64_t r_io_latency_avg,
                                              uint64_t w_byteps, uint64_t w_iops,
                                              uint64_t w_io_latency_max, uint64_t w_io_latency_avg,
                                              const std::string& thread_name) {
 ULOG_DEBUG<<" thread_name:"<<thread_name
          << ",r_iops: " << r_iops
          << " w_iops: " << w_iops
          << ",r_byteps: " << r_byteps
          << " w_byteps: " << w_byteps
          << ",r_io_latency_max: " << r_io_latency_max
          << " w_io_latency_max: " << w_io_latency_max
          << ",r_io_latency_avg: " << r_io_latency_avg
          << " w_io_latency_avg: " << w_io_latency_avg;
  auto found = thread_io_count_.find(thread_name);
  if (found == thread_io_count_.end()) {
    ThreadIOCount info(r_byteps, r_iops,
                       r_io_latency_max,
                       r_io_latency_avg,
                       w_byteps, w_iops,
                       w_io_latency_max,
                       w_io_latency_avg);
    thread_io_count_.insert(std::make_pair(thread_name, info));
  } else {
    found->second.r_iops = r_iops;
    found->second.w_iops = w_iops;
    found->second.r_byteps = r_byteps;
    found->second.w_byteps = w_byteps;
    found->second.r_io_latency_max = r_io_latency_max;
    found->second.r_io_latency_avg = r_io_latency_avg;
    found->second.w_io_latency_max = w_io_latency_max;
    found->second.w_io_latency_avg = w_io_latency_avg;
  }
}

void ManagerHandle::ReportChunkFailureInLoop(uint32_t chunk_id,
                                             int32_t  retcode) {
  ucloud::udisk::CHUNK_FAILURE_TYPE failure_type;
  switch (retcode) {
    case common::RETCODE_AIO_ERR:
      failure_type = ucloud::udisk::CHUNK_FAILURE_AIO_ERR;
      break;
    case common::RETCODE_AIO_WRITE_TIMEOUT:
      failure_type = ucloud::udisk::CHUNK_FAILURE_AIO_WRITE_TIMEOUT;
      break;
    case common::RETCODE_AIO_READ_TIMEOUT:
      failure_type = ucloud::udisk::CHUNK_FAILURE_AIO_READ_TIMEOUT;
      break;
    case common::RETCODE_REPLICA_TIMEOUT:
      failure_type = ucloud::udisk::CHUNK_FAILURE_REPLICA_TIMEOUT;
      break;
    case common::RETCODE_THREAD_HANG_ERR:
      failure_type = ucloud::udisk::CHUNK_FAILURE_THREAD_HANG;
      break;
    default:
      ULOG_ERROR << "unkonw retcode from chunk: " << chunk_id
                << " retcode: " << retcode;
      return;
  }
  auto it = failure_info_.find(chunk_id);
  if (it != failure_info_.end()) {
    it->second.set_type(failure_type);
  } else {
    ucloud::udisk::ChunkFailureInfoPb info;
    info.set_id(chunk_id);
    info.set_type(failure_type);
    failure_info_[chunk_id] = info;
  }
}

void ManagerHandle::BuildFailureReportRequest(ucloud::udisk::HeartbeatChunkMetaServerRequest *req) {
  for (auto it = failure_info_.begin(); it != failure_info_.end();) {
    ucloud::udisk::ChunkFailureInfoPb *cfi= req->add_failure_info();
    *cfi = it->second;
    failure_info_.erase(it++);
  }
}

void ManagerHandle::UpdateLCIODepthLimit(uint32_t lc_id, int io_depth_limit) {
  std::vector<uevent::EventLoop*> all_loops = g_context->io_listener()->GetAllLoops();
  for (size_t i = 0; i < all_loops.size(); ++i) {
    assert(all_loops[i]);
    ChunkLoopHandle *loop_handle = (ChunkLoopHandle*)all_loops[i]->GetLoopHandle();
    all_loops[i]->RunInLoop(
        std::bind(&ChunkLoopHandle::UpdateUDiskIODepthLimit, loop_handle, lc_id, io_depth_limit),
        true);
  }
  g_context->detection_handle()->NotifyIODepthModify((uint32_t)io_depth_limit);
}

void ManagerHandle::DispatchIOInLoopMode(uint32_t io_depth_limit) {
  std::vector<uevent::EventLoop*> all_loops = g_context->io_listener()->GetAllLoops();
  for (size_t i = 0; i < all_loops.size(); ++i) {
    assert(all_loops[i]);
    ChunkLoopHandle *loop_handle = (ChunkLoopHandle*)all_loops[i]->GetLoopHandle();
    all_loops[i]->RunInLoop(
        std::bind(&ChunkLoopHandle::DispatchIOInLoopMode, loop_handle, io_depth_limit),
        true);
  }
}

void ManagerHandle::MigrateUDisk(uint32_t lc_id, const std::string &thread_name) {
  std::vector<uevent::EventLoop*> all_loops = g_context->io_listener()->GetAllLoops();
  for (size_t i = 0; i < all_loops.size(); ++i) {
    assert(all_loops[i]);
    if (all_loops[i]->worker()->name() == thread_name) {
      ChunkLoopHandle *loop_handle = (ChunkLoopHandle*)all_loops[i]->GetLoopHandle();
      all_loops[i]->RunInLoop(
          std::bind(&ChunkLoopHandle::MigrateUDisk, loop_handle, lc_id),
          true);
    }
  }
}

uevent::ConnectionUeventPtr ManagerHandle::get_out_connection(
    const std::string &ip, int port) {
  UsockAddress addr(ip, port, false);
  uint64_t conn_id = (static_cast<int64_t>(addr.IpNetEndian()) << 16) |
                     addr.PortNetEndian();
  auto found = out_connectors_.find(conn_id);
  if (found != out_connectors_.end()) {
    if (found->second->HasAvailableConnection()) {
      return found->second->GetConnection();
    } else {
      return uevent::ConnectionUeventPtr(); 
    }
  }
  std::stringstream ss;
  ss << "connector-" << ip << ":" << port;
  ConnectorUeventPtr connector =
    std::make_shared<uevent::ConnectorLibevent>(
        static_cast<uevent::PosixWorker*>(man_loop_->worker()), addr, ss.str());
  connector->SetConnectionSuccessCb(
      std::bind(&ManagerHandle::OutConnectionSuccessHandle, this, std::placeholders::_1));
  connector->SetConnectionClosedCb(
      std::bind(&ManagerHandle::OutConnectionCloseHandle, this, std::placeholders::_1, conn_id));
  connector->SetMessageReadCb(
      std::bind(&uevent::MessageUtil::ProtobufReadCallBack, std::placeholders::_1));
  connector->Connect();
  out_connectors_.insert(std::make_pair(conn_id, connector));

  return connector->GetConnection();
}

void ManagerHandle::ReportLCIOError(
    const IOErrorContainer::LCIOErrorMap& lc_io_errors) {
  man_loop_->RunInLoop(std::bind(&ManagerHandle::ReportLCIOErrorInLoop,
                       this, lc_io_errors), true);
}

void ManagerHandle::ReportLCIOErrorInLoop(
    const IOErrorContainer::LCIOErrorMap& lc_io_errors) {
  io_error_container_.Add(lc_io_errors);
}

void ManagerHandle::ReportThreadInfo(
    pid_t thread_id, const std::string& thread_name) {
  man_loop_->RunInLoop(std::bind(&ManagerHandle::ReportThreadInfoInLoop,
                       this, thread_id, thread_name));
}

void ManagerHandle::ReportThreadInfoInLoop(
    pid_t thread_id, const std::string& thread_name) {
  ULOG_DEBUG << "receive heartbeat message from " << thread_id << "\t" << thread_name;
  // 接收到线程心跳信息，更新对应线程记录
  auto it = thread_heartbeat_info_.find(thread_id);
  if (it == thread_heartbeat_info_.end()) {
    ThreadHeartbeatInfo info(thread_name, base::Timestamp::now().secondsSinceEpoch(), 0);
    thread_heartbeat_info_.insert(std::make_pair(thread_id, info));
    return;
  }
  time_t current_time = base::Timestamp::now().secondsSinceEpoch();
  it->second.last_time = it->second.current_time;
  it->second.current_time = current_time;
  return;
}

//检查IO线程状态,若干个心跳周期内未收到心跳信息，则认为线程异常，记录错误
void ManagerHandle::CheckThreadActive() {
  time_t current_time = base::Timestamp::now().secondsSinceEpoch();
  for (auto it = thread_heartbeat_info_.begin(); it != thread_heartbeat_info_.end(); it++) {
    ULOG_DEBUG << it->first << "\t" << it->second.thread_name << "\t"
              << it->second.current_time << "\t" << it->second.last_time;
    if (current_time - it->second.current_time > kThreadHeartbeatTimeout) {
      ULOG_WARN << "thread:[" << it->first << " : "<< it->second.thread_name 
               << "], not report heartbeat. current_time: "
               << it->second.current_time << ", last_time:" << it->second.last_time;
      ReportChunkFailure(g_context->config().my_id(), common::RETCODE_THREAD_HANG_ERR);
    }
  }
}

