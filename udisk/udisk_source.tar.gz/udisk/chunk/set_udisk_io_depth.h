#ifndef UDISK_CHUNK_SET_UDISK_IO_DEPTH_H_
#define UDISK_CHUNK_SET_UDISK_IO_DEPTH_H_

#include <ustevent/pb_request_handle.h>
#include "udisk_message.h"

namespace udisk {
namespace chunk {
 
class SetUDiskIODepthHandle: public uevent::PbRequestHandle {
 public:
  explicit SetUDiskIODepthHandle(uevent::EventLoop* loop) {}
  virtual ~SetUDiskIODepthHandle() {}
  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         const uevent::UMessagePtr& um);
  MYSELF_CREATE(SetUDiskIODepthHandle);
   
 private:
  static int type_;
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage response_;
  ucloud::udisk::ChunkSetUDiskIODepthResponse* resp_body_;
};

}
}

#endif

