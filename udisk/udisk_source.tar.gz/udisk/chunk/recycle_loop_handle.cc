#include <sstream>
#include <string>
#include <deque>
#include <unistd.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <malloc.h>
#include <ustevent/base/logging.h>
#include <ustevent/message_util.h>
#include "chunk_context.h"
#include "udisk_message.h"
#include "umessage_common.h"
#include "udisk_types.h"
#include "recycle_pc.h"
#include "chunk_storage.h"
#include "recycle_loop_handle.h"
#include "create_chunk_storage.h"


namespace udisk {
namespace chunk {

// 每次回收1M
const static uint32_t kBytesPerTime = (1 << 20);

RecycleLoopHandle::RecycleLoopHandle(): token_bucket_(g_context->config().recycle_rate(),
                                          g_context->config().recycle_rate()), slab_(kBytesPerTime, 128) {
  recycle_thread_ = nullptr;
  recycle_loop_ = nullptr;

  chunk_storage_ = CreateChunkStorage();
  assert(chunk_storage_ != nullptr);
}

void RecycleLoopHandle::Start() {
  uevent::Option option;
  option.enable_aio = true;
  recycle_thread_ = new uevent::WorkerThread("RecycleThread", nullptr, option);
  recycle_loop_ = recycle_thread_->StartWorker()->eventloop();

  g_context->set_recycle_loop(recycle_loop_);
  g_context->set_recycle_handle(this);
  chunk_storage_->Init(g_context->chunk_pool(), recycle_loop_);
  recycle_loop_->RunEvery(g_context->config().heartbeat_chunk_interval(),
    std::bind(&RecycleLoopHandle::ReportLCIOError, this));
}

void RecycleLoopHandle::RecyclePC(const ChunkID& chunkID, const std::shared_ptr<RecyclePCHandle>& ptr) {
  int rc = FormatPC(chunkID, ptr);
  std::string error_msg = "";
  if (rc != UDISK_OK) {
    if (rc == UDISK_PC_NOT_EXIST_ERROR)  {
      // pc 不存在不作为一种错误
      ULOG_INFO << "recycle pc success. chunkID: " << chunkID.to_string();

      // TODO(fangran.fr) 统一错误码
      rc = 0;
    }
    else {
      ULOG_ERROR << "recycle pc error. chunkID: " << chunkID.to_string();

      // TODO(fangran.fr) 统一错误码
      rc = -1;
      error_msg = "format pc error";
    }
    g_context->man_listen_loop()->RunInLoop(std::bind(
          &RecyclePCHandle::EntryRecyclePC, ptr, rc, error_msg));
  }
}

int RecycleLoopHandle::FormatPC(const ChunkID& chunkID,
                                 const std::shared_ptr<RecyclePCHandle>& ptr) {
  OpenChunkCb cb = std::bind(&RecycleLoopHandle::OpenChunkResCb, this,
                    std::placeholders::_1, std::placeholders::_2, chunkID, ptr);
  int32_t ret = chunk_storage_->OpenChunk(chunkID, false, cb);
  if (ret == UDISK_PC_NOT_EXIST_ERROR) {
    ULOG_INFO << "this pc not exist "
        << chunkID.to_string();
    return UDISK_PC_NOT_EXIST_ERROR;
  }
  if (ret != UDISK_OK) {
      ULOG_ERROR << "Open Chunk Fail when format pc"
                << chunkID.to_string()
                << "return code: "
                << ret;
      // TODO(fangran.fr) add error code
      return -1;
  }

  return UDISK_OK;
}

int RecycleLoopHandle::MovePCToPool(const ChunkID& chunkID,
                                    const std::shared_ptr<RecyclePCHandle>& ptr) {
  ChunkOpCb cb = std::bind(&RecycleLoopHandle::PutChunkResCb, this,
                           std::placeholders::_1, chunkID, ptr);
  int32_t ret = g_context->chunk_pool()->PutChunk(chunkID, cb, recycle_loop_);
  if (ret == UDISK_OK) {
    return 0;
  }
  else {
    return -3;
  }
}

void RecycleLoopHandle::ReportLCIOError() {
  if (io_error_container_.IsEmpty()) {
    return;
  }

  g_context->manager_handle()->ReportLCIOError(io_error_container_.lc_io_errors());
  io_error_container_.Clear();
}

void RecycleLoopHandle::OpenChunkResCb(int retcode, ChunkHandle* handle,
                                        const ChunkID& chunkID,
                                        const std::shared_ptr<RecyclePCHandle>& ptr) {
  int rc = 0;
  std::string error_msg = "";
  if (retcode != UDISK_OK) {
    io_error_container_.Add(chunkID.lc_id, IOErrorContainer::kRecycleIOError,
                             IOErrorContainer::kIOWrite);
    rc = -1;
    error_msg = "format pc error";
    g_context->man_listen_loop()->RunInLoop(std::bind(
          &RecyclePCHandle::EntryRecyclePC, ptr, rc, error_msg));
    return;
  }
  auto buf = slab_.Malloc();
  assert(buf != nullptr);
  ::memset(buf, '\0', kBytesPerTime);

  uint64_t offset = 0;
  for (uint32_t i = 0; i < g_context->chunk_pool()->pc_size() / kBytesPerTime; i++) {
    while(!token_bucket_.grant(1)) {
      ULOG_INFO << "No token left, wait for 20 ms...";
      ::usleep(20000);
    }
    // set PWrite CallBack to nullptr so this is a SYNC PWrite
    int32_t ret = handle->PWrite((void*)buf, kBytesPerTime, offset);
    if (ret != UDISK_OK) {
      io_error_container_.Add(chunkID.lc_id, IOErrorContainer::kRecycleIOError,
                              IOErrorContainer::kIOWrite);
      ULOG_SYSERR << "write file error "
               << chunkID.to_string();
      rc = -1;
      error_msg = "format pc error";
      g_context->man_listen_loop()->RunInLoop(std::bind(
            &RecyclePCHandle::EntryRecyclePC, ptr, rc, error_msg));
      return;
    }
    offset += kBytesPerTime;
  }
  slab_.Free(buf);
  chunk_storage_->CloseChunk(handle);

  rc = MovePCToPool(chunkID, ptr);
  if (rc != 0) {
    ULOG_ERROR << "move pc to pool error.chunkID: " << chunkID.to_string();
    g_context->man_listen_loop()->RunInLoop(std::bind(
                                    // TODO(fangran.fr) 统一错误码
                                    &RecyclePCHandle::EntryRecyclePC, ptr, -3,
                                    "move pc to pool error"));
  }
}

void RecycleLoopHandle::PutChunkResCb(int retcode, const ChunkID& chunkID,
                                     const std::shared_ptr<RecyclePCHandle>& ptr) {
  if (retcode != UDISK_OK) {
    ULOG_ERROR << "move pc to pool error.chunkID: " << chunkID.to_string();
    g_context->man_listen_loop()->RunInLoop(std::bind(
                                    &RecyclePCHandle::EntryRecyclePC, ptr, -3,
                                    "move pc to pool error"));
  }
  else {
    ULOG_INFO << "recycle pc success.chunkID: " << chunkID.to_string();
    g_context->man_listen_loop()->RunInLoop(std::bind(
                                   &RecyclePCHandle::EntryRecyclePC, ptr, 0, ""));
  }
}

}; // end of chunk
}; // end of udisk
