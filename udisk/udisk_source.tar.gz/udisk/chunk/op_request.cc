#include "op_request.h"
#include <ustevent/base/logging.h>
#include "likely.h"
#include "chunk_context.h"

namespace udisk {
namespace chunk {

int OpRequest::IncTimerCount() {
  ++timer_count_;
  if (timer_count_ >= g_context->config().io_timer_count() && !timeout()) {
    return 1;
  }
  return 0;
}

OpRequest::~OpRequest() {
  ULOG_DEBUG << "op release,seqno=" << op_seq_ << ",msg_hdr=" << msg_hdr_;
  if (msg_data_) {
    if (DecMsgDataRef()) { // MIGRATE_MEMTABLE直接使用memtable中内存，由memtable管理
      mem_pool_->Free((void*)msg_data_, mem_slab_);
    }
  }
  if (read_buffer_) {
    mem_pool_->Free((void*)read_buffer_, mem_slab_);
  }
  if (mem_buffer_) {
    assert(mem_buf_slab_);
    mem_pool_->Free((void*)mem_buffer_, mem_buf_slab_);
  }
  if (msg_hdr_) {
    msg_header_slab_->Free((void*)msg_hdr_);
  }
}

void OpRequest::TimeoutCb(bool dispatched) {
  ULOG_ERROR << "op request timeout, " << trace_tag();
  set_timeout(true);
  // 如果触发超时不可能所有的位都收到回复
  // 如果收到全部，会从inflight 中移除，不会出触发超时回调
  // assert(!replicas_bit_set_.none()); //pending队列中也可能超时
  if (UNLIKELY(replica_chunk_ids_.size() < 1)) {
    ULOG_FATAL << "replica num invalid, " << replica_chunk_ids_.size();
    return;
  }
  // io未下发按主副本超时处理
  if (!dispatched || replicas_bit_set_[0] == true) {
    int err_type = common::RETCODE_AIO_WRITE_TIMEOUT;
    switch (msg_hdr_->msg_type) {
      case common::MSG_GATE_IO_REQ: {
        const common::GateIORequestHead *hdr =
          (const common::GateIORequestHead*)sub_msg_hdr_offset();
        if (hdr->cmd == common::GATE_CMD_READ) {
          err_type = common::RETCODE_AIO_READ_TIMEOUT;
        }
        break;
      }
      case common::MSG_ARK_IO_REQ: {
        const common::ArkIORequestHead *hdr =
          (const common::ArkIORequestHead*)sub_msg_hdr_offset();
        if (hdr->cmd == common::ARK_CMD_READ) {
          err_type = common::RETCODE_AIO_READ_TIMEOUT;
        }
        break;
      } 
      case common::MSG_CHUNK_IO_REQ: {
        const common::ChunkIORequestHead *hdr =
          (const common::ChunkIORequestHead*)sub_msg_hdr_offset();
        if (hdr->cmd == common::CHUNK_CMD_READ) {
          err_type = common::RETCODE_AIO_READ_TIMEOUT;
        }
        break;
      }
      // Hela
      case common::MSG_HELA_CHUNK_REQ: {
        const common::HelaChunkRequestHead *hdr =
          (const common::HelaChunkRequestHead*)sub_msg_hdr_offset();
        if (hdr->cmd == common::HELA_CMD_READ) {
          err_type = common::RETCODE_AIO_READ_TIMEOUT;
        }
      }
      default:
        // do nothing
        break;
    }
    ULOG_ERROR << "local aio timeout, type=" << err_type
              << ", dispatched=" << dispatched;
    replicas_retcode_ |= err_type;
    g_context->manager_handle()->ReportChunkFailure(
      replica_chunk_ids_[0], err_type);
  }
  for (uint32_t i = 1; i < replica_chunk_ids_.size(); i++) {
    if (replicas_bit_set_[i] == true) {
      ULOG_ERROR << "replica chunk timeout, chunk id: "
                << replica_chunk_ids_[i];
      g_context->manager_handle()->ReportChunkFailure(
          replica_chunk_ids_[i], common::RETCODE_REPLICA_TIMEOUT);
      replicas_retcode_ |= (common::RETCODE_REPLICA_TIMEOUT << (i * 8));
    }
  }  
}

std::string OpRequest::trace_tag() const {
  std::stringstream ss;
  ss << "OpRequestTag-op_seq: " << op_seq_ << ",type: " 
     << common::msg_type_name(msg_hdr_->msg_type);
  switch (msg_hdr_->msg_type) {
    case common::MSG_GATE_IO_REQ: {
      const common::GateIORequestHead *hdr =
          (const common::GateIORequestHead*)sub_msg_hdr_offset();
      ss << "{" << FormatGateIOReq(*hdr) << "}";
      break;
    }
    case common::MSG_CHUNK_IO_REQ: {
      const common::ChunkIORequestHead *hdr =
          (const common::ChunkIORequestHead*)sub_msg_hdr_offset();
      ss << "{" << FormatChunkIOReq(*hdr) << "}";
      break;
    }
    case common::MSG_CHUNK_IO_RES: {
      const common::ChunkIOResponseHead *hdr =
          (const common::ChunkIOResponseHead*)sub_msg_hdr_offset();
      ss << "{" << FormatChunkIORes(*hdr) << "}";
      break;
    }
    case common::MSG_CHUNK_REPAIR_REQ:
    case common::MSG_CHUNK_REPAIR_RES: {
      const common::ChunkRepairHead *hdr =
          (const common::ChunkRepairHead*)sub_msg_hdr_offset();
      ss << "{" << DumpChunkRepairHead(*hdr) << "}";
      break;
    }
    case common::MSG_ARK_IO_REQ: {
      const common::ArkIORequestHead *hdr =
          (const common::ArkIORequestHead*)sub_msg_hdr_offset();
      ss << "{" << DumpArkReqHead(*hdr) << "}";
      break;
    }
    case common::MSG_ARK_IO_RES: {
      const common::ArkIOResponseHead *hdr =
          (const common::ArkIOResponseHead*)sub_msg_hdr_offset();
      ss << "{" << DumpArkResHead(*hdr) << "}";
      break;
    }
    case common::MSG_MIGRATE_JOURNAL_REQ:
    case common::MSG_MIGRATE_JOURNAL_RES: {
      const common::MigrateHead *hdr =
          (const common::MigrateHead*)sub_msg_hdr_offset();
      ss << "{" << DumpMigrateHead(*hdr) << "}";
      break;
    }
    // Hela
    case common::MSG_HELA_CHUNK_REQ: {
      const common::HelaChunkRequestHead *hdr =
        (const common::HelaChunkRequestHead*)sub_msg_hdr_offset();
      ss << "{" << DumpHelaReqHead(*hdr) << "}";
      break;
    }
    case common::MSG_HELA_CHUNK_RES: {
      const common::HelaChunkResponseHead *hdr =
        (const common::HelaChunkResponseHead*)sub_msg_hdr_offset();
      ss << "{" << DumpHelaResHead(*hdr) << "}";
      break;
    }
    default:
      // nerver to here
      assert(false);
      break;
    }
    return ss.str();
  }

} // namespace chunk
} // namespace udisk
