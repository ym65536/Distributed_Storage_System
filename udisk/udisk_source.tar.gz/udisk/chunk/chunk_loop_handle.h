#ifndef UDISK_CHUNK_LOOP_HANDLE_H_
#define UDISK_CHUNK_LOOP_HANDLE_H_

#include <unordered_map>
#include <functional>

#include <ustevent/libevent/listener_libevent.h>
#include <ustevent/libevent/eventloop_libevent.h>
#include <ustevent/libevent/connector_libevent.h>
#include <ustevent/disk_io_util.h>
#include <ustevent/base/obj_pool.h>
#include "op_request.h"
#include "udisk_handle.h"
#include "udisk_types.h"
#include "cluster_map.h"
#include "cluster_hash_ring.h"
#include "chunk_begin_repair.h"
#include "migrate_manager.h"
#include "chunk_storage.h"
#include "io_error_container.h"
#include "pool/memory_pool.h"

namespace udisk {

namespace journal {
  class PGJournalMeta;
  class JournalEngine;
}

namespace chunk {

class ChunkStorage;
class UDiskHandle;
class OpRequest; 

class ChunkLoopHandle : public uevent::LoopHandle {
 public:
  struct ChunkRouteEntry {
    uint32_t chunk_id;
    uint32_t primary_chunk_id;
    uevent::ConnectorUeventPtr ctor;
  };

  struct PgRouteEntry {
    PgRouteEntry(): version(0) {}  
    uint64_t version;
    std::vector<ChunkRouteEntry> chunk_routes;
  };

  explicit ChunkLoopHandle(uevent::EventLoop* loop);
  virtual ~ChunkLoopHandle();

  static uevent::LoopHandle* CreateMyself(uevent::EventLoop* loop) {
      return new ChunkLoopHandle(loop);
  }

  static void ConnectionSuccessHandle(const uevent::ConnectionUeventPtr& conn);

  static void ConnectionClosedHandle(const uevent::ConnectionUeventPtr& conn);

  static void MessageReadHandle(const uevent::ConnectionUeventPtr& conn);

  static void MessageWriteHandle(const uevent::ConnectionUeventPtr& conn);

  // 因为回调时udisk_handle 可能会被析构，所以不适合作为udisk_handle的成员函数
  static void LocalAioCb(int retcode, void* arg);

  // 因为回调时udisk_handle 可能会被析构，所以不适合作为udisk_handle的成员函数
  void OpenChunkResCb(int retcode, ChunkHandle* ch, uint32_t lc_id, uint64_t op_seq);

  void OutConnectionSuccessHandle(const uevent::ConnectionUeventPtr& conn);

  void OutConnectionCloseHandle(const uevent::ConnectionUeventPtr& conn);

  ChunkStorage* GetChunkStorage() {
    return chunk_storage_;
  }

  uint64_t get_next_op_seq(uint32_t pg_id);

  uint32_t my_chunk_id() const {
    return my_chunk_id_;
  }

  void HandleRequest(OpRequest &op);

  void HandleGateRequest(OpRequest &op);

  void HandleChunkRequest(OpRequest &op);

  void HandleChunkResponse(OpRequest &op);
 
  uevent::ConnectorUeventPtr get_out_connector(const uevent::UsockAddress& addr);

  void DestroyChunkConnection(int64_t conn_id);

  void ArkConnectionSuccessHandle(const uevent::ConnectionUeventPtr& conn);

  void ArkConnectionCloseHandle(const uevent::ConnectionUeventPtr& conn);

  uevent::ConnectionUeventPtr GetArkConnection(const uevent::UsockAddress& addr);
  
  // 这里传值是因为其会有不同的线程而执行RunInLoop
  void UpdateClusterMap(cluster::ClusterMap map);

  void DispatchIOInLoopMode(uint32_t io_depth_limit);
  void UpdateUDiskIODepthLimit(uint32_t lc_id, int io_depth_limit);
  void MigrateUDisk(uint32_t lc_id);

  void RepairPCStartNotify(uint32_t pg_id, PhysicalChunkSet pcs);
  void RepairPCMergeNotify(uint32_t lc_id, uint32_t lc_size, uint32_t pc_no);
  void RepairPCFinishNotify(uint32_t lc_id, uint32_t lc_size, uint32_t pc_no);
 
  const cluster::ClusterMap& cluster_map() const {
    return cluster_map_;
  }

  void set_cluster_map(const cluster::ClusterMap &map) {
    cluster_map_ = map;
  }

  MemoryPool &mem_pool() { return mem_pool_;}
  base::ObjPool<OpRequest>& op_pool() { return op_pool_; }
  MemorySlab& msg_header_slab() { return msg_header_slab_; }

  int GetPgRoute(uint32_t pg_id, uint64_t version, std::vector<ChunkRouteEntry>** ctors);

  int GetHelaPgRoute(uint32_t pg_id, uint64_t version, std::vector<ChunkRouteEntry>** ctors);
  
  UDiskHandle* LookupUDiskHandle(uint32_t lc_id, uint32_t lc_random_id, 
      uint32_t lc_size, bool create);

  void DispatchNextPendingIO(UDiskHandle* udisk_handle);
  bool IsLoopDispatchIO() {return dispatch_io_state_ == kLoopDispatchIoStateOn;
  }

  uint32_t dispatch_io_cur_total() const {
    return dispatch_io_cur_total_;
  }

  uint32_t CurrentIODepthTotalInc() {
    return ++dispatch_io_cur_total_;
  }

  uint32_t dispatch_io_depth() const {
    return dispatch_io_depth_;
  }

  void AddLCIOError(uint32_t lc_id, 
                    IOErrorContainer::IO_ERROR_TYPE error_type, 
                    IOErrorContainer::IO_OP_TYPE op_type); 
  
  // journal 相关
  journal::JournalEngine* JournalEngine(uint32_t pg_id) {
    assert(pg_id < MAX_PG_NUM);
    return journal_engine_[pg_id];
  }
  void JournalRecover(const std::vector<journal::PGJournalMeta*> journal_metas);
  void JournalSwapMemTableReq(uevent::EventLoop* src_loop, uint32_t pg_id);
  void JournalSwapMemTableRes(uevent::EventLoop* src_loop,
                              uint32_t jpc_id, 
                              uint32_t pg_id);
  void ClearJournalOpRequestByConnId(int64_t conn_id);
  void JournalTimerCb();

  int MigrateJournalRequest(OpRequest* op, 
                            const IOMeta& meta,
                            uint32_t pg_id,
                            uint32_t lc_size,
                            const ucloud::udisk::MigratePcMeta& migrate_pc); 
  void ReplicaRemoteRequest(OpRequest* op);
  void ReplicaRemoteResponse(const common::MigrateHead* hdr);

  MigrateManager* migrate_manager() {
    return migrate_manager_;
  }

 private:
  void IOTimerCb();
  void IoReportTimerCb();
  void RecycleUDiskHandleTimerCb();

  void ClientDisconnection(uint32_t conn_id);

  void HandleMessage(common::MessageHeader *msg_hdr,
                       char *msg_data,
                       const uevent::ConnectionUeventPtr &conn,
                       MemorySlab *slab);

  static bool DecodeMsg(const uevent::ConnectionUeventPtr &conn,
                         uint8_t msg_type,
                         common::MessageHeader **hdr,
                         char **data,
                         MemorySlab **slab);

  void ClearUDiskOpRequstByConnId(int64_t conn_id);

  void AddUDiskHandle(UDiskHandle* handle);
  UDiskHandle* DeleteUDiskHandle(UDiskHandle* handle,
                                 UDiskHandle* prev = nullptr);
  void ReportLCIOError();
  void FreeMsg(common::MessageHeader *msg_hdr, char *msg_data, MemorySlab *slab);
  void ManagerHeartbeatTimerCb();

  uint64_t last_op_seq_;

  std::vector<UDiskHandle*> udisks_;
  std::unordered_map<uint64_t, const uevent::ConnectionUeventPtr> conns_;

  ChunkStorage* chunk_storage_;
  uint32_t my_chunk_id_;
  std::unordered_map<uint64_t, uevent::ConnectorUeventPtr> chunk_connector_map_;
  std::unordered_map<uint64_t, uevent::ConnectorUeventPtr> ark_connector_map_;
  std::vector<PgRouteEntry> pg_route_cache_;
  std::vector<PgRouteEntry> hela_pg_route_cache_;

  cluster::ClusterMap cluster_map_;

  uevent::TimerId io_report_timer_;
  int io_report_interval_;

  enum {
    kLoopDispatchIoStateOff,    // 线性派发io模式关闭
    kLoopDispatchIoStateOn,     // 线性派发io模式开启
  } dispatch_io_state_;
  uint32_t dispatch_io_depth_;
  UDiskHandle* head_; // 连接UDiskHandle的链表表头 
  UDiskHandle* tail_; // 连接UDiskHandle的链表表尾 
  int64_t dispatch_io_cur_total_;
  MigrateManager* migrate_manager_;
  
  // journal相关
  journal::JournalEngine* journal_engine_[MAX_PG_NUM] = {nullptr};
  // 用于遍历,只在初始化和timer中调用
  std::vector<journal::JournalEngine*> engine_list_;

  // io 读写错误统计 
  IOErrorContainer io_error_container_;
  base::ObjPool<OpRequest> op_pool_;
  MemoryPool mem_pool_;
  MemorySlab msg_header_slab_;
};

}; // end of ns chunk
}; // end of ns udisk

#endif
