#include "migrate_manager.h"
#include <unistd.h>

#include "chunk_loop_handle.h"
#include "chunk_context.h"
#include <ustevent/base/my_uuid.h>
#include "umessage_common.h"
#include "get_pg_pc.h"
#include "chunk_storage_flags.h"
#include "create_chunk_storage.h"
#include "journal_format.h"

using namespace udisk::chunk;
using namespace ucloud::udisk;
using namespace std::placeholders;
using namespace uevent;

MigrateManager::MigrateManager(ChunkLoopHandle* clh) : loop_handle_(clh) {
  token_bucket_.reset(new TokenBucket(g_context->config().migrate_rate(), 
                                      g_context->config().migrate_rate()));
  ULOG_TRACE << "MigrateManager construct~";
}

MigrateManager::~MigrateManager() {
  ULOG_TRACE << "MigrateManager destroy~";
}

void MigrateManager::Init() {
  loop_handle_->GetLoop()->RunEvery(g_context->config().heartbeat_chunk_interval(),
      std::bind(&MigrateManager::CheckMigratePCState, this));
}

void MigrateManager::CheckMigratePCState() {
  // 上报io读写错误
  ReportLCIOError(); 
  base::Timestamp now_time(base::Timestamp::now());
  // 超时没有完成迁移的pending pc, 直接从列表删除
  for (auto it = pending_list_.begin(); it != pending_list_.end();
      /*nothing*/) {
    if (timeDifference(now_time, it->migrate_time) <= 
        g_context->config().migrate_timeout()) {
      ++it;
      continue;
    }
    ULOG_ERROR << "Migrate pending pc timeout,info=" << it->ToString();
    it = pending_list_.erase(it);
  }

  // 超时没有完成迁移的migrating_pc
  for (auto it = migrating_list_.begin(); it != migrating_list_.end(); 
      /* nothig */) {
    const auto& entry = it->second;
    if (timeDifference(now_time, entry.migrate_time) <= 
        g_context->config().migrate_timeout()) {
      ++it;
      continue;
    }
    //清除pending_list中属于超时迁移pc的OpRequest 
    for (auto item = inflying_list_.begin(); item != inflying_list_.end(); ) {
      const common::MigrateHead* migrate_hdr =
        (const common::MigrateHead*)(item->second->sub_msg_hdr_offset());
      if (migrate_hdr->reserved_lc_id == entry.local.lc_id() && 
          migrate_hdr->reserved_pc_no == entry.local.pc_no() && 
          migrate_hdr->reserved_lc_random_id == entry.local.lc_random_id()) {
        ULOG_ERROR << "Migrate OpTimeout. op=" << item->second->trace_tag();
        item->second->DecRefs(); 
        item = inflying_list_.erase(item);
      } else {
        ++ item;
      }
    }
    ULOG_ERROR << "Migrating pc timeout,info=" << entry.ToString();
    it = migrating_list_.erase(it);
  }
}

void MigrateManager::SyncMigrateDataProcess(
                                        const MigratePcMeta& local_migrate_pc,
                                        const MigratePcMeta& peer_migrate_pc,
                                        uint32_t peer_chunk_id,
                                        std::string peer_chunk_ip,
                                        uint32_t peer_chunk_port,
                                        uint32_t lc_size,
                                        MigratePCHandlePtr migrate_pc_handle) {
  pending_list_.emplace_back(local_migrate_pc,
                             peer_migrate_pc,
                             peer_chunk_ip, 
                             peer_chunk_port, 
                             peer_chunk_id,
                             lc_size,
                             migrate_pc_handle);
  ULOG_DEBUG << "migrating_size=" << migrating_list_.size();
  last_version_ = local_migrate_pc.route_version();
  SendNextMigratePC();
}

void MigrateManager::SendMigratePCRequest(const MigrateKey& key) {
  if (migrating_list_.count(key) == 0) {
    ULOG_ERROR << "Cannot find migrate key=" << key.ToString();
    return;
  }
  auto& entry = migrating_list_[key];
  ULOG_DEBUG << "Migrate PC entry=" << entry.ToString();
  const auto& local = entry.local;
  const auto& peer = entry.peer;
  uint32_t lc_size = entry.lc_size;
  uint64_t cluster_version = loop_handle_->cluster_map().GetClusterVersion();
  if (local.route_version() != cluster_version) {
    ULOG_ERROR << "pc cluster version is expire, migrate pc failed." 
        << entry.ToString() << ",version=" << cluster_version;
    entry.migrate_pc_handle->MigrateResponse(EC_UDISK_VERSION_LAG, 
                                             "cluster version expire");
    for (auto it = pending_list_.begin(); it != pending_list_.end(); /* nothing */) {
      if (it->PcEqual(local, peer)) {
        if (local.route_version() == it->local.route_version()) {
          ULOG_DEBUG << "remove cluster version expire entry:" 
              << it->ToString();
          it = pending_list_.erase(it);
        }
      } else {
        ++ it;
      }
    }
    ULOG_DEBUG << "migrating_size=" << migrating_list_.size();
    SendNextMigratePC();
    return;
  }
  auto& msg_header_slab = loop_handle_->msg_header_slab();
  auto msg_hdr = (const common::MessageHeader*)(msg_header_slab.Malloc());
  if (UNLIKELY(msg_hdr == nullptr)) {
    ULOG_ERROR << "Failed to malloc msg header from slab,will discard this req";
    return;
  }
  uint64_t op_seq = loop_handle_->get_next_op_seq(local.pg_id());
  entry.seqno = op_seq;
  op_keys_.insert(std::make_pair(std::make_pair(local.pg_id(), op_seq), key));
  BuildMigratePCRequest((common::MessageHeader*)msg_hdr, op_seq, lc_size,
                        local, peer);
  common::MigrateHead *migrate_hdr = 
    (common::MigrateHead*)((char* )msg_hdr + sizeof(common::MessageHeader));
   auto& op_pool = loop_handle_->op_pool();
  OpRequest* op = op_pool.Malloc(op_seq, nullptr, msg_hdr, nullptr, 
      (uint32_t)migrate_hdr->length, migrate_hdr->cmd, (uint32_t)migrate_hdr->pg_id,
      op_pool, nullptr, nullptr, &msg_header_slab);
  if (UNLIKELY(op == nullptr)) {
    ULOG_ERROR << "Failed to malloc OpRequest,seqno=" << op_seq;
    msg_header_slab.Free((void *)msg_hdr);
    return;
  }    
  ULOG_DEBUG << "Migrate pc op=" << op->trace_tag() << ",local=" 
      << local.DebugString();
  OpenChunkCb cb = std::bind(&MigrateManager::OpenChunkResCb, this, _1, _2, op, local.pg_id());
  ChunkID chunk_id(local.pg_id(), local.lc_id(), local.pc_no(), local.lc_random_id());
  int32_t ret_code = loop_handle_->GetChunkStorage()->OpenChunk(chunk_id, true, cb);
  if (ret_code != UDISK_OK) {
    ULOG_ERROR << "submit open chunk error, op: " << op->trace_tag();
    op->DecRefs();
    return;
  }
  ULOG_DEBUG << "Need open chunk_id=" << chunk_id.to_string();
}

void MigrateManager::BuildMigratePCRequest(common::MessageHeader* msg_hdr, 
                                           uint64_t op_seq, 
                                           uint32_t lc_size,
                                           const MigratePcMeta& local,
                                           const MigratePcMeta& peer) {
  uint64_t data_size = MIGRATE_TINYPC_SIZE;
  msg_hdr->msg_type = common::MSG_MIGRATE_JOURNAL_REQ;
  // MigrateHead + data
  msg_hdr->data_len = sizeof(common::MigrateHead) + data_size;
  msg_hdr->version = 0; // unused now

  common::MigrateHead* migrate_hdr = 
    (common::MigrateHead* )&(((char* )msg_hdr)[sizeof(common::MessageHeader)]);
  migrate_hdr->size = data_size;
  migrate_hdr->cmd = common::MIGRATE_CMD_PC_READ;
  migrate_hdr->flowno = op_seq;
  migrate_hdr->offset = local.pc_offset();
  migrate_hdr->length = data_size;
  migrate_hdr->lc_id = peer.lc_id();
  migrate_hdr->lc_random_id = peer.lc_random_id();
  migrate_hdr->lc_size = lc_size; 
  migrate_hdr->pg_id = peer.pg_id();
  migrate_hdr->pc_no = peer.pc_no();
  migrate_hdr->route_version = peer.route_version();//对端的version,从tyr下发
  migrate_hdr->magic = common::MIGRATE_IO_MAGIC;
  migrate_hdr->retcode = 0;
  migrate_hdr->reserved_lc_id = local.lc_id();
  migrate_hdr->reserved_pg_id = local.pg_id();
  migrate_hdr->reserved_lc_random_id = local.lc_random_id();
  migrate_hdr->reserved_pc_no = local.pc_no();
}

// tips: 迁移过程中失败，由超时机制清理内存中request_handle，pending io等
bool MigrateManager::DoLocal(ChunkHandle* handle, 
                             OpRequest* op, 
                             uint32_t pg_id) {
  const common::MessageHeader *common_hdr = op->msg_hdr();
  if (common_hdr->msg_type != common::MSG_MIGRATE_JOURNAL_REQ) {
    ULOG_ERROR << "Get Error msg_type=" << common_hdr->msg_type;
    return false;
  }
  const common::MigrateHead *migrate_hdr =
    (const common::MigrateHead*)op->sub_msg_hdr_offset();
  ULOG_TRACE << "DoLocal, request head=" << DumpMigrateHead(*migrate_hdr);
  //migrate handle中只做读pc操作，写pc在udisk_handle中完成
  assert(migrate_hdr->cmd == common::MIGRATE_CMD_PC_READ);
  int ret = SubmitReadLocal(handle, migrate_hdr->offset, migrate_hdr->length, op, pg_id);
  IOErrorContainer::IO_OP_TYPE type = IOErrorContainer::kIORead;
  if (ret < 0) {
    io_error_container_.Add(migrate_hdr->reserved_lc_id, 
                            IOErrorContainer::kJournalIOError, type); 
    ULOG_ERROR << "Req submit fail,head=" << DumpMigrateHead(*migrate_hdr);
    return false;
  }
  op->IncRefs(); // Submit使用op的read_buffer, 需要增加引用计数
  return true;
}

int MigrateManager::SubmitReadLocal(ChunkHandle *handle, 
                                    uint32_t offset,
                                    uint32_t len, 
                                    OpRequest* op,
                                    uint32_t pg_id) {
  auto cb = std::bind(&MigrateManager::LocalAioCb, this,
                      _1, _2, offset, len, op, pg_id);
  void *read_buf = nullptr;
  MemorySlab *slab = nullptr;
  auto& mem_pool = loop_handle_->mem_pool();
  std::tie(read_buf, slab) = mem_pool.Malloc(len, kDefaultDevBlockSize);
  assert(read_buf);
  op->set_read_buffer((char*)read_buf, &mem_pool, slab);
  int32_t ret = handle->PRead(read_buf, len, offset, cb, nullptr);
  if (ret != UDISK_OK) {
    ULOG_ERROR << "Submit Local Read Parent Op:" << op->trace_tag()
              << " failed,ret:" << ret;
    return ret;
  } 
  ULOG_TRACE << "Submit Local Read Parent Op: " << op->trace_tag()
             << ", pg_id=" << pg_id;
  return ret;
}

void MigrateManager::OpenChunkResCb(int retcode,
                                    ChunkHandle* handle, 
                                    OpRequest* op,
                                    uint32_t pg_id) {
  if ((retcode != UDISK_OK) || (handle == nullptr)) {
    ULOG_ERROR << "open chunk cb error for op: " << op->trace_tag();
    auto type = IOErrorContainer::kIOWrite;
    const common::MigrateHead* migrate_hdr =
          (const common::MigrateHead*)op->sub_msg_hdr_offset();
    io_error_container_.Add(migrate_hdr->reserved_lc_id, 
                            IOErrorContainer::kJournalIOError, type); 
    op->DecRefs();
    return;
  }
  if (op_keys_.count(std::make_pair(pg_id, op->op_seq())) == 0) {
    ULOG_ERROR << "Cannot find op=" << op->trace_tag() 
               << "pg_id= " << pg_id << " in op_keys.";
    op->DecRefs();
    return;
  }
  const auto& key = op_keys_[std::make_pair(pg_id,op->op_seq())];
  if (migrating_list_.count(key) == 0) {
    ULOG_ERROR << "Cannot find migrate key=" << key.ToString() 
               << ",pg_id=" << pg_id << ",seqno=" << op->op_seq();
    return;
  }
  const auto& entry = migrating_list_[key];
  if (entry.seqno != op->op_seq()){
    ULOG_ERROR << "migrating entry expire,new seq:" << entry.seqno 
        << ",old seq:" << op->op_seq();
    return;
  }
  ULOG_DEBUG << "open chunk succ. handle=" << handle->chunk_id_.to_string() 
      << ",op=" << op->trace_tag(); 
  // 依赖定时器超时检查
  inflying_list_.insert(std::make_pair(std::make_pair(pg_id, op->op_seq()), op)); 
  if (!token_bucket_->grant(1)) {
    ULOG_TRACE << "No token left, wait for a minit...";
    op->IncRefs();
    loop_handle_->GetLoop()->RunAfter(0.01,
        std::bind(&MigrateManager::WaitTokenTimerCb, this, handle, op, pg_id));
    return;
  }
  DoLocal(handle, op, pg_id);
}

void MigrateManager::WaitTokenTimerCb(ChunkHandle* handle, 
                                      OpRequest* op, 
                                      uint32_t pg_id) {
  auto it = inflying_list_.find(std::make_pair(pg_id, op->op_seq()));
  if (it == inflying_list_.end()) {
    ULOG_INFO << "op timeout when waiting token, " << op->trace_tag()
              << ", pg_id=" << pg_id;
    op->DecRefs(); // 会析构
    return;
  }
  op->DecRefs();

  if (!token_bucket_->grant(1)) {
    ULOG_TRACE << "No token left, wait for a minit...";
    op->IncRefs();
    loop_handle_->GetLoop()->RunAfter(0.01,
        std::bind(&MigrateManager::WaitTokenTimerCb, this, handle, op, pg_id));
    return;
  }
  DoLocal(handle, op, pg_id);
}

void MigrateManager::LocalAioCb(int retcode, 
                                void* arg, 
                                uint64_t offset, 
                                uint64_t len,
                                OpRequest* op,
                                uint32_t pg_id) {
  uint64_t op_seq = op->op_seq();
  ULOG_DEBUG << "aio recv: op_seq=" << op_seq
             << ", pg_id=" << pg_id 
             << ", retcode=" << retcode;
  if (inflying_list_.count(std::make_pair(pg_id, op_seq)) == 0) {
    ULOG_ERROR << "Cannot found req. pg_id = " << pg_id
               << ", seqno=" << op_seq << ",retcode=" 
               << retcode << ",may be timeout!";
    bool del = op->DecRefs(); // 一定是超时后被释放
    assert(del == true);
    ULOG_DEBUG << "migrating_size=" << migrating_list_.size();
    SendNextMigratePC();
    return;
  }
  bool del = op->DecRefs();
  assert(del == false); // 在inflying_list_中肯定没有超时,aio回调中不可能析构
  const common::MigrateHead *migrate_hdr = 
      (const common::MigrateHead*)op->sub_msg_hdr_offset();
  assert(migrate_hdr->cmd == common::MIGRATE_CMD_PC_READ);
  if (retcode != MIGRATE_TINYPC_SIZE) {
    ULOG_ERROR << "AIO_ERROR: pg_id=" << pg_id 
               << ", op_seq=" << op_seq << ",retcode=" << retcode;
    IOErrorContainer::IO_OP_TYPE type = IOErrorContainer::kIORead;
    io_error_container_.Add(migrate_hdr->reserved_lc_id,
                            IOErrorContainer::kJournalIOError, type); 
    return;
  }
  if (op_keys_.count(std::make_pair(pg_id, op_seq)) == 0) {
    ULOG_ERROR << "Cannot find op=" << op->trace_tag()
               << ", pg_id=" << pg_id;
    op->DecRefs();
    return;
  }
  const auto& key = op_keys_[std::make_pair(pg_id,op->op_seq())];
  if (migrating_list_.count(key) == 0) {
    ULOG_ERROR << "Cannot find migrate key=" << key.ToString() << ",seqno=" 
               << op->op_seq() << ", pg_id =" << pg_id;
    return;
  }
  const auto& entry = migrating_list_[key];
  if (entry.seqno != op->op_seq()){
    ULOG_ERROR << "migrating entry expire,new seq:" << entry.seqno 
        << ",old seq:" << op->op_seq();
    return;
  }
  ULOG_TRACE << "AIO_SUCC:op" << op->trace_tag() << ",entry=" << entry.ToString();
  SyncMigrateDataRequest(op, entry);
}

int MigrateManager::SyncMigrateDataRequest(OpRequest* op, 
                                           const MigrateEntry& entry) {
  const common::MessageHeader *msg_hdr = op->msg_hdr();
  size_t msg_hdr_len = sizeof(common::MessageHeader) + 
                       sizeof(common::MigrateHead);
  common::MigrateHead *migrate_hdr = 
    (common::MigrateHead*)((char* )msg_hdr + sizeof(common::MessageHeader));
  migrate_hdr->cmd = common::MIGRATE_CMD_PC_WRITE;
  // 对于不同的pc_size区分处理
  if (entry.local.pc_size() <= entry.peer.pc_size()) {
    migrate_hdr->offset += entry.peer.pc_offset(); 
  } else {
    migrate_hdr->offset %= entry.peer.pc_size();
  }

  const std::string ip = entry.peer_chunk_ip;
  int port = entry.peer_chunk_port;
  uint32_t peer_chunk_id = entry.peer_chunk_id;
  uevent::UsockAddress addr(ip, port, false);
  bool rc = SendMsg((const char*)msg_hdr, msg_hdr_len, addr);
  if (!rc) {
    ULOG_ERROR << "Gate Op: " << op->op_seq()
              << " op seqno: " << migrate_hdr->flowno
              << "->Sub Op: " << DumpMigrateHead(*migrate_hdr)
              << " to chunk: " << peer_chunk_id
              << " " << ip << ":" << port << " failed";
    return -1;
  }
  ULOG_DEBUG << "size:" << migrate_hdr->size << ",rc:" << rc << " ===> addr:" 
      << ip << ":" << port << ",op=" << op->trace_tag() << ",data="
      << journal::values_string(op->read_buffer(), migrate_hdr->size);
  rc = SendMsg(op->read_buffer(), migrate_hdr->size, addr);
  if (rc) {
    op->mark_replica_waiting(0, peer_chunk_id);
  } else {
    ULOG_ERROR << "Gate Op: " << op->op_seq()
              << " op flowno: " << migrate_hdr->flowno
              << "->Sub Op: " << DumpMigrateHead(*migrate_hdr)
              << " data to chunk: " << peer_chunk_id
              << " " << ip << ":" << port << " failed";
    return -1;
  }
  ULOG_DEBUG << "Gate Op: " << op->op_seq()
            << " op flowno: " << migrate_hdr->flowno
            << "->Sub Op: " << DumpMigrateHead(*migrate_hdr)
            << " to chunk: " << peer_chunk_id
          << " " << ip << ":" << port;
  return 0;
}

void MigrateManager::DoMigratePcResponse(const common::MigrateHead* migrate_hdr) {
  ULOG_DEBUG << "migrate pc response head=" << DumpMigrateHead(*migrate_hdr);
  uint64_t op_seq = migrate_hdr->flowno;
  uint32_t pg_id = migrate_hdr->reserved_pg_id;
  auto found = inflying_list_.find(std::make_pair(pg_id, op_seq));
  if (found == inflying_list_.end()) {
    uint32_t limit = (uint32_t)g_context->config().migrate_pc_concurrency();
    if (inflying_list_.size() >= limit) {
      // op超时删除后，又触发了迁移
      ULOG_ERROR << "Get a Migrate Msg=" << DumpMigrateHead(*migrate_hdr)
            << ",op_seq:" << op_seq << " but cannot found this seqno in inflying list,Ignore!";
    } else { // inflying_list_为空，说明op已经超时被清除，需要触发迁移下一个pc
      ULOG_DEBUG << "migrating_size=" << migrating_list_.size();
      SendNextMigratePC();
    }
    return;
  }
  OpRequest* op = found->second;
  if (op_keys_.count(std::make_pair(pg_id,op_seq)) == 0) {
    ULOG_ERROR << "Cannot find op=" << op->trace_tag() << ", pg_id=" << pg_id;
    op->DecRefs();
    return;
  }
  const auto key = op_keys_[std::make_pair(pg_id, op_seq)];
  if (migrating_list_.count(key) == 0) {
    ULOG_ERROR << "Cannot find migrate key=" << key.ToString() << ",seqno=" 
        << op->op_seq();
    return;
  }
  auto& entry = migrating_list_[key];
  if (entry.seqno != op_seq){
    ULOG_ERROR << "migrating entry is expire,new seq:" << entry.seqno 
        << ",old seq:" << op_seq;
    return;
  }
  uint32_t lc_id = migrate_hdr->reserved_lc_id;
  uint32_t lc_random_id = migrate_hdr->reserved_lc_random_id;
  assert(entry.local.lc_id() == lc_id);
  assert(entry.local.lc_random_id() == lc_random_id);
  ULOG_TRACE << "migrate op response=" << op->trace_tag();
  inflying_list_.erase(found);
  bool del = op->DecRefs();
  assert(del == true);
  op_keys_.erase(std::make_pair(pg_id,op_seq));
  //对端chunk写pc异常,本次pc写失败,返回迁移失败
  if (migrate_hdr->retcode != 0) {
    ULOG_ERROR << "migrate pc failed,retcode=" << migrate_hdr->retcode 
      << ",migrate_entry=" << entry.ToString();
    entry.migrate_pc_handle->MigrateResponse(migrate_hdr->retcode, 
                                             "migrate failed");
    for (auto it = pending_list_.begin(); it != pending_list_.end();
        /* nothing */) {
      if (it->PcEqual(entry.local, entry.peer)) {
        ULOG_DEBUG << "remove failed migrate entry:" << it->ToString();
        it = pending_list_.erase(it);
      } else {
        ++it;
      }
    }
    ULOG_DEBUG << "migrating_size=" << migrating_list_.size();
    SendNextMigratePC();
    return;
  }
  // 收到回复，开启下一个tinypc的迁移
  ULOG_DEBUG << "migrate tpc finish,key=" << key.ToString() << ",entry=" << entry.ToString();
  uint32_t pc_offset = entry.local.pc_offset() + MIGRATE_TINYPC_SIZE;
  entry.local.set_pc_offset(pc_offset);
  if ((entry.local.pc_size() > entry.peer.pc_size() && 
      entry.local.pc_offset() % entry.peer.pc_size() == 0) || 
      (entry.local.pc_size() <= entry.peer.pc_size() &&
      entry.local.pc_offset() == entry.local.pc_size())) {
    entry.migrate_pc_handle->MigrateResponse(0, "migrate success");
    ULOG_DEBUG << "migrate pc finish,key=" << key.ToString() << ",entry=" << entry.ToString();
    //删除迁移队列中所有该pc的entry
    for (auto it = pending_list_.begin(); it != pending_list_.end(); /* nothing */) {
      if (it->PcEqual(entry.local, entry.peer)) {
        ULOG_DEBUG << "remove migrate entry:" << it->ToString();
        it = pending_list_.erase(it);
      } else {
        ++it;
      }
    }
    ULOG_DEBUG << "migrating_size=" << migrating_list_.size() << ",finish key=" 
      << key.ToString() << ",entry=" << entry.ToString();
    migrating_list_.erase(key);
    ULOG_DEBUG << "migrating_size=" << migrating_list_.size();
    SendNextMigratePC();
  } else {
    SendMigratePCRequest(key);
  }
}

void MigrateManager::SendNextMigratePC() {
  if (pending_list_.empty()) {
    // 所有数据同步完毕
    ULOG_INFO << "Finish all migrate pc data_sync:)";
    return;
  } 
  uint32_t limit = (uint32_t)g_context->config().migrate_pc_concurrency();
  if (migrating_list_.size() >= limit) {
    ULOG_ERROR << "migrating size too large,size=" << migrating_list_.size();
    return;
  }
  const auto& entry = pending_list_.front();
  // 把需要迁移的pc信息加入待迁移列表
  MigrateKey key(entry.local.pc_no(), entry.peer.pc_no());
  migrating_list_.insert(std::make_pair(key, entry)),
  pending_list_.pop_front();  
  SendMigratePCRequest(key);
}

bool MigrateManager::SendMsg(const char *msg, 
                              size_t len, 
                              const uevent::UsockAddress& addr) {
  ConnectorUeventPtr ctor = loop_handle_->get_out_connector(addr);
  if (!ctor->HasAvailableConnection()) {
    ULOG_ERROR << "No available connection to chunk:" 
               << ctor->GetPeerAddress().ToString();
    return false;
  }
  ConnectionUeventPtr connection = ctor->GetConnection();
  return connection->SendData(msg, len) == 0 ? true : false;
}

void MigrateManager::ReportLCIOError() {
  if (io_error_container_.IsEmpty()) {
    return;
  }
  g_context->manager_handle()->ReportLCIOError(io_error_container_.lc_io_errors()); 
  io_error_container_.Clear();
}

int MigrateManager::DoMigrateJournalRemoteRequest(OpRequest* op, 
                               const IOMeta& meta, 
                               uint32_t pg_id,
                               uint32_t lc_size,
                               const ucloud::udisk::MigratePcMeta& migrate_pc) {
  ULOG_DEBUG << "Send Migrate Journal Request: pg_id=" << pg_id 
             << ",seqno=" << op->op_seq() << ",meta=" << meta.ToString(); 
  //cluster version check
  auto current_version = loop_handle_->cluster_map().GetClusterVersion();
  if (last_version_ != current_version) {
    ULOG_ERROR << "Cluster version is expire, migrate journal failed. last version="
               << last_version_ << ",current version=" << current_version;
    return common::RETCODE_CLUSTER_VERSION_ERR; 
  }
  uint32_t msg_hdr_len = sizeof(common::MessageHeader) + sizeof(common::MigrateHead);
  char msg_hdr[msg_hdr_len];
  BuildMigrateJournalRemoteRequest((common::MessageHeader*)msg_hdr, 
                                   op->op_seq(), 
                                   meta, 
                                   pg_id,
                                   lc_size, 
                                   migrate_pc,
                                   op->cmd());
  const auto& conn = op->conn();
  const auto& peer_addr = conn->GetPeerAddress();
  ULOG_DEBUG << "migrate op=" << op->op_seq() << ",peer_addr=" 
      << peer_addr.ToString() << ",conn_id=" << conn->GetId(); 
  int rc = conn->SendData(msg_hdr, msg_hdr_len);
  if (rc) {
    ULOG_ERROR << "Migrate Op=" << op->op_seq() << " failed, retcode=" << rc;
    return common::RETCODE_RESET_CONNECTION;
  }
  assert(op->read_buffer() || op->msg_data());
  assert(op->cmd() == common::MIGRATE_CMD_JOURNAL || 
         op->cmd() == common::MIGRATE_CMD_MEMTABLE);
  const char* send_msg = (op->cmd() == common::MIGRATE_CMD_JOURNAL) ? 
                     op->read_buffer() : op->msg_data();
  rc = conn->SendData(send_msg, meta.length);
  if (rc) {
    ULOG_ERROR << "Migrate Op=" << op->op_seq() << " failed, retcode=" << rc;
    return common::RETCODE_RESET_CONNECTION;
  }
  ULOG_DEBUG << "Migrate Op: " << op->op_seq(); 
  return 0;
}

void MigrateManager::BuildMigrateJournalRemoteRequest(common::MessageHeader* msg_hdr, 
                                           uint64_t seqno,
                                           const IOMeta& meta, 
                                           uint32_t pg_id,
                                           uint32_t lc_size, 
                                           const MigratePcMeta& migrate_pc,
                                           uint8_t cmd) {
  uint64_t data_size = meta.length;
  msg_hdr->msg_type = common::MSG_MIGRATE_JOURNAL_REQ;
  // MigrateHead + data
  msg_hdr->data_len = sizeof(common::MigrateHead) + data_size;
  msg_hdr->version = 0; // unused now

  common::MigrateHead* migrate_hdr = 
    (common::MigrateHead* )&(((char*)msg_hdr)[sizeof(common::MessageHeader)]);
  migrate_hdr->size = data_size;
  migrate_hdr->cmd = cmd;
  migrate_hdr->flowno = seqno;
  migrate_hdr->offset = migrate_pc.pc_offset();
  migrate_hdr->length = data_size;
  migrate_hdr->lc_id = migrate_pc.lc_id();
  migrate_hdr->lc_random_id = migrate_pc.lc_random_id();
  migrate_hdr->lc_size = lc_size; 
  migrate_hdr->pg_id = migrate_pc.pg_id();
  migrate_hdr->pc_no = migrate_pc.pc_no();
  migrate_hdr->route_version = migrate_pc.route_version();
  migrate_hdr->magic = common::MIGRATE_IO_MAGIC;
  migrate_hdr->reserved_lc_id = meta.lc_id;
  migrate_hdr->reserved_pg_id = pg_id;
  migrate_hdr->reserved_lc_random_id = meta.random_id;
  migrate_hdr->retcode = 0;
  ULOG_DEBUG << "Build migrate_head=" << common::DumpMigrateHead(*migrate_hdr);
}

void MigrateManager::DoMigrateRemoteResponse(const common::MigrateHead* hdr) {
  ULOG_DEBUG << "Migrate response head=" << common::DumpMigrateHead(*hdr);
  uint32_t pg_id = hdr->reserved_pg_id;
  auto journal_engine = loop_handle_->JournalEngine(pg_id);
  assert(journal_engine && journal_engine->IsInit());
  switch (hdr->cmd) {
  case common::MIGRATE_CMD_PC_WRITE:
    DoMigratePcResponse(hdr);
    break;
  case common::MIGRATE_CMD_JOURNAL:
    journal_engine->MigrateJournalResponse(hdr);
    break;
  case common::MIGRATE_CMD_MEMTABLE:
    journal_engine->MigrateMemTableResponse(hdr);
    break;
  case common::MIGRATE_CMD_DUALWRITE:
    loop_handle_->ReplicaRemoteResponse(hdr);
    break;
  default:
    assert(0 == "Migrate Journal response");
  };
}

int MigrateManager::ReplicaRemoteRequest(OpRequest* op, 
                                         const MigratePcMeta& migrate_pc,
                                         ConnectorUeventPtr& ctor) {
  assert(op->msg_type() == common::MSG_GATE_IO_REQ);
  const common::GateIORequestHead* gate_hdr = 
      (const common::GateIORequestHead*)op->sub_msg_hdr_offset();
  constexpr size_t msg_hdr_len = sizeof(common::MessageHeader) +
                       sizeof(common::MigrateHead);
  char msg_hdr[msg_hdr_len] = {0};
  // index=kReplicaNum表示迁移到对端chunk
  op->mark_replica_waiting(common::kReplicaNum, UINT32_MAX);
  if (ctor == nullptr || ctor->HasAvailableConnection() == false) {
    ULOG_ERROR << " Migrate Op: " << op->op_seq()
              << " req flowno: " << gate_hdr->flowno
              << " with retcode: " << op->retcode()
              << " error, the response connection has closed";
    return false;
  }
  IOMeta meta = {gate_hdr->lc_id, gate_hdr->lc_random_id, 
                  gate_hdr->pc_no, gate_hdr->offset, gate_hdr->length};
  BuildMigrateJournalRemoteRequest((common::MessageHeader*)msg_hdr,
                          op->op_seq(),
                          meta,
                          gate_hdr->pg_id,
                          gate_hdr->lc_size, 
                          migrate_pc,
                          common::MIGRATE_CMD_DUALWRITE);
  //没有重试报错依赖超时检测
  const uevent::ConnectionUeventPtr& connection = ctor->GetConnection();
  int rc = connection->SendData(msg_hdr, msg_hdr_len);
  if (rc) {
    ULOG_ERROR << "Replicate Gate Op seqno=" << op->op_seq()
              << " failed, retcode: " << rc; 
  }
  rc = connection->SendData(op->msg_data(), gate_hdr->size);
  if (rc) {
    ULOG_ERROR << "Replicate Gate Op seqno=" << op->op_seq()
              << " failed, retcode: " << rc; 
  }
  ULOG_DEBUG << "migrate_dualwrite Replicate Gate Op seqno=" << op->op_seq()
             << " success, op=" << op->trace_tag();
  return 0;
}

