#include <ustevent/message_util.h>
#include <ustevent/connection_uevent.h>
#include <ustevent/base/logging.h>
#include <ustevent/eventloop.h>
#include "chunk_context.h"
#include "manager_handle.h"
#include "chunk_loop_handle.h"
#include "cluster_map.h"
#include "migrate_task_finish.h"

using namespace uevent;
using namespace udisk::chunk;
using namespace udisk::journal;
using namespace ucloud::udisk;

int MigrateTaskFinishHandle::type_ = TYR_MIGRATE_TASK_FINISH_REQUEST;
uint32_t MigrateTaskFinishHandle::selector_ = 0;

void MigrateTaskFinishHandle::SendResponse(uint32_t retcode, 
                                           const std::string& message) {
  MigrateTaskFinishHandlePtr this_ptr =
    std::dynamic_pointer_cast<MigrateTaskFinishHandle>(shared_from_this());
  loop_->RunInLoop(std::bind(&MigrateTaskFinishHandle::SendResponseInLoop,
                             this_ptr, retcode, message));
}

void MigrateTaskFinishHandle::SendResponseInLoop(uint32_t retcode, 
                                                 const std::string& message) {
  TyrMigrateTaskFinishResponse* resp = 
      response_.mutable_body()->MutableExtension(tyr_migrate_task_finish_response);
  resp->mutable_rc()->set_retcode(retcode);
  resp->mutable_rc()->set_error_message(message);
  ULOG_DEBUG << response_.DebugString();
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void MigrateTaskFinishHandle::EntryInit(const ConnectionUeventPtr& conn, 
                                        const UMessagePtr& um) {
  conn_ = conn;
  ULOG_INFO << "protobuf recv conn_id=" << conn_->GetId() << ", msg " 
      << um->DebugString();
  assert(um->head().message_type() == type_);
  assert(um->body().HasExtension(tyr_migrate_task_finish_request));

  MakeResponse(um.get(), TYR_MIGRATE_TASK_FINISH_RESPONSE, &response_);
  request_ = um;
  MigrateTaskFinishProcess(um);
}

void MigrateTaskFinishHandle::MigrateTaskFinishProcess(const UMessagePtr& um) {
  TyrMigrateTaskFinishRequest req = 
      um->body().GetExtension(tyr_migrate_task_finish_request);
  ULOG_INFO << "recv MigrateTaskFinishHandle request: lc_id=" << req.lc_id();
  ManagerHandle* manager_handle = g_context->manager_handle();
  cluster::ClusterMap cluster_map = manager_handle->const_cluster_map();
  std::vector<PGInfoPb> pg_infos = cluster_map.pgs();
  if (req.lc_id() == UINT32_MAX ||
      req.pg_id() >= (uint32_t)pg_infos.size() ||
      req.pg_id() != pg_infos[req.pg_id()].id()) {
    ULOG_ERROR << "request migrate lc_id=" << req.lc_id() << ", pg_id=" 
        << req.pg_id() << ", param invalid.";
    SendResponse(EC_UDISK_PARAM_INVALID, "param invalid");
    return;
  }

  int32_t journal_enable = g_context->config().journal_enable();
  // 所有线程共用一个migrate_udisk，随机选择任意线程即可
  auto all_loops = g_context->io_listener()->GetAllLoops();
  auto loop = all_loops[selector_ % all_loops.size()];
  ++ selector_;
  auto clh = dynamic_cast<ChunkLoopHandle*>(loop->GetLoopHandle());
  JournalEngine* engine = clh->JournalEngine(req.pg_id());
  if (!journal_enable || !engine || !engine->IsInit() ||
      !engine->InMigrate(req.lc_id())) {
    ULOG_ERROR << "request migrate lc_id=" << req.lc_id() << ", pg_id=" 
        << req.pg_id() << ", journal engine not init, or udisk in migrate.";
    SendResponse(EC_UDISK_PARAM_INVALID, "param invalid");
    return;
  }
  ULOG_DEBUG << "pg_id=" << req.pg_id() << ",lc_id=" << req.lc_id() 
      << ",thread=" << loop->thread_id();

  MigrateTaskFinishHandlePtr this_ptr =
    std::dynamic_pointer_cast<MigrateTaskFinishHandle>(shared_from_this());

  loop->RunInLoop(
      std::bind(&JournalEngine::EntryMigrateTaskFinish, engine, this_ptr, 
                req.lc_id(), false));
  //SendResponse(0, "success");
}

