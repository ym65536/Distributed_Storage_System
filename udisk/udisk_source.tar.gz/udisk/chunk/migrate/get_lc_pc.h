#ifndef UDISK_CHUNK_GET_LC_PC_H_
#define UDISK_CHUNK_GET_LC_PC_H_

#include <ustevent/pb_request_handle.h>
#include "udisk_message.h"


namespace udisk {
namespace chunk {
 
class GetLCPhysicalChunkHandle: public uevent::PbRequestHandle {
 public:
  explicit GetLCPhysicalChunkHandle(uevent::EventLoop* loop) 
    : loop_(loop){
  }
  virtual ~GetLCPhysicalChunkHandle() {
  }
  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         const uevent::UMessagePtr& um);

  void SendResponse(uint32_t retcode, const std::string& message);
 
  int GetLCPhysicalChunkInfo(uint32_t pg_id, 
                             uint32_t lc_id,
                             ::google::protobuf::RepeatedPtrField<::ucloud::udisk::PGPhysicalChunk>& pg_slices);
  void GetLCPhysicalChunkProcess(uint32_t pg_id, uint32_t lc_id, 
                                 uint64_t cluster_version);

  MYSELF_CREATE(GetLCPhysicalChunkHandle);

 private:
  static int type_;
  static uint32_t selector_;
  uevent::EventLoop* loop_;
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage response_;
};

} // namespace chunk
} // namespace udisk
#endif

