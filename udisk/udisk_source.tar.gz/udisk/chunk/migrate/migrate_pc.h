#ifndef UDISK_CHUNK_BEGIN_MIGRATE_PC_HANDLE_H_
#define UDISK_CHUNK_BEGIN_MIGRATE_PC_HANDLE_H_

#include <atomic>
#include <tuple>
#include <set>
#include <ustevent/pb_request_handle.h>
#include <ucloud.pb.h>
#include "udisk_message.h"

namespace udisk {
namespace chunk {

class MigratePCHandle: public uevent::PbRequestHandle {
 public:
  explicit MigratePCHandle(uevent::EventLoop* loop) : loop_(loop) {
  }
  virtual ~MigratePCHandle() {
  }

  MYSELF_CREATE(MigratePCHandle);

  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         const uevent::UMessagePtr& um);
  void ChunkBeginMigratePcProcess(
                const ucloud::udisk::TyrChunkMigratePcRequest& um);
  void MigrateResponse(uint32_t retcode, const std::string& message);
  void MigrateTimeout();
  void SendResponse(uint32_t retcode, const std::string& message);

 private:
  void MigrateResponseInLoop(uint32_t retcode, 
                             const std::string& message);

  static int type_;
  ucloud::udisk::MigratePcMeta local_migrate_pc_;
  ucloud::udisk::MigratePcMeta peer_migrate_pc_;
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage response_;
  uevent::EventLoop* loop_;
  uevent::TimerId timer_id_;
};

typedef std::shared_ptr<MigratePCHandle> MigratePCHandlePtr;

}
}

#endif

