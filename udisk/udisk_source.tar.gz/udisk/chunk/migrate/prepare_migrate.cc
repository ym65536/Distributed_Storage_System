#include <ustevent/message_util.h>
#include <ustevent/connection_uevent.h>
#include <ustevent/base/logging.h>
#include <ustevent/eventloop.h>
#include "chunk_context.h"
#include "manager_handle.h"
#include "chunk_loop_handle.h"
#include "cluster_map.h"
#include "prepare_migrate.h"

using namespace uevent;
using namespace udisk::chunk;
using namespace udisk::journal;
using namespace ucloud::udisk;

int PrepareMigrateHandle::type_ = TYR_PREPARE_MIGRATE_REQUEST;

void PrepareMigrateHandle::SendResponse(uint32_t retcode, 
                                        const std::string& message,
                                        uint64_t seqno) {
  PrepareMigrateHandlePtr this_ptr =
    std::dynamic_pointer_cast<PrepareMigrateHandle>(shared_from_this());
  loop_->RunInLoop(std::bind(&PrepareMigrateHandle::SendResponseInLoop,
                             this_ptr, retcode, message, seqno));
}

void PrepareMigrateHandle::SendResponseInLoop(uint32_t retcode, 
                                              const std::string& message,
                                              uint64_t seqno) {
  TyrPrepareMigrateResponse* resp = 
      response_.mutable_body()->MutableExtension(tyr_prepare_migrate_response);
  resp->mutable_rc()->set_retcode(retcode);
  resp->mutable_rc()->set_error_message(message);
  resp->set_seqno(seqno);
  ULOG_DEBUG << response_.DebugString();
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void PrepareMigrateHandle::EntryInit(const ConnectionUeventPtr& conn, 
                                     const UMessagePtr& um) {
  conn_ = conn;
  ULOG_INFO << "recv connid=" << conn_->GetId() << ",msg=" << um->DebugString();
  assert(um->head().message_type() == type_);
  assert(um->body().HasExtension(tyr_prepare_migrate_request));

  MakeResponse(um.get(), TYR_PREPARE_MIGRATE_RESPONSE, &response_);
  request_ = um;
  PrepareMigrateProcess(um);
}

void PrepareMigrateHandle::PrepareMigrateProcess(const UMessagePtr& um) {
  TyrPrepareMigrateRequest req = 
      um->body().GetExtension(tyr_prepare_migrate_request);
  ULOG_INFO << "recv PrepareMigrateHandle request: lc_id=" << req.lc_id();
  ManagerHandle* manager_handle = g_context->manager_handle();
  cluster::ClusterMap cluster_map = manager_handle->const_cluster_map();
  std::vector<PGInfoPb> pg_infos = cluster_map.pgs();
  // seqno = 0表示该pg没有写过.
  if (req.lc_size() == 0 || req.lc_size() > 32 * 1024 ||
      req.tyr_ip().empty() || req.tyr_port() == 0 ||
      req.pg_id() >= (uint32_t)pg_infos.size() ||
      req.pg_id() != pg_infos[req.pg_id()].id() ||
      (uint32_t)g_context->config().my_id() != 
          pg_infos[req.pg_id()].primary_chunk_id()) {
    ULOG_ERROR << "request migrate lc_id=" << req.lc_id() << ", pg_id=" 
        << req.pg_id() << ", param invalid.";
    SendResponse(EC_UDISK_PARAM_INVALID, "param invalid", 0);
    return;
  }

  int32_t journal_enable = g_context->config().journal_enable();
  // 所有线程共用一个memtable，随机选择任意线程即可
  auto loop = g_context->io_listener()->GetOneLoop();
  auto clh = dynamic_cast<ChunkLoopHandle*>(loop->GetLoopHandle());
  JournalEngine* engine = clh->JournalEngine(req.pg_id());
  if (!journal_enable || !engine || !engine->IsInit() ||
      engine->InMigrate(req.lc_id())) {
    ULOG_ERROR << "request migrate lc_id=" << req.lc_id() << ", pg_id=" 
        << req.pg_id() << ", journal engine not init, or udisk in migrate.";
    SendResponse(EC_UDISK_PARAM_INVALID, "param invalid", 0);
    return;
  }
  ULOG_DEBUG << "pg_id=" << req.pg_id() << ",lc_id=" << req.lc_id() 
      << ",thread=" << loop->thread_id();
  PrepareMigrateHandlePtr this_ptr =
    std::dynamic_pointer_cast<PrepareMigrateHandle>(shared_from_this());
  loop->RunInLoop(std::bind(&JournalEngine::DoPrepareMigrateTask, engine, 
                            this_ptr, req));
  //SendResponse(0, "success");
}

