#include <sstream>
#include <ustevent/message_util.h>
#include <ustevent/connection_uevent.h>
#include <ustevent/base/logging.h>
#include "chunk_context.h"
#include "manager_handle.h"
#include "str_list.h"
#include "chunk_loop_handle.h"
#include "chunk_storage_errorcode.h"
#include "get_lc_pc.h"

using namespace udisk::chunk;
using namespace ucloud::udisk;
using namespace udisk::journal;
using namespace google::protobuf;
using namespace uevent;
 
int GetLCPhysicalChunkHandle::type_ = GET_LC_PHYSICAL_CHUNK_REQUEST;
uint32_t GetLCPhysicalChunkHandle::selector_ = 0;

void GetLCPhysicalChunkHandle::SendResponse(uint32_t retcode, 
                                        const std::string& message) {
  GetLCPhysicalChunkResponse* resp_body = 
      response_.mutable_body()->MutableExtension(get_lc_physical_chunk_response);
  resp_body->mutable_rc()->set_retcode(retcode);
  resp_body->mutable_rc()->set_error_message(message);
  ULOG_DEBUG << response_.DebugString();
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void GetLCPhysicalChunkHandle::EntryInit(const ConnectionUeventPtr& conn, 
                                         const UMessagePtr& um) {
  ULOG_INFO << "protobuf recv conn=" << conn->GetId() << ", msg " 
            << um->DebugString();
  conn_ = conn;
  assert(um->head().message_type() == type_);
  assert(um->body().HasExtension(get_lc_physical_chunk_request));
  GetLCPhysicalChunkRequest req_body = 
    um->body().GetExtension(get_lc_physical_chunk_request);
  MakeResponse(um.get(), GET_LC_PHYSICAL_CHUNK_RESPONSE, &response_);
  GetLCPhysicalChunkProcess(req_body.pg_id(), 
                            req_body.lc_id(), 
                            req_body.cluster_version());
}

int GetLCPhysicalChunkHandle::GetLCPhysicalChunkInfo(uint32_t pg_id, 
                                                     uint32_t lc_id,
                        RepeatedPtrField<PGPhysicalChunk>& lc_physical_chunks) {
  ChunkIDList chunk_ids;
  int32_t ret = g_context->chunk_pool()->GetExistChunkByPG(pg_id, &chunk_ids);
  if (ret != UDISK_OK) {
    if (ret != UDISK_PC_NOT_EXIST_ERROR) {
      ULOG_ERROR << "GetExistChunkByPG Error code :" << ret << ", lc_id=" 
          << lc_id << ", pg_id=" << pg_id;
      return ret;
    } else { // 分片不存在认为正常
      ULOG_INFO << "GetExistChunkByPG no pc," << " lc_id=" << lc_id 
                << ", pg_id=" << pg_id;
      return UDISK_OK;
    }
  }

  for (auto it = chunk_ids.begin(); it != chunk_ids.end(); ++it) {
    if (it->lc_id == lc_id) {
      ULOG_DEBUG << "Chunk ID:" << it->to_string(); 
      PGPhysicalChunk* pg_physical_chunk = lc_physical_chunks.Add();
      pg_physical_chunk->set_lc_id(it->lc_id);
      pg_physical_chunk->set_pc_id(it->pc_no);
      pg_physical_chunk->set_lc_random_id(it->lc_random_id);
      // TODO(fangran.fr)
      pg_physical_chunk->set_lc_size(0);
    }
  }

  return UDISK_OK;
}

void GetLCPhysicalChunkHandle::GetLCPhysicalChunkProcess(uint32_t pg_id, 
                                                    uint32_t lc_id, 
                                                    uint64_t cluster_version) {
  ULOG_INFO << "recv GetLCPhysicalChunk request: pg_id=" << pg_id 
      <<", lc_id:" << lc_id << ",cluster_version=" << cluster_version;
  ManagerHandle* manager_handle = g_context->manager_handle();
  cluster::ClusterMap cluster_map = manager_handle->const_cluster_map();
  if (cluster_map.GetClusterVersion() != cluster_version) {
    ULOG_ERROR << "Recv pg_id cluster version error. cluster_version=" 
        << cluster_version << ",my version=" << cluster_map.GetClusterVersion();
    SendResponse(EC_UDISK_VERSION_LAG, "cluster version error");
    return;
  }
  std::vector<PGInfoPb> pg_infos = cluster_map.pgs();
  if (pg_id >= (uint32_t)pg_infos.size()) {
    ULOG_ERROR << "Recv pg_id error. pg_id=" << pg_id;
    SendResponse(EC_UDISK_PARAM_INVALID, "input param error");
    return;
  }

  ucloud::udisk::PGInfoPb pg_info = pg_infos[pg_id];
  if (pg_info.primary_chunk_id() != 
      static_cast<uint32_t>(g_context->config().my_id())) {
    ULOG_ERROR << "Not primary chunk. pg_id=" << pg_id << " lc_id:" << lc_id;
    SendResponse(EC_UDISK_PARAM_INVALID, "This is secondary chunk");
    return;
  }

  int32_t journal_enable = g_context->config().journal_enable();
  // 相同pg所有线程共用一个seqno，随机选择任意线程即可
  auto all_loops = g_context->io_listener()->GetAllLoops();
  auto loop = all_loops[selector_ % all_loops.size()];
  ++ selector_;
  auto clh = dynamic_cast<ChunkLoopHandle*>(loop->GetLoopHandle());
  JournalEngine* engine = clh->JournalEngine(pg_id);
  if (!journal_enable || !engine || !engine->IsInit() || 
      !engine->InMigrate(lc_id)) {
    ULOG_ERROR << "request migrate lc_id=" << lc_id << ", pg_id=" << pg_id 
        << ",engine=" << engine << ",init=" << engine->IsInit() << ",migrate=" 
        << engine->InMigrate(lc_id) << ",journal engine not init/not in migrate.";
    SendResponse(EC_UDISK_PARAM_INVALID, "param invalid");
    return;
  }
  // 必须先获取seqno
  uint64_t seqno = engine->MigrateSeqno();
  ULOG_DEBUG << "pg_id=" << pg_id << ",lc_id=" << lc_id << " get migrate seqno="
      << seqno;

  RepeatedPtrField<PGPhysicalChunk> lc_physical_chunks;
  if (GetLCPhysicalChunkInfo(pg_id, lc_id, lc_physical_chunks) != UDISK_OK) {
    ULOG_ERROR << "get lc_physical_chunk fail. pg_id=" << pg_id
        << " lc_id" << lc_id;
    SendResponse(EC_UDISK_GET_PC_SLICE, "get lc physical_chunk fail");
    return;
  }

  GetLCPhysicalChunkResponse* resp_body = 
      response_.mutable_body()->MutableExtension(get_lc_physical_chunk_response);
  resp_body->mutable_pcs()->Swap(&lc_physical_chunks);
  resp_body->set_seq_no(seqno);
  SendResponse(0, "success");
}

