#ifndef UDISK_PREPARE_MIGRATE_HANDLE_H_
#define UDISK_PREPARE_MIGRATE_HANDLE_H_

#include <atomic>
#include <set>
#include <ustevent/pb_request_handle.h>
#include <ucloud.pb.h>

namespace udisk {
namespace chunk {

class PrepareMigrateHandle: public uevent::PbRequestHandle {
 public:
  explicit PrepareMigrateHandle(uevent::EventLoop* loop): loop_(loop) {
  }
  virtual ~PrepareMigrateHandle() {
  }
  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         const uevent::UMessagePtr& um);
 
  void PrepareMigrateProcess(const uevent::UMessagePtr& um);

  MYSELF_CREATE(PrepareMigrateHandle);

  void SendResponse(uint32_t retcode, const std::string& message, uint64_t seqno); 
  void SendResponseInLoop(uint32_t retcode, const std::string& message, uint64_t seqno);
   
 private:
  uevent::EventLoop* loop_;
  static int type_;
  uevent::ConnectionUeventPtr conn_;
  uevent::UMessagePtr request_;
  ucloud::UMessage response_;
};

typedef std::shared_ptr<PrepareMigrateHandle> PrepareMigrateHandlePtr;
}
}
#endif

