#include <ustevent/message_util.h>
#include <ustevent/connection_uevent.h>
#include <ustevent/base/logging.h>
#include <ustevent/eventloop.h>
#include "chunk_context.h"
#include "manager_handle.h"
#include "chunk_loop_handle.h"
#include "cluster_map.h"
#include "prepare_migrate.h"

using namespace uevent;
using namespace udisk::chunk;
using namespace udisk::journal;
using namespace ucloud::udisk;

int ManualCompactHandle::type_ = TYR_MANUAL_COMPACT_REQUEST;

void ManualCompactHandle::SendResponse(uint32_t retcode, 
                                       const std::string& message) {
  ManualCompactHandlePtr this_ptr =
    std::dynamic_pointer_cast<ManualCompactHandle>(shared_from_this());
  loop_->RunInLoop(std::bind(&ManualCompactHandle::SendResponseInLoop,
                             this_ptr, retcode, message));
}

void ManualCompactHandle::SendResponseInLoop(uint32_t retcode, 
                                             const std::string& message) {
  TyrManualCompactResponse* resp = 
      response_.mutable_body()->MutableExtension(tyr_manual_compact_response);
  resp->mutable_rc()->set_retcode(retcode);
  resp->mutable_rc()->set_error_message(message);
  ULOG_DEBUG << response_.DebugString();
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void ManualCompactHandle::EntryInit(const ConnectionUeventPtr& conn, 
                                    const UMessagePtr& um) {
  conn_ = conn;
  ULOG_INFO << "recv connid=" << conn_->GetId() << ",msg=" << um->DebugString();
  assert(um->head().message_type() == type_);
  assert(um->body().HasExtension(tyr_manual_compact_request));

  MakeResponse(um.get(), TYR_MANUAL_COMPACT_RESPONSE, &response_);
  request_ = um;
  ManualCompactProcess(um);
}

void ManualCompactHandle::ManualCompactProcess(const UMessagePtr& um) {
  TyrManualCompactRequest req = 
      um->body().GetExtension(tyr_manual_compact_request);
  lc_id_ = req.lc_id();
  pg_id_ = req.pg_id();
  if (req.has_compact_type()) {
    compact_type_ = req.compact_type();
  }
  ULOG_INFO << "recv ManualCompact request:" << this->ToString();
  ManagerHandle* manager_handle = g_context->manager_handle();
  cluster::ClusterMap cluster_map = manager_handle->const_cluster_map();
  std::vector<PGInfoPb> pg_infos = cluster_map.pgs();
  if (req.pg_id() >= (uint32_t)pg_infos.size() ||
      req.pg_id() != pg_infos[req.pg_id()].id() ||
      (uint32_t)g_context->config().my_id() != 
          pg_infos[req.pg_id()].primary_chunk_id()) {
    ULOG_ERROR << "request migrate lc_id=" << lc_id_ << ",pg_id=" 
        << pg_id_ << ",param invalid.";
    SendResponse(EC_UDISK_PARAM_INVALID, "param invalid");
    return;
  }

  int32_t journal_enable = g_context->config().journal_enable();
  // 所有线程共用一个memtable，随机选择任意线程即可
  auto loop = g_context->io_listener()->GetOneLoop();
  auto clh = dynamic_cast<ChunkLoopHandle*>(loop->GetLoopHandle());
  JournalEngine* engine = clh->JournalEngine(req.pg_id());
  if (!journal_enable || !engine || !engine->IsInit()) {
    ULOG_ERROR << "request migrate lc_id=" << lc_id_ << ",pg_id=" << pg_id_ 
        << ",journal engine not init";
    SendResponse(EC_UDISK_PARAM_INVALID, "param invalid");
    return;
  }
  ULOG_DEBUG << "pg_id=" << req.pg_id() << ",lc_id=" << req.lc_id() 
      << ",thread=" << loop->thread_id();
  ManualCompactHandlePtr this_ptr =
    std::dynamic_pointer_cast<ManualCompactHandle>(shared_from_this());
  loop->RunInLoop(std::bind(&JournalEngine::DoManualCompactTask, engine, 
                            this_ptr, lc_id_, pg_id_));
  // compact结束之后在返回
  // SendResponse(0, "success");
}

