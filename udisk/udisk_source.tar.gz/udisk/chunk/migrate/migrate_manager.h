#ifndef UDISK_CHUNK_MIGRATE_MANAGER_H_
#define UDISK_CHUNK_MIGRATE_MANAGER_H_

#include <sstream>
#include <list>
#include <vector>
//#include <ustevent/disk_io_util.h>
#include <ustevent/libevent/listener_libevent.h>
#include <ustevent/libevent/eventloop_libevent.h>
#include <ustevent/libevent/connector_libevent.h>
#include <ustevent/callbacks.h>
#include <ustevent/base/obj_pool.h>
#include <ustevent/worker_thread.h>
#include "migrate_pc.h"
#include "udisk_time.h"
#include "flow_ctrl.h"
#include "io_error_container.h"
#include "pool/memory_pool.h"
#include "udisk_message.h"
#include "migrate_io_proto.h"
#include "msgr.h"
#include "message.h"

namespace udisk {
namespace chunk {

class OpRequest;
class ChunkHandle;
class ChunkLoopHandle;

struct MigrateEntry {
  MigrateEntry() = default;
  MigrateEntry(const ucloud::udisk::MigratePcMeta& local,
               const ucloud::udisk::MigratePcMeta& peer,
               const std::string& peer_ip,
               uint32_t peer_port,
               uint32_t peer_id,
               uint32_t size,
               MigratePCHandlePtr ptr) : peer_chunk_ip(peer_ip), 
      peer_chunk_port(peer_port), peer_chunk_id(peer_id), lc_size(size), 
      seqno(0), migrate_pc_handle(ptr), migrate_time(base::Timestamp::now()) {
    this->local.CopyFrom(local);
    this->peer.CopyFrom(peer);
  }
  ucloud::udisk::MigratePcMeta local;
  ucloud::udisk::MigratePcMeta peer;
  std::string peer_chunk_ip;
  uint32_t peer_chunk_port;
  uint32_t peer_chunk_id;
  uint32_t lc_size;
  uint64_t seqno;
  MigratePCHandlePtr migrate_pc_handle;
  base::Timestamp migrate_time;

  std::string ToString() const {
    std::stringstream ss;
    ss << "local=" << local.DebugString() << ",peer=" << peer.DebugString() 
        << ",peer_id=" << peer_chunk_ip << ",seqno=" << seqno;
    return ss.str();
  }

  bool PcEqual(const ucloud::udisk::MigratePcMeta& local,
               const ucloud::udisk::MigratePcMeta& peer) {
    return PcEqual(local.lc_id(), local.lc_random_id(), 
                   local.pc_no(), peer.pc_no());
  }

  bool PcEqual(uint32_t lc_id, uint32_t lc_random_id, 
               uint32_t pc_no, uint32_t peer_pc_no) {
    if (lc_id == local.lc_id() && 
        lc_random_id == local.lc_random_id() && 
        pc_no == local.pc_no() &&
        peer_pc_no == peer.pc_no()) {
      return true;
    } else {
      return false;
    }
  }
};

struct MigrateKey {
  MigrateKey() :local_pc_no(UINT32_MAX), peer_pc_no(UINT32_MAX) {
  }
  MigrateKey(uint32_t my_pc, uint32_t peer_pc): 
    local_pc_no(my_pc), peer_pc_no(peer_pc) {
  }
  bool operator == (const MigrateKey& key) const {
    return (local_pc_no == key.local_pc_no && 
            peer_pc_no == key.peer_pc_no);
  }
  bool operator < (const MigrateKey& key) const {
    uint64_t value = ((uint64_t)local_pc_no << 32) | peer_pc_no;
    uint64_t peer_value = ((uint64_t)key.local_pc_no << 32) | key.peer_pc_no;
    return value < peer_value;
  }
  std::string ToString() const {
    std::stringstream ss;
    ss << "local_pc_no=" << local_pc_no << ",peer_pc_no=" << peer_pc_no; 
    return ss.str();
  }
  uint32_t local_pc_no;
  uint32_t peer_pc_no;
};

typedef std::list<MigrateEntry> MigrateEntryList;
typedef std::map<MigrateKey, MigrateEntry> MigrateEntryMap;

class MigrateManager {
 public:
  MigrateManager(ChunkLoopHandle* clh);
  virtual ~MigrateManager();

  void Init();
  void Start(const std::string &ip, int port);
  void SyncMigrateDataProcess(const ucloud::udisk::MigratePcMeta& local,
                              const ucloud::udisk::MigratePcMeta& peer,
                              uint32_t peer_chunk_id,
                              std::string peer_chunk_ip,
                              uint32_t peer_chunk_port,
                              uint32_t lc_size,
                              MigratePCHandlePtr migrate_pc_handle); 

  void CheckMigratePCState();

  void DoMigratePcResponse(const common::MigrateHead* migrate_hdr);

  // 迁移journal相关
  int DoMigrateJournalRemoteRequest(OpRequest* op, 
                               const IOMeta& meta, 
                               uint32_t pg_id,
                               uint32_t lc_size,
                               const ucloud::udisk::MigratePcMeta& migrate_pc);
  void DoMigrateRemoteResponse(const common::MigrateHead* hdr);
  void BuildMigrateJournalRemoteRequest(common::MessageHeader* msg_hdr, 
                                uint64_t seqno,
                                const IOMeta& meta, 
                                uint32_t pg_id,
                                uint32_t lc_size, 
                                const ucloud::udisk::MigratePcMeta& migrate_pc,
                                uint8_t cmd);
  int ReplicaRemoteRequest(OpRequest* op, 
                           const ucloud::udisk::MigratePcMeta& migrate_pc,
                           uevent::ConnectorUeventPtr& ctor);
 private:
  void WaitTokenTimerCb(ChunkHandle* handle, OpRequest* op, uint32_t pg_id);
  bool DoLocal(ChunkHandle* handle, OpRequest* op, uint32_t pg_id);
  int SubmitReadLocal(ChunkHandle *handle, uint32_t offset,
                      uint32_t len, OpRequest* op, uint32_t pg_id); 
  void LocalAioCb(int retcode, 
                  void* arg, 
                  uint64_t offset, 
                  uint64_t len,
                  OpRequest* op,
                  uint32_t pg_id);
  void OpenChunkResCb(int retcode, ChunkHandle* handle, OpRequest* op, uint32_t pg_id);
  int SyncMigrateDataRequest(OpRequest* op, const MigrateEntry& entry);
  bool SendMsg(const char *msg, 
               size_t len, 
               const uevent::UsockAddress& addr);

  void BuildMigratePCRequest(common::MessageHeader* msg_hdr, 
                             uint64_t op_seq, 
                             uint32_t lc_size,
                             const ucloud::udisk::MigratePcMeta& local,
                             const ucloud::udisk::MigratePcMeta& peer); 
  void SendMigratePCRequest(const MigrateKey& key);
  void SendNextMigratePC();
 
  void ReportLCIOError();
   
  ChunkLoopHandle* loop_handle_;
  std::unique_ptr<TokenBucket> token_bucket_;

  MigrateEntryMap migrating_list_;
  MigrateEntryList pending_list_;
  struct pairhash {
   public:
    template <typename T, typename U>
    std::size_t operator()(const std::pair<T, U> &x) const {
      return std::hash<T>()(x.first) ^ std::hash<U>()(x.second);
    }
  };
  // pg_id+seqno 作为key， pg内seqno唯一，不同pg内seqno可能相同
  std::unordered_map<std::pair<uint32_t, uint64_t>, MigrateKey, pairhash> op_keys_;
  std::unordered_map<std::pair<uint32_t, uint64_t>, OpRequest*, pairhash> inflying_list_;

  // io 读写错误统计 
  IOErrorContainer io_error_container_;
  uint8_t last_version_;
};

}; // end of ns chunk
}; // end of ns udisk

#endif
