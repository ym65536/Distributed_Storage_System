#ifndef UDISK_MIGRATE_JOURNAL_HANDLE_H_
#define UDISK_MIGRATE_JOURNAL_HANDLE_H_

#include <atomic>
#include <set>
#include <ustevent/pb_request_handle.h>
#include <ucloud.pb.h>

namespace udisk {
namespace chunk {

class MigrateJournalHandle: public uevent::PbRequestHandle {
 public:
  explicit MigrateJournalHandle(uevent::EventLoop* loop): loop_(loop)  {
  }
  virtual ~MigrateJournalHandle() {
  }
  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         const uevent::UMessagePtr& um);
 
  void MigrateJournalProcess(const uevent::UMessagePtr& um);

  MYSELF_CREATE(MigrateJournalHandle);

  void SendResponse(uint32_t retcode, const std::string& message); 
  void SendResponseInLoop(uint32_t retcode, const std::string& message);
   
 private:
  uevent::EventLoop* loop_;
  static int type_;
  uevent::ConnectionUeventPtr conn_;
  uevent::UMessagePtr request_;
  ucloud::UMessage response_;
};

typedef std::shared_ptr<MigrateJournalHandle> MigrateJournalHandlePtr;
}
}
#endif

