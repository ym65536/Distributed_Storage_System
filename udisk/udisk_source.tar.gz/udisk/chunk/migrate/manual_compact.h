#ifndef UDISK_MANUAL_COMPACT_HANDLE_H_
#define UDISK_MANUAL_COMPACT_HANDLE_H_

#include <atomic>
#include <set>
#include <ustevent/pb_request_handle.h>
#include <ucloud.pb.h>

namespace udisk {
namespace chunk {

class ManualCompactHandle: public uevent::PbRequestHandle {
 public:
  explicit ManualCompactHandle(uevent::EventLoop* loop): loop_(loop) {
    ULOG_DEBUG << "manual compact construct. my loop=" << loop_;
  }
  virtual ~ManualCompactHandle() {
    ULOG_DEBUG << "manual compact destruct. my loop=" << loop_ << ",msg="
        << ToString();
  }
  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         const uevent::UMessagePtr& um);
 
  void ManualCompactProcess(const uevent::UMessagePtr& um);

  MYSELF_CREATE(ManualCompactHandle);

  void SendResponse(uint32_t retcode, const std::string& message); 

  int CompactTimes() const {
    return compact_times_;
  }

  void IncCompactTimes() {
    ++ compact_times_;
  }

  ucloud::udisk::ManualCompactType CompactType() const {
    return compact_type_;
  }

  uint32_t LcId() const {
    return lc_id_;
  }

  uint32_t PgId() const {
    return pg_id_;
  }

  std::string ToString() const {
    std::stringstream ss;
    ss << "lc_id=" << lc_id_ << ",pg_id=" << pg_id_ << ",compact_times=" 
        << compact_times_ << ",compact_type=" << compact_type_;
    return ss.str();
  }
   
 private:
  void SendResponseInLoop(uint32_t retcode, 
                          const std::string& message);

  uevent::EventLoop* loop_;
  static int type_;
  uevent::ConnectionUeventPtr conn_;
  uevent::UMessagePtr request_;
  ucloud::UMessage response_;

  uint32_t lc_id_ = UINT32_MAX;
  uint32_t pg_id_ = UINT32_MAX;
  int compact_times_ = 0;
  ucloud::udisk::ManualCompactType compact_type_ = ucloud::udisk::ManualCompactNormal;
};

typedef std::shared_ptr<ManualCompactHandle> ManualCompactHandlePtr;

}
}
#endif

