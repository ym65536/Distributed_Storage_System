#include <ustevent/message_util.h>
#include <ustevent/connection_uevent.h>
#include <ustevent/base/logging.h>
#include "chunk_context.h"
#include "manager_handle.h"
#include "migrate_manager.h"
#include "chunk_loop_handle.h"
#include "cluster_map.h"
#include "migrate_pc.h"

using namespace udisk::chunk;
using namespace ucloud::udisk;
using namespace uevent;

int MigratePCHandle::type_ = TYR_CHUNK_MIGRATE_PC_REQUEST;

void MigratePCHandle::EntryInit(const ConnectionUeventPtr& conn, 
                                const UMessagePtr& um) {
  conn_ = conn;
  ULOG_INFO << "recv conn_id=" << conn_->GetId() << ",msg " << um->DebugString();
  assert(um->head().message_type() == type_);
  assert(um->body().HasExtension(tyr_chunk_migrate_pc_request));
  MakeResponse(um.get(), TYR_CHUNK_MIGRATE_PC_RESPONSE, &response_);
  const auto& req = um->body().GetExtension(tyr_chunk_migrate_pc_request);
  peer_migrate_pc_.CopyFrom(req.peer());
  local_migrate_pc_.CopyFrom(req.local());
  // 处理迁移请求
  ChunkBeginMigratePcProcess(req);
}

void MigratePCHandle::SendResponse(uint32_t retcode, 
    const std::string& message) {
  TyrChunkMigratePcResponse* resp = 
      response_.mutable_body()->MutableExtension(tyr_chunk_migrate_pc_response);
  resp->mutable_rc()->set_retcode(retcode);
  resp->mutable_rc()->set_error_message(message);
  ULOG_DEBUG << response_.DebugString();
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void MigratePCHandle::ChunkBeginMigratePcProcess(
                                          const TyrChunkMigratePcRequest& req) {
  ManagerHandle* manager_handle = g_context->manager_handle();
  cluster::ClusterMap cluster_map = manager_handle->const_cluster_map();
  std::vector<PGInfoPb> pg_infos = cluster_map.pgs();
  uint32_t pg_id = local_migrate_pc_.pg_id(); 
  if (pg_id >= (uint32_t)pg_infos.size() || pg_infos[pg_id].id() != pg_id) {
    ULOG_ERROR << "Recv pg_id error. pg_id=" << pg_id;
    SendResponse(EC_UDISK_PARAM_INVALID, "input pg_id error");
    return;
  }
  if (pg_infos[pg_id].primary_chunk_id() != 
      static_cast<uint32_t>(g_context->config().my_id())) { 
    ULOG_ERROR << "migrate failed,I am not primary chunk of pg:" << pg_id
        << " chunk id:" << g_context->config().my_id();
    SendResponse(EC_UDISK_PARAM_INVALID, 
                 "migrate failed, I am not primary chunk of pg:" + pg_id);
    return;
  }
  // 随机选择一个io loop 进行迁移
  uevent::EventLoop* io_loop = g_context->io_listener()->GetOneLoop();
  ChunkLoopHandle* clh = dynamic_cast<ChunkLoopHandle*>(io_loop->GetLoopHandle());
  // primary chunk, 通知migrate handle开始迁移数据，迁移完毕后回复
  ULOG_DEBUG << "Send migrate pc to thread=" << io_loop->thread_id() 
      << ",local_pc=" << local_migrate_pc_.DebugString();
  std::shared_ptr<MigratePCHandle> this_ptr =
    std::dynamic_pointer_cast<MigratePCHandle>(shared_from_this());
  // 发送给migrate thread 开始迁移
  io_loop->RunInLoop(
    std::bind(&MigrateManager::SyncMigrateDataProcess, clh->migrate_manager(),
                local_migrate_pc_, peer_migrate_pc_, req.peer_chunk_id(), 
                req.peer_chunk_ip(), req.peer_chunk_port(), req.lc_size(),
                this_ptr), 
              true);
  timer_id_ = loop_->RunAfter(g_context->config().migrate_timeout(), 
                        std::bind(&MigratePCHandle::MigrateTimeout, this_ptr));
}

void MigratePCHandle::MigrateResponse(uint32_t retcode, 
                                      const std::string& message) {
  std::shared_ptr<MigratePCHandle> this_ptr =
    std::dynamic_pointer_cast<MigratePCHandle>(shared_from_this());
  loop_->RunInLoop(std::bind(&MigratePCHandle::MigrateResponseInLoop,
                             this_ptr, retcode, message));
}

void MigratePCHandle::MigrateResponseInLoop(uint32_t retcode, 
                                            const std::string& msg) {
  if (retcode != 0) {
    ULOG_ERROR << "migrate pc error.ret=" << retcode << ",msg=" << msg 
        << ",migrate_pc=" << local_migrate_pc_.DebugString();
    SendResponse(retcode, msg);
    return;
  }
  ULOG_INFO << "migrate pc success,info=" << local_migrate_pc_.DebugString();
  loop_->CancelTimer(timer_id_);
  SendResponse(0, "success");
  return;
}

void MigratePCHandle::MigrateTimeout() {
  ULOG_ERROR << "migrate pc timeout.info=" << local_migrate_pc_.DebugString();
  SendResponse(EC_UDISK_MIGRATE_TIMEOUT, "migrate pc timeout");
  return;
}

