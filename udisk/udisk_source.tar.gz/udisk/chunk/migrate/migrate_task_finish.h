#ifndef UDISK_MIGRATE_TASK_FINISH_HANDLE_H_
#define UDISK_MIGRATE_TASK_FINISH_HANDLE_H_

#include <atomic>
#include <set>
#include <ustevent/pb_request_handle.h>
#include <ucloud.pb.h>

namespace udisk {
namespace chunk {

class MigrateTaskFinishHandle: public uevent::PbRequestHandle {
 public:
  explicit MigrateTaskFinishHandle(uevent::EventLoop* loop): loop_(loop) {
  }
  virtual ~MigrateTaskFinishHandle() {
  }
  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         const uevent::UMessagePtr& um);
 
  void MigrateTaskFinishProcess(const uevent::UMessagePtr& um);

  MYSELF_CREATE(MigrateTaskFinishHandle);

  void SendResponse(uint32_t retcode, const std::string& message); 
   
 private:
  void SendResponseInLoop(uint32_t retcode, 
                          const std::string& message);

  uevent::EventLoop* loop_;
  static int type_;
  static uint32_t selector_;
  uevent::ConnectionUeventPtr conn_;
  uevent::UMessagePtr request_;
  ucloud::UMessage response_;
};

typedef std::shared_ptr<MigrateTaskFinishHandle> MigrateTaskFinishHandlePtr;

}
}
#endif

