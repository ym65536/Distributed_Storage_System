#ifndef REMOVE_HOST_BLACKLIST_H_
#define REMOVE_HOST_BLACKLIST_H_

#include <ustevent/pb_request_handle.h>
#include "udisk_message.h"
//#include "uevent.h"
//#include "connector_libevent.h"
//#include "eventloop_libevent.h"
//#include "logging.h"
//#include "thread.h"
//#include "pb_request_handle.h"
//#include "message_util.h"
//#include "my_uuid.h"
//#include "chunk_context.h"

using namespace uevent;

namespace udisk {
namespace chunk {

class RemoveHostBlacklistHandle : public uevent::PbRequestHandle {
 public:
  explicit RemoveHostBlacklistHandle(uevent::EventLoop* loop) : loop_(loop) {}
  virtual ~RemoveHostBlacklistHandle() {}
  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn, const uevent::UMessagePtr& um);

  MYSELF_CREATE(RemoveHostBlacklistHandle);

 private:
  static int type_;
  uevent::EventLoop* loop_;
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage response_;
  ucloud::udisk::RemoveHostBlacklistResponse* resp_body_;
};

}  // ns chunk
}  // ns udisk
#endif
