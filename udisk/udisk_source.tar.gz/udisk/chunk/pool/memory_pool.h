//
// Created by lizgao on 9/18/18.
//

#ifndef UDISK_MEMORY_POOL_H
#define UDISK_MEMORY_POOL_H
#include <cstdint>
#include <map>
#include <memory>
#include <vector>
#include "memory_slab.h"
namespace udisk {
namespace chunk {

class MemoryPool {
 public:
  MemoryPool();
  ~MemoryPool();
 public:
  std::pair<void *, MemorySlab *> Malloc(int size, int alignment);
  void Free(void *ptr, MemorySlab *slab);
 private:
  bool AddSlab(int chunk_size, int chunk_cnt);
 private:
 private:
  std::vector<std::unique_ptr<MemorySlab>> slab_list_; // sorted list

};
}
}
#endif //UDISK_MEMORY_POOL_H
