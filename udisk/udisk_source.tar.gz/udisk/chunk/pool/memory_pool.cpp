//
// Created by lizgao on 9/18/18.
//

#include "memory_pool.h"
#include <algorithm>
#include <ustevent/base/logging.h>
namespace udisk {
namespace chunk {

MemoryPool::MemoryPool() {
  auto result = AddSlab(4 * 1024, 1024)
      && AddSlab(8 * 1024, 1024)
      && AddSlab(16 * 1024, 1024)
      && AddSlab(32 * 1024, 1024)
      && AddSlab(64 * 1024, 1024)
      && AddSlab(128 * 1024, 1024)
      && AddSlab(256 * 1024, 1024)
      && AddSlab(512 * 1024, 1024)
      && AddSlab(1024 * 1024, 128);
  if (!result) {
    ULOG_ERROR << "MemoryPool Init Failed!";
    return;
  }
}

MemoryPool::~MemoryPool() {

}

std::pair<void *, MemorySlab *> MemoryPool::Malloc(int size, int alignment) {

  auto result = std::pair<void *, MemorySlab *>(nullptr, nullptr);
  for (auto &slab : slab_list_) {
    if (slab->chunk_size() >= size && slab->chunk_size() % alignment == 0) {
      result.first = slab->Malloc();
      result.second = slab.get();
      break;
    }
  }
  if (!result.first) {
    posix_memalign(&result.first, alignment, size);
    result.second = nullptr;
    ULOG_WARN << "Memory pool malloc fail, apply posix_memalign! size="
              << size << ", alignment=" << alignment;
  }
  return result;
}

void MemoryPool::Free(void *ptr, MemorySlab *slab) {
  if (slab) {
    slab->Free(ptr);
  } else {
    free(ptr);
  }
}

bool MemoryPool::AddSlab(int chunk_size, int chunk_cnt) {
  auto it_exist = std::find_if(slab_list_.begin(), slab_list_.end(),
                               [chunk_size](std::unique_ptr<MemorySlab> &slab) {
                                 return slab->chunk_size() == chunk_size;
                               });
  if (it_exist != slab_list_.end()) {
    ULOG_ERROR << "MemorySlab with same size " << chunk_size << " already exists!";
    return false;
  }
  auto slab = std::unique_ptr<MemorySlab>(new MemorySlab(chunk_size, chunk_cnt, false));

  auto it = std::find_if(slab_list_.begin(), slab_list_.end(),
                         [chunk_size](std::unique_ptr<MemorySlab> &slab) {
                           return slab->chunk_size() > chunk_size;
                         });
  if (it == slab_list_.end()) {
    slab_list_.emplace_back(std::move(slab));
  } else {
    slab_list_.insert(it, std::move(slab));
  }

  return true;
}

}
}