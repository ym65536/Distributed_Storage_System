//
// Created by lizgao on 9/18/18.
//

#ifndef UDISK_I_SLAB_H
#define UDISK_I_SLAB_H
#include <cstdint>
namespace udisk {
namespace chunk {

class MemorySlab {
 public:
  MemorySlab(int chunk_size, int chunk_cnt, bool enable_huge_page = false);
  ~MemorySlab();

  MemorySlab(const MemorySlab &) = delete;
  MemorySlab &operator=(const MemorySlab &) = delete;
 public:
  void *Malloc();
  void Free(void *ptr);
  int chunk_size() const { return chunk_size_; }
  int chunk_cnt() const { return chunk_cnt_; }

 private:
  int chunk_size_;
  int chunk_cnt_;
  bool enable_huge_page_;
  void **free_list_ = nullptr;
  int free_list_size_ = 0;
  void *mem_start_ = nullptr;
};

}
}
#endif //UDISK_I_SLAB_H
