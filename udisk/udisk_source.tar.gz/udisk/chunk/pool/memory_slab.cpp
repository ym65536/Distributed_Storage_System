//
// Created by lizgao on 9/19/18.
//

#include "memory_slab.h"
#include <cstdlib>
#include <sys/mman.h>
#include <ustevent/base/logging.h>
namespace udisk {
namespace chunk {

MemorySlab::MemorySlab(int chunk_size, int chunk_cnt, bool enable_huge_page)
    : chunk_size_(chunk_size), chunk_cnt_(chunk_cnt), enable_huge_page_(enable_huge_page) {
  free_list_ = (void **) malloc(chunk_cnt_ * sizeof(void *));
  int flags = MAP_PRIVATE | MAP_ANONYMOUS;
  if (enable_huge_page_) {
    flags |= MAP_HUGETLB;
  }
  mem_start_ = mmap(NULL, chunk_size_ * chunk_cnt_, PROT_READ | PROT_WRITE, flags, -1, 0);
  if (mem_start_ == MAP_FAILED) {
    ULOG_SYSERR << "Failed to mmap, size=" << chunk_size_ << "*" << chunk_cnt_;
    mem_start_ = nullptr;
    return;
  }
  for (int i = 0; i < chunk_cnt_; ++i) {
    free_list_[free_list_size_++] = (char *) mem_start_ + chunk_size_ * i;
  }
}

MemorySlab::~MemorySlab() {
  if (free_list_) {
    free(free_list_);
  }
  if (mem_start_) {
    munmap(mem_start_, chunk_size_ * chunk_cnt_);
  }
}
void *MemorySlab::Malloc() {
  if (free_list_size_ == 0) {
    return nullptr;
  }
  return free_list_[--free_list_size_];
}

void MemorySlab::Free(void *ptr) {
  free_list_[free_list_size_++] = ptr;
}

}
}