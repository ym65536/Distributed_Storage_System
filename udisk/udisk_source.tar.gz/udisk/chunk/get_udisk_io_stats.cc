#include <ustevent/message_util.h>
#include <ustevent/connection_uevent.h>
#include <ustevent/base/logging.h>
#include "chunk_context.h"
#include "manager_handle.h"
#include "get_udisk_io_stats.h"

namespace udisk {
namespace chunk {
 
int GetUDiskIOStatsHandle::type_ = ucloud::udisk::CHUNK_GET_UDISKS_IO_STATS_REQUEST;

void GetUDiskIOStatsHandle::EntryInit(const uevent::ConnectionUeventPtr& conn, 
                                      const uevent::UMessagePtr& um) {
  ULOG_INFO << "protobuf recv conn_id=" << conn->GetId() << ", msg " << um->DebugString();
  conn_ = conn;
  assert(um->head().message_type() == type_);
  assert(um->body().HasExtension(ucloud::udisk::chunk_get_udisks_io_stats_request));

  const ucloud::udisk::ChunkGetUDisksIOStatsRequest &req_body = 
    um->body().GetExtension(ucloud::udisk::chunk_get_udisks_io_stats_request);
  MakeResponse(um.get(), ucloud::udisk::CHUNK_GET_UDISKS_IO_STATS_RESPONSE, &response_);
  resp_body_ = response_.mutable_body()->
    MutableExtension(ucloud::udisk::chunk_get_udisks_io_stats_response);

  g_context->manager_handle()->FillChunkGetUDisksIOStatsResponse(&req_body,
      resp_body_);
  
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

}
}
