#include "remove_host_blacklist.h"
#include <ustevent/message_util.h>
#include <ustevent/connection_uevent.h>
#include <ustevent/base/logging.h>
#include "chunk_context.h"
#include "manager_handle.h"
#include "umessage_common.h"

namespace udisk {
namespace chunk {

using namespace uevent;

int RemoveHostBlacklistHandle::type_ =
    ucloud::udisk::REMOVE_HOST_BLACKLIST_REQUEST;

void RemoveHostBlacklistHandle::EntryInit(const uevent::ConnectionUeventPtr& conn,
                                          const uevent::UMessagePtr& um) {
  ULOG_INFO << "protobuf recv conn_id=" << conn->GetId() << ", msg "
            << um->DebugString();
  conn_ = conn;
  assert(um->head().message_type() == type_);
  assert(um->body().HasExtension(ucloud::udisk::remove_host_blacklist_request));

  const ucloud::udisk::RemoveHostBlacklistRequest& req_body =
      um->body().GetExtension(ucloud::udisk::remove_host_blacklist_request);
  MakeResponse(um.get(), ucloud::udisk::REMOVE_HOST_BLACKLIST_RESPONSE, &response_);
  resp_body_ = response_.mutable_body()->MutableExtension(
      ucloud::udisk::remove_host_blacklist_response);

  for (int i = 0; i < req_body.items_size(); ++i) {
    g_context->io_listener()->RemoveSrcIpBlacklist(req_body.items(i).ip());
  }

  resp_body_->mutable_rc()->set_retcode(0);
  resp_body_->mutable_rc()->set_error_message("success");

  MessageUtil::SendPbResponse(conn_, response_);
}

}  // ns chunk
}  // ns udisk
