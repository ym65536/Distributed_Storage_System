#ifndef UDISK_CHUNK_RECYCLE_PC_H
#define UDISK_CHUNK_RECYCLE_PC_H

#include <ustevent/pb_request_handle.h>
#include "udisk_message.h"

namespace udisk {
namespace chunk {

class RecyclePCHandle: public uevent::PbRequestHandle {
public:
  explicit RecyclePCHandle(uevent::EventLoop* loop) {}
  virtual ~RecyclePCHandle() {}

  MYSELF_CREATE(RecyclePCHandle);

  void SendResponse(uint32_t retcode, const char* message);
  
  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         const uevent::UMessagePtr& um);
  void EntryRecyclePC(int recode, std::string msg);  
  
  void RecyclePC();
private:
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage response_;
  ucloud::udisk::ChunkRecyclePCRequest req_;
  std::string session_no_;
};

}; // end of ns chunk
}; // end of ns udisk

#endif
