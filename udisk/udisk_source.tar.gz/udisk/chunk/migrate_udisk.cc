#include <ustevent/message_util.h>
#include <ustevent/connection_uevent.h>
#include <ustevent/base/logging.h>
#include "chunk_context.h"
#include "manager_handle.h"
#include "migrate_udisk.h"

namespace udisk {
namespace chunk {
 
int MigrateUDiskHandle::type_ = ucloud::udisk::CHUNK_MIGRATE_UDISK_REQUEST;

void MigrateUDiskHandle::EntryInit(const uevent::ConnectionUeventPtr& conn,
                                   const uevent::UMessagePtr& um) {
  ULOG_INFO << "protobuf recv conn_id=" << conn->GetId() << ", msg " << um->DebugString();
  conn_ = conn;
  assert(um->head().message_type() == type_);
  assert(um->body().HasExtension(ucloud::udisk::chunk_migrate_udisk_request));

  ucloud::udisk::ChunkMigrateUDiskRequest req_body = 
    um->body().GetExtension(ucloud::udisk::chunk_migrate_udisk_request);
  MakeResponse(um.get(), ucloud::udisk::CHUNK_MIGRATE_UDISK_RESPONSE, &response_);
  resp_body_ = 
    response_.mutable_body()->MutableExtension(ucloud::udisk::chunk_migrate_udisk_response);

  g_context->manager_handle()->MigrateUDisk(req_body.lc_id(),
        req_body.thread_name());
  
  resp_body_->mutable_rc()->set_retcode(0);
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

}
}
