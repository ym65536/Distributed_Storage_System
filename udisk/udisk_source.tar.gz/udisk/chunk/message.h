#ifndef UDISK_CHUNK_MESSAGE_H_
#define UDISK_CHUNK_MESSAGE_H_

#include "msgr.h"
#include "gate_io_proto.h"
#include "chunk_io_proto.h"
#include "ark_io_proto.h"
#include "migrate_io_proto.h"
#include "hela_io_proto.h"

namespace udisk {
namespace chunk {

inline std::string FormatChunkIOReq(const struct common::ChunkIORequestHead& head) {
    std::ostringstream oss;
    oss << "{size: " << head.size
        << ", version: " << (uint32_t)head.version
        << ",cmd: " << (uint32_t)head.cmd
        << ",flowno: " << head.flowno
        << ",replica_no: " << (uint32_t)head.replica_no
        << ",offset: " << head.offset
        << ",length: " << head.length
        << ",lc_id: " << head.lc_id
        << ",lc_size: " << head.lc_size
        << ",pc_no: " << head.pc_no
        << ",pg_id: " << head.pg_id
        << ",route_version: " << head.route_version
        << ",magic: " << head.magic << "}";
    return oss.str();
}

inline std::string FormatChunkIORes(const struct common::ChunkIOResponseHead& head) {
    std::ostringstream oss;
    oss << "{size: " << head.size <<
           ", version: " << (uint32_t)head.version <<
           ", cmd: " << (uint32_t)head.cmd  <<
           ", flowno: " << head.flowno <<
           ", replica_no: " << (uint32_t)head.replica_no <<
           ", lc_id: " << head.lc_id <<
           ", lc_size: " << head.lc_size <<
           ", pc_no: " << head.pc_no <<
           ", pg_id: " << head.pg_id <<
           ", route_version: " << head.route_version <<
           ", retcode: " << head.retcode <<
           ", magic: " << head.magic << "}";
    return oss.str();
}
inline std::string FormatGateIOReq(const struct common::GateIORequestHead& head) {
  std::ostringstream oss;
  oss << "{size: " << head.size <<
         ", version: " << (uint32_t)head.version <<
         ", cmd: " << (uint32_t)head.cmd  <<
         ", flowno: " << head.flowno <<
         ", fragno: " << head.fragno <<
         ", offset: " << head.offset <<
         ", length: " << head.length <<
         ", lc_id: " << head.lc_id <<
         ", pc_no: " << head.pc_no <<
         ", pg_id: " << head.pg_id <<
         ", route_version: " << head.route_version <<
         ", magic: " << head.magic << "}";
  return oss.str();
}

inline std::string FormatGateIORes(const struct common::GateIOResponseHead& head) {
  std::ostringstream oss;
  oss << "{size: " << head.size <<
         ", version: " << (uint32_t)head.version <<
         ", cmd: " << (uint32_t)head.cmd  <<
         ", flowno: " << head.flowno <<
         ", fragno: " << head.fragno <<
         ", lc_id: " << head.lc_id <<
         ", pc_no: " << head.pc_no <<
         ", route_version: " << head.route_version <<
         ", retcode: " << head.retcode <<
         ", magic: " << head.magic << "}";
  return oss.str();
}

class ChunkLoopHandle;
struct AioCbArgs {
  ChunkLoopHandle *loop_handle = nullptr;
  uint32_t lc_id= 0;
  uint32_t pg_id = 0;
  uint64_t op_seq = 0;
};

// [start, end)
struct Interval {
  int start;
  int end;
  Interval() : start(0), end(0) {}
  Interval(int s, int e) : start(s), end(e) {}
};

struct IOMeta {
  IOMeta(uint32_t lc,
         uint32_t random, 
         uint32_t pc,
         uint64_t off,
         uint64_t len)
      : lc_id(lc),
        random_id(random), 
        pc_no(pc),
        offset(off),
        length(len) {
        }
  IOMeta() {
  }
  uint32_t lc_id;
  uint32_t random_id;
  uint32_t pc_no;
  uint64_t offset;
  uint64_t length;

  std::string ToString() const {
    std::ostringstream oss;
    oss << "lc_id=" << lc_id << ", random_id=" << random_id <<", pc_no=" 
        << pc_no << ", offset=" << offset << ", length=" << length;
    return oss.str();
  }
} __attribute__((packed));

static const uint32_t MAX_PG_NUM = 4096;

}; // end of ns chunk
}; // end of ns udisk

#endif
