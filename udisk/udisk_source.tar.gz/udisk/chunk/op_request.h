#ifndef UDISK_CHUNK_OP_REQUEST_H_
#define UDISK_CHUNK_OP_REQUEST_H_


#include <stdlib.h>
#include <assert.h>
#include <memory>
#include <vector>
#include <bitset>

#include <ustevent/timer.h>
#include <ustevent/callbacks.h>
#include <ustevent/base/obj_pool.h>
#include "message.h"
#include "udisk_time.h"
#include "chunk_storage.h"
#include "journal_format.h"
#include "pool/memory_pool.h"

namespace udisk {
namespace chunk {

class ChunkStorage;

class OpRequest {
 public:
  OpRequest(uint64_t seq,
            const uevent::ConnectionUeventPtr& conn,
            const common::MessageHeader *msg_hdr,
            const char *msg_data,
            uint32_t date_len,
            uint32_t cmd,
            uint32_t pg_id, base::ObjPool<OpRequest> &pool,
            MemoryPool *mem_pool, MemorySlab *mem_slab, MemorySlab *msg_header_slab) :
    op_seq_(seq),
    conn_(conn),
    msg_hdr_(msg_hdr),
    msg_data_(msg_data),
    msg_data_ref_(1),
    date_len_(date_len),
    cmd_(cmd),
    pg_id_(pg_id),
    read_buffer_(nullptr),
    mem_buffer_(nullptr),
    replica_chunk_ids_(common::kReplicaNum + 1, 0),
    replicas_bit_set_(),
    replicas_retcode_(0),
    timeout_(false),
    refs_(1), 
    pool_(pool), 
    mem_pool_(mem_pool), mem_slab_(mem_slab),
    msg_header_slab_(msg_header_slab) {
  }

  OpRequest(const OpRequest &) = delete;
  OpRequest &operator=(const OpRequest &) = delete;

  ~OpRequest();

  void set_read_buffer(char *buff, MemoryPool *mem_pool, MemorySlab *mem_slab) {
    // 只允许一次read buffer设置
    assert(!read_buffer_);
    read_buffer_ = buff;
    mem_pool_ = mem_pool;
    mem_slab_ = mem_slab;
  }

  // 这里mem_pool必须和set_read_buffer中的一致
  void set_mem_buffer(char *buff, MemoryPool *mem_pool, MemorySlab *mem_slab) {
    // 只允许一次mem buffer设置
    assert(!mem_buffer_);
    assert(mem_pool_ == mem_pool);
    mem_buffer_ = buff;
    mem_buf_slab_ = mem_slab;
  }

  void set_msg_hdr(const common::MessageHeader *msg_hdr) {
    assert(!msg_hdr_);
    msg_hdr_ = msg_hdr;
  } 

  const char* read_buffer() const {
    return read_buffer_;
  }

  char* mutable_read_buffer() {
    return read_buffer_;
  }

  const char* mem_buffer() const {
    return mem_buffer_;
  }

  const common::MessageHeader *msg_hdr() const {
    return msg_hdr_;
  }

  const char *msg_data() const {
    return msg_data_;
  }

  const char *sub_msg_hdr_offset() const {
    return ((const char*)msg_hdr_ + sizeof(common::MessageHeader));
  }

  uint8_t msg_type() const {
    return msg_hdr_->msg_type;
  }

  const uevent::ConnectionUeventPtr& conn() const {
    return conn_;
  }
  uint64_t op_seq() const {
    return op_seq_;
  }
  uint32_t retcode() {
    return replicas_retcode_;
  }
  uint32_t data_len() const {
    return date_len_;  
  }
  uint32_t cmd() const {
    return cmd_;
  }
  uint32_t pg_id() const {
    return pg_id_;
  }
  void set_retcode(int idx, int retcode) {
    replicas_retcode_ |= retcode << (idx * 8);
  }
  uint32_t GetChunkId(int idx) {
    return replica_chunk_ids_[idx];
  }
  void mark_replica_waiting(int idx, uint32_t chunk_id) {
    assert(idx < (int)replica_chunk_ids_.size());
    replica_chunk_ids_[idx] = chunk_id;
    replicas_bit_set_[idx] = true;
  }
  
  // 所有副本请求都被接收返回true
  bool mark_replica_received(int idx, int retcode) {
    assert(idx < (int)replica_chunk_ids_.size());
    replicas_bit_set_[idx] = false;
    replicas_retcode_ |= retcode << (idx * 8);
    if (idx == 0) {
      aio_ack_time_ = timer_count_;
    } else {
      if (timer_count_ > rep_ack_time_) {
        rep_ack_time_ = timer_count_;
      }
    }
    return replicas_bit_set_.none(); // 全为0 表示收到了所有的分片
  }

  // 返回值大于0，则说明超时
  int IncTimerCount();

  // false表示io未下发情况超时，例如pending_list内超时
  void TimeoutCb(bool dispatched = true);

  int latency() const {
    return timer_count_;
  }

  int aio_latency() const {
    return aio_ack_time_;
  }

  int rep_latency() const {
    return rep_ack_time_;
  }

  std::string trace_tag() const;

  void set_timeout(bool timeout) {
    timeout_ = timeout;
  }

  bool timeout() const {
    return timeout_;
  }

  void IncRefs() {
    refs_++;
    ULOG_DEBUG << "seqno=" << op_seq_ << " inc ref, now_ref=" << refs_; 
  }
  // 释放返回true
  bool DecRefs() {
    ULOG_DEBUG << "seqno=" << op_seq_ << " dec ref, now_ref=" << refs_ - 1; 
    if (--refs_ == 0) {
      pool_.Free(this);
      return true;
    }
    return false;
  }

  void IncMsgDataRef() {
    ++ msg_data_ref_;
  }

  bool DecMsgDataRef() {
    -- msg_data_ref_;
    return msg_data_ref_ == 0;
  }

  std::vector<Interval>& intervals() {
    return intervals_;
  }

 private:
  uint64_t op_seq_;
  // 保存连接的id, 应答返回时快速找到连接
  uevent::ConnectionUeventPtr conn_;
  // 接收到的消息头,子消息的头也在msg_hdr指向的数据段中
  const common::MessageHeader *msg_hdr_;
  // 接受到的消息数据段
  const char* msg_data_;
  uint32_t msg_data_ref_;
  uint32_t date_len_;
  uint32_t cmd_;
  uint32_t pg_id_;

  // 保存读到的数据,OpRequest负责空间的释放
  char* read_buffer_;
  char* mem_buffer_;
  // 用于跟踪副本的请求, 下标0表示本地，其他表示副本,vector中存的是chunk id
  std::vector<int> replica_chunk_ids_;
  std::bitset<common::kReplicaNum + 1> replicas_bit_set_; // 最后一个用于迁移
  // 每8bit 标识一个副本的retcode
  int32_t replicas_retcode_;
  int timer_count_ = 0;

  int aio_ack_time_ = 0;
  int rep_ack_time_ = 0;
  bool timeout_; // 超时标识
  int refs_; // 引用计数，本地io下发时增引用，返回时减引用，修复io暂不使用
  std::vector<Interval> intervals_; // 与memtable中重叠的部分
  base::ObjPool<OpRequest> &pool_;
  MemoryPool *mem_pool_ = nullptr;
  MemorySlab *mem_slab_ = nullptr;
  MemorySlab *mem_buf_slab_ = nullptr;
  MemorySlab *msg_header_slab_ = nullptr;
};

}; // end of ns chunk
}; // end of ns udisk

#endif
