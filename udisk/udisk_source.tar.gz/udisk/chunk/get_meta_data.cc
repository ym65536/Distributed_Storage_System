#include <ustevent/message_util.h>
#include <ustevent/connection_uevent.h>
#include <ustevent/base/logging.h>
#include "chunk_context.h"
#include "manager_handle.h"
#include "get_meta_data.h"

namespace udisk {
namespace chunk {

using namespace uevent;
// 用于dump chunk 内的路由信息，主要用于调试, 检测chunk内的路由是否正确

int GetMetaDataHandle::type_ = ucloud::udisk::GET_META_DATA_REQUEST;

void GetMetaDataHandle::EntryInit(const uevent::ConnectionUeventPtr& conn, 
                                  const uevent::UMessagePtr& um) {
  ULOG_INFO << "protobuf recv conn=" << conn->GetId() << ", msg " << um->DebugString();
  conn_ = conn;
  assert(um->head().message_type() == type_);
  assert(um->body().HasExtension(ucloud::udisk::get_meta_data_request));

  ucloud::udisk::GetMetaDataRequest req_body = 
    um->body().GetExtension(ucloud::udisk::get_meta_data_request);
  MakeResponse(um.get(), ucloud::udisk::GET_META_DATA_RESPONSE, &response_);
  resp_body_ = 
    response_.mutable_body()->MutableExtension(ucloud::udisk::get_meta_data_response);
  // 处理心跳上报
  GetMetaDataProcess(req_body.cluster_version());
}

void GetMetaDataHandle::GetMetaDataProcess(uint64_t req_cluster_version) {
  ULOG_INFO << "recv GetMetaData request: cluster_version=" << req_cluster_version;
  ManagerHandle* manager_handle = g_context->manager_handle();
    
  uint64_t cluster_version = manager_handle->const_cluster_map().GetClusterVersion();
  if (req_cluster_version < cluster_version) {
    cluster::ClusterMap cluster_map = manager_handle->const_cluster_map();

    ucloud::udisk::ClusterInfoPb* cluster_info = resp_body_->mutable_cluster_info();
    cluster_info->CopyFrom(cluster_map.cluster());

    udisk::cluster::ChunkInfoMap chunk_info_map = cluster_map.chunks();
    for (udisk::cluster::ChunkInfoMap::iterator it = chunk_info_map.begin();
        it != chunk_info_map.end(); ++it) {
      ucloud::udisk::ChunkInfoPb* chunk_info = resp_body_->add_chunk_info();
      chunk_info->CopyFrom(it->second);
    }

    std::vector<ucloud::udisk::PGInfoPb> pg_infos = cluster_map.pgs();
    for (uint32_t id = 0; id < pg_infos.size(); id++) {
      ucloud::udisk::PGInfoPb* pg_info = resp_body_->add_pg_info();
      pg_info->CopyFrom(pg_infos[id]);
    }
    resp_body_->set_pc_size(g_context->chunk_pool()->pc_size());
  }

  resp_body_->mutable_rc()->set_retcode(0);
  resp_body_->mutable_rc()->set_error_message("success");
  MessageUtil::SendPbResponse(conn_, response_);
}

}
}
