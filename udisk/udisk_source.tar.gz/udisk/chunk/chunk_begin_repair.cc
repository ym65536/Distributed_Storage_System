#include <ustevent/message_util.h>
#include <ustevent/connection_uevent.h>
#include <ustevent/base/logging.h>
#include "chunk_context.h"
#include "manager_handle.h"
#include "repair_loop_handle.h"
#include "chunk_loop_handle.h"
#include "cluster_map.h"
#include "chunk_begin_repair.h"

namespace udisk {
namespace chunk {
 
using namespace uevent;

int ChunkBeginRepairHandle::type_ = ucloud::udisk::CHUNK_BEGIN_REPAIR_REQUEST;

void ChunkBeginRepairHandle::EntryInit(const ConnectionUeventPtr& conn, 
                                       const UMessagePtr& um) {
  conn_ = conn;
  ULOG_INFO << "protobuf recv conn_id=" << conn_->GetId() << ", msg " << um->DebugString();
  assert(um->head().message_type() == type_);
  assert(um->body().HasExtension(ucloud::udisk::chunk_begin_repair_request));

  MakeResponse(um.get(), ucloud::udisk::CHUNK_BEGIN_REPAIR_RESPONSE, &response_);
  session_no_ = um->head().session_no();
  request_ = um;
  // 处理修复请求
  ChunkBeginRepairProcess(um);
}

void ChunkBeginRepairHandle::SendResponse(uint32_t retcode, 
    const std::string& message) {
  ucloud::udisk::ChunkBeginRepairResponse* resp = 
    response_.mutable_body()->MutableExtension(
      ucloud::udisk::chunk_begin_repair_response);
  resp->mutable_rc()->set_retcode(retcode);
  resp->mutable_rc()->set_error_message(message);
  ULOG_DEBUG << response_.DebugString();
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void ChunkBeginRepairHandle::ChunkBeginRepairProcess(const UMessagePtr& um) {
  ucloud::udisk::ChunkBeginRepairRequest req = 
    um->body().GetExtension(ucloud::udisk::chunk_begin_repair_request);
  pg_id_ = req.pg_id();
  ULOG_INFO << "recv ChunkBeginRepairHandle request: pg_id=" << pg_id_;
  ManagerHandle* manager_handle = g_context->manager_handle();
  cluster::ClusterMap cluster_map = manager_handle->const_cluster_map();
  std::vector<ucloud::udisk::PGInfoPb> pg_infos = cluster_map.pgs();
  if (pg_id_ >= (uint32_t)pg_infos.size()) {
    ULOG_ERROR << "Recv pg_id error. pg_id=" << pg_id_;
    SendResponse(ucloud::udisk::EC_UDISK_PARAM_INVALID, "input pg_id error");
    return;
  }
  ucloud::udisk::PGInfoPb& pg_info = pg_infos[pg_id_];
  if (pg_info.id() != pg_id_) {
    ULOG_ERROR << "db pg info error. req pg_id=" << pg_id_ 
      << ", real pg_id=" << pg_info.id();
    SendResponse(ucloud::udisk::EC_UDISK_PARAM_INVALID, "input pg_id error");
    return;
  }
  repair_chunk_ = req.repair_chunk();
  int i = 0;
  for (; i < pg_info.chunk_id_size(); i++) {
    if (repair_chunk_ == pg_info.chunk_id(i)) {
      break;    
    }
  }
  if (i >= pg_info.chunk_id_size()) {
    ULOG_ERROR << "repair_chunk and pg_id not match. pg_id=" << 
      pg_id_ << ", repair_chunk=" << repair_chunk_;
    SendResponse(ucloud::udisk::EC_UDISK_PARAM_INVALID, 
      "input pg_id/repair_chunk not match");
    return;
  }
  udisk::cluster::ChunkInfoMap chunk_map = cluster_map.chunks(); 
  if (chunk_map.find(repair_chunk_) == chunk_map.end()) {
    ULOG_ERROR << "Repair chunk id not found. repair_chunk=" << repair_chunk_;
    SendResponse(ucloud::udisk::EC_UDISK_PARAM_INVALID, 
      "input repair_chunk error");
    return;
  }
  for (uint32_t i = 0; i < static_cast<uint32_t>(req.pcs_size()); i++) {
    ucloud::udisk::PGPhysicalChunk pc = req.pcs(i);
    pcs_.insert(PhysicalChunk(pc.lc_id(), pc.lc_size(), pc.pc_id(), pc.lc_random_id(), pg_id_));
  }
  // 暂定每次传入1个待修复pc
  if (pcs_.size() != 1) {
    ULOG_ERROR << "Repair pc size error. size=" << pcs_.size();
    SendResponse(ucloud::udisk::EC_UDISK_PARAM_INVALID, "input repair_chunk error");
    return;
  }
  if (pg_info.primary_chunk_id() != 
      static_cast<uint32_t>(g_context->config().my_id())) { 
    // 需要修复的chunk
    if (repair_chunk_ != static_cast<uint32_t>(g_context->config().my_id())) {
      ULOG_ERROR << "Need Repair chunk id error. repair_chunk=" << repair_chunk_
        << ", my_id=" << g_context->config().my_id() 
        << ", primary_chunk_id=" << pg_info.primary_chunk_id();
      SendResponse(ucloud::udisk::EC_UDISK_PARAM_INVALID, "input repair_chunk error");
      return;
    }
    PhysicalChunkSet::iterator pc_it = pcs_.begin();
    uint32_t lc_id = pc_it->lc_id;
    uint32_t pc_no = pc_it->pc_no;
    ManagerHandle* manage_handle = g_context->manager_handle();
    int32_t io_thread_num = g_context->io_listener()->worker_num();
    if (!req.has_repair_notify() || req.repair_notify() != 1) {
      // 表示secondary收到一个pending io 的请求, 开始pending, 而不是修复数据
      std::shared_ptr<ChunkBeginRepairHandle> client_ptr = 
        std::dynamic_pointer_cast<ChunkBeginRepairHandle>(shared_from_this());
      int ret = manage_handle->PendingIORequestHandles(
          lc_id, pc_no, io_thread_num, client_ptr);
      if (ret < 0) { // 请求已经存在
        ULOG_ERROR << "pc is pending, wait. lc_id=" << lc_id << ", pc_no=" << pc_no;
        SendResponse(ucloud::udisk::EC_UDISK_REPAIR_DOING, "pc is pending");
        return;
      }
      // secondary通知io loop pending 所有写请求
      NotifyIOLoopHandle();
      // 暂不回复primary, 等io线程 pending io完再回复
      //SendResponse(0, "success");
      return;
    } else {
      // 这里表示primary收到secondary已经pending的回复后，
      // 告知secondary开始修复数据.
      std::shared_ptr<ChunkBeginRepairHandle> client_ptr = 
        std::dynamic_pointer_cast<ChunkBeginRepairHandle>(shared_from_this());
      int ret = manage_handle->RepairRequestHandles(
          lc_id, pc_no, io_thread_num, client_ptr);
      if (ret < 0) { // 请求已经存在
        ULOG_ERROR << "pc is repairing. lc_id=" << lc_id << ", pc_no=" << pc_no;
        SendResponse(ucloud::udisk::EC_UDISK_REPAIR_DOING, "pc is repairing");
        return;
      }
      ULOG_DEBUG << "RepairRequestHandles finish. lc_id=" << 
        lc_id << ", pc_no=" << pc_no;
      // 暂时不回复primary，等到io线程merge完数据后再通知
      //SendResponse(0, "success");
      return;
    }
  };
  // 本chunk是primary chunk, 请求是由loki发来
  // 通知repair chunk需要pending io
  ucloud::UMessage msg;
  uint32_t obj_id = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&msg, flowno, session_no_,
                ucloud::udisk::CHUNK_BEGIN_REPAIR_REQUEST, 
                0, false, obj_id, 0, "ChunkNotifyPendingIO", NULL, NULL);
  ucloud::udisk::ChunkBeginRepairRequest* request = 
    msg.mutable_body()->MutableExtension(ucloud::udisk::chunk_begin_repair_request);
  request->CopyFrom(
      request_->body().GetExtension(ucloud::udisk::chunk_begin_repair_request));
  ucloud::udisk::ChunkInfoPb& chunk_info = chunk_map[repair_chunk_];
  uevent::ConnectionUeventPtr conn = 
    manager_handle->get_out_connection(chunk_info.ip(), chunk_info.man_port());
  manager_handle->set_repair_conn(conn);
  std::shared_ptr<ChunkBeginRepairHandle> client_ptr = 
    std::dynamic_pointer_cast<ChunkBeginRepairHandle>(shared_from_this());
  uevent::MessageUtil::SendPbRequest(conn, msg, 
      std::bind(&ChunkBeginRepairHandle::NotifyPendingIOResponse, client_ptr, 
        std::placeholders::_1), 
      std::bind(&ChunkBeginRepairHandle::NotifyPendingIOTimeout, client_ptr), 
      g_context->config().repair_notify_timeout());
  return;
}

void ChunkBeginRepairHandle::NotifyPendingIOResponse(const UMessagePtr& um) {
  const ucloud::udisk::ChunkBeginRepairResponse& res = 
    um->body().GetExtension(ucloud::udisk::chunk_begin_repair_response); 
  if (res.rc().retcode() != 0) {
    ULOG_ERROR << "Notify pending io error: retcode=" << res.rc().retcode() 
      << ", ret_msg=" << res.rc().error_message();
    SendResponse(ucloud::udisk::EC_UDISK_REPAIR_FAIL, res.rc().error_message());
    return;
  }
  // primary chunk, 通知repair chunk开始同步数据，repair_chunk merge完毕后回复
  ManagerHandle* manager_handle = g_context->manager_handle();
  ucloud::UMessage msg;
  uint32_t obj_id = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&msg, flowno, session_no_,
                ucloud::udisk::CHUNK_BEGIN_REPAIR_REQUEST, 
                0, false, obj_id, 0, "ChunkBeginRepair", NULL, NULL);
  ucloud::udisk::ChunkBeginRepairRequest* req = 
    msg.mutable_body()->MutableExtension(ucloud::udisk::chunk_begin_repair_request);
  req->CopyFrom(
    request_->body().GetExtension(ucloud::udisk::chunk_begin_repair_request));
  req->set_repair_notify(1);
  uevent::ConnectionUeventPtr conn = manager_handle->get_repair_conn(); 
  if (conn->IsClosed()) {
    ULOG_ERROR << "Notify repair error: Connection reset by peer.";
    SendResponse(ucloud::udisk::EC_UDISK_REPAIR_FAIL, "Connection reset by peer");
    return;
  }
  std::shared_ptr<ChunkBeginRepairHandle> client_ptr = 
    std::dynamic_pointer_cast<ChunkBeginRepairHandle>(shared_from_this());
  uevent::MessageUtil::SendPbRequest(conn, msg, 
      std::bind(&ChunkBeginRepairHandle::NotifyRepairChunkResponse, client_ptr, 
        std::placeholders::_1), 
      std::bind(&ChunkBeginRepairHandle::NotifyRepairChunkTimeout, client_ptr),
      g_context->config().repair_pc_timeout());
  PhysicalChunkSet::iterator pc_it = pcs_.begin();
  uint32_t lc_id = pc_it->lc_id;
  uint32_t pc_no = pc_it->pc_no;
  uint32_t pg_id = pc_it->pg_id;
  ULOG_DEBUG << "Send repair pc to repair loop: pg_id=" << pg_id
    << ", repair_chunk=" << repair_chunk_ 
    << ", lc_id=" << lc_id << ", pc_no=" << pc_no;
  // 发送给repair thread 开始修复
  g_context->repair_loop()->RunInLoop(
    std::bind(&RepairLoopHandle::SyncDataProcess, 
      g_context->repair_handle(), repair_chunk_, pcs_),
      true);
  // 这里不回复loki
  return; 
}

void ChunkBeginRepairHandle::NotifyPendingIOTimeout() {
  ULOG_DEBUG << "Notify pending io chunk timeout: pg_id=" << 
    pg_id_ << ", repair_chunk=" << repair_chunk_;
  SendResponse(ucloud::udisk::EC_UDISK_REPAIR_TIMEOUT, "notify pending io timeout");
  return;
}

void ChunkBeginRepairHandle::NotifyRepairChunkResponse(const uevent::UMessagePtr& um) {
  const ucloud::udisk::ChunkBeginRepairResponse &res = 
    um->body().GetExtension(ucloud::udisk::chunk_begin_repair_response); 
  if (res.rc().retcode() != 0) {
    ULOG_ERROR << "Notify repair chunk error: retcode=" << res.rc().retcode() 
      << ", ret_msg=" << res.rc().error_message();
    SendResponse(ucloud::udisk::EC_UDISK_REPAIR_FAIL, res.rc().error_message());
    return;
  }
  ULOG_DEBUG << "PC Repair success.";
  SendResponse(0, "success");
  return;
}

void ChunkBeginRepairHandle::NotifyRepairChunkTimeout() {
  ULOG_DEBUG << "Notify repair chunk timeout: pg_id=" << pg_id_ 
    << ", repair_chunk=" << repair_chunk_;
  SendResponse(ucloud::udisk::EC_UDISK_REPAIR_TIMEOUT, "notify repair_chunk timeout");
  return;
}

void ChunkBeginRepairHandle::NotifyIOLoopHandle() {
  std::vector<uevent::EventLoop*> all_loops = g_context->io_listener()->GetAllLoops();
  PhysicalChunkSet::iterator pc_it = pcs_.begin();
  uint32_t lc_id = pc_it->lc_id;
  uint32_t pc_no = pc_it->pc_no;
  uint32_t pg_id = pc_it->pg_id;
  for (size_t i = 0; i < all_loops.size(); ++i) {
    ULOG_DEBUG << "==> Notify pending io. lc_id=" << lc_id << 
      ", pc_no=" << pc_no << ", pg_id=" << pg_id;
    assert(all_loops[i]);
    ChunkLoopHandle *loop_handle = (ChunkLoopHandle*)all_loops[i]->GetLoopHandle();
    all_loops[i]->RunInLoop(
        std::bind(&ChunkLoopHandle::RepairPCStartNotify, loop_handle, pg_id_, pcs_),
        true);
  }
}

}
}
