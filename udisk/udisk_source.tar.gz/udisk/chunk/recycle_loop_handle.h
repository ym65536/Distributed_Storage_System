#ifndef UDISK_CHUNK_RECYCLE_LOOP_HANDLE_H_
#define UDISK_CHUNK_RECYCLE_LOOP_HANDLE_H_

#include <string>
#include <map>
#include <ustevent/libevent/eventloop_libevent.h>
#include <ustevent/worker_thread.h>
#include "flow_ctrl.h"
#include "io_error_container.h"
#include "pool/memory_pool.h"



namespace udisk {
namespace chunk {

class RecyclePCHandle;
class ChunkStorage;
class ChunkHandle;
struct ChunkID;

class RecycleLoopHandle {
 public:
  RecycleLoopHandle();

  void Start();

  void RecyclePC(const ChunkID& chunkID,
      const std::shared_ptr<RecyclePCHandle>& ptr);

  uevent::EventLoop* eventloop() {
    return recycle_loop_;
  }
 private:

  int FormatPC(const ChunkID& chunkID, const std::shared_ptr<RecyclePCHandle>& ptr);
  int MovePCToPool(const ChunkID& chunkID, const std::shared_ptr<RecyclePCHandle>& ptr);
  void ReportLCIOError(); 

  uevent::WorkerThread* recycle_thread_;
  uevent::EventLoop* recycle_loop_;
  void OpenChunkResCb(int retcode, ChunkHandle* handle, const ChunkID& chunkID,
                       const std::shared_ptr<RecyclePCHandle>& ptr);
  void PutChunkResCb(int retcode, const ChunkID& chunkID,
                       const std::shared_ptr<RecyclePCHandle>& ptr);

  TokenBucket token_bucket_;
  ChunkStorage* chunk_storage_;
  // io 读写错误统计 
  IOErrorContainer io_error_container_;
  MemorySlab slab_;
};

}; // end of ns chunk
}; // end of ns udisk

#endif
