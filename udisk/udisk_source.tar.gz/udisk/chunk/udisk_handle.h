#ifndef UDISK_CHUNK_UDISK_HANDLE_H_
#define UDISK_CHUNK_UDISK_HANDLE_H_

#include <deque>
#include <memory>
#include <unordered_map>

#include "udisk_message.h"
#include "op_request.h"
#include "cluster_map.h"
#include "repair_buffer.h"
#include "udisk_types.h"
#include "chunk_storage.h"
#include "op_request.h"
#include "throttle.h"

namespace udisk {
namespace chunk {

class ChunkLoopHandle;
class ChunkHandle;
class OpRequest;

class UDiskHandle {
 public:
  explicit UDiskHandle(uint32_t lc_id,
              uint32_t lc_random_id, 
              uint32_t pc_count,
              ChunkLoopHandle* lh);
  ~UDiskHandle();
  // 处理Gate请求
  bool DoGateOpRequest(OpRequest* op);

  // 处理Ark请求
  bool DoArkOpRequest(OpRequest* op);

  // 处理Hela请求
  bool DoHelaOpRequest(OpRequest* op);

  // 处理Chunk请求
  bool DoChunkOpRequest(OpRequest* op);

  // 处理Chunk应答
  void DoChunkResponse(const common::ChunkIOResponseHead* hdr);

  // 迁移双写时，处理端主chunk的返回
  void DoReplicaRemoteResponse(const common::MigrateHead* hdr); 

  // 处理openchunk应答
  void DoOpenChunkResCb(uint64_t op_seq, int32_t retcode, ChunkHandle* handle);
  // 处理Aio的应答, journal模式，部分情况下会同步应答
  void DoLocalAioResponse(uint32_t pg_id, 
                          uint64_t op_seq, 
                          int32_t retcode, 
                          bool sync = false);

  void ArkOpTimeout(OpRequest* op);
  void HelaOpTimeout(OpRequest* op);

  uint32_t lc_id() const {
    return lc_id_;
  }

  uint32_t lc_random_id() const {
    return lc_random_id_;  
  }

  // GiB
  uint32_t lc_size() const {
    return ((uint64_t)pc_count_ * g_context->chunk_pool()->pc_size()) >> GB_SHIFT;
  }

  // 修复相关
  int RepairPCStart(uint32_t pg_id, uint32_t pc_no);
  int RepairPCMerge(uint32_t pc_no);
  int RepairPCFinish(uint32_t pc_no);

  void set_io_depth_limit(int io_depth_limit) {
    io_depth_limit_ = io_depth_limit; 
  }

  uint32_t io_depth_limit() {
    return io_depth_limit_;
  }

  uint64_t r_io_count() const {
    return r_io_count_;
  }
  uint64_t w_io_count() const {
    return w_io_count_;
  }
  void reset_io_count(uint64_t r_iops, uint64_t w_iops) {
    r_io_count_ = 0;
    w_io_count_ = 0;
    last_r_iops_ = r_iops;
    last_w_iops_ = w_iops;
  }

  uint64_t r_io_bytes() const {
    return r_io_bytes_;
  }
  uint64_t w_io_bytes() const {
    return w_io_bytes_;
  }

  void reset_io_bytes(uint64_t r_bw, uint64_t w_bw) {
    r_io_bytes_ = 0;
    w_io_bytes_ = 0;
    last_r_bw_ = r_bw;
    last_w_bw_ = w_bw;
  }

  void reset_io_latency() {
    r_io_latency_ = 0;
    w_io_latency_ = 0;
  }

  uint64_t r_io_latency() const {
    return r_io_latency_;
  }
  uint64_t w_io_latency() const {
    return w_io_latency_;
  }

  uint64_t r_aio_latency() const {
    return r_aio_latency_;
  }
  uint64_t w_aio_latency() const {
    return w_aio_latency_;
  }

  uint64_t w_rep_latency() const {
    return w_rep_latency_;
  }

  uint32_t current_io_depth() const {
    return inflying_list_.size();
  }

  uint64_t is_inuse() const {
    return inuse_flag_;
  }

  void reset_inuse_flag() {
    inuse_flag_ = false;
  }

  void connection_reset() {
    reset_flag_ = true;
  }

  void set_next(UDiskHandle *handle) {
    next_ = handle;
  }

  UDiskHandle* next() const {
    return next_;
  }

  bool DispatchNextPendingIO();
  void IOTimerCb();
  void ClearOpRequstByConnId(int64_t conn_id);

  bool ProcessMigrateJournalRequest(OpRequest* op);
  void DispatchMigrateJournalRequest(OpRequest* op);
  void AckMigrateJournalRequest(OpRequest* op);
  void BuildMigrateJournalRemoteResponse(int retcode,
                                   const common::MessageHeader &req_common_hdr,
                                   common::MessageHeader *res_common_hdr,
                                   const common::MigrateHead &req_hdr,
                                   common::MigrateHead *res_hdr);
  void EndMigrateJournalRequest(OpRequest* op);

 private:
  const cluster::ClusterMap& cluster_map();
  /**
   * @brief 分发gate的io请求
   */
  void DispatchGateRequest(OpRequest* op);
  /**
   * @brief 分发ark的io请求
   */
  void DispatchArkRequest(OpRequest* op);
  /**
   * @brief 分发hela的io请求
   */
  void DispatchHelaRequest(OpRequest* op);
  /**
   * @brief 分发Chunk的IO请求
   */
  void DispatchChunkRequest(OpRequest* op);
  /**
   * @brief 复制请求到其副本
   */
  int ReplicaRequest(OpRequest* op);
  /**
   * @brief hela io复制到writeonly的副本
   */
  int HelaReplicaRequest(OpRequest* op);
  /**
   * @brief 发送请求到本地
   */
  bool LocalAioRequest(OpRequest* op);
  /**
   * @brief 迁移复制请求到目标set
   */
  int ReplicaRemoteRequest(OpRequest* op, 
                           const chunk::IOMeta& meta,
                           uint32_t target_lc_id,
                           uint32_t target_random_id,
                           uint64_t target_version,
                           uint32_t target_pg_id,
                           uevent::ConnectorUeventPtr& ctor);
  /**
   * @brief 根据Gate请求构造chunk请求
   */
  void BuildChunkRequestWithGateReq(const common::MessageHeader &src_common_hdr,
                           common::MessageHeader *dst_common_hdr,
                           const common::GateIORequestHead &src,
                           common::ChunkIORequestHead *dst,
                           uint64_t op_seq,
                           uint8_t replica_no);
  /**
   * @brief 根据Ark请求构造chunk请求
   */
  void BuildChunkRequestWithArkReq(const common::MessageHeader &src_common_hdr,
                           common::MessageHeader *dst_common_hdr,
                           const common::ArkIORequestHead &src,
                           common::ChunkIORequestHead *dst,
                           uint64_t op_seq,
                           uint8_t replica_no);

  void BuildChunkRequestWithMigrateReq(
                           const common::MessageHeader &src_common_hdr,
                           common::MessageHeader *dst_common_hdr,
                           const common::MigrateHead &migrate_req,
                           common::ChunkIORequestHead *chunk_req,
                           uint64_t op_seq,
                           uint8_t replica_no);
  /**
   * @brief 根据Hela请求构造chunk请求
   */
  void BuildChunkRequestWithHelaReq(const common::MessageHeader &src_common_hdr,
                           common::MessageHeader *dst_common_hdr,
                           const common::HelaChunkRequestHead &src,
                           common::ChunkIORequestHead *dst,
                           uint64_t op_seq,
                           uint8_t replica_no);
  /**
   * @brief 发送请求到指定的ip,port上
   */
  bool SendMsg(const char *msg, size_t len, const uevent::ConnectionUeventPtr& conn);

  /**
   * @brief op操作请求已经发送出去，即本地和副本请求
   */
  void EnqueueInflying(OpRequest* op);

  /**
   * @brief 当前lc队列深度操作udisk_queue_max_depth,将op
   * 放入pending队列中，当inflying的请求完成或则超时后，
   * 取出pending队列中的请求然后分发执行下去
   */
  void EnqueuePending(OpRequest* &op) {
    pending_list_.push_back(op);
  }


  // 使用ChunkHandle提交本地请求
  void SubmitReadLocal(ChunkHandle* handle, const IOMeta& meta, OpRequest* op);
  void SubmitWriteLocal(ChunkHandle* handle, const IOMeta& meta, OpRequest* op);

  // 应答请求者
  void AckArkIORequest(OpRequest* op);
  void AckHelaIORequest(OpRequest* op);
  void AckGateIORequest(OpRequest* op);
  void AckChunkIORequest(OpRequest* op);

  // 发送下一个在pending 队列中的IO
  void DoNextOpReuquest(OpRequest* op);

  // 应答请求者并清理保存的op资源
  void EndIORequest(OpRequest* op);
  void EndGateIORequest(OpRequest* op);
  void EndArkIORequest(OpRequest* op);
  void EndHelaIORequest(OpRequest* op);
  void EndChunkIORequest(OpRequest* op);


  void EndPendingIO(OpRequest *op);

  // io统计
  void GateIOCount(OpRequest *op);
  void ArkIOCount(OpRequest *op);
  void HelaIOCount(OpRequest *op);
  void ChunkIOCount(OpRequest *op);

  // 构建gate应答
  void BuildGateResponse(int retcode,
                         const common::MessageHeader &req_common_hdr,
                         common::MessageHeader *res_common_hdr,
                         const common::GateIORequestHead &req_gate_hdr,
                         common::GateIOResponseHead *res_gate_hdr,
                         size_t data_len);
  // 构建ark应答
  void BuildArkResponse(int retcode,
                        const common::MessageHeader &req_common_hdr,
                        common::MessageHeader *res_common_hdr,
                        const common::ArkIORequestHead &req_ark_hdr,
                        common::ArkIOResponseHead *res_ark_hdr,
                        size_t data_len);
  // 构建hela应答
  void BuildHelaResponse(int retcode,
                         const common::MessageHeader &req_common_hdr,
                         common::MessageHeader *res_common_hdr,
                         const common::HelaChunkRequestHead &req_hela_hdr,
                         common::HelaChunkResponseHead *res_hela_hdr,
                         size_t data_len);

  // 构建chunk应答
  void BuildChunkResponse(int retcode,
                          const common::MessageHeader &req_common_hdr,
                          common::MessageHeader *res_common_hdr,
                          const common::ChunkIORequestHead &req_hdr,
                          common::ChunkIOResponseHead *res_hdr,
                          size_t data_len);
  void DispatchOpRequest(OpRequest* op);
  void ReportTimerCb();
  void DispatchPendingIO();
  void OpEnqueue(OpRequest* op);
  bool ArkReadRequest(OpRequest* op);
  void ReadZeroResponse(OpRequest* op, int32_t retcode);
  uint32_t lc_id_;
  uint32_t lc_random_id_;
  uint32_t pc_count_;
  ChunkLoopHandle* loop_handle_;
  std::deque<OpRequest*> pending_list_;
  struct pairhash {
   public:
    template <typename T, typename U>
    std::size_t operator()(const std::pair<T, U> &x) const {
      return std::hash<T>()(x.first) ^ std::hash<U>()(x.second);
    }
  };
  std::unordered_map<std::pair<uint32_t, uint64_t>, OpRequest*, pairhash> inflying_list_;
  int io_depth_limit_;
  std::unordered_map<uint32_t, std::shared_ptr<RepairBuffer>> repair_pcs_;
  typedef Throttle<OpRequest*> OpThrottle;
  std::unique_ptr<OpThrottle> ark_throttle_;

  UDiskHandle *next_ = nullptr;
  bool reset_flag_ = false;
  // 用于检测udiskhandle存活性
  // 记录上次检测到这次检测
  // udisk handle是否在使用，在使用的标记
  // 1、primary chunk 接收 gate io
  // 2、secondary 接收主primary同步的写请求
  // 3、主从在同步修复
  bool inuse_flag_ = true;
  uint64_t r_io_count_ = 0;
  uint64_t last_r_iops_ = 0;
  uint64_t w_io_count_ = 0;
  uint64_t last_w_iops_ = 0;
  uint64_t r_io_bytes_ = 0;
  uint64_t last_r_bw_ = 0;
  uint64_t w_io_bytes_ = 0;
  uint64_t last_w_bw_ = 0;
  uint64_t r_io_latency_ = 0; // microseconds
  uint64_t w_io_latency_ = 0; // microseconds
  uint64_t r_aio_latency_ = 0; // microseconds
  uint64_t w_aio_latency_ = 0; // microseconds
  uint64_t w_rep_latency_ = 0; // microseconds
};

}; // end of ns chunk
}; // end of ns udisk

#endif
