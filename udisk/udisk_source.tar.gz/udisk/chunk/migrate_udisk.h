#ifndef UDISK_CHUNK_MIGRATE_UDISK_H_
#define UDISK_CHUNK_MIGRATE_UDISK_H_

#include <ustevent/pb_request_handle.h>
#include "udisk_message.h"

namespace udisk {
namespace chunk {
 
class MigrateUDiskHandle: public uevent::PbRequestHandle {
 public:
  explicit MigrateUDiskHandle(uevent::EventLoop* loop) {
  }
  virtual ~MigrateUDiskHandle() {
  }
  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         const uevent::UMessagePtr& um);
 
  MYSELF_CREATE(MigrateUDiskHandle);
   
 private:
  static int type_;
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage response_;
  ucloud::udisk::ChunkMigrateUDiskResponse* resp_body_;
};

}
}

#endif

