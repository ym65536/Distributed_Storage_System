#ifndef UDISK_CHUNK_HEARTBEAT_CHUNK_CHUNK_H_
#define UDISK_CHUNK_HEARTBEAT_CHUNK_CHUNK_H_

#include <ustevent/pb_request_handle.h>

namespace udisk {
namespace chunk {

class ManagerHandle;

class HeartbeatChunkChunkHandle : public uevent::PbRequestHandle {
 public:
  explicit HeartbeatChunkChunkHandle(uevent::EventLoop* loop)  {
  }
  ~HeartbeatChunkChunkHandle() {
  };

  MYSELF_CREATE(HeartbeatChunkChunkHandle);
  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn, 
                         const uevent::UMessagePtr& msg);

};

}; // end of ns chunk
}; // end of ns udisk

#endif
