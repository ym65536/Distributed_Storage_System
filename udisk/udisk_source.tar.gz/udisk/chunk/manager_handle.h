#ifndef UDISK_MANAGER_HANDLE_H_
#define UDISK_MANAGER_HANDLE_H_

#include <ustevent/base/timestamp.h>
#include <ustevent/libevent/listener_libevent.h>
#include <ustevent/libevent/eventloop_libevent.h>
#include <ustevent/libevent/connector_libevent.h>
#include <ustevent/worker_thread.h>
#include <ustevent/callbacks.h>
#include "udisk_message.h"
#include "cluster_map.h"
#include "io_error_container.h"
#include "udisk_journal.h"

namespace udisk {
namespace chunk {

class ChunkBeginRepairHandle;

class ManagerHandle {
 public:
  static const uint32_t kThreadHeartbeatTimeout = 5; //线程hang超时时间，单位s
  ManagerHandle();

  void start(const std::string &ip, int port);

  // 收到chunk服务的应答后调用,更新
  // 对应chunk的超时时间点
  void HandleChunkHeartbeat(uint32_t chunk_id);

  // chunk故障
  void ChunkFailure(uint32_t chunk_id, ucloud::udisk::CHUNK_FAILURE_TYPE t);
    
  int RepairRequestHandles(uint32_t, uint32_t, uint32_t, std::shared_ptr<ChunkBeginRepairHandle>&);

  void RepairResponseHandles(uint32_t lc_id, uint32_t pc_no, uint32_t front_io,
    uint32_t retcode, const std::string& message);

  int PendingIORequestHandles(uint32_t, uint32_t, uint32_t, std::shared_ptr<ChunkBeginRepairHandle>&);

  void PendingIOResponseHandles(uint32_t lc_id, uint32_t pc_no,
    uint32_t retcode, const std::string& message);

  void ReportChunkFailure(uint32_t chunk_id, int32_t retcode);

  void ReportChunkFailureInLoop(uint32_t chunk_id, int32_t retcode);

  const cluster::ClusterMap& const_cluster_map() const {
    return cluster_map_;
  }
  void ClearUDiskStats(const std::string& thread_name);
  void ReportThreadIOCount(uint64_t r_byteps, uint64_t r_iops,
                                        uint64_t r_io_latency_max, uint64_t r_io_latency_avg,
                                        uint64_t w_byteps, uint64_t w_iops,
                                        uint64_t w_io_latency_max, uint64_t w_io_latency_avg,
                                        const std::string &thread_name);

  void ReportUDiskIOCount(uint32_t lc_id, uint32_t lc_size,
                          uint32_t io_depth, uint32_t io_depth_limit,
                          uint64_t r_iops, uint64_t w_iops,
                          uint64_t r_bw, uint64_t w_bw,
                          const std::string& thread_name);

  
  void UpdateLCIODepthLimit(uint32_t lc_id, int io_depth_limit);
  void DispatchIOInLoopMode(uint32_t io_depth_limit);

  void MigrateUDisk(uint32_t lc_id, const std::string &thread_name);

  void FillChunkGetUDisksIOStatsResponse(
    const ucloud::udisk::ChunkGetUDisksIOStatsRequest *req,
    ucloud::udisk::ChunkGetUDisksIOStatsResponse *res);

  uevent::ConnectionUeventPtr get_out_connection(const std::string &ip, int port);
  void set_repair_conn(uevent::ConnectionUeventPtr& conn) {
    repair_conn_ = conn;
  }
  uevent::ConnectionUeventPtr get_repair_conn() {
    return repair_conn_;
  }
  
  void ReportLCIOError(const IOErrorContainer::LCIOErrorMap& lc_io_errors); 

  void MigratePgFinishRequest(uint32_t lc_id, uint32_t pg_id,
                              std::string tyr_ip, uint32_t tyr_port);
  void MigratePgFinishResponse(const uevent::UMessagePtr& msg, 
                               uint32_t lc_id, uint32_t pg_id);

  void UpdateMigrateProcess(const journal::MigrateUDiskInfo migrate_info);
  void UpdateMigrateProcessResponse(const uevent::UMessagePtr& msg, 
                                    uint32_t lc_id, uint32_t pg_id);

  void AccessTyrTimeout(uint32_t lc_id, uint32_t pg_id, 
                        const std::string& task_tag);

  void MigrateJournalFailRequest(uint32_t lc_id, uint32_t pg_id,
                                 std::string& tyr_ip, uint32_t tyr_port);
  void MigrateJournalFailResponse(const uevent::UMessagePtr& msg, 
                                  uint32_t lc_id, uint32_t pg_id);

  void ReportThreadInfo(pid_t thread_id, const std::string& thread_name);

 private:
  typedef std::pair<std::string, int> ConnectorKey;

  // 注册managerhandle处理
  // 的消息的handle
  void RegisterService();

  //定时malloc_trim
  void CheckChunkMemory();

  void TakeMetaDataFromMetaServer();
  void GetMetaDataResponse(const uevent::UMessagePtr& msg);
  void GetMetaDataTimeout(uint64_t flowno);

  // 向metaserver发送心跳请求
  void HeartBeatMetaServer();

  // 向同为伙伴的chunk服务发送心跳请求
  void HeartbeatChunk();

  // 周期调用，用于检测副本的心跳超时
  void CheckPartnerChunksActive();

  void ConnectionSuccessHandle(const uevent::ConnectionUeventPtr& conn);

  void ConnectionClosedHandle(const uevent::ConnectionUeventPtr& conn);

  void MessageWriteHandle(const uevent::ConnectionUeventPtr& conn);

  void OutConnectionSuccessHandle(const uevent::ConnectionUeventPtr& conn);

  void OutConnectionCloseHandle(const uevent::ConnectionUeventPtr& conn, uint64_t conn_id);

  void HeartbeatMetaServer();
  void CheckRepairRequestState();


  // cluster_map发生变动，
  // 1) 使用metaserver传送过来的新的cluster map覆盖cluster_map_
  // 2) 将此cluster_map的变动通知到其他loop handle中去
  // 3) 清理统计的伙伴chunk服务的超时时间点,因为这个时候，伙伴关系可能
  // 已经发生了变化
  void UpdateClusterMap(const ucloud::udisk::ClusterInfoPb &cluser_info,
    const ::google::protobuf::RepeatedPtrField<::ucloud::udisk::ChunkInfoPb> &chunk_info,
    const ::google::protobuf::RepeatedPtrField<::ucloud::udisk::PGInfoPb> &pg_info);

  void AddBlacklist(const ::google::protobuf::RepeatedPtrField<std::string> &blacklist_hosts,
                    uint32_t refuse_seconds);

  void NotifyIOLoopHandle(const cluster::ClusterMap &map);
  void NotifyRepairLoopHandle(const cluster::ClusterMap &map); 

  void HearbeatMetaServerTimeout(uint32_t flowno);
  void HeartbeatMetaServerResponse(const uevent::UMessagePtr& msg);

  void HeartbeatChunkResponse(const uevent::UMessagePtr& msg);
  void HearbeatChunkTimeout(uint32_t chunk_id);

  void HeartbeatOdinServer();
  void HeartbeatOdinServerResponse(const uevent::UMessagePtr& msg);
  void HeartbeatOdinServerTimeout();

  void BuildIOReportToOdinRequest(ucloud::udisk::ReportChunkOdinRequest* req);
  void BuildFailureReportRequest(ucloud::udisk::HeartbeatChunkMetaServerRequest *req);

  void ReportOdinIOError(); 
  void OdinWarningResponseCb(const uevent::UMessagePtr& msg); 
  void OdinWarningTimeout();

  void ClearUDiskStatsInLoop(const std::string& thread_name);

  void ReportThreadIOCountInLoop(uint64_t r_byteps, uint64_t r_iops,
                                              uint64_t r_io_latency_max, uint64_t r_io_latency_avg,
                                              uint64_t w_byteps, uint64_t w_iops,
                                              uint64_t w_io_latency_max, uint64_t w_io_latency_avg,
                                              const std::string& thread_name);
  void ReportUDiskIOCountInLoop(uint32_t lc_id, uint32_t lc_size,
                                uint32_t io_depth, uint32_t io_depth_limit,
                                uint64_t r_iops, uint64_t w_iops,
                                uint64_t r_bw, uint64_t w_bw,
                                const std::string& thread_name);

  void ReportLCIOErrorInLoop(const IOErrorContainer::LCIOErrorMap& lc_io_errors); 
  
  bool GetMetaServerAddress(std::string& ip, int& port);
  bool GetOdinServerAddress(std::string &ip, int &port);
  void ReportThreadInfoInLoop(pid_t thread_id, const std::string& thread_name);
  void CheckThreadActive();

  struct ThreadIOCount {
    uint64_t r_byteps;
    uint64_t w_byteps;
    uint64_t r_iops;
    uint64_t w_iops;
    uint64_t r_io_latency_max;
    uint64_t r_io_latency_avg;
    uint64_t w_io_latency_max;
    uint64_t w_io_latency_avg;
    ThreadIOCount(uint64_t r_byteps_, uint64_t w_byteps_,
                  uint64_t r_io_latency_max_, uint64_t r_io_latency_avg_,
                  uint64_t r_iops_, uint64_t w_iops_,
                  uint64_t w_io_latency_max_, uint64_t w_io_latency_avg_) :
      r_byteps(r_byteps_), w_byteps(w_byteps_),
      r_iops(r_iops_), w_iops(w_iops_) ,
      r_io_latency_max(r_io_latency_max_), 
      r_io_latency_avg(r_io_latency_avg_),
      w_io_latency_max(w_io_latency_max_), 
      w_io_latency_avg(w_io_latency_avg_) {}
  };

 private:
  bool CheckChunkUuid(const ucloud::udisk::ChunkInfoPb& my_chunk_info);

  struct RepairRequest {
    base::Timestamp start_time;
    uint32_t left_io_thread_num;//剩余尚未返回的线程数
    uint32_t front_io_thread_num;//触发过pending io的线程统计量，正常情况下该值为1
    std::shared_ptr<ChunkBeginRepairHandle> begin_repair_handle;

    RepairRequest() = default;

    RepairRequest (uint32_t io_thread_num,
                  const std::shared_ptr<ChunkBeginRepairHandle>& handle)
        : start_time(base::Timestamp::now()),
          left_io_thread_num(io_thread_num),
          front_io_thread_num(0),
          begin_repair_handle(handle) {
    }
  };

  struct ThreadHeartbeatInfo {
    std::string thread_name;  // 线程名
    time_t current_time;      // 当前心跳时间
    time_t last_time;         // 上次心跳时间

    ThreadHeartbeatInfo(std::string name, 
                        time_t c_time, time_t l_time)
      : thread_name(name),
        current_time(c_time),
        last_time(l_time) {}
  };

  //typedef std::map<std::pair<uint32_t, uint32_t>, 
  //  std::tuple<base::Timestamp, uint32_t, std::shared_ptr<ChunkBeginRepairHandle>>> 
  //    RepairRequestMap;
  typedef std::map<std::pair<uint32_t, uint32_t>, RepairRequest> RepairRequestMap;
  uevent::WorkerThread* man_thread_;
  uevent::EventLoop* man_loop_;
  uevent::ListenerUevent* man_listener_;

  // 缓存的与本chunk是伙伴chunk，
  // 其中如果cluster_map_变动的时候，需要重新计算
  std::vector<ucloud::udisk::ChunkInfoPb> partner_chunks_;
  cluster::ClusterMap cluster_map_;

  std::unordered_map<uint64_t, uevent::ConnectorUeventPtr> out_connectors_;
  // <chunk id, failure info>
  std::unordered_map<uint32_t, ucloud::udisk::ChunkFailureInfoPb> failure_info_;
  RepairRequestMap repair_requests_;
  RepairRequestMap pending_io_requests_;

  // <thread, io count>
  // 线程io统计
  std::map<std::string, ThreadIOCount> thread_io_count_;
  // <thread, <lc id, io stat> >
  std::map<std::string, std::map<uint32_t, ucloud::udisk::ChunkUDiskIOStat>> 
    thread_udisk_io_count_;
 
  // io 读写错误统计 
  IOErrorContainer io_error_container_; 
  
  // pending通知和修复要保证使用同一个连接，防止pending通知完成后primary重启，导致pending丢失
  uevent::ConnectionUeventPtr repair_conn_;
  //线程信息  pid：<thread_name, current_time, last_time>
  std::map<pid_t, ThreadHeartbeatInfo> thread_heartbeat_info_;
};

}; // end of ns chunk
}; // end of ns udisk

#endif
