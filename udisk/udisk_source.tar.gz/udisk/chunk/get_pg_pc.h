#ifndef UDISK_CHUNK_GET_PG_PC_H_
#define UDISK_CHUNK_GET_PG_PC_H_

#include <ustevent/pb_request_handle.h>
#include "udisk_message.h"


namespace udisk {
namespace chunk {
 
class GetPGPhysicalChunkHandle: public uevent::PbRequestHandle {
 public:
  explicit GetPGPhysicalChunkHandle(uevent::EventLoop* loop) {
  }
  virtual ~GetPGPhysicalChunkHandle() {
  }
  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         const uevent::UMessagePtr& um);
 
  int GetPGPhysicalChunkInfo(int pg_id, 
      ::google::protobuf::RepeatedPtrField<::ucloud::udisk::PGPhysicalChunk>& pg_slices);
  void GetPGPhysicalChunkProcess(uint32_t pg_id, uint64_t cluster_version);

  MYSELF_CREATE(GetPGPhysicalChunkHandle);

 private:
  static int type_;
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage response_;
  ucloud::udisk::GetPGPhysicalChunkResponse* resp_body_;
};

} // namespace chunk
} // namespace udisk
#endif

