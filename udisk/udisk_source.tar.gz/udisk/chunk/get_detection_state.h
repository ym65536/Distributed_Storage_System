#ifndef UDISK_GET_DETECTION_STATE_H_
#define UDISK_GET_DETECTION_STATE_H_

#include <ustevent/pb_request_handle.h>
#include "udisk_message.h"

namespace udisk {
namespace chunk {
 
class GetDetectionStateHandle: public uevent::PbRequestHandle {
 public:
  explicit GetDetectionStateHandle(uevent::EventLoop* loop) {
  }
  virtual ~GetDetectionStateHandle() {
  }
  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         const uevent::UMessagePtr& um);
 
  MYSELF_CREATE(GetDetectionStateHandle);

 private:
  static int type_;
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage response_;
  ucloud::udisk::ChunkGetDetectionStateResponse* resp_body_;
};

} // namespace chunk
} // namespace udisk
#endif

