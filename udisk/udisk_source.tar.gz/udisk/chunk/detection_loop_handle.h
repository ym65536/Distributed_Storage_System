#ifndef UDISK_CHUNK_DETECTION_LOOP_HANDLE_H_
#define UDISK_CHUNK_DETECTION_LOOP_HANDLE_H_

#include <string>
#include <map>
#include <vector>
#include <ustevent/libevent/eventloop_libevent.h>
#include <ustevent/worker_thread.h>
#include "io_error_container.h"
#include "raw_device_manager.h"
#include "raw_chunk_storage_type.h"

namespace udisk {
namespace chunk {

enum DetectionPeriod {
  SUPERBLOCK_PERIOD = 0,
  PCMETA_PERIOD = 1,
  CHECK_PERIOD = 2,
};

class DetectionLoopHandle {
 public:
  DetectionLoopHandle();
  ~DetectionLoopHandle();

  void Start();
  void StartInLoop();

  void NotifyIODepthModify(uint32_t io_depth);
  void NotifyIODepthModifyInLoop(uint32_t io_depth);

  void DetectionDevice();

  uevent::EventLoop* loop() { return detection_loop_; }

  bool is_overload() {return is_overload_; }
  bool is_init() {return is_init_; }
  void GetNextDetectionPC(uint64_t* pc_id, uint64_t* offset, uint64_t* length);
  std::string GetDevName() {return dev_manager_->dev_name(); }

 private:
  void ReportLCIOError();
  std::string EncodeMsg(DetectionPeriod dp);

  uevent::WorkerThread* detection_thread_;
  uevent::EventLoop* detection_loop_;

  std::vector<struct PCMeta*> pcs_;
  // 标识当前设备是否过载
  // 如果过载将不会进行设备检测
  bool is_overload_;
  bool is_init_;
  uint32_t pre_io_depth_;
  uint64_t current_pc_index_;
  DetectionPeriod current_detection_period_;

  RawDeviceManager* dev_manager_;

  // io 读写错误统计
  IOErrorContainer io_error_container_;
};

};  // end of ns chunk
};  // end of ns udisk

#endif
