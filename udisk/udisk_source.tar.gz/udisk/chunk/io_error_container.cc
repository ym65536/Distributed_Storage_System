#include "io_error_container.h"
#include <sstream>

namespace udisk {
namespace chunk {

std::string IOErrorContainer::IOErrorTypeString(IO_ERROR_TYPE type) {
  switch (type) {
    case kRepairIOError:
      return "repair_io_error";
    case kRecycleIOError:
      return "recycle_io_error";
    case kNormalIOError:
      return "normal_io_error";
    case kDetectionIOError:
      return "detection_io_error";
    case kJournalIOFull:
      return "migrate_io_full";
    case kJournalIOTimeout:
      return "migrate_io_timeout";
    case kJournalIOError:
      return "migrate_io_error";
    default:
      return "";
  }
}

std::string IOErrorContainer::IOOpTypeString(IO_OP_TYPE type) {
  switch (type) {
    case kIORead:
      return "read";
    case kIOWrite:
      return "write";
    default:
      return "";
  }
}

void IOErrorContainer::Add(uint32_t lc_id, IO_ERROR_TYPE error_type,
                           IO_OP_TYPE op_type) {
  std::ostringstream ss;
  ss << "lc_id(" << lc_id << ")-" << IOErrorTypeString(error_type) << "-"
     << IOOpTypeString(op_type);
  lc_io_errors_[ss.str()]++;
}

void IOErrorContainer::Add(const std::string& msg) { lc_io_errors_[msg]++; }

void IOErrorContainer::Add(const LCIOErrorMap& lc_io_error) {
  for (auto& it : lc_io_error) {
    lc_io_errors_[it.first] += it.second;
  }
}

};  // end of ns chunk
};  // end of ns udisk

// vim: set ts=2 sw=2 sts=2 et:
