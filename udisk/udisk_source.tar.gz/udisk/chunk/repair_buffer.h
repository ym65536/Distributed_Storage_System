#ifndef UDISK_CHUNK_REPAIR_BUFFER_H_ 
#define UDISK_CHUNK_REPAIR_BUFFER_H_ 

#include <vector>
#include <algorithm>
#include <map>
#include <ustevent/libevent/eventloop_libevent.h>
#include <ustevent/base/timestamp.h>
#include <ustevent/base/logging.h>
#include "udisk_types.h"
#include "chunk_context.h"
#include "pool/memory_pool.h"

namespace udisk {
namespace chunk {

class ChunkLoopHandle;
class ChunkHandle;

enum TPC_STATE {
  TPC_EMPTY = 0,  // 初始状态
  TPC_FINISH = 1, // 结束状态FINISH
  TPC_WRITE = 2,  // 正在写入
};

class TinyPC {
 public:
  TinyPC(uint32_t lc_id, uint32_t pc_no, uint32_t tpc_no, MemorySlab &slab):
    state_(TPC_EMPTY), lc_id_(lc_id), pc_no_(pc_no), tpc_no_(tpc_no), slab_(slab) {
    data_ = (char*)slab_.Malloc();
  };

  ~TinyPC() {
    if(data_) {
      slab_.Free(data_);
    }
  }

  void Insert(uint32_t offset, uint32_t length, const char* data);
  std::string ToString ();

 public:
  std::vector<Interval> write_ranges_;
  char* data_;
  TPC_STATE state_;
  uint32_t lc_id_;
  uint32_t pc_no_;
  uint32_t tpc_no_;
  MemorySlab &slab_;
};

typedef std::shared_ptr<TinyPC> TinyPCPtr;

class RepairBuffer: public std::enable_shared_from_this<RepairBuffer> {
 public:
  const uint32_t TPC_SIZE_ = g_context->chunk_pool()->pc_size() / CHUNK_REPAIR_TINYPC_SIZE;
  const uint32_t TPC_ACTIVE_ = 0;
  const uint32_t TPC_INACTIVE_ = 1;

  RepairBuffer (uint32_t lc_id, uint32_t lc_size, uint32_t pc_no, uint32_t pg_id, uint32_t lc_random_id, 
      ChunkLoopHandle* loop_handle) 
    : lc_id_(lc_id), lc_size_(lc_size), pc_no_(pc_no), pg_id_(pg_id), lc_random_id_(lc_random_id), 
      loop_handle_(loop_handle), ts_pending_(base::Timestamp::now()), slab_(CHUNK_REPAIR_TINYPC_SIZE, 128) {
    active_.resize(TPC_SIZE_, TPC_ACTIVE_);
    inactive_.resize(TPC_SIZE_, TPC_INACTIVE_);
    swap_times_.resize(TPC_SIZE_, 0);
    tiny_pcs_[TPC_ACTIVE_].resize(TPC_SIZE_, nullptr);
    tiny_pcs_[TPC_INACTIVE_].resize(TPC_SIZE_, nullptr);
    states_.resize(TPC_SIZE_, TPC_EMPTY);
    ULOG_INFO << "Init pending buffer, lc_id=" << lc_id_ << ", pc_no=" << pc_no_ << ", lc_random_id=" << lc_random_id_
      << ", start time=" << ts_pending_.toString();
  }

  bool PCNeedRepair(uint32_t offset); 
  void Insert(uint32_t offset, uint32_t length, const char* data);
  void MergePendingBuffer();

 private:
  void MergeTPC();
  void IOSubmitTimer();
  static void AioResponseHandle(int retcode, void* arg);
  void OpenChunkResCb(int retcode, ChunkHandle* handle, const TinyPCPtr& tpc);
  void SubmitLocalWrite(const TinyPCPtr& tpc);
  void NotifyIOLoopHandle();
  void FinishNotify(uint32_t errcode, const std::string& errmsg);

  const uint32_t lc_id_;
  const uint32_t lc_size_;
  const uint32_t pc_no_;
  const uint32_t pg_id_;
  const uint32_t lc_random_id_;
  uint32_t merge_tpc_seqno_ = 0;
  uint32_t front_io_ = 0;
  bool timeout_flag_ = false;
  bool error_flag_ = false;
  std::vector<uint32_t> active_;
  std::vector<uint32_t> inactive_;
  std::vector<uint32_t> swap_times_;
  std::map<uint32_t, base::Timestamp> inflight_list_;
  ChunkLoopHandle* loop_handle_;
  std::vector<TinyPCPtr> tiny_pcs_[2]; //  下标为offset/CHUNK_REPAIR_TINYPC_SIZE;
  std::vector<TPC_STATE> states_;
  uevent::TimerId ti_; 
  // 时间统计
  base::Timestamp ts_pending_; // 开始pending buffer的时间，即RepairBuffer创建时间
  base::Timestamp ts_merge_; // 同步base数据完成，开始merge的时间
  MemorySlab slab_;
};

}
}

#endif
