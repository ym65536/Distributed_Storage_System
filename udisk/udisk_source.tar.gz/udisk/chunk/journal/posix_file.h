#ifndef UDISK_JOURNAL_POSIXFILE_H
#define UDISK_JOURNAL_POSIXFILE_H

#include <string>
#include <unistd.h>
#include "journal_format.h"
#include "jpc_handle.h"
#include "mem_pool.h"
#include "raw_chunk_storage_type.h"

namespace udisk {

namespace journal {

class JPCHandle;

// 由于journal写不是对齐的，需要保存在内存中做处理, 
const static uint64_t kBufferSize = (4 << 20);

class WriteableFile {
 public:
  WriteableFile(JPCHandle* jpc_handle, uint64_t write_offset = 0);
  ~WriteableFile();

  int32_t Append(const char* buf, uint64_t length);
  int32_t Flush(uevent::DiskIOCb done, JournalAioArgs* journal_args);

  uint64_t AvailableSpace() const {
    return file_size_ - AlignUpper(SeekOffset(), BLOCK_SIZE);
  }

  bool IsSpaceAvailable(uint64_t size) const {
    ULOG_TRACE << "file_offset=" << file_offset_ << ", write_offset=" 
        << write_offset_ << ", need_size=" << size;
    return AvailableSpace() >= (size + 3 * (kHeaderSize + kPaddingSize + kEndingSize));
  }

  uint64_t SeekOffset() const {
    assert(file_offset_ + write_offset_ <= file_size_);
    return file_offset_ + write_offset_;
  }
  
  uint64_t Size() const {
    return file_size_;
  }

  JPCHandle* GetJPCHandle() const {
    return jpc_handle_;
  }

 private:
  void RegionFlush(bool init = false);

  JPCHandle* jpc_handle_ = nullptr;
  uint64_t file_size_ = 0;
  uint64_t file_offset_ = 0;
  uint64_t write_offset_ = 0;
  uint64_t sync_offset_ = 0;
  char* data_ = nullptr;
  MemPool mem_pool_;
};

class ReadableFile {
 public:
  ReadableFile(JPCHandle* jpc_handle);
  ~ReadableFile();

  int32_t SequentialRead(char* buf, uint64_t length);

  uint64_t Size() {
    return file_size_;
  }

 private:
  JPCHandle* jpc_handle_ = nullptr;
  uint64_t file_size_ = 0;
  uint64_t read_offset_ = 0;
  char* data_ = nullptr;
};

}
}

#endif

