#ifndef UDISK_JOURNAL_READER_H
#define UDISK_JOURNAL_READER_H

#include "journal_format.h"

namespace udisk {
namespace journal {

const int32_t INVALID_BLOCK_OFFSET = kBlockSize + 1;

class ReadableFile;

class JournalReader {
 public:
  explicit JournalReader(ReadableFile* rfile);
  ~JournalReader();

  // no copy and assignment
  JournalReader(const JournalReader&) = delete;
  JournalReader& operator=(const JournalReader&) = delete;

  int32_t ReadRecord(std::string* record);

  uint64_t SeekOffset() const;

 private:
  int32_t ReadPhysicalRecord(std::string* fragment, uint32_t* record_type);

  ReadableFile* journal_file_;
  int block_offset_ = INVALID_BLOCK_OFFSET;
  uint32_t readable_offset_ = 0;
  char* buffer_;
};

}
}

#endif
