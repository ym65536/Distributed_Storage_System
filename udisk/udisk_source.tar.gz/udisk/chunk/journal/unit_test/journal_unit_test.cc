#include </usr/include/gtest/gtest.h>
#include <unistd.h>
#include <sys/time.h>
#include <sstream>
#include <fstream>
#include <malloc.h>
#include <time.h>

#include <ustevent/base/logging.h>
#include "chunk_context.h"
#include "memtable.h"
#include "skiplist.h"
#include "jpc_handle.h"
#include "posix_file.h"
#include "journal_writer.h"
#include "journal_reader.h"
#include "journal_meta.h"
#include "crc32c.h"
#include "write_batch.h"

using namespace udisk::journal;
using namespace udisk::chunk;

// Construct a string of the specified length made out of the supplied
// partial string.
static std::string BigString(const std::string& partial_string, size_t n) {
  std::string result;
  uint32_t count = 0;
  while (result.size() < n) {
    result.append(partial_string + "_" + std::to_string(count++));
  }
  result.resize(n);
  return result;
}

// Construct a string from a number
static std::string NumberString(int n) {
  char buf[50];
  snprintf(buf, sizeof(buf), "%d.", n);
  return std::string(buf);
}

static std::string PrintContents(WriteBatch* b) {
  const std::string& rep = b->Content();
  std::ostringstream stream;
  stream << b->Count() << "->";
  uint32_t pos = kBatchHeader; // skip count
  IOMeta meta;
  while (pos < rep.size()) {
    stream << "[";
    // parse sequence
    uint64_t sequence = 0;
    memcpy(&sequence, &rep[pos], sizeof (sequence));
    stream << sequence << "@"; 
    pos += sizeof (sequence);
    //parse k-v
    memcpy(&meta, &rep[pos], sizeof(meta));
    stream << meta.lc_id << "." << meta.random_id << "." << meta.pc_no << "." 
        << meta.offset << "." << meta.length << ":";
    pos += sizeof (meta);
    stream << std::string(&rep[pos], meta.length) << "]";
    pos += meta.length;
  }
  return stream.str();
}

static std::string PrintContents(const std::string& rep) {
  std::ostringstream stream;
  IOMeta meta;
  uint64_t sequence = 0;
  uint32_t pos = 0;
  while (pos < rep.size()) {
    stream << "[";
    // parse sequence
    memcpy(&sequence, &rep[pos], sizeof (sequence));
    stream << sequence << "@"; 
    pos += sizeof (sequence);
    //parse k-v
    memcpy(&meta, &rep[pos], sizeof(meta));
    stream << meta.lc_id << "." << meta.random_id << "." << meta.pc_no << "." 
        << meta.offset << "." << meta.length << "]";
    pos += sizeof (meta);
  }
  return stream.str();
}

std::string g_buffer = "UDISKV4E";
class MockJPCHandle : public JPCHandle {
 public:
  MockJPCHandle(bool reset = false) : reset_(reset) {
    if (reset) {
      g_buffer.clear();
    }
    g_buffer.resize(plain_zone_size_, 0);
  }
  virtual ~MockJPCHandle() {
    if (reset_) {
      g_buffer.clear();
    }
  }

  virtual int PRead(void* data, 
                    uint64_t offset, 
                    uint64_t len, 
                    uevent::DiskIOCb done,
                    void* arg,
                    uevent::EventLoop* loop) {
    EXPECT_TRUE(1) << "READ: offset=" << offset << ", len=" << len << ", g_buffer_size=" << g_buffer.size();
    if (g_buffer.size() < offset + len) {
      return -1;
    }
    if (done == nullptr) {
      memcpy((char* )data, &g_buffer[offset], len);
    } else {
      memcpy((char* )data, &g_buffer[offset], len);
      done(len, arg);
    }
    return 0; 
  }
  virtual int PWrite(const void* data, 
                     uint64_t offset, 
                     uint64_t len, 
                     uevent::DiskIOCb done,
                     void* arg,
                     uevent::EventLoop* loop) {
    EXPECT_TRUE(1) << "WRITE: offset=" << offset << ", len=" << len << ", g_buffer_size=" << g_buffer.size(); 
    if (offset + len > plain_zone_size_) {
      return -1;
    }
    if (done == nullptr) {
      memcpy((char*)(&g_buffer[offset]), (const char*)data, len);
    } else {
      memcpy((char*)(&g_buffer[offset]), (const char*)data, len);
      done(len, arg);
    }
    return 0;
  }
  virtual uint32_t GetID() const {
    return jpc_id_;
  }
  virtual uint32_t JPCSize() const {
    return plain_zone_size_;
  }
 
  const char* ToByte() const {
    return (const char*)&g_buffer[0];
  }

  virtual int ResetData() {
    g_buffer.clear();
    g_buffer.assign(kEnding, kEndingSize);
    return UDISK_OK;
  } 

 private:
  bool reset_ = false;
  uint32_t jpc_id_ = 0;
  const static uint32_t plain_zone_size_ = 1024 * 1024 * 128 /*128M*/;
  const static uint32_t plain_zone_num_ = 2;
};

class LogTest {
 public:
  LogTest(bool reset = false) {
    jpc_handle_ = new MockJPCHandle(reset);
    rfile_ = new ReadableFile(jpc_handle_);
    journal_reader_ = new JournalReader(rfile_);
    wfile_ = new WriteableFile(jpc_handle_);
    journal_writer_ = new JournalWriter(wfile_);
  } 

  ~LogTest() {
    delete jpc_handle_;
    delete rfile_;
    delete journal_reader_;
    delete wfile_;
    delete journal_writer_;
  }

  std::string Read() {
    std::string record;
    if (journal_reader_->ReadRecord(&record) >= 0) {
      return record;
    } else {
      return "EOF";
    }
  }

  void Write(const std::string& msg, 
             uevent::DiskIOCb done, 
             JournalAioArgs* journal_args) {
    journal_writer_->AddRecord(msg, done, journal_args);
  }

  static void WriteCb(int32_t retcode, void* arg) {
    auto cb_arg = 
        std::unique_ptr<JournalAioArgs>(reinterpret_cast<JournalAioArgs*>(arg));
    uint64_t buffer = (uint64_t)cb_arg->align_buffer;
    ULOG_TRACE << "AddRecordCb retcode=" << retcode << ", buffer=" << buffer;
    if (retcode <= 0) {
      ULOG_FATAL << "aio recv ERROR, retcode=" << retcode;
      return;
    }
    if (cb_arg->align_buffer) {
      free(cb_arg->align_buffer);
      cb_arg->align_buffer = nullptr;
    }
  }

  const char* Message() {
    return jpc_handle_->ToByte();
  }
  
 private:
  MockJPCHandle* jpc_handle_ = nullptr;
  WriteableFile* wfile_ = nullptr;
  ReadableFile* rfile_ = nullptr;
  JournalWriter* journal_writer_ = nullptr;
  JournalReader* journal_reader_ = nullptr;
};

static std::string RandString(int len) {
  std::string str;
  char *tmp = (char*) calloc(1, len + 1);
  for (auto i = 0; i < len; i++) {
    *(tmp + i) = 97 + (rand() % 26);
  }
  str.assign(tmp);
  free(tmp);
  return str;
}

static int GenLcId() {
  return rand() % 10000;
}

static int GenPcId() {
  return rand() % 10000;
}

static int GenOffset() {
  return rand() % 33554432;
}

static void context_init(const std::string& conf_file) {
  UDiskContext *context = new UDiskContext(conf_file);
  std::tuple<int, std::string> result = context->init();
  if (std::get<0>(result)) {
    std::cerr << "Init Failed," << std::get<1>(result) << std::endl;
    std::exit(-1);
  }
  //初始化成功
  g_context = context;
}

struct ExpectData {
  ExpectData (uint32_t s, uint32_t e, const char* v) :
    start(s), end(e), data(v) {
  }
  uint32_t start;
  uint32_t end;
  const char* data;
};

// test case start
TEST(AllTest, start) {/*{{{*/
  context_init("chunk.conf");
}

TEST(Skiplist, merge_io) {/*{{{*/
  const char* a = "01234";
  const char* b = "xxxx";
  const char* c = "56789";
  const char* d = "ABCDEFG";

  MemTable table1(1024, 1024*1024*1024);
  MemTable table2(1024, 1024*1024*1024);
  MemTable table3(1024, 1024*1024*1024);
  MemTable table4(1024, 1024*1024*1024);

  IOMeta meta_a(0, 0, 0, 0, strlen(a));
  table1.Put(meta_a, a, 0);

  IOMeta meta_b(0, 0, 0, 3, strlen(b));
  table1.Put(meta_b, b, 1);

  IOMeta meta_c(0, 0, 0, 5, strlen(c));
  table2.Put(meta_c, c, 2);

  IOMeta meta_d(0, 0, 0, 16, strlen(d));
  table2.Put(meta_d, d, 3);

  table3.MergeFrom(&table1, UINT32_MAX);
  table3.MergeFrom(&table2, UINT32_MAX);

  IOMeta meta_r(0, 0, 0, 0, 32);
  char buf[32] = {0};
  std::vector<Interval> intervals;
  table3.Get(meta_r, &intervals, buf);
  ASSERT_EQ(intervals.size(), 2);
  ExpectData exp[2] = {
    {0, 10, "012xx56789"},
    {16, 23, d},
  };
  for (uint32_t i = 0; i < (uint32_t)intervals.size(); i++) {
    ASSERT_EQ(exp[i].start, intervals[i].start);
    ASSERT_EQ(exp[i].end, intervals[i].end);
    ASSERT_STREQ(exp[i].data, &buf[exp[i].start]);
  }
  intervals.clear();

  table4.MergeFrom(&table2, UINT32_MAX);
  table4.MergeFrom(&table1, UINT32_MAX);
  table4.Get(meta_r, &intervals, buf);
  for (uint32_t i = 0; i < (uint32_t)intervals.size(); i++) {
    ASSERT_EQ(exp[i].start, intervals[i].start);
    ASSERT_EQ(exp[i].end, intervals[i].end);
    ASSERT_STREQ(exp[i].data, &buf[exp[i].start]);
  }
}/*}}}*/

TEST(Skiplist, Merge_Consistent) {/*{{{*/
  MemTable table1(1024, 1024*1024*1024);
  MemTable table2(1024, 1024*1024*1024);
  uint64_t test_size = 100; // MB
  char buf[1048576];
  int lc_id = 0;
  int pc_no = 0;
  uint64_t offset = 0;
  uint64_t length = BLOCK_SIZE + 8;
  for (uint64_t i = 0; i < (test_size << 20) / length; ++i) {
    std::string data = BigString(NumberString(i), length);
    IOMeta io_meta(lc_id, 0, pc_no, offset, data.length());
    table1.Put(io_meta, data.c_str(), i);
    offset += length;
  }
  table2.MergeFrom(&table1, UINT32_MAX);
  offset = 0;
  for (uint64_t i = 0; i < (test_size << 20) / length; ++i) {
    std::string data = BigString(NumberString(i), length);
    IOMeta io_meta(lc_id, 0, pc_no, offset, data.length());
    memset(buf, 0, sizeof(buf));
    std::vector<Interval> intervals;
    bool ret = table2.Get(io_meta, &intervals, buf);
    ASSERT_EQ(ret, true);
    ASSERT_EQ(intervals.size(), 1);
    ASSERT_STREQ(data.c_str(), buf);
    intervals.clear();
    memset(buf, 0, sizeof(buf));
    ret = table1.Get(io_meta, &intervals, buf);
    ASSERT_EQ(ret, true);
    ASSERT_EQ(intervals.size(), 1);
    ASSERT_STREQ(data.c_str(), buf);
    offset += length;
  }
}/*}}}*/

#if 1
TEST(Skiplist, iterator) {/*{{{*/
  char a0[1024] = "123";
  char b0[1024] = "456";
  char c0[1024] = "789";
  char a1[1024] = "789";
  char b1[1024] = "456";
  char c1[1024] = "123";

  MemTable table(1024, 1024*1024*1024);

  IOMeta meta_0a(0, 0, 0, 0, strlen(a0));
  table.Put(meta_0a, a0, 0);

  IOMeta meta_0b(0, 0, 0, 4, strlen(b0));
  table.Put(meta_0b, b0, 0);

  IOMeta meta_0c(0, 0, 0, 8, strlen(c0));
  table.Put(meta_0c, c0, 0);

  IOMeta meta_1a(0, 0, 1, 0, strlen(a1));
  table.Put(meta_1a, a1, 0);

  IOMeta meta_1b(0, 0, 1, 4, strlen(b1));
  table.Put(meta_1b, b1, 0);

  IOMeta meta_1c(0, 0, 1, 8, strlen(c1));
  table.Put(meta_1c, c1, 0);

  auto iter1 = table.NewIterator();
  while (iter1->Valid()) {
    ExternalIOList values;
    iter1->Value(&values);
    for (auto it = values.begin(); it != values.end(); it++ ) {
      char str[100];
      memset(str, 0, sizeof(str));
      memcpy(str, it->value, it->key.length);
      if (it->key.pc_no == 0) {
        switch (it->key.offset) {
          case 0:
            EXPECT_STREQ(a0, str);
            break;
          case 4:
            EXPECT_STREQ(b0, str);
            break;
          case 8:
            EXPECT_STREQ(c0, str);
            break;
          default:
            ASSERT_EQ(0, 1);
        }
      } else if(it->key.pc_no == 1) {
        switch (it->key.offset) {
          case 0:
            EXPECT_STREQ(a1, str);
            break;
          case 4:
            EXPECT_STREQ(b1, str);
            break;
          case 8:
            EXPECT_STREQ(c1, str);
            break;
          default:
            ASSERT_EQ(0, 1);
        }

      } else {
        ASSERT_EQ(0, 1);
      }
    }
    iter1->Next();
  }
}/*}}}*/

TEST(Skiplist, io_merge) {/*{{{*/
  const char* a = "01234";
  const char* b = "xxxx";
  const char* c = "56789";
  const char* d = "ABCDEFG";

  MemTable table(1024, 1024*1024*1024);

  IOMeta meta_a(0, 0, 0, 0, strlen(a));
  table.Put(meta_a, a, 0);

  IOMeta meta_b(0, 0, 0, 3, strlen(b));
  table.Put(meta_b, b, 1);

  IOMeta meta_c(0, 0, 0, 5, strlen(c));
  table.Put(meta_c, c, 2);

  IOMeta meta_d(0, 0, 0, 16, strlen(d));
  table.Put(meta_d, d, 3);

  IOMeta meta_r(0, 0, 0, 0, 32);
  char buf[32] = {0};
  std::vector<Interval> intervals;
  table.Get(meta_r, &intervals, buf);

  ASSERT_EQ(intervals.size(), 2);
  ExpectData exp[2] = {
    {0, 10, "012xx56789"},
    {16, 23, d},
  };
  for (uint32_t i = 0; i < (uint32_t)intervals.size(); i++) {
    ASSERT_EQ(exp[i].start, intervals[i].start);
    ASSERT_EQ(exp[i].end, intervals[i].end);
    ASSERT_STREQ(exp[i].data, &buf[exp[i].start]);
  }
}/*}}}*/

TEST(MemPool, mem_pool_test) {/*{{{*/
  const uint32_t kBlockSize = (1 << 20);
  for (auto t = 0; t < 100; t++) {
    struct  timeval tv;
    gettimeofday(&tv, nullptr);
    MemTable table(1024, kBlockSize*1024);
    srand(tv.tv_usec);
    uint64_t test_count = 100;
    char buf[kBlockSize];
    for (uint64_t i = 0; i < test_count; i++) {
      int lc_id = GenLcId();
      int pc_id = GenPcId();
      int offset = GenOffset() % kBlockSize;
      int left = kBlockSize - offset;
      std::string data = RandString(rand() % left);
      if (data.length() == 0) {
        continue;
      }
      IOMeta io_meta(lc_id, 0, pc_id, offset, data.length());
      table.Put(io_meta, data.c_str(), i);

      memset(buf, 0, sizeof(buf));
      std::vector<Interval> intervals;
      table.Get(io_meta, &intervals, buf);

      ASSERT_STREQ(data.c_str(), buf);
    }
  }
}/*}}}*/

TEST(Skiplist, skiplist_rand_test) {/*{{{*/
  const uint32_t kBlockSize = (1 << 20);
  MemTable table(1024, 1024*1024*1024);
  uint64_t test_count = 10000;
  char buf[kBlockSize];
  for (uint64_t i = 0; i < test_count; i++) {
    struct  timeval tv;
    gettimeofday(&tv, nullptr);
    srand(tv.tv_usec);
    int lc_id = GenLcId();
    int pc_id = GenPcId();
    int offset = GenOffset() % kBlockSize;
    int left = kBlockSize - offset;
    std::string data = RandString(rand() % left);
    if (data.length() == 0) {
      continue;
    }
    IOMeta io_meta(lc_id, 0, pc_id, offset, data.length());
    table.Put(io_meta, data.c_str(), i);

    memset(buf, 0, sizeof(buf));
    std::vector<Interval> intervals;
    table.Get(io_meta, &intervals, buf);

    ASSERT_STREQ(data.c_str(), buf);
  }
}/*}}}*/

TEST(Skiplist, consistent) {/*{{{*/
  MemTable table(1024, 1024*1024*1024);
  uint64_t test_size = 100; // MB
  char buf[1048576];
  int lc_id = 0;
  int pc_no = 0;
  uint64_t offset = 0;
  uint64_t length = BLOCK_SIZE + 8;
  for (uint64_t i = 0; i < (test_size << 20) / length; ++i) {
    std::string data = BigString(NumberString(i), length);
    IOMeta io_meta(lc_id, 0, pc_no, offset, data.length());
    table.Put(io_meta, data.c_str(), i);
    offset += length;
  }
  offset = 0;
  for (uint64_t i = 0; i < (test_size << 20) / length; ++i) {
    std::string data = BigString(NumberString(i), length);
    IOMeta io_meta(lc_id, 0, pc_no, offset, data.length());
    memset(buf, 0, sizeof(buf));
    std::vector<Interval> intervals;
    bool ret = table.Get(io_meta, &intervals, buf);
    ASSERT_EQ(ret, true);
    ASSERT_EQ(intervals.size(), 1);
    ASSERT_STREQ(data.c_str(), buf);
    offset += length;
    std::cout << "seq_no:" << i 
        << "# lc:" << lc_id
        << " pc:" << pc_no
        << " offset:" << offset
        << " pass" << std::endl;
  }
}/*}}}*/

TEST(Memtable, rw_test) {/*{{{*/
  MemTable table(1024, 1024*1024*1024);
  char a[1024] = "this is a test";
  IOMeta meta_w(0, 0, 0, 0, strlen(a));
  table.Put(meta_w, a, 0);

  IOMeta meta_r(0, 0, 0, 0, strlen(a));
  std::vector<Interval> intervals;
  char buf[1024];
  memset(buf, 0, sizeof(buf));
  table.Get(meta_r, &intervals, buf);
  char b[1024];
  memset(b, 0, sizeof(b));
  memcpy(b, buf + size_t(intervals[0].start), (intervals[0].end - intervals[0].start) + 1);
  
  EXPECT_STREQ(a, b);
}/*}}}*/

TEST(Skiplist, skiplist_test) {/*{{{*/
  char a0[1024] = "123";
  char b0[1024] = "456";
  char c0[1024] = "789";
  char a1[1024] = "789";
  char b1[1024] = "456";
  char c1[1024] = "123";

  MemTable table(1024, 1024*1024*1024);

  IOMeta meta_0a(0, 0, 0, 0, strlen(a0));
  table.Put(meta_0a, a0, 0);

  IOMeta meta_0b(0, 0, 0, 4, strlen(b0));
  table.Put(meta_0b, b0, 0);

  IOMeta meta_0c(0, 0, 0, 8, strlen(c0));
  table.Put(meta_0c, c0, 0);

  IOMeta meta_1a(0, 0, 1, 0, strlen(a1));
  table.Put(meta_1a, a1, 0);

  IOMeta meta_1b(0, 0, 1, 4, strlen(b1));
  table.Put(meta_1b, b1, 0);

  IOMeta meta_1c(0, 0, 1, 8, strlen(c1));
  table.Put(meta_1c, c1, 0);

  table.Shrink();
  auto iter1 = table.NewIterator();
  while (iter1->Valid()) {
    ExternalIOList values;
    iter1->Value(&values);
    std::cout << "####:size:" << values.size() << std::endl;
    for (auto it = values.begin(); it != values.end(); it++ ) {
      char str[100];
      memset(str, 0, sizeof(str));
      memcpy(str, it->value, it->key.length);
      if (it->key.pc_no == 0) {
        switch (it->key.offset) {
          case 0:
            EXPECT_STREQ(a0, str);
            break;
          case 4:
            EXPECT_STREQ(b0, str);
            break;
          case 8:
            EXPECT_STREQ(c0, str);
            break;
          default:
            ASSERT_EQ(0, 1);
        }
      } else if(it->key.pc_no == 1) {
        switch (it->key.offset) {
          case 0:
            EXPECT_STREQ(a1, str);
            break;
          case 4:
            EXPECT_STREQ(b1, str);
            break;
          case 8:
            EXPECT_STREQ(c1, str);
            break;
          default:
            ASSERT_EQ(0, 1);
        }
      } else {
        ASSERT_EQ(0, 1);
      }
    }
    iter1->Next();
  }
}/*}}}*/

TEST(Skiplist, shrink_test) {/*{{{*/
  const char* a = "123";
  const char* b = "456";
  const char* c = "789";
  MemTable table(1024, 1024*1024*1024);
  std::vector<ExpectData> Expects;
  IOMeta meta_0a(0, 0, 0, 0, strlen(a));
  table.Put(meta_0a, a, 0);
  Expects.emplace_back(0, 3, a);
  IOMeta meta_0b(0, 0, 0, 3, strlen(b));
  table.Put(meta_0b, b, 0);
  Expects.emplace_back(3, 6, b);
  IOMeta meta_0c(0, 0, 0, 6, strlen(c));
  table.Put(meta_0c, c, 0);
  Expects.emplace_back(6, 9, c);
  IOMeta meta_0d(0, 0, 0, 9, strlen(a));
  table.Put(meta_0d, a, 0);
  Expects.emplace_back(9, 12, a);

  IOMeta meta_0e(0, 0, 0, 15, strlen(b));
  table.Put(meta_0e, b, 0);
  Expects.emplace_back(15, 18, b);
  IOMeta meta_0f(0, 0, 0, 18, strlen(c));
  table.Put(meta_0f, c, 0);
  Expects.emplace_back(18, 21, c);

  auto iter1 = table.NewIterator();
  while (iter1->Valid()) {
    ExternalIOList values;
    iter1->Value(&values);
    ASSERT_EQ(values.size(), Expects.size());
    uint32_t i = 0;
    for (auto item : values) {
      const IOMeta& meta = item.key;
      ASSERT_EQ(Expects[i].start, meta.offset);
      ASSERT_EQ(Expects[i].end - Expects[i].start, meta.length);
      ASSERT_STREQ(Expects[i].data, std::string(item.value, strlen(Expects[i].data)).c_str());
      ++ i;
    }
    iter1->Next();
  }

  Expects.clear();
  Expects.emplace_back(0, 12, "123456789123");
  Expects.emplace_back(15, 21, "456789");
  table.Shrink();
  auto iter = table.NewIterator();
  while (iter->Valid()) {
    ExternalIOList values;
    iter->Value(&values);
    uint32_t i = 0;
    for (auto item : values) {
      const IOMeta& meta = item.key;
      ASSERT_EQ(Expects[i].start, meta.offset);
      ASSERT_EQ(Expects[i].end - Expects[i].start, meta.length);
      ASSERT_STREQ(Expects[i].data, std::string(item.value, strlen(Expects[i].data)).c_str());
      ++ i;
    }
    iter->Next();
  }
}/*}}}*/
#endif

#if 1
TEST(Skiplist, shrink_unmerge_test) {/*{{{*/
  context_init("chunk.conf");
  MemTable table(1024, 1024*1024*1024);
  std::string str_a;
  std::string str_b;
  std::string str_c;

  for (uint32_t lc_id = 0; lc_id < 100; lc_id++) {
    for (uint32_t pc_id = 0; pc_id < 100; pc_id++) {
      int offset = 0;
      for (auto i = 0; i < 100; i++) {
        auto len = (rand() % 512) + 1;
        std::string data = RandString(len);
        str_a += data;
        offset += (rand() % 3) + 1;
        IOMeta meta(lc_id, 0, pc_id, offset, len);
        table.Put(meta, data.c_str(), 0);
        offset += len;
      }
    }
  }

  auto iter1 = table.NewIterator();
  while (iter1->Valid()) {
    ExternalIOList values;
    iter1->Value(&values);
    for (auto it = values.begin(); it != values.end(); ++ it) {
      str_b += std::string(it->value, it->key.length);
    }
    iter1->Next();
  }
  ASSERT_STREQ(str_a.c_str(), str_b.c_str());

  table.Shrink();
  auto iter = table.NewIterator();
  while (iter->Valid()) {
    ExternalIOList values;
    iter->Value(&values);
    for (auto it = values.begin(); it != values.end(); ++ it) {
      str_c += std::string(it->value, it->key.length);
    }
    iter->Next();
  }
  ASSERT_STREQ(str_a.c_str(), str_c.c_str());
}/*}}}*/

TEST(Skiplist, shrink_merge_test) {/*{{{*/
  MemTable table(1024, 1024*1024*1024);
  int lc_id = 0;
  int pc_id = 0;
  std::string str_a;
  std::string str_b;
  std::string str_c;

  for (; lc_id < 100; lc_id++) {
    for (; pc_id < 100; pc_id++) {
      int offset = 0;
      for (auto i = 0; i < 100; i++) {
        auto len = (rand() % 512) + 1;
        std::string data = RandString(len);
        str_a += data;
        IOMeta meta(lc_id, 0, pc_id, offset, len);
        table.Put(meta, data.c_str(), 0);
        offset += len;
      }
    }
  }

  auto iter1 = table.NewIterator();
  while (iter1->Valid()) {
    ExternalIOList values;
    iter1->Value(&values);
    for (auto it = values.begin(); it != values.end(); ++ it) {
      str_b += std::string(it->value, it->key.length);
    }
    iter1->Next();
  }
  ASSERT_STREQ(str_a.c_str(), str_b.c_str());

  table.Shrink();
  auto iter = table.NewIterator();
  while (iter->Valid()) {
    ExternalIOList values;
    iter->Value(&values);
    for (auto it = values.begin(); it != values.end(); ++ it) {
      str_c += std::string(it->value, it->key.length);
    }
    iter->Next();
  }
  ASSERT_STREQ(str_a.c_str(), str_c.c_str());
}/*}}}*/

TEST(Skiplist, consistent_test) {/*{{{*/
  for (auto k = 0; k < 10; k++) {
    MemTable* table = new MemTable(k, 1024*1024*1024);
    struct  timeval tv;
    gettimeofday(&tv, nullptr);
    srand(tv.tv_usec);
    uint64_t test_count = 1000;
    char buf[1048576];
    table->IncRef();
    for (uint64_t i = 0; i < test_count; i++) {
      ULOG_DEBUG << ">>>>>>>:" << i;
      int lc_id = GenLcId();
      int pc_id = GenPcId();
      int offset = GenOffset();
      int left = (1048576 - offset % 1048576) / 512;
      ULOG_DEBUG << "#size:" << left;
      if (left == 0) {
        continue;
      }
      int sec_num = rand() % left;
      std::string data = RandString(sec_num * 512);
      if (data.length() == 0) {
        continue;
      }

      std::cout << "###:" << data.length();
      IOMeta io_meta(lc_id, 0, pc_id, offset, data.length());
      table->Put(io_meta, data.c_str(), i);

      memset(buf, 0, sizeof(buf));
      std::vector<Interval> intervals;
      table->Get(io_meta, &intervals, buf);

      ASSERT_STREQ(data.c_str(), buf);
    }
    table->DecRef();
  }
}/*}}}*/
#endif

#if 1 
TEST(LogTestInfo, Empty) {
  context_init("chunk.conf");
  LogTest journal;
  ASSERT_EQ("EOF", journal.Read()) << ", Info=" << journal.Read();
} 

TEST(LogTestInfo, ReadWrite) {
  LogTest journal;
  auto args = new JournalAioArgs();
  journal.Write("foo", LogTest::WriteCb, args);
  args = new JournalAioArgs();
  journal.Write("bar", LogTest::WriteCb, args);
  args = new JournalAioArgs();
  journal.Write("", LogTest::WriteCb, args);
  args = new JournalAioArgs();
  journal.Write("xxxx", LogTest::WriteCb, args);
  ASSERT_EQ("foo", journal.Read());
  ASSERT_EQ("bar", journal.Read());
  //ASSERT_EQ("", journal.Read());
  ASSERT_EQ("xxxx", journal.Read());
  ASSERT_EQ("EOF", journal.Read());
  ASSERT_EQ("EOF", journal.Read());
} 

TEST(LogTestInfo, ManyBlocks) {
  LogTest journal;
  int32_t count = 10000;
  int32_t size = 4 * 1024 + 40;
  for (int i = 0; i < count; i++) {
    auto args = new JournalAioArgs();
    journal.Write(BigString("test" + std::to_string(i), size), LogTest::WriteCb, args);
  }
  for (int i = 0; i < count; i++) {
    ASSERT_EQ(BigString("test" + std::to_string(i), size), journal.Read());
  }
  ASSERT_EQ("EOF", journal.Read());
}

TEST(LogTestInfo, Fragmentation) {
  LogTest journal;
  uint32_t block_size = (1 << 20);
  auto args = new JournalAioArgs();
  journal.Write("small", LogTest::WriteCb, args);
  args = new JournalAioArgs();
  journal.Write(BigString("medium", block_size >> 1), LogTest::WriteCb, args);
  int count = 16;
  for (int i = 0; i < count; ++i) {
    args = new JournalAioArgs();
    journal.Write(BigString("large", block_size << 1), LogTest::WriteCb, args);
  }
  ASSERT_EQ("small", journal.Read());
  ASSERT_EQ(BigString("medium", block_size >> 1), journal.Read());
  for (int i = 0; i < count; ++i) {
    ASSERT_EQ(BigString("large", block_size << 1), journal.Read());
  }
  ASSERT_EQ("EOF", journal.Read());
}

TEST(LogTestInfo, MarginalTrailer) {
  // Make a trailer that is exactly the same length as an empty record.
  LogTest journal;
  const int n = kBlockSize - 2*kHeaderSize;
  auto args = new JournalAioArgs();
  journal.Write(BigString("foo", n), LogTest::WriteCb, args);
  //ASSERT_EQ(kBlockSize - kHeaderSize, WrittenBytes());
  args = new JournalAioArgs();
  journal.Write("bar", LogTest::WriteCb, args);
  ASSERT_EQ(BigString("foo", n), journal.Read());
  ASSERT_EQ("bar", journal.Read());
  ASSERT_EQ("EOF", journal.Read());
}

TEST(LogTestInfo, AlignedEof) {
  LogTest journal;
  const int n = kBlockSize - 2*kHeaderSize + 4;
  auto args = new JournalAioArgs();
  journal.Write(BigString("foo", n), LogTest::WriteCb, args);
  //ASSERT_EQ(kBlockSize - kHeaderSize + 4, WrittenBytes());
  ASSERT_EQ(BigString("foo", n), journal.Read());
  ASSERT_EQ("EOF", journal.Read());
}
#endif

#if 1
TEST(WriteBatchInfo, Empty) {
  WriteBatch batch;
  ASSERT_EQ("0->", PrintContents(&batch));
}

TEST(WriteBatchInfo, Multi) {
  WriteBatch batch;
  uint64_t seqno = 1;
  std::string data = "foobarhaha";
  IOMeta meta = {1, 2988, 1, 0, 10};
  batch.Put(meta, data.c_str(), seqno);
  ASSERT_EQ("1->[1@1.2988.1.0.10:foobarhaha]", PrintContents(&batch));
  WriteBatch last;
  last.Append(&batch);
  last.Append(&batch);
  ASSERT_EQ("2->[1@1.2988.1.0.10:foobarhaha][1@1.2988.1.0.10:foobarhaha]", PrintContents(&last));
}

TEST(InternalBatchInfo, AllContent) {
  WriteBatch batch;
  uint64_t seqno = 1;
  std::string data = "foobarhaha";
  IOMeta meta = {1, 9, 1, 0, 10};
  batch.Put(meta, data.c_str(), seqno);
  ASSERT_EQ("1->[1@1.9.1.0.10:foobarhaha]", PrintContents(&batch));

  WriteBatch batch1;
  seqno = 2;
  data = "barfoohaha";
  meta = {2, 9, 2, 6, 10};
  batch1.Put(meta, data.c_str(), seqno);
  ASSERT_EQ("1->[2@2.9.2.6.10:barfoohaha]", PrintContents(&batch1));

  WriteBatch last;
  last.Append(&batch);
  last.Append(&batch1);
  ASSERT_EQ("2->[1@1.9.1.0.10:foobarhaha][2@2.9.2.6.10:barfoohaha]", PrintContents(&last));
  
  const uint32_t SIZE = sizeof (IOMeta) + sizeof (uint64_t);
  InternalBatch inter_batch;
  last.Slim(&inter_batch);
  std::vector<std::string> data_list;
  data_list.push_back("[1@1.9.1.0.10]");
  data_list.push_back("[2@2.9.2.6.10]");
  InternalBatchData* batch_data;
  while ((batch_data = inter_batch.SequentialRead()) != nullptr) {
    uint32_t nbyte = batch_data->rep.size();
    ASSERT_EQ(SIZE * 2, nbyte);
    for (uint32_t i = 0; i < nbyte / SIZE; ++i) {
      const char* buffer = batch_data->rep.data();
      std::string data(buffer + i * SIZE, SIZE);
      ASSERT_EQ(data_list[i], PrintContents(data));
    }
  }
}
#endif

/**********************main*************************/
int main(int argc, char** argv) {
  ::testing::InitGoogleTest(&argc, argv);
  base::Logger::setLogLevel(base::Logger::LogLevel::TRACE);
  return RUN_ALL_TESTS();
}
