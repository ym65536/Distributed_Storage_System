#ifndef UDISK_JOURNAL_WRITE_BATCH_H
#define UDISK_JOURNAL_WRITE_BATCH_H

#include <string>
#include <map>
#include <algorithm>
#include <assert.h>
#include <memory>
#include "journal_format.h"

namespace udisk {
namespace journal {

class MemTable;
class InternalBatch;

const static uint32_t kBatchHeader = 4/* count */;

class WriteBatch {
 public:
  WriteBatch();
  ~WriteBatch();

  //copyable
  
  const std::string& Content() const;

  void Put(const chunk::IOMeta& meta, const char* buf, uint64_t seqno);

  void Append(const WriteBatch* batch);
  
  void SetContent(std::string& record);
  
  void Slim(InternalBatch* slim);

  void Clear() {
    rep_.assign(kBatchHeader, 0);
  }

  uint32_t ByteSize() {
    return rep_.size() - kBatchHeader;
  }

  uint32_t Count() const;

  void Iterator(MemTable* mem, 
                uint64_t* last_sequence, 
                uint32_t lc_id = UINT32_MAX);

 private:
  void SetCount(uint32_t count);
  /*
   * +---------+-------------+-------------+-----+-------------+
   * | count   | seqno, K-V  | seqno, K-V  | ... | seqno, K-V  |
   * +---------+-------------+-------------+-----+-------------+ 
   * */
  std::string rep_;  
};

typedef WriteBatch* WriteBatchPtr;

struct InternalBatchData {
  std::string rep;
  uint64_t min_seq = UINT64_MAX;
  uint64_t max_seq = 0;
};

typedef std::unique_ptr<InternalBatchData> InternalBatchDataPtr;

class InternalBatch {
 public:
  InternalBatch() {
    Clear();
  }
  ~InternalBatch() {
    batch_blocks_.clear();
    cursor_ = 0;
  }

  void Append(uint64_t seqno, const chunk::IOMeta& meta); 

  InternalBatchData* SequentialRead();

  void ParseContent(const std::string& record, 
                    std::map<uint64_t, chunk::IOMeta>* migrate_meta,
                    uint32_t lc_id,
                    uint64_t seqno);

  void Clear() {
    batch_blocks_.clear();
    InternalBatchDataPtr batch_data(new InternalBatchData);
    batch_blocks_.push_back(std::move(batch_data));
    cursor_ = 0;
  }

  private:
  std::vector<InternalBatchDataPtr> batch_blocks_;
  uint32_t cursor_;
};

} 
}

#endif
