#include <ustevent/base/logging.h>
#include <ustevent/base/my_uuid.h>
#include "memtable.h"
#include "skiplist.h"
#include "chunk_context.h"

using namespace udisk::journal;
using namespace udisk::chunk;

MemTable::MemTable(uint32_t pg_id, uint64_t cap) : id_(UINT64_MAX), refs_(0), 
    pg_id_(pg_id), mem_usage_(0), mem_cap_(cap) {/*{{{*/
  lc_map_.resize(g_context->config().max_udisk_num(), nullptr);
  lc_mem_usage_.resize(g_context->config().max_udisk_num(), 0);
  struct timeval tv;
  gettimeofday(&tv, nullptr);
  id_ = tv.tv_sec * 1000000 + tv.tv_usec;
  ULOG_DEBUG << "pg_id=" << pg_id_ << ", Create memtable id=" << id_ 
      << ", ref=" << refs_;
}/*}}}*/

MemTable::~MemTable() {/*{{{*/
  ULOG_DEBUG << "pg_id=" << pg_id_ << ", Release memtable id=" << id_ 
      << ", ref=" << refs_;
  for (auto item : lc_list_) {
    delete item;
  }
}/*}}}*/

// Increase reference count.
void MemTable::IncRef() { 
  ++ refs_;
  ULOG_DEBUG << "pg_id=" << pg_id_ << ", Inc memtable id=" << id_ 
      << ", now ref=" << refs_;
}

// Drop reference count.  Delete if no more references exist.
void MemTable::DecRef() {
  -- refs_;
  assert(refs_ >= 0);
  ULOG_INFO << "pg_id=" << pg_id_ << ", Dec memtable id=" << id_ 
      << ", now ref=" << refs_;
  if (refs_ == 0) {
    delete this;
  }
}

bool MemTable::Get(const IOMeta& meta, /*{{{*/
              std::vector<Interval>* intervals, 
              char* buf) {
  ULOG_TRACE << meta.ToString();
  if (lc_map_[meta.lc_id] == nullptr) {
    return false;
  }
  size_t size = lc_map_[meta.lc_id]->Read(
      meta.lc_id, meta.pc_no, meta.offset, meta.length, buf, intervals);
  return (size == meta.length);
}/*}}}*/

void MemTable::Put(const IOMeta& meta, /*{{{*/
                   const char* buf, 
                   uint64_t seqno) {
  ULOG_TRACE << "pg_id=" << pg_id_ << ", meta=" << meta.ToString() 
      << ",seqno=" << seqno;
  min_seq_ = std::min(min_seq_, seqno);
  max_seq_ = std::max(max_seq_, seqno);
  if (lc_map_[meta.lc_id] == nullptr) {
    Skiplist* new_skp = new Skiplist();
    {
      std::lock_guard<std::mutex> guard(mutex_);
      lc_list_.push_back(new_skp);
    }
    lc_map_[meta.lc_id] = new_skp;
  } 
  mem_usage_ += meta.length;
  lc_mem_usage_[meta.lc_id] += meta.length;
  lc_map_[meta.lc_id]->Write(meta.lc_id, meta.pc_no, meta.offset, meta.random_id,
                             meta.length, seqno, buf);
}/*}}}*/

std::shared_ptr<MemTableIterator> MemTable::NewIterator() {/*{{{*/
  return std::make_shared<MemTableIterator>(lc_list_);
}/*}}}*/

//存在多个线程同时merge，需要加锁
void MemTable::MergeFrom(MemTable* mem, uint32_t lc_id) {
  if (mem == nullptr) {
    return;
  }
  for (auto iter = mem->NewIterator(); iter->Valid(); iter->Next()) {
    ExternalIOList internal_ios;
    iter->Value(&internal_ios);
    assert(!internal_ios.empty());
    auto io = internal_ios.front();
    const auto& meta = io.key;
    if ((meta.lc_id != lc_id) && (lc_id != UINT32_MAX)) {
      continue;
    } 
    for (auto item : internal_ios) {
      assert(item.key.lc_id == meta.lc_id);
      assert(item.key.pc_no == meta.pc_no);
      mem_usage_ += meta.length;
      min_seq_ = std::min(min_seq_, item.seqno);
      max_seq_ = std::max(max_seq_, item.seqno);
    }
    if (lc_map_[meta.lc_id] == nullptr) {
      Skiplist* new_skp = new Skiplist();
      {
        std::lock_guard<std::mutex> guard(mutex_);
        lc_list_.push_back(new_skp);
      }
      lc_map_[meta.lc_id] = new_skp;
    } 
    lc_map_[meta.lc_id]->Merge(internal_ios);
  }
}

void MemTable::CopyFrom(MemTable* mem, uint32_t lc_id) {
  if (mem == nullptr) {
    return;
  }
  for (auto iter = mem->NewIterator(); iter->Valid(); iter->Next()) {
    ExternalIOList ext_ios;
    iter->Value(&ext_ios);
    //对IO按seqno排序
    auto seqno_compare = [] (const ExternalIO& a, const ExternalIO& b) {
      return a.seqno < b.seqno;
    };
    ext_ios.sort(seqno_compare);
    for (auto ext_io : ext_ios) {
      if (lc_id == ext_io.key.lc_id) {
        this->Put(ext_io.key, ext_io.value, ext_io.seqno);
      }
    }
  }
}

void MemTable::SpliceFrom(MemTable* mem, uint32_t lc_id) {
  if (mem == nullptr) {
    return;
  }
  assert(lc_map_[lc_id] == nullptr);
  Skiplist* skip = nullptr;
  uint64_t mem_usage = 0;
  std::tie(skip, mem_usage) = mem->SpliceTo(lc_id);
  if (skip == nullptr) {
    return;
  }
  {
    std::lock_guard<std::mutex> guard(mutex_);
    lc_list_.push_back(skip);
  }
  lc_map_[lc_id] = skip;
  mem_usage_ += mem_usage;
  lc_mem_usage_[lc_id] = mem_usage;
}

std::pair<Skiplist*, uint64_t> MemTable::SpliceTo(uint32_t lc_id) {
  if (lc_map_[lc_id] == nullptr) {
    return std::make_pair(nullptr, 0);
  }
  std::lock_guard<std::mutex> guard(mutex_);
  Skiplist* skp = lc_map_[lc_id];
  uint64_t mem_usage = lc_mem_usage_[lc_id];
  for(auto it = lc_list_.begin(); it != lc_list_.end(); ) {
    if (*it == skp) {
      it = lc_list_.erase(it);
    } else {
      ++ it;
    }
  } 
  lc_map_[lc_id] = nullptr;
  assert(mem_usage_ >= mem_usage);
  mem_usage_ -= mem_usage;
  lc_mem_usage_[lc_id] = 0;
  return std::make_pair(skp, mem_usage);
}

void MemTable::Shrink() {
  for (auto iter = NewIterator(); iter->Valid(); iter->Next()) {
    iter->Shrink();
  }
}

