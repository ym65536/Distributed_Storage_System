#include "posix_file.h"
#include <algorithm>
#include <ustevent/base/logging.h>
#include "jpc_handle.h"

using namespace udisk::journal;
using namespace udisk;
using namespace udisk::chunk;

WriteableFile::WriteableFile(JPCHandle* jpc_handle, uint64_t write_offset) :
    jpc_handle_(jpc_handle) {
  file_size_ = jpc_handle->JPCSize();
  ULOG_DEBUG << "WriteableFile Create: file_size=" << file_size_ 
      << ", posix malloc kBufferSize=" << kBufferSize << ", init write_offset="
      << write_offset;
  posix_memalign((void**)&data_, BLOCK_SIZE, kBufferSize << 1);
  if (write_offset == 0) {
    RegionFlush(true);
  } else {
    write_offset_ = write_offset & (kBufferSize - 1);
    sync_offset_ = write_offset_;
    // 获取write_offset所属的BufferData
    file_offset_ = write_offset & (~(kBufferSize - 1));
    int32_t ret = jpc_handle_->PRead(data_, file_offset_, 
        AlignUpper(sync_offset_, BLOCK_SIZE), nullptr, nullptr, nullptr);
    assert(ret == UDISK_OK);
    ULOG_DEBUG << "Init write_offset=" << write_offset << ". file_offset=" 
        << file_offset_ << ", sync_offset=" << sync_offset_ << ", write_offset="
        << write_offset_ << ", ret=" << ret;
  }
}

WriteableFile::~WriteableFile() {
  ULOG_DEBUG << "posix Release kBufferSize=" << kBufferSize;
  free(data_);
}

/* 
 * 总写入大小不超过kBufferSize * 2
 * */
int32_t WriteableFile::Append(const char* buf, uint64_t length) {
  assert(length <= (kBufferSize >> 1));
  int32_t result = 0;
  while (length > 0) {
    size_t avail = kBufferSize - write_offset_;
    ULOG_DEBUG << "file_offset=" << file_offset_ << ", write_offset=" << write_offset_
        << ", avail_size=" << avail << ", need_length=" << length;
    if (avail <= 0) {
      avail = kBufferSize * 2 - write_offset_;
      assert(avail > 0);
      ULOG_WARN << "need region flush, use left space. avail=" << avail;
    }
    size_t nbytes = std::min((uint64_t)avail, length);
    memcpy(data_ + write_offset_, buf + result, nbytes);
    length -= nbytes;
    write_offset_ += nbytes;
    result += nbytes;
  }
  ULOG_DEBUG << "file_offset=" << file_offset_ << ", write_offset=" << write_offset_
      << ", result=" << result << ", length=" << length;
  return result;
}

void WriteableFile::RegionFlush(bool init) {
  ULOG_DEBUG << "Write file switch new shm data. file_offset=" << file_offset_
      << ", sync_offset=" << sync_offset_ << ", write_offset=" << write_offset_;
  // BufferData切换时, 可能部分数据还没有flush，需要先flush一次
  if (write_offset_ > kBufferSize) {
    assert(write_offset_ - kBufferSize < kBufferSize);
    // 通过assert可以确认不会有重叠，改成memcopy即可
    // memmove(data_, data_ + kBufferSize, write_offset_ - kBufferSize);
    memcpy(data_, data_ + kBufferSize, write_offset_ - kBufferSize);
    write_offset_ -= kBufferSize;
    sync_offset_ = write_offset_;
  } else {
    write_offset_ = 0;
    sync_offset_ = 0;
  }
  if (init == false) {
    file_offset_ += kBufferSize;
  } else {
    file_offset_ = 0;
  }
  // 后续取消同步AddRecord, memset可以取消
  //memset(data_ + write_offset_, 0, (kBufferSize << 1) - write_offset_);
  ULOG_DEBUG << "Write file switch to new shm data. file_offset=" << file_offset_
      << ", sync_offset=" << sync_offset_ << ", write_offset=" << write_offset_;
  assert(file_offset_ + kBufferSize <= file_size_);
  return;
}

int32_t WriteableFile::Flush(uevent::DiskIOCb done, 
                             JournalAioArgs* journal_args) {
  uint64_t pos1 = AlignLower(sync_offset_, BLOCK_SIZE);
  uint64_t pos2 = AlignUpper(write_offset_, BLOCK_SIZE);
  if (pos2 == pos1) {
    return UDISK_OK;
  }
  ULOG_DEBUG << "sync_offset=" << sync_offset_ << ", write_offset_=" << write_offset_ 
    << ", file_offset=" << file_offset_ << ", pos1=" << pos1 << ", pos2=" << pos2;
  assert(journal_args != nullptr);
  assert(!(done == nullptr));
  int32_t ret = UDISK_OK;
  bool mem_shared = false;
  assert(journal_args->align_buffer == nullptr);
  uint64_t sync_size = 0;
  if (pos2 - write_offset_ < kEndingSize) {
    // 这里增加ending，recover时根据header==ending标记结束
    sync_size = pos2 - pos1;
    pos2 += BLOCK_SIZE;
    ULOG_DEBUG << "sync_offset=" << sync_offset_ << ", write_offset_=" << write_offset_ 
      << ", pos1=" << pos1 << ", add padding now pos2=" << pos2;
  } else {
    sync_size = pos2 - pos1;
  }
  journal_args->align_buffer = mem_pool_.AllocateIO(sizeof(char) * (pos2 - pos1), mem_shared);
  memcpy(journal_args->align_buffer, data_ + pos1, sync_size);
  assert(pos2 - write_offset_ >= kEndingSize);
  memcpy(journal_args->align_buffer + write_offset_ - pos1, kEnding, kEndingSize);
  const void* addr = journal_args->align_buffer; 
  if (mem_shared) { // 共享模式，由mem_pool管理内存
    journal_args->align_buffer = nullptr;
  }
  ret = jpc_handle_->PWrite(addr, 
                            file_offset_ + pos1, 
                            pos2 - pos1, 
                            done, 
                            journal_args, 
                            journal_args->loop);
  if (ret < 0) {
    ULOG_ERROR << "PWrite error, ret=" << ret;
    return ret;
  }
  ULOG_DEBUG << "Flush Data ret=" << ret << ", sync_offset=" << sync_offset_ 
      << ", write_offset=" << write_offset_ << ", file_offset=" << file_offset_ 
      << ", sync_size=" << pos2 - pos1 << ", shared=" << mem_shared; 
  sync_offset_ = write_offset_;
  if (write_offset_ >= kBufferSize) {
    RegionFlush();
  }
  return ret;
}

ReadableFile::ReadableFile(JPCHandle* jpc_handle) :
    jpc_handle_(jpc_handle) {
  file_size_ = jpc_handle->JPCSize();
  posix_memalign((void**)&data_, BLOCK_SIZE, kBufferSize);
  memset(data_, 0, kBufferSize);
}

ReadableFile::~ReadableFile() {
  free(data_);
}

int32_t ReadableFile::SequentialRead(char* buf, uint64_t length) {
  assert(read_offset_ + length <= file_size_);
  int32_t ret = 0;
  ret = jpc_handle_->PRead(buf, read_offset_, length, nullptr, nullptr, nullptr);
  if (ret < 0) {
    return ret;
  }
  read_offset_ += length;

  return length;
}

