#ifndef UDISK_JOURNAL_SKIPLIST_H_
#define UDISK_JOURNAL_SKIPLIST_H_

#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <assert.h>
#include <vector>
#include <list>
#include <string>
#include <memory>
#include <atomic>
#include "journal_format.h"
#include <ustevent/base/logging.h>
#include "mem_pool.h"

namespace udisk {
namespace journal {

class Skiplist {
 private:
  struct Node;

 public:
  explicit Skiplist();
  ~Skiplist();

  Skiplist(const Skiplist&) = delete;//禁止拷贝
  void operator=(const Skiplist&) = delete;//禁止赋值

  class Iterator {
   public:
    explicit Iterator(Skiplist* list);

    bool Valid() const;

    void Next();

    void Value(ExternalIOList*) const;

    void Shrink();

    void Seek(uint32_t lc_id,
              uint32_t pc_no,
              uint32_t tpc);

    void Rewind() {
      node_ = skp_->head_->next_node[0].load(std::memory_order_acquire);
    }

   private:
    Skiplist* skp_;
    Node* node_;
  };

  void Write(uint32_t lc_id, 
             uint32_t pc_no,
             uint64_t offset,
             uint32_t random_id,
             uint64_t length,
             uint64_t seqno,
             const char* data);

  size_t Read(uint32_t lc_id,
            uint32_t pc_no,
            uint64_t offset,
            uint64_t length,
            char* buf,
            std::vector<chunk::Interval>* intervals);

  void Merge(const ExternalIOList& ext_ios);

  //非线程安全
  bool Empty() {
    return (length_ == 1);
  }

  void Dump();

  void Visit () const;

 private:
  struct IO {
    explicit IO (uint64_t off,
                 uint64_t len,
                 uint64_t seq,
                 bool mem_shared,
                 char* io) 
        : offset(off), 
          length(len), 
          seqno(seq),
          shared(mem_shared),
          data(io) {
      ULOG_TRACE << ">>>new IO, shared:" << shared
          << " address:" << (void*)data;
    }

    ~IO() {
      if (shared == false) {
        ULOG_TRACE << ">>>free IO, shared:" << shared
          << " address:" << (void*)data;
        free(data);
        data = nullptr;
      }
    }

    std::string ToString() const {
      std::ostringstream oss;
      oss << "IO offset=" << offset << ",len=" << length << ",seqno=" << seqno 
          << ",mem_shared=" << shared << ",data_addr=" << (void*)data;
      return oss.str();
    }

    uint64_t offset;//tpc offset
    uint64_t length;
    uint64_t seqno;
    const bool shared;
    char* data;
  };

  struct Node {
    Node (uint32_t lc, uint32_t pc,
          uint32_t tpc, uint32_t random_id) 
        : lc_id(lc),
          pc_no(pc),
          tpc_no(tpc),
          random(random_id) {
      ULOG_TRACE << "Create " << ToString();
    }

    ~Node() {
      ULOG_TRACE << "Free " << ToString();
    }

    std::string ToString() const { 
      std::ostringstream oss;
      oss << "Node lc=" << lc_id << ",pc=" << pc_no << ",tpc=" << tpc_no 
          << ",random=" << random << ",io_list={";
      for (auto io : io_list) {
        oss << "[" << io->ToString() << "],"; 
      }
      oss << "}.";
      return oss.str();
    }

    int32_t Compare(const Node& node) const {
      // 这里lc_id->[0,2^24-1], pc->[0,2^32-1], tpc->[0,255]
      assert(node.lc_id < (1 << 24));
      assert(node.tpc_no < (1 << 8));
      uint64_t my_val = (((uint64_t)lc_id << 40) | (pc_no << 8) | tpc_no);
      uint64_t node_val = (((uint64_t)node.lc_id << 40) | (node.pc_no << 8) | node.tpc_no);
      ULOG_TRACE << "my_val=" << my_val << ",target node val=" << node_val;
      if (my_val < node_val) {
        return -1;
      } else if (my_val == node_val) {
        return 0;
      } else {
        return 1;
      }
    }

    size_t Get(uint64_t offset, 
             uint64_t length,
             char* buf,
             std::vector<chunk::Interval>* intervals);

    const uint32_t lc_id;
    const uint32_t pc_no;
    const uint32_t tpc_no;
    const uint32_t random;
    std::list<IO*> io_list;
    std::atomic<Node*> next_node[0];
  };

  Node* head_;
  uint32_t level_;//当前跳表的层数(1~12)
  std::atomic<uint32_t> length_;
  std::string id_;
  const int32_t kMaxLevel = 12;
  MemPool mem_pool_;

  Node* NewNode(uint32_t lc,
                uint32_t pc,
                uint32_t tpc,
                uint32_t random_id,
                uint32_t height);

  void ShrinkNode(Skiplist::Node* node);

  IO* NewIO(uint64_t offset,
                            uint64_t length,
                            uint64_t seqno,
                            const char* data);

  IO* NewIOWithData(uint64_t offset,
                                    uint64_t length,
                                    uint64_t seqno,
                                    char* data,
                                    bool shared);

  void InsertIO(Node* node,
                uint64_t offset,
                uint64_t length,
                uint64_t seqno,
                const char* data);
  void MergeIO(Node* node, std::list<IO*>& io_list);
  Node* FindNode(uint32_t lc, uint32_t pc, uint32_t tpc) const;
  Node* FindNodeTrace(uint32_t lc, uint32_t pc, uint32_t tpc, 
                      std::vector<Node*>& trace) const;
  uint32_t RollLevel();
};

}; // end of ns journal
}; // end of ns udisk

#endif
