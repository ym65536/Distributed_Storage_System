#ifndef UDISK_JOURNAL_FORMAT_H_
#define UDISK_JOURNAL_FORMAT_H_

#include <assert.h>
#include <string>
#include <memory>
#include "udisk_types.h"
#include "message.h"
#include "chunk_storage/chunk_storage_errorcode.h"
#include <ustevent/base/logging.h>
#include "route_manager.h"

namespace uevent {
class EventLoop;
}

namespace udisk {
namespace chunk {
class ChunkHandle;
class ChunkLoopHandle;
}
namespace journal {

static inline std::string values_string(const char* str, 
                                        uint64_t length, 
                                        bool full = false) {
  std::string ret;
  uint32_t step = full ? sizeof (uint32_t) : BLOCK_SIZE;
  for (uint64_t i = 0; i < length/step; ++i) {
    ret += std::to_string(*(uint32_t*)(str + i * step)) + "|";
    if (ret.size() > 3000) {
      ULOG_DEBUG << "data=" << ret;
      ret = "";
    }
  }
  ULOG_DEBUG << "data=" << ret;
 
  return "\n";
}

enum RecordType {
  kZeroType = 0,
  kFullType = 1,
  // for fragments
  kFirstType = 2,
  kMiddleType = 3,
  kLastType = 4,
  kRecordEOF = 5,
};

enum JournalErrorType {
  kOK = 0,
  kBadLength = -1,
  kEOF = -2,
  kCRC = -3,
};

enum JournalZoneType {
  kPlainZone = 0,
  kCompactZone = 1,
};

enum MigrateState {
  kMigrateEof = 0,
  kMigrateJournal = 1,
  kMigrateMemTable = 2,
  kMigrateMemTableFinish = 3, // migrate memtable finish -> dual write之间的io当作超时处理
  kMigrateDualWrite = 4,
};

const static int kBlockSize = (1 << 20);

const static int kHeaderSize = 4/*crc32*/ + 3/*length*/ + 1/*type*/;

const static int kPaddingSize = kHeaderSize;
/*根据type和length取值，head第4位和第7位肯定不可能是K和J*/
const static char kPadding[kPaddingSize] = {'U', 'D', 'I', 'S', 'K', 'V', '4', 'J'};

const static int kEndingSize = kHeaderSize;
/*根据type和length取值，head第4位和第7位肯定不可能是K和E*/
const static char kEnding[kEndingSize] = {'U', 'D', 'I', 'S', 'K', 'V', '4', 'E'};

static inline uint32_t AlignLower(uint32_t offset, uint32_t page_size) {
  offset = offset & (~(page_size - 1));
  assert((offset & (page_size - 1)) == 0); 
  return offset;
}

static inline uint32_t AlignUpper(uint32_t offset, uint32_t page_size) {
  uint32_t pad = offset & (page_size - 1);
  if (pad) {
    offset = (offset + page_size) & (~(page_size - 1));
  }
  assert((offset & (page_size - 1)) == 0); 
  return offset;
}

struct ExternalIO {
  ExternalIO(chunk::IOMeta meta, char* data, uint64_t seq_no)
      : key(meta), value(data), seqno(seq_no) {
  }
  chunk::IOMeta key;
  const char* value = nullptr;
  uint64_t seqno = UINT64_MAX;
  uint32_t timer_count = 0; 
};

typedef std::list<ExternalIO> ExternalIOList;

struct Writer;
class JournalEngine;
struct JournalAioArgs {
  JournalEngine* engine = nullptr;
  chunk::IOMeta meta;
  uint64_t seqno = UINT64_MAX;
  uint32_t cmd = UINT32_MAX;
  uevent::EventLoop* loop = nullptr;
  chunk::ChunkLoopHandle* loop_handle = nullptr;
  char* align_buffer = nullptr;
  uint32_t req_ref = 1;
  ucloud::udisk::MigratePcMeta migrate_pc;
  void* reserved = nullptr; 
};

enum UpdateVersionCbType {
  kUMAppendActiveJPC = 1, 
  kUMSwapMemTable = 2,
  kUMUpdateCompactMeta = 3,
  kUMImmuCompactFinish = 4,
  kUMImmuCompactReset = 5,
  kUMInitActiveJPC = 6,
  kUVTEof = kUMInitActiveJPC + 1,
};

typedef google::protobuf::RepeatedPtrField<ucloud::udisk::JournalMigrateItem> 
  JournalMigrateItemArray;

}
}

#endif
