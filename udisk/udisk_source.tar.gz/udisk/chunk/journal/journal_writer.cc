#include "journal_writer.h"
#include <ustevent/base/logging.h>
#include "posix_file.h"
#include "crc32c.h"
#include "chunk_context.h"

using namespace udisk::journal;
using namespace udisk::common;

static const char* PAYLOAD = 
    "\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";

JournalWriter::JournalWriter(WriteableFile* wfile) :
    journal_file_(wfile) {
  for (int i = 0; i < kRecordEOF; ++ i) {
    char c = static_cast<char>(i);
    type_crc_[i] = CalCRC32C(&c, 1); 
  }
  
  block_offset_ = journal_file_->SeekOffset() % kBlockSize;
  ULOG_DEBUG << "journal writer initial block_offset=" << block_offset_;
}

JournalWriter::~JournalWriter() {
}

int32_t JournalWriter::AddRecord(const std::string& record, 
                                 uevent::DiskIOCb done,
                                 JournalAioArgs* journal_args) {
  return AddRecord(record.data(), record.size(), done, journal_args);
}

int32_t JournalWriter::AddRecord(const char* ptr, 
                                 uint32_t left,
                                 uevent::DiskIOCb done,
                                 JournalAioArgs* journal_args) {
  uint32_t ret = 0;
  bool begin = true;

  while (left > 0) { // 空值不处理
    const int32_t leftover = kBlockSize - block_offset_;
    ULOG_TRACE << "block_offset=" << block_offset_ << ", need_size=" << left 
        << ", left_over=" << leftover; 
    assert(leftover >= 0);
    if (leftover < kHeaderSize + kPaddingSize) { // shift to new block
      block_offset_ = 0;
      if (leftover > 0) {
        journal_file_->Append(PAYLOAD, leftover);
      }
    }

    const uint32_t avail_space = 
        kBlockSize - block_offset_ - kHeaderSize - kPaddingSize;
    const uint32_t fragment_size = std::min(left, avail_space);
    RecordType type;
    bool end = (left == fragment_size);
    if (begin && end) {
      type = kFullType;
    } else if (begin && !end) {
      type = kFirstType;
    } else if (!begin && !end) {
      type = kMiddleType;
    } else {
      type = kLastType;
    }
    ret = SubmitPhysicalRecord(ptr, fragment_size, type, end, done, journal_args);
    ULOG_TRACE << "block_offset_=" << block_offset_ << ", avail_space=" 
               << avail_space << ", fragment_size=" << fragment_size 
               << ", type=" << type << ", ret=" << ret; 
    if (ret < 0) {
      return ret;
    }
    begin = false;
    left -= fragment_size;
    ptr += fragment_size;
    block_offset_ += fragment_size + kHeaderSize + kPaddingSize;
  }
  return ret;
}

int32_t JournalWriter::SubmitPhysicalRecord(const char* data, 
                                            uint32_t fragment_size, 
                                            RecordType type, 
                                            bool end,
                                            uevent::DiskIOCb done,
                                            JournalAioArgs* journal_args) {
  assert(block_offset_ + fragment_size + kHeaderSize + kPaddingSize <= kBlockSize);
  char buf[kHeaderSize] = {0};
  buf[4] = (fragment_size & 0x0000FF);
  buf[5] = (fragment_size & 0x00FF00) >> 8;
  buf[6] = (fragment_size & 0xFF0000) >> 16;
  buf[7] = type;

  uint32_t crc_value = 0;
  if (g_context->config().crc_enable()) {
    crc_value = Extend(type_crc_[type], data, fragment_size);
    memcpy(buf, &crc_value, 4);
  }

  int32_t ret = journal_file_->Append(buf, kHeaderSize);
  if (ret < 0) {
    ULOG_ERROR << "Append Journal head error, ret=" << ret;
    return ret;
  }
  ret = journal_file_->Append(data, fragment_size);
  if (ret < 0) {
    ULOG_ERROR << "Append Journal data error, ret=" << ret;
    return ret;
  }
  ret = journal_file_->Append(kPadding, kPaddingSize);
  ULOG_TRACE << "Append Journal ending ret=" << ret;
  if ((ret >= 0) && end) { //每次AppendRecod结束，flush到disk
    ret = journal_file_->Flush(done, journal_args);
  }
  ULOG_TRACE << "Submit Record ret=" << ret << ", length=" << fragment_size 
      << ", CRC=" << crc_value << ", type=" << type; 
  return ret;
}

