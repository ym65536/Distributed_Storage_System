#ifndef UDISK_JOURNAL_WRITER_H
#define UDISK_JOURNAL_WRITER_H

#include "journal_format.h"
#include "jpc_handle.h"

namespace udisk {
namespace journal {

class WriteableFile;

class JournalWriter {
 public:
  explicit JournalWriter(WriteableFile* wfile);
  ~JournalWriter();

  // no copy and assignment
  JournalWriter(const JournalWriter&) = delete;
  JournalWriter& operator=(const JournalWriter&) = delete;

  int32_t AddRecord(const std::string& record, 
                    uevent::DiskIOCb done, 
                    JournalAioArgs* journal_args);
  int32_t AddRecord(const char* ptr, 
                    uint32_t left, 
                    uevent::DiskIOCb done, 
                    JournalAioArgs* journal_args);
  int32_t SubmitPhysicalRecord(const char* data, 
                               uint32_t fragment_size, 
                               RecordType type, 
                               bool end, 
                               uevent::DiskIOCb done, 
                               JournalAioArgs* journal_args);

 private:
  WriteableFile* journal_file_;
  int block_offset_ = 0;
  uint32_t type_crc_[kRecordEOF] = {0};
};

}
}

#endif
