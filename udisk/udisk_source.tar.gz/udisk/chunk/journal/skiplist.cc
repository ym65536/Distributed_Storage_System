#include "skiplist.h"
#include <time.h>
#include <algorithm>
#include <ustevent/base/my_uuid.h>
#include <ustevent/base/logging.h>
#include "udisk_types.h"

using namespace udisk::journal;
using namespace udisk::chunk;

Skiplist::Skiplist()/*{{{*/
    : level_(1),
      length_(0) {
  id_ = base::MyUuid::NewUuid();
  head_ = NewNode(777, 777, 777, 0, kMaxLevel);
  for (auto i = 0; i < kMaxLevel; i++) {
    head_->next_node[i].store(nullptr, std::memory_order_release);
  }
  srand(time(0));
  ULOG_DEBUG << "construct skiplist";
}/*}}}*/

Skiplist::~Skiplist() {/*{{{*/
  auto iter = head_;
  while(iter != nullptr) {
    auto next_iter = iter->next_node[0].load(std::memory_order_acquire);
    for (auto io_iter = iter->io_list.begin(); io_iter != iter->io_list.end(); ++ io_iter) {
      delete * io_iter;
    }
    delete iter;
    iter = next_iter;
  }
  ULOG_DEBUG << "deconstruct skiplist";
}/*}}}*/

uint32_t Skiplist::RollLevel() {/*{{{*/
  uint32_t level = 0;
  while (rand() % 2) {
    level++;
  }
  return ((level % kMaxLevel) + 1);
}/*}}}*/

Skiplist::Node* Skiplist::NewNode(uint32_t lc,/*{{{*/
                                  uint32_t pc,
                                  uint32_t tpc,
                                  uint32_t random_id,
                                  uint32_t height) {
  ++ length_;
  ULOG_DEBUG << "lc:" << lc << " pc:" << pc << " tpc:" << tpc
      << " skp_len:" << length_;
  char* addr = (char*) malloc(sizeof(Node) + sizeof(std::atomic<Node *>) * height);
  return new (addr) Node(lc, pc, tpc, random_id);
}/*}}}*/

Skiplist::IO* Skiplist::NewIO(uint64_t offset,/*{{{*/
                              uint64_t length,
                              uint64_t seqno,
                              const char* data) {
  ULOG_DEBUG << "offset:" << offset
      << " length:" << length
      <<" seqno:" << seqno;
  bool mem_shared;
  char* io = mem_pool_.AllocateIO(sizeof(char) * length, mem_shared);
  memcpy(io, data, length);
  return new IO(offset, length, seqno, mem_shared, io);
}/*}}}*/

Skiplist::IO* Skiplist::NewIOWithData(uint64_t offset,/*{{{*/
                                      uint64_t length,
                                      uint64_t seqno, 
                                      char* data,
                                      bool mem_shared) {
  ULOG_DEBUG << "offset:" << offset
      << " length:" << length
      <<" seqno:" << seqno;
  return new IO(offset, length, seqno, mem_shared, data);
}/*}}}*/

void Skiplist::Visit() const {/*{{{*/
  auto iter = head_->next_node[0].load(std::memory_order_acquire);
  Node* pre_iter = nullptr;
    while (iter != nullptr) {
      pre_iter = iter;
      //ULOG_DEBUG << "lc:" << iter->lc_id
      //    << " pc:" << iter->pc_no
      //    <<" tpc:" << iter->tpc_no;
      iter = iter->next_node[0].load(std::memory_order_acquire);
      if (iter != nullptr) {
        if (pre_iter->lc_id > iter->lc_id) {
          ULOG_FATAL << "pre_lc:" << pre_iter->lc_id
              << " lc:" << iter->lc_id
              << "bad lc node!!!";
        } else if (pre_iter->lc_id == iter->lc_id) {
          if (pre_iter->pc_no > iter->pc_no) {
            ULOG_FATAL << "pre_pc:" << pre_iter->pc_no
                << " pc:" << iter->pc_no
                << "bad pc node!!!";
          } else if (pre_iter->pc_no == iter->pc_no) {
            if (pre_iter->tpc_no >= iter->tpc_no) {
              ULOG_FATAL << "pre_tpc:" << pre_iter->tpc_no
                  << " tpc:" << iter->tpc_no
                  << "bad tpc node!!!";
          }
        }
      }
    }
  }
}/*}}}*/

Skiplist::Node* Skiplist::FindNodeTrace(uint32_t lc, uint32_t pc, uint32_t tpc,
                                        std::vector<Node*>& trace) const {
  Node fake_node(lc, pc, tpc, 0);
  auto iter = head_;
  Node* found = nullptr;
  int32_t level = level_;
  for (auto i = level - 1; i >= 0; i--) {
    //自动过滤head,所以head的lc和pc可以为0
    Node* next_iter = nullptr;
    while ((next_iter = iter->next_node[i].load(std::memory_order_acquire)) != nullptr) {
      int32_t ret = fake_node.Compare(*next_iter);
      if (ret == 0) {
        found = next_iter;
        break;
      } else if (ret < 0) {
        break;
      } else {
        iter = next_iter;
        continue;
      }
    }
    trace[i] = iter;
    if (found) {
      break;
    }
  }
  ULOG_DEBUG << "Target node=" << fake_node.ToString() << ",found=" << found;
  return found;
}

Skiplist::Node* Skiplist::FindNode(uint32_t lc, uint32_t pc, uint32_t tpc) const {
  std::vector<Node*> trace(kMaxLevel, nullptr);
  return FindNodeTrace(lc, pc, tpc, trace);
}

void Skiplist::InsertIO(Node* node,/*{{{*/
                        uint64_t offset,
                        uint64_t length,
                        uint64_t seqno,
                        const char* data) {
  ULOG_TRACE << "offset:" << offset << " length:" << length << " seqno:" 
      << seqno << ", org_node=" << node->ToString();
  IO tmp_io(offset, length, seqno, true, nullptr);
  auto comp = [] (const IO* a, const IO* b) {
    return (a->offset + a->length) <= b->offset;
  };
  auto range = equal_range(node->io_list.begin(), node->io_list.end(), &tmp_io, comp);
  if (range.first == range.second) {
    IO* new_io = NewIO(offset ,length, seqno, data);
    node->io_list.insert(range.first, new_io);
    ULOG_DEBUG << "no merge ==> now node=" << node->ToString();
    return;
  } 
  //合并IO
  ULOG_TRACE << "merge before ==>node=" << node->ToString() << ",seqno:" << seqno;
  uint64_t merge_begin = std::min((*range.first)->offset, offset);
  //获取最后一个有效的io_segment
  auto iter_end = prev(range.second);
  //io区域已经存在
  if (range.first == iter_end && ((*range.first)->offset <= offset) && 
      (((*range.first)->offset + (*range.first)->length) >= (offset + length))) {
    ULOG_DEBUG << "lc:" << node->lc_id << " pc:" << node->pc_no << " tpc:" 
        << node->tpc_no << " can cover io [offset:" << offset << " length:" 
        << length << " seqno:" << seqno << "] completely, cover it directly";
    auto inner_io = *range.first;
    if (seqno < inner_io->seqno) { 
      // 由于线程切换原因，可能导致老seqno在线程A里，新seqno在线程B，但是B处理更快
      // 这种情况下，必然是主chunk重发导致的，直接丢弃即可
      ULOG_WARN << "seqno=" << seqno << ",offset=" << offset << ",length=" 
        << length << ",seqno small,discuss old value." << inner_io->ToString();
      return;
    }
    memcpy(inner_io->data + (offset - inner_io->offset), data, length);
    assert(seqno > inner_io->seqno);
    inner_io->seqno = seqno;
    ULOG_TRACE << "now node=" << node->ToString();
    return;
  }
  uint64_t merge_end = std::max(((*iter_end)->offset + (*iter_end)->length), (offset + length));
  char* new_block = nullptr;
  bool mem_shared;
  new_block = mem_pool_.AllocateIO(sizeof(char) * (merge_end - merge_begin), mem_shared);
  //合并之前的IO
  for (auto it = range.first; it != range.second; ++it) {
    ULOG_DEBUG << "merge ==> lc:" << node->lc_id << " pc:" << node->pc_no 
      << " tpc:" << node->tpc_no << " seqno:" << seqno
      << " ==>[" << (*it)->offset << ", " << ((*it)->offset + (*it)->length) << ")";
    assert(seqno > (*it)->seqno);
    memcpy(new_block + ((*it)->offset - merge_begin), (*it)->data, (*it)->length);
  }
  //合并最新IO
  memcpy(new_block + (offset - merge_begin), data, length);
  ULOG_DEBUG << "cover ==> lc:" << node->lc_id << " pc:" << node->pc_no
      << " tpc:" << node->tpc_no << " seqno:" << seqno
      << " ==>(" << offset << ", " << (offset + length) << ")";
  for (auto iter = range.first; iter != range.second; ++ iter) {
    delete *iter;
  }
  auto pos = node->io_list.erase(range.first, range.second);
  IO* merge_io = NewIOWithData(merge_begin, (merge_end - merge_begin), seqno, 
                               new_block, mem_shared);
  node->io_list.insert(pos, merge_io);
  ULOG_TRACE << "Merge after==>node=" << node->ToString();
}/*}}}*/

void Skiplist::MergeIO(Node* node, std::list<IO*>& io_list) {
  ULOG_TRACE << "Merge Node before=" << node->ToString();
  io_list.splice(io_list.begin(), node->io_list);
  auto seqno_compare = [] (const IO* a, const IO* b) {
    return a->seqno < b->seqno;
  };
  io_list.sort(seqno_compare);
  while (!io_list.empty()) { 
    IO* inner_io = io_list.front();
    io_list.pop_front();
    uint32_t offset = inner_io->offset;
    uint32_t length = inner_io->length;
    uint32_t seqno = inner_io->seqno;
    const char* data = inner_io->data;
    InsertIO(node, offset, length, seqno, data);
    delete inner_io;
  }
  ULOG_TRACE << "Merge Node after=" << node->ToString();
}

void Skiplist::Write(uint32_t lc, /*{{{*/
                     uint32_t pc,
                     uint64_t offset,
                     uint32_t random_id,
                     uint64_t length,
                     uint64_t seqno,
                     const char* data) {
  assert(length <= UDISK_TPC_SIZE);
  uint32_t tpc = offset / UDISK_TPC_SIZE;
  uint32_t tpc_offset = offset % UDISK_TPC_SIZE;
  ULOG_DEBUG << "lc:" << lc << " pc:" << pc << " tpc:" << tpc << " offset:" 
      << offset << " length:" << length << " seqno:" << seqno 
      << " skp_len:" << length_;
  std::vector<Node*> trace(kMaxLevel, nullptr);
  Node* found = FindNodeTrace(lc, pc, tpc, trace);
  if (found != nullptr) {
    InsertIO(found, tpc_offset, length, seqno, data);
    return;
  }
  uint32_t rand_level = RollLevel();
  ULOG_DEBUG << "rand_level:" << rand_level;
  auto new_node = NewNode(lc, pc, tpc, random_id, rand_level);
  InsertIO(new_node, tpc_offset, length, seqno, data);
  if (rand_level > level_) {
    for (auto i = level_; i < rand_level; i++) {
      trace[i] = head_;
    }
    level_ = rand_level;
  }

  for (uint32_t i = 0; i < rand_level; i++) {
    new_node->next_node[i].store(trace[i]->next_node[i], std::memory_order_release);
    trace[i]->next_node[i].store(new_node, std::memory_order_release);
  }
}/*}}}*/

size_t Skiplist::Node::Get(uint64_t offset,/*{{{*/
                           uint64_t length,
                           char* buf,
                           std::vector<Interval>* intervals) {
  ULOG_DEBUG << "offset:" << offset
      << " length:" << length;
  IO* fake_io = new IO(offset, length, 0, true, nullptr);
  auto comp = [] (const IO* a, const IO* b) {
    return (a->offset + a->length) <= b->offset;
  };

  auto overlap_iter = equal_range(io_list.begin(), io_list.end(), fake_io, comp);
  if (overlap_iter.first == overlap_iter.second) {
    ULOG_INFO << "not found offset:" << offset << ", length:" << length
        << ", <lc:" << lc_id << " pc:" << pc_no << ">";
    return 0;
  }

  size_t size = 0;
  for (auto it = overlap_iter.first; it != overlap_iter.second; ++it) {
    auto left = std::max(offset, (*it)->offset);
    auto right = std::min(offset + length, (*it)->offset + (*it)->length);
    ULOG_TRACE << "offest:" << offset<< " length:" << length << (*it)->ToString();
    ULOG_TRACE << "left:" << left << " right:" << right;
    assert(right >= left);
    Interval interval;
    interval.start= left - offset;
    interval.end = right - offset;
    intervals->push_back(interval);
    size += right - left;
    memcpy(buf + interval.start, (*it)->data + (left - (*it)->offset), right - left);
  }
  return size;
}/*}}}*/

size_t Skiplist::Read(uint32_t lc_id,/*{{{*/
                    uint32_t pc_no,
                    uint64_t offset,
                    uint64_t length,
                    char* buf,
                    std::vector<Interval>* intervals) {
  uint32_t tpc = offset / UDISK_TPC_SIZE;
  ULOG_DEBUG << "lc:" << lc_id << " pc:" << pc_no << " tpc:" << tpc 
      << " skp_len:" << length_;
  Node* target = FindNode(lc_id, pc_no, tpc);
  if (target != nullptr) {
    uint32_t tpc_offset = offset % UDISK_TPC_SIZE;
    return target->Get(tpc_offset, length, buf, intervals);
  }

  return 0;
}/*}}}*/

void Skiplist::Merge(const ExternalIOList& ext_ios) {
  if (ext_ios.empty()) {
    ULOG_WARN << "need merge external_ios empty!";
    return;
  }
  const auto& item = ext_ios.front();
  std::vector<Node*> trace(kMaxLevel, nullptr);
  std::list<IO*> io_list;
  uint32_t lc_id = item.key.lc_id;
  uint32_t pc_no = item.key.pc_no;
  uint32_t random_id = item.key.random_id;
  uint32_t tpc_no = item.key.offset / UDISK_TPC_SIZE;
  for (auto ext_io : ext_ios) {
    assert(ext_io.key.lc_id == lc_id && ext_io.key.pc_no == pc_no && 
        ext_io.key.offset / UDISK_TPC_SIZE == tpc_no);
    IO* inner_io = NewIO(ext_io.key.offset % UDISK_TPC_SIZE, ext_io.key.length, 
                         ext_io.seqno, ext_io.value);
    ULOG_DEBUG << "Need merge " << inner_io->ToString();
    io_list.push_back(inner_io);
  }
  Node* found = FindNodeTrace(lc_id, pc_no, tpc_no, trace);
  if (found != nullptr) {
    MergeIO(found, io_list);
    return;
  }
  uint32_t rand_level = RollLevel();
  ULOG_DEBUG << "rand_level:" << rand_level;
  auto new_node = NewNode(lc_id, pc_no, tpc_no, random_id, rand_level);
  MergeIO(new_node, io_list);
  if (rand_level > level_) {
    for (auto i = level_; i < rand_level; i++) {
      trace[i] = head_;
    }
    level_ = rand_level;
  }

  for (uint32_t i = 0; i < rand_level; i++) {
    new_node->next_node[i].store(trace[i]->next_node[i], std::memory_order_release);
    trace[i]->next_node[i].store(new_node, std::memory_order_release);
  }
}

//需要保证调用ShrinkNode, 非线程安全
void Skiplist::ShrinkNode(Skiplist::Node* node) {/*{{{*/
  assert(node);
  if (node->io_list.size() <= 1) {
    ULOG_INFO << "Node don't need shrink. size=" << node->io_list.size();
    return;
  }
  auto prev_iter = node->io_list.begin();
  auto next_iter = next(prev_iter);
  while (next_iter != node->io_list.end()) {
    auto curr_iter = prev_iter;
    ULOG_DEBUG <<"prev:" <<(*prev_iter)->offset 
        <<" curr:" << (*curr_iter)->offset 
        << " next:" << (*next_iter)->offset;
    while (next_iter != node->io_list.end()
           && ((*curr_iter)->offset +  (*curr_iter)->length) == (*next_iter)->offset) {
      ULOG_TRACE << ">>>prev:" << (*prev_iter)->offset
          << " curr:" << (*curr_iter)->offset
          << " next:" << (*next_iter)->offset;
      curr_iter = next_iter;
      next_iter = next(next_iter);
    }

    if (prev_iter != curr_iter) {
      bool mem_shared;
      uint64_t seqno = 0;
      auto merge_begin = prev_iter;
      auto merge_end = prev(next_iter);
      auto merge_size = (*merge_end)->offset - (*merge_begin)->offset + (*merge_end)->length;
      char* new_block = mem_pool_.AllocateIO(sizeof(char) * (merge_size), mem_shared);
      for (auto it = merge_begin; it != next_iter; ++ it) {
        if ((*it)->seqno > seqno) {
          seqno = (*it)->seqno;
        }
        memcpy(new_block + ((*it)->offset - (*merge_begin)->offset), (*it)->data, (*it)->length);
      }
      ULOG_DEBUG << "new merge_io offset:[" << (*merge_begin)->offset
          << ", " << (*merge_begin)->offset + merge_size << ")";
      IO* merge_io = NewIOWithData((*merge_begin)->offset, merge_size, seqno, new_block, mem_shared);
      for (auto iter = prev_iter; iter != next_iter; ++ iter) {
        delete *iter;
      }
      node->io_list.erase(prev_iter, next_iter);
      node->io_list.insert(next_iter, merge_io);
    }

    if (next_iter != node->io_list.end()) {
      prev_iter = next_iter;
      next_iter = next(prev_iter);
    }
  }
}/*}}}*/

void Skiplist::Dump() {/*{{{*/
  Node* node = head_;
  while (node != nullptr) {
    for (auto it = node->io_list.begin(); it != node->io_list.end(); ++it) {
      ULOG_DEBUG << node<< " Dump===>lc:" << node->lc_id
          << " pc:" << node->pc_no
          << " tpc:" << node->tpc_no
          << " offset:" << (*it)->offset
          << " length:" << (*it)->length;
    }
    node = node->next_node[0].load(std::memory_order_acquire);
  }
}/*}}}*/

Skiplist::Iterator::Iterator(Skiplist* skiplist) {/*{{{*/
  assert(skiplist != nullptr);
  skp_ = skiplist;
  node_ = skp_->head_->next_node[0].load(std::memory_order_acquire);
}/*}}}*/

bool Skiplist::Iterator::Valid() const {/*{{{*/
  return node_ != nullptr;
}/*}}}*/

void Skiplist::Iterator::Next() {/*{{{*/
  assert(node_ != nullptr);
  node_ = node_->next_node[0].load(std::memory_order_acquire);
  if (node_ != nullptr) {
    assert(!node_->io_list.empty());
  }
}/*}}}*/

void Skiplist::Iterator::Shrink() {/*{{{*/
  //合并连续IO
  ULOG_DEBUG << "Before Shirnk Node=" << node_->ToString();
  skp_->ShrinkNode(node_);
  ULOG_DEBUG << "After Shirnk Node=" << node_->ToString();
}/*}}}*/

void Skiplist::Iterator::Value(ExternalIOList* external_ios) const {/*{{{*/
  uint32_t pc_begin = node_->tpc_no * UDISK_TPC_SIZE;
  ULOG_DEBUG << "Read io node=" << node_->ToString();
  for(auto iter = node_->io_list.begin(); iter != node_->io_list.end(); ++iter) {
    IOMeta meta(node_->lc_id, node_->random, node_->pc_no, pc_begin + (*iter)->offset, (*iter)->length);
    external_ios->emplace_back(meta, (*iter)->data, (*iter)->seqno);
  }
}/*}}}*/

void Skiplist::Iterator::Seek(uint32_t lc_id,/*{{{*/
                              uint32_t pc_no,
                              uint32_t tpc) {
   node_ = skp_->FindNode(lc_id, pc_no, tpc);
}/*}}}*/


