#include <stack>
#include "journal_engine.h"
#include "memtable.h"
#include "write_batch.h"
#include <ustevent/base/logging.h>
#include <ustevent/eventloop.h>
#include "chunk_storage.h"
#include "posix_file.h"
#include "journal_writer.h"
#include "journal_reader.h"
#include "udisk_journal.h"
#include "op_request.h"
#include "route_manager.h"
#include "io_error_container.h"

using namespace ucloud::udisk;
using namespace udisk::journal;
using namespace udisk::chunk;
using namespace std::placeholders;
using namespace std;

const uint32_t JOURNAL_TIMER_FREQUENCY = 100;

JournalEngine::JournalEngine(ChunkLoopHandle* handle, uint32_t pg_id) :
    handle_(handle),
    pg_id_(pg_id), 
    req_ref_(0),
    wfile_(nullptr), 
    journal_file_(nullptr), 
    internal_batch_(new WriteBatch()), 
    immu_iter_(nullptr), 
    compact_batch_(new InternalBatch()),
    manual_compact_handle_ptr_(nullptr) {
}

JournalEngine::~JournalEngine() {
  if (internal_batch_) {
    delete internal_batch_;
  }
  if (compact_batch_) {
    delete compact_batch_;
  }
}

bool JournalEngine::IsInit() {
  UDiskJournal* udisk_journal = g_context->udisk_journal(pg_id_);
  return udisk_journal->is_init.load();
}

void JournalEngine::RecoverRecord(uint32_t type, uint32_t pre_cnt) {
  UDiskJournal* udisk_journal = g_context->udisk_journal(pg_id_);
  for (uint32_t i = pre_cnt; i < udisk_journal->records.size(); ++ i) {
    uint32_t pos = kBatchHeader; // skip count
    uint64_t sequence = 0;
    IOMeta meta;
    const char* buffer = nullptr;
    while (pos < udisk_journal->records[i].size()) {
      // parse sequence
      memcpy(&sequence, &udisk_journal->records[i][pos], sizeof (sequence));
      pos += sizeof (sequence);
      //parse k-v
      memcpy(&meta, &udisk_journal->records[i][pos], sizeof(meta));
      pos += sizeof (meta);
      buffer = &udisk_journal->records[i][pos];
      ULOG_DEBUG << "insert date_map memtype=" << type << " meta=" << meta.ToString() << ", seqno=" << sequence 
          << "data=" << values_string(buffer, meta.length);
      if (type == kImmutable) {
        udisk_journal->rc_immu_data_.insert(std::make_pair(sequence, std::make_pair(meta, buffer)));
      } else if (type == kMemtable) {
        udisk_journal->rc_mem_data_.insert(std::make_pair(sequence, std::make_pair(meta, buffer)));
      } else {
        ULOG_FATAL << "unknow memtable type";
      }
      pos += meta.length;
    }
  }
}

void JournalEngine::EntryRecover(const PGJournalMeta* meta) {
  assert(!IsInit());
  ULOG_DEBUG << "Recover Journal meta=" << meta->ToString();
  // recover inactive journal file
  ULOG_DEBUG << "Recover inactive pg_id=" << pg_id_;
  UDiskJournal* udisk_journal = g_context->udisk_journal(pg_id_);

  udisk_journal->rc_inact_num.fetch_add(meta->inactive_num); //记录所有inactive个数
  for (uint32_t i = 0; i < meta->inactive_num; ++ i) {
    uint32_t jpc_id = meta->inactive_zone[i];
    JPCHandle* jpc_handle = nullptr;
    {
      std::lock_guard<std::mutex> lock(udisk_journal->mtx);
      jpc_handle = udisk_journal->jpc_storage->AcquireInActiveJPC(jpc_id);
      uint32_t size = udisk_journal->records.size();
      uint32_t read_offset = RecoverJournalFile(jpc_handle, &udisk_journal->records);
      RecoverRecord(kImmutable, size);
      ULOG_DEBUG << "recover inactive. pg_id=" << pg_id_ << ",jpc_id=" << jpc_id 
          << ",offset=" << read_offset;
    }
  }

  // recover active journal file
  ULOG_DEBUG << "Recover active pg_id=" << pg_id_; 
  uint32_t jpc_id = UINT32_MAX;
  uint32_t write_offset = 0;
  for (uint32_t i = 0; i < meta->active_num; ++ i) {
    jpc_id = meta->active_zone[i];
    JPCHandle* jpc_handle = nullptr;
    {
      std::lock_guard<std::mutex> lock(udisk_journal->mtx);
      jpc_handle = udisk_journal->jpc_storage->AcquireActiveJPC(jpc_id);
      uint32_t size = udisk_journal->records.size();
      write_offset = RecoverJournalFile(jpc_handle, &udisk_journal->records);
      RecoverRecord(kMemtable, size);
      ULOG_DEBUG << "Recover Active pg_id=" << pg_id_ << ",jpc_id=" << jpc_id 
          << ",offset=" << write_offset;
    }
  }

  JPCHandle* jpc_handle = nullptr;
  {
    std::lock_guard<std::mutex> lock(udisk_journal->mtx);
    if (jpc_id == UINT32_MAX) { // 说明active_num空,获取新的jpc
      assert(meta->active_num == 0);
      jpc_handle = udisk_journal->jpc_storage->AcquireFreeJPC();
    } else {
      jpc_handle = udisk_journal->jpc_storage->AcquireActiveJPC(jpc_id);
    }
    assert(jpc_handle);
  }

  wfile_.reset(new WriteableFile(jpc_handle, write_offset));
  journal_file_.reset(new JournalWriter(wfile_.get()));
  if (meta->active_num == 0) { // 获取新的jpc，需要更新superblock
    JournalAioArgs* journal_args = new JournalAioArgs;
    journal_args->engine = this;
    journal_args->cmd = kUMInitActiveJPC;
    journal_args->loop = handle_->GetLoop();
    auto journal_meta = g_context->journal_meta();
    journal_meta->AppendActiveJPC(pg_id_, 
                                  handle_->GetLoop()->thread_id(),
                                  jpc_handle->GetID(),
                                  JournalEngine::UpdateJournalMetaCbWrapper,
                                  journal_args);
  } else {
    UMInitActiveJPCCb();
  }
}

void JournalEngine::UMInitActiveJPCCb() {
  UDiskJournal* udisk_journal = g_context->udisk_journal(pg_id_);
  {
    std::lock_guard<std::mutex> lock(udisk_journal->mtx);
    ++ udisk_journal->rcref;
    if (udisk_journal->rcref < (uint32_t)g_context->config().thread_num()) {
      ULOG_DEBUG << "pg_id=" << pg_id_ << " rcref=" << udisk_journal->rcref 
        << ".wait for peers. max_seq=" << udisk_journal->last_seq.load();
      return;
    }
  }

  // 开始恢复immu table
  for (auto item = udisk_journal->rc_immu_data_.begin();
       item != udisk_journal->rc_immu_data_.end(); item++) {
    ULOG_DEBUG << "write immutable memtable meta=" << item->second.first.ToString() << ", seqno="
               << item->first << ", data=" << values_string(item->second.second, item->second.first.length);
    udisk_journal->rcmem->Put(item->second.first, item->second.second, item->first);
  }
  auto it = udisk_journal->rc_immu_data_.rbegin();
  if (it != udisk_journal->rc_immu_data_.rend()) {
    ULOG_DEBUG << "pg:" << pg_id_ << " immutable last_seq:" << it->first
               << ", udisk_journal last_seq:" << udisk_journal->last_seq.load();
    udisk_journal->last_seq.store(std::max(udisk_journal->last_seq.load(), it->first));
  }
  // 恢复完成 清空data_map
  udisk_journal->rc_immu_data_.clear();

  // 开始恢复memtable
  for (auto item = udisk_journal->rc_mem_data_.begin();
       item != udisk_journal->rc_mem_data_.end(); item++) {
    ULOG_DEBUG << "write memtable meta=" << item->second.first.ToString() << ", seqno="
               << item->first << ", data=" << values_string(item->second.second, item->second.first.length);
    udisk_journal->mem->Put(item->second.first, item->second.second, item->first);
  }
  it = udisk_journal->rc_mem_data_.rbegin();
  if (it != udisk_journal->rc_mem_data_.rend()) {
    ULOG_DEBUG << "pg:" << pg_id_ << " immutable last_seq:" << it->first
               << ", udisk_journal last_seq:" << udisk_journal->last_seq.load();
    udisk_journal->last_seq.store(std::max(udisk_journal->last_seq.load(), it->first));
  }
  // 恢复完成 清空data_map
  udisk_journal->rc_mem_data_.clear();
  udisk_journal->records.clear();

  // 加上udisk_queue_max_depth是为了防止pending_writers里没有提交，导致主seqno小于从seqno
  udisk_journal->last_seq.fetch_add(g_context->config().udisk_queue_max_depth());
  ULOG_DEBUG << "pg_id=" << pg_id_ << " recover finish.seqno=" 
      << udisk_journal->last_seq.load(); 

  udisk_journal->is_init.store(true);
  // 此时恢复结束，开始继续重启前compact流程
  if (udisk_journal->rc_inact_num > 0) {
    ULOG_DEBUG << "pg_id=" << pg_id_ << ",Inactive jpc exist. imm=" 
        << udisk_journal->rcmem->ToString();
    if (udisk_journal->rcmem->MaxSeq() > 0) {
      udisk_journal->immu = udisk_journal->rcmem;
      udisk_journal->rcmem = nullptr; // 此时rcmem生命周期结束.
      TriggerCompact();
    } else {
      // 这种情况说明inactive jpc被reset，但是journal meta中inactive_num没有被写入就异常重启
      ULOG_WARN << "pg_id=" << pg_id_ << " Must be abnormal compact stop occur!";
      // 只需要把journal meta中inactive_num写入即可
      ImmuCompactReset(false);
    }
  } else {
    ULOG_DEBUG << "pg_id=" << pg_id_ << ",Inacitve not exist"; 
  }
}

int32_t JournalEngine::RecoverJournalFile(JPCHandle* jpc_handle, 
                                          std::vector<std::string>* records) {
  ULOG_DEBUG << "pg_id=" << pg_id_ << ", reader jpc_id=" << jpc_handle->GetID();
  std::unique_ptr<ReadableFile> rfile(new ReadableFile(jpc_handle));
  std::unique_ptr<JournalReader> reader(new JournalReader(rfile.get()));
  int32_t ret = 0;
  while (true) {
    std::string record;
    ret = reader->ReadRecord(&record);
    if (ret != UDISK_OK) {
      if (ret == kEOF) {
        ULOG_INFO << "pg_id=" << pg_id_ << ", Recover file finish. break.";
        break;
      } else if (ret == kCRC) {
        ULOG_FATAL << "pg_id=" << pg_id_ << ", Crc error";
      } else {
        ULOG_FATAL << "pg_id=" << pg_id_ << ", Recover file Error. ret=" << ret;
      }
    } else if (record.size() < kBatchHeader) {
      ULOG_FATAL << "pg_id=" << pg_id_ << ", Parse Record size too small." 
          << " size=" << record.size();
    }
    records->push_back(record);
  }

  return reader->SeekOffset();
}

int32_t JournalEngine::Read(const IOMeta& meta, 
                            char* buf, 
                            vector<Interval>* intervals) {
  int32_t ret = -1;
  UDiskJournal* udisk_journal = g_context->udisk_journal(pg_id_);
  // 这里加锁是防止immu_在读的时候被另外线程释放, 考虑怎样避免?
  std::unique_lock<std::mutex> lock(udisk_journal->mtx); 
  MemTable* mem = udisk_journal->mem;
  mem->IncRef();
  MemTable* immu = udisk_journal->immu;
  if (immu != nullptr) {
    immu->IncRef();
  }
  lock.unlock();

  do {
    if (mem->Get(meta, intervals, buf)) { // 所有数据都在mem中, 直接返回
      ULOG_DEBUG << "Mem Get full data finish. meta=" << meta.ToString();
      ret = 0;
      break;
    }
    ULOG_DEBUG << "mem Not get full data, try immu. meta=" << meta.ToString()
        << ", intervals.size=" << intervals->size();
    if (immu == nullptr) {
      break;
    }
    // mem_中没有读取完，读取immu
    vector<Interval> immu_intervals;
    char* immu_data = nullptr;
    posix_memalign((void**)&immu_data, BLOCK_SIZE, meta.length);
    immu->Get(meta, &immu_intervals, immu_data);
    // 把buf中不重叠部分覆盖到immu_data，并更新得到新的intervals
    uint32_t length = MergeInterval(&immu_intervals, *intervals, immu_data, buf);
    memcpy(buf, immu_data, meta.length);
    free(immu_data);
    intervals->swap(immu_intervals);
    if (meta.length == length) { // 合并后覆盖所有buf, success
      ULOG_DEBUG << "Immu Get full data finish. meta=" << meta.ToString();
      ret = 0;
      break;
    }
    ULOG_DEBUG << "immu not get full data. meta=" << meta.ToString() << 
        ", intervals.size=" << intervals->size();
  } while (false);

  lock.lock();
  mem->DecRef();
  if (immu != nullptr) {
    immu->DecRef();
  }
  ULOG_DEBUG << "Get not all MemTable data. meta=" << meta.ToString() << 
      ", intervals.size=" << intervals->size();
  return ret;
}

bool JournalEngine::MergeInterval(vector<Interval>* old_intervals, 
                                  const vector<Interval>& new_intervals, 
                                  char* old_buf, 
                                  const char* new_buf) {
  auto comp = [] (const Interval &intv1, const Interval &intv2) { 
    return intv1.end < intv2.start; 
  };
  uint32_t length = 0;
  for (auto item : new_intervals) {
    auto range = 
        equal_range(old_intervals->begin(), old_intervals->end(), item, comp);
    auto itr1 = range.first;
    auto itr2 = range.second;
    if (itr1 == itr2) {
      old_intervals->insert(itr1, item);
      length += item.end - item.start;
    } else {
      --itr2;
      itr2->start = min(item.start, itr1->start);
      itr2->end = max(item.end, itr2->end);
      length += itr2->end - itr2->start;
      old_intervals->erase(itr1, itr2);
    }
    memcpy(&old_buf[item.start], &new_buf[item.start], item.end - item.start);
  }
  return length;
}

int32_t JournalEngine::Write(const IOMeta& meta, 
                             const char* buf, 
                             uint64_t seqno,
                             OpRequest* op) {
  WriteBatchPtr my_batch = new WriteBatch;
  my_batch->Put(meta, buf, seqno);
  WriterPtr w = new Writer();
  w->batch = my_batch;
  w->done = false;
  w->seqno = seqno;
  w->meta = meta;
  w->loop = handle_->GetLoop();
  w->op = op;
  op->IncRefs(); // journal里需要使用op, 防止udisk_handle里释放op后导致core
  ULOG_TRACE << "Write seqno=" << seqno << ", meta=" << meta.ToString() 
    << ", op=" << op->trace_tag() << ", data=" << values_string(buf, meta.length);

  return EntryBatchWrite(w, false);
}

int32_t JournalEngine::EntryBatchWrite(const WriterPtr w,
                                       bool reenter) {
  ULOG_DEBUG << "BatchWrite seqno=" << w->seqno << ", meta=" << w->meta.ToString()
      << ", op=" << w->op->trace_tag();
  if (!reenter) { 
    // reenter说明是提交AddRecord返回后wrtier_非空，返回继续提交wrtier_，
    // 此时writer已经在writers_中，不需要继续push_back
    pending_writers_.push_back(w);
  } 
  if ((w != pending_writers_.front()) || !inflight_writers_.empty()) {
    ULOG_DEBUG << "BatchWrite not head, enqueue. loop=" << w->loop << ", op=" 
      << w->op->trace_tag();
    return 0; // 不是队列head writer, 直接返回
  }

  UDiskJournal* udisk_journal = g_context->udisk_journal(pg_id_);
  BuildBatchGroup();
  assert(!inflight_writers_.empty());
  uint32_t batch_size = internal_batch_->ByteSize();
  bool space_enough = true;
  ULOG_TRACE << "batch_size=" << batch_size;
  do {
    if (wfile_->IsSpaceAvailable(batch_size)) { 
      break;
    }
    auto jpc_handle = wfile_->GetJPCHandle();
    ULOG_WARN << "pg_id=" << pg_id_ << ", JPC_id=" << jpc_handle->GetID()
        << " space is full, allocate new jpc.";
    // 当前文件写满，重新分配jpc, 多个线程可能同时触发，需要加锁
    MemTable* mem = udisk_journal->mem;
    std::unique_lock<std::mutex> lock(udisk_journal->mtx);
    mem->IncRef();
    if (mem->GetID() != udisk_journal->mem->GetID() ||
        udisk_journal->schedule_swap.load() == true) {
      // 这种情况说明另外一个线程先抢到lock, 并执行memtable切换，为了简单，直接把请求丢弃
      ULOG_WARN << "pg_id=" << pg_id_ << ",mem_id=" << mem->GetID() << ",journal_mem_id=" 
          << udisk_journal->mem->GetID() << ",schedule_swap=" << udisk_journal->schedule_swap
          << " must swaped, discard seqno=" << w->seqno;
      space_enough = false;
      mem->DecRef();
      break;
    }
    mem->DecRef();
    jpc_handle = udisk_journal->jpc_storage->AcquireFreeJPC(); 
    if (jpc_handle == nullptr) { // 无剩余jpc情况下，需要调度切换
      ULOG_WARN << "pg_id=" << pg_id_ << ", no Free JPC left!";
      if (udisk_journal->immu != nullptr) {
        space_enough = false;
        ULOG_WARN << "pg_id=" << pg_id_ << ", Both mem and immu full";
        break;
      } else {
        ULOG_WARN << "pg_id=" << pg_id_ << ", Memtable is full. Entry swap schedule";
        udisk_journal->schedule_swap.store(true);
        TriggerSwapMemTable(lock);
        return 0;
      }
    } else {
      ULOG_WARN << "pg_id=" << pg_id_ << ", acquire free jpc_id=" 
          << jpc_handle->GetID();
      wfile_.reset(new WriteableFile(jpc_handle));
      journal_file_.reset(new JournalWriter(wfile_.get()));
      JournalAioArgs* journal_args = new JournalAioArgs;
      journal_args->engine = this;
      journal_args->cmd = kUMAppendActiveJPC;
      journal_args->loop = handle_->GetLoop();
      auto journal_meta = g_context->journal_meta();
      journal_meta->AppendActiveJPC(pg_id_, 
                                    handle_->GetLoop()->thread_id(),
                                    jpc_handle->GetID(),
                                    JournalEngine::UpdateJournalMetaCbWrapper,
                                    journal_args);
      return 0;
    }
  } while (false);
    
  do {
    if (space_enough == false) { // 说明journal盘空间不足，直接返回error
      break;
    }
    if (!udisk_journal->mem->IsFull(batch_size)) {
      break;
    }
    std::unique_lock<std::mutex> lock(udisk_journal->mtx);
    if (udisk_journal->immu != nullptr) { // both mem and immu are full
      ULOG_WARN << "pg_id=" << pg_id_ << ",No space left.Both mem and immu full";
      space_enough = false;
      break;
    } else { // mem_ is full, chage to immu_
      ULOG_WARN << "pg_id=" << pg_id_ << ", Memtable is full. Entry swap schedule";
      udisk_journal->schedule_swap.store(true);
      TriggerSwapMemTable(lock);
      return 0;
    }
  } while (false);

  return BatchWrite(space_enough);
}

void JournalEngine::TriggerSwapMemTable(std::unique_lock<std::mutex>& lock) {
  UDiskJournal* udisk_journal = g_context->udisk_journal(pg_id_);
  ULOG_INFO << "pg_id=" << pg_id_ << ",MemTable is full. mem=" 
      << udisk_journal->mem->ToString();
  udisk_journal->immu = udisk_journal->mem;
  udisk_journal->mem = new MemTable(pg_id_, udisk_journal->memtable_cap);
  udisk_journal->mem->IncRef();
  udisk_journal->jpc_storage->JPCSwap();
  assert(req_ref_ == 0);
  lock.unlock(); // 当前线程为自身时，会直接调用SwapMemTableReq，不释放会造成死锁

  auto all_loops = g_context->io_listener()->GetAllLoops();
  req_ref_ = all_loops.size();
  for (auto loop : all_loops) {
    ULOG_DEBUG << "pg_id=" << pg_id_ << ",req_ref=" << req_ref_ << ",src_loop="
        << handle_->GetLoop();
    loop->RunInLoop(std::bind(&ChunkLoopHandle::JournalSwapMemTableReq, 
                      dynamic_cast<ChunkLoopHandle*>(loop->GetLoopHandle()),
                      handle_->GetLoop(), // 传递handle_是为了各自线程swap mem后还要绕回来
                      pg_id_)); 
  }
  return;
}

void JournalEngine::SwapMemTableReq(uevent::EventLoop* src_loop) {
  // 每一个线程都要分配新的jpc
  UDiskJournal* udisk_journal = g_context->udisk_journal(pg_id_);
  JPCHandle* jpc_handle = nullptr;
  { 
    std::lock_guard<std::mutex> lock(udisk_journal->mtx);
    jpc_handle = udisk_journal->jpc_storage->AcquireFreeJPC();
  }
  assert(jpc_handle != nullptr);
  wfile_.reset(new WriteableFile(jpc_handle));
  journal_file_.reset(new JournalWriter(wfile_.get()));
  ULOG_DEBUG << "pg_id=" << pg_id_ << ",Swap mem alloc new jpc_id=" << 
      jpc_handle->GetID() << ",src_loop=" << src_loop;

  // 切换完毕后告知原线程
  src_loop->RunInLoop(std::bind(&ChunkLoopHandle::JournalSwapMemTableRes, 
                      dynamic_cast<ChunkLoopHandle*>(src_loop->GetLoopHandle()),
                      handle_->GetLoop(), 
                      jpc_handle->GetID(),
                      pg_id_));
  return;
}

void JournalEngine::SwapMemTableRes(uevent::EventLoop* peer_loop, 
                                    uint32_t jpc_id) {
  req_ref_ --;
  assert(jpc_map_.count(peer_loop->thread_id()) == 0);
  jpc_map_[peer_loop->thread_id()] = jpc_id;
  if (req_ref_ > 0) { 
    ULOG_DEBUG << "SwapMemTableRes pg_id=" << pg_id_ << ", ref=" << req_ref_;
    return;
  }
  ULOG_DEBUG << "SwapMemTableRes pg_id=" << pg_id_ << " update meta. jpc_map.size=" 
      << jpc_map_.size();
  JournalAioArgs* journal_args = new JournalAioArgs;
  journal_args->engine = this;
  journal_args->cmd = kUMSwapMemTable;
  journal_args->loop = handle_->GetLoop();
  auto journal_meta = g_context->journal_meta();
  journal_meta->SwapMemTable(pg_id_,
                             jpc_map_,
                             JournalEngine::UpdateJournalMetaCbWrapper, 
                             journal_args);
  jpc_map_.clear();
}

void JournalEngine::UMSwapMemTableCb() {
  UDiskJournal* udisk_journal = g_context->udisk_journal(pg_id_);
  assert(udisk_journal->schedule_swap.load() == true);
  udisk_journal->schedule_swap.store(false);
  ULOG_DEBUG << "pg_id=" << pg_id_ << " SwapMemTable finish. trigger compact.";
  {
    std::lock_guard<std::mutex> lock(udisk_journal->mtx);
    // 这里对immu中连续数据进行合并
    udisk_journal->immu->Shrink();
  }
  // 1. 触发immu compact
  TriggerCompact();
  // 2. 开始继续写
  if (manual_compact_handle_ptr_ != nullptr) {
    // manual_compact情况下不是由io触发memswap，无需BatchWrite
    ULOG_INFO << "pg_id=" << pg_id_<< " trigger manual compact...";
  } else {
    BatchWrite(true);
  } 
}

void JournalEngine::UMAppendActiveJPCCb() {
  ULOG_DEBUG << "pg_id=" << pg_id_ << " AppendActive resp.continue BatchWrite.";
  BatchWrite(true);
}

int32_t JournalEngine::BatchWrite(bool space_enough) {
  if (!space_enough) {
    ULOG_WARN << "pg_id=" << pg_id_ << ", BatchWrite full...";
    std::deque<WriterPtr> tmp_writers;
    inflight_writers_.swap(tmp_writers);
    tmp_writers.insert(tmp_writers.end(), 
                       pending_writers_.begin(), 
                       pending_writers_.end());
    pending_writers_.clear();
    for (auto ready : tmp_writers) {
      ready->retcode = IOErrorContainer::kJournalIOFull;
    }
    BatchResponse(tmp_writers);
    internal_batch_->Clear();
    return UDISK_IO_ERROR; 
  }

  // 链接切换情况下，会导致inflight_writers_被清空 
  if (inflight_writers_.empty()) {
    ULOG_WARN << "pg_id=" << pg_id_ << " writers empty, must be re-connect";
    assert(internal_batch_->ByteSize() == 0);
    return UDISK_IO_ERROR;
  }
  int32_t ret = 0;
  UDiskJournal* udisk_journal = g_context->udisk_journal(pg_id_);
  auto w = inflight_writers_.front();
  w->mem_id = udisk_journal->mem->GetID();
  w->jpc_id = wfile_->GetJPCHandle()->GetID();
  JournalAioArgs* journal_args = new JournalAioArgs;
  journal_args->engine = this;
  journal_args->meta = w->meta;
  journal_args->seqno = w->seqno;
  journal_args->loop = handle_->GetLoop();
  ret = journal_file_->AddRecord(internal_batch_->Content(), 
                               JournalEngine::AddRecordCbWrapper, 
                               journal_args);
  if (ret != UDISK_OK) {
    ULOG_SYSERR << "submit write fail, ret=" << ret << ", meta=" 
               << w->meta.ToString();
    handle_->AddLCIOError(w->meta.lc_id, IOErrorContainer::kNormalIOError, 
                          IOErrorContainer::kIOWrite); 
    return UDISK_IO_ERROR;
  }
  return 0; 
}

void JournalEngine::AddRecordCb(int32_t retcode, 
                                uint64_t seqno) {
  UDiskJournal* udisk_journal = g_context->udisk_journal(pg_id_);
  // 链接切换情况下，会导致inflight_writers_被清空 
  if (inflight_writers_.empty()) {
    ULOG_WARN << "pg_id=" << pg_id_ << " writers empty, must be re-connect";
    assert(internal_batch_->ByteSize() == 0);
    return;
  }
  auto w = inflight_writers_.front();
  if (seqno != w->seqno) {
    ULOG_ERROR << "pg_id=" << pg_id_ << " AddRecord seqno miss!seqno=" << seqno 
      << ", retcode=" << retcode;
    return;
  }
  ULOG_DEBUG << "pg_id=" << pg_id_ << " AddRecord response seqno=" << seqno 
    << " retcode=" << retcode;
  do {
    if (udisk_journal->schedule_swap.load() == true) {
      ULOG_ERROR << "pg_id=" << pg_id_ << ",AddRecord response seqno=" << seqno 
          << " retcode=" << retcode << ",memtable swap scheudle, return error";
      retcode = IOErrorContainer::kJournalIOTimeout;
      break;
    }
    if (w->mem_id != udisk_journal->mem->GetID()) {
      ULOG_ERROR << "pg_id=" << pg_id_ << ",AddRecord response seqno=" << seqno
          << ",memtable swap.mem_id=" << w->mem_id << ",new mem_id=" 
          << udisk_journal->mem->GetID();
      retcode = IOErrorContainer::kJournalIOTimeout;
      break;
    }
    if (w->jpc_id != wfile_->GetJPCHandle()->GetID()) {
      ULOG_ERROR << "pg_id=" << pg_id_ << ",AddRecord response seqno=" << seqno
          << ",jpc swap.jpc_id=" << w->jpc_id << ",new jpc_id=" 
          << wfile_->GetJPCHandle()->GetID();
      retcode = IOErrorContainer::kJournalIOTimeout;
      break;
    }
    
    {
      std::lock_guard<std::mutex> lock(udisk_journal->mtx);
      internal_batch_->Iterator(udisk_journal->mem, nullptr);
    }
    
    do {
      auto migrate_task = g_context->migrate_task(pg_id_);
      if (migrate_task->IsMigrate.load() == false) {
        break; // 没有迁移任务，无需进入迁移相关流程
      }
      std::lock_guard<std::mutex> lock(migrate_task->mtx);
      for (auto& item : migrate_task->udisk_map) {
        uint32_t lc_id = item.first;
        auto udisk = item.second;
        if (CheckPendingIO(udisk)) {
          ULOG_ERROR << "pg_id=" << pg_id_ << ",AddRecord response seqno=" 
              << seqno << ",pending IO";
          retcode = IOErrorContainer::kJournalIOTimeout;
          break;
        }
        if (udisk->status == kMigrateMemTableFinish) {
          // kMigrateMemTableFinish到DualWrite状态之间的io，需要直接返回error，否则导致迁移不一致
          inflight_writers_.insert(inflight_writers_.end(), 
              pending_writers_.begin(), pending_writers_.end());
          pending_writers_.clear();
          ULOG_ERROR << "AddRecord response seqno=" << seqno << ",retcode=" << retcode 
              << ",In MigrateMemTableFinish state,set retcode=kJournalIOError";
          retcode = IOErrorContainer::kJournalIOError;
          break;
        }
        // migrate_immu必须是每个pg一个，迁移时随机选线程，任意线程都可以访问migrate_immu_
        // 迁移memtable时开始记IO
        if (udisk->status == kMigrateMemTable) {
          internal_batch_->Iterator(migrate_task->mem, nullptr, lc_id);
          if (migrate_task->mem->IsFull(0)) { // migrate mem满了，防止mem-killer，直接返回本次迁移失败
            ULOG_ERROR << "Migrate mem is full,abort migrate.udisk=" << udisk->ToString();
            //notify tyr to abort migrate
            g_context->man_listen_loop()->RunInLoop(
                std::bind(&ManagerHandle::MigrateJournalFailRequest, 
                    g_context->manager_handle(), udisk->lc_id, pg_id_, 
                    udisk->tyr_ip, udisk->tyr_port));
          }
        }
      }
    } while (false);
  } while (false);
  internal_batch_->Clear();

  std::deque<WriterPtr> temp_writers; 
  while (!inflight_writers_.empty()) {
    WriterPtr ready = inflight_writers_.front();
    inflight_writers_.pop_front();
    ULOG_TRACE << "ready writer=" << ready << ", seqno=" << ready->seqno; 
    ready->retcode = retcode;
    ready->done = true;
    temp_writers.push_back(ready);
  }
  ULOG_DEBUG << "Left writers size=" << pending_writers_.size();

  BatchResponse(temp_writers);
  DispatchNextWriter();
}

void JournalEngine::BatchResponse(const std::deque<WriterPtr>& writers) {
  for (auto ready : writers) {
    // 数据error不回复，等待超时重试
    ULOG_DEBUG << "response seqno=" << ready->seqno << ", retcode=" 
               << ready->retcode << ", meta=" << ready->meta.ToString() 
               << ", batch_response size=" << writers.size() << ", op=" 
               << ready->op->trace_tag();
    ready->op->DecRefs(); // 减去journal中自增的引用
    if (ready->retcode == IOErrorContainer::kJournalIOFull) {
      // 异常情况不回复，等待Gate重试
      ULOG_ERROR << "MigrateIOFull seqno=" << ready->seqno << ", retcode=" 
               << ready->retcode << ", meta=" << ready->meta.ToString() 
               << ", op=" << ready->op->trace_tag() << ", Just not response.";
    } else {
      ChunkLoopHandle* loop_handle = (ChunkLoopHandle*)(ready->loop->GetLoopHandle());
      AioCbArgs* args = new AioCbArgs;
      args->loop_handle = loop_handle;
      args->op_seq = ready->seqno;
      args->pg_id = pg_id_;
      args->lc_id = ready->meta.lc_id;
      loop_handle->LocalAioCb(ready->retcode, args); 
    }
    delete ready;
  }
}

void JournalEngine::AddRecordCbWrapper(int32_t retcode, 
                                       void* arg) {
  auto cb_arg = 
      std::unique_ptr<JournalAioArgs>(reinterpret_cast<JournalAioArgs*>(arg));
  ULOG_TRACE << "AddRecordCb retcode=" << retcode << ", seqno=" << cb_arg->seqno;
  JournalEngine* engine = cb_arg->engine;
  const IOMeta& meta = cb_arg->meta;
  if (retcode <= 0) {
    ULOG_FATAL << "aio recv ERROR, retcode=" << retcode << ", meta=" 
               << meta.ToString();
    return;
  }
  if (cb_arg->align_buffer) {
    free(cb_arg->align_buffer);
    cb_arg->align_buffer = nullptr;
  }
  engine->AddRecordCb(retcode, cb_arg->seqno);
}

void JournalEngine::BuildBatchGroup() {
  while (!pending_writers_.empty()) {
    WriterPtr w = pending_writers_.front();
    if (internal_batch_->ByteSize() + w->batch->ByteSize() >= 
        ((kBufferSize >> 1) - 3 * kHeaderSize)) {
      // 防止一个batch超过2M, 2M 最多跨3个block
      break;
    }
    internal_batch_->Append(w->batch);
    inflight_writers_.push_back(w);
    pending_writers_.pop_front();
  }
}

// 当连接Conn1发生切换时，假设连接原来在线程TA，重连后切换到TB，
// TA中Conn提交的写请求没有回复，Conn在TB中的写请求可能会和TA中回复的写请求共同操作skiplist
void JournalEngine::ClearJournalOpRequest(int64_t conn_id) {
  ULOG_WARN << "pg_id=" << pg_id_ << ",ConnId=" << conn_id << " will clear journal op...";
  std::deque<WriterPtr> tmp_writers;
  // clear inflight list
  bool inflight = false;
  for (auto it = inflight_writers_.begin(); it != inflight_writers_.end(); ++ it) {
    OpRequest* op = (*it)->op;
    if (op->conn()->GetId() == conn_id) {
      inflight = true;
      break;
    }
  }
  if (inflight) {
    inflight_writers_.swap(tmp_writers);
    internal_batch_->Clear(); // 必须清除数据，否则可能导致journal里inflight数据写两次
  }
  // clear pending list
  for (auto it = pending_writers_.begin(); it != pending_writers_.end(); ) {
    OpRequest* op = (*it)->op;
    if (op->conn()->GetId() == conn_id) {
      tmp_writers.push_back(*it);
      it = pending_writers_.erase(it);
    } else {
      ++ it;
    }
  }
  for (auto item : tmp_writers) {
    ULOG_ERROR << "reset recode journal io error.op=" << item->op->trace_tag() 
        << ",meta=" << item->meta.ToString(); 
    item->retcode = IOErrorContainer::kJournalIOTimeout; 
  }
  BatchResponse(tmp_writers);
  DispatchNextWriter();
}

void JournalEngine::DispatchNextWriter() {
  if (pending_writers_.empty()) {
    return;
  }
  EntryBatchWrite(pending_writers_.front(), true);
}

void JournalEngine::TimerCb() {
  std::deque<WriterPtr> tmp_writers;
  // check inflight list timeout
  bool timeout = false;
  for (auto it = inflight_writers_.begin(); it != inflight_writers_.end(); ++ it) {
    OpRequest* op = (*it)->op;
    if (op->timeout()) {
      timeout = true;
      break;
    }
  }
  if (timeout) {
    inflight_writers_.swap(tmp_writers);
    internal_batch_->Clear(); // 必须清除数据，否则可能导致journal里inflight数据写两次
  }
  // clear pending list
  for (auto it = pending_writers_.begin(); it != pending_writers_.end(); ) {
    OpRequest* op = (*it)->op;
    if (op->timeout()) {
      tmp_writers.push_back(*it);
      it = pending_writers_.erase(it);
    } else {
      ++ it;
    }
  }
  for (auto item : tmp_writers) {
    item->retcode = IOErrorContainer::kJournalIOTimeout; 
  }
  BatchResponse(tmp_writers);
  DispatchNextWriter();

  // compact超时需要不断重试
  for (auto item : compact_list_) {
    auto& io = item.second;
    io.timer_count += 10; // 精度10ms
    if ((int)io.timer_count <= g_context->config().io_timer_count()) {
      continue;
    }
    ULOG_ERROR << "pg_id=" << pg_id_ << ", Compact io timeout! seqno=" 
        << item.first << ", meta=" << io.key.ToString();
    io.timer_count = 0;
    CompactSingleIO(io);
  }
}

void JournalEngine::TriggerCompact() {
  UDiskJournal* udisk_journal = g_context->udisk_journal(pg_id_);
  assert(immu_iter_ == nullptr);
  assert(udisk_journal->immu != nullptr);
  ULOG_DEBUG << "pg_id=" << pg_id_ << ", Entry Compact MemTable seq:[" << 
      udisk_journal->immu->MinSeq() << "," << udisk_journal->immu->MaxSeq() << "].";
  immu_iter_ = udisk_journal->immu->NewIterator(); 
  assert(immu_iter_->Valid());

  // compact_ios_可能会有上一次的遗留数据
  compact_ios_.clear();
  CompactMemTable();
}

void JournalEngine::CompactMemTable() {
  while (compact_list_.size() < (uint32_t)g_context->config().compact_depth()
      && (immu_iter_->Valid() || (!compact_ios_.empty()))) {
    if (compact_ios_.empty()) {
      immu_iter_->Value(&compact_ios_);
      assert(!compact_ios_.empty());
      ULOG_DEBUG << "pg_id=" << pg_id_ << "==>Switch to next immu_iter, size=" 
          << compact_ios_.size();
      immu_iter_->Next();
    }
    auto compact_io = compact_ios_.front(); 
    compact_list_.insert(std::make_pair(compact_io.seqno, compact_io));
    compact_ios_.pop_front();
    CompactSingleIO(compact_io);
  }
}

void JournalEngine::CompactSingleIO(const ExternalIO& compact_io) {
  const uint64_t seqno = compact_io.seqno;
  const IOMeta& meta = compact_io.key;
  compact_batch_->Append(seqno, meta);
  const char* value = compact_io.value;
  ULOG_DEBUG << "pg_id=" << pg_id_ << ", Need Compact seqno=" << seqno 
      << ", meta=" << meta.ToString() << ", inflight size=" << compact_list_.size() 
      << ", data=" << values_string(value, meta.length);
  OpenChunkCb cb = std::bind(&JournalEngine::OpenChunkResponse, this, _1, _2, 
      seqno, meta, value);
  int32_t ret = handle_->GetChunkStorage()->OpenChunk(
      ChunkID(pg_id_, meta.lc_id, meta.pc_no, meta.random_id), true, cb);
  if (ret != UDISK_OK) {
    ULOG_SYSERR << "pg_id=" << pg_id_ << ", Get filehandle fail! pg_id=" 
        << pg_id_ << ", meta=" << meta.ToString() << ", ret=" << ret;
    return; 
  }
  ULOG_DEBUG << "pg_id=" << pg_id_ << ", OpenChunk success. seqno=" << seqno 
      << ", meta=" << meta.ToString() << ", inflight size=" << compact_list_.size();
}

void JournalEngine::OpenChunkResponse(int retcode, 
                                      ChunkHandle* handle, 
                                      uint64_t seqno, 
                                      const IOMeta& meta,
                                      const char* value) {
  if (handle == nullptr || retcode != UDISK_OK) {
    ULOG_SYSERR << "pg_id=" << pg_id_ << ", open chunk fail, ret=" << retcode 
        << ", meta=" << meta.ToString();
    return;
  }
  auto args = new JournalAioArgs();
  args->engine = this;
  args->meta = meta;
  args->seqno = seqno;
  args->loop_handle = handle_;
  int32_t ret =  handle->PWrite(value, meta.length, meta.offset, 
                                JournalEngine::CompactMemTableCbWrapper, args);
  if (ret != UDISK_OK) {
    ULOG_SYSERR << "pg_id=" << pg_id_ << ", submit write fail, ret=" << ret 
        << ", meta=" << meta.ToString();
    handle_->AddLCIOError(meta.lc_id, IOErrorContainer::kNormalIOError, 
                          IOErrorContainer::kIOWrite); 
    return;
  }
  ULOG_DEBUG << "pg_id=" << pg_id_ << ", submit write succ, seqno=" << seqno 
      << ", meta=" << meta.ToString() << ", infilght size=" << compact_list_.size()
      << ", data=" << values_string(value, meta.length);
}

void JournalEngine::CompactMemTableCbWrapper(int32_t retcode, void* arg) {
  auto cb_arg = 
      std::unique_ptr<JournalAioArgs>(reinterpret_cast<JournalAioArgs*>(arg));
  JournalEngine* engine = cb_arg->engine;
  const IOMeta meta = cb_arg->meta;
  if (retcode != (int)meta.length) {
    ULOG_SYSERR << "aio recv ERROR: retcode=" << retcode << ", meta=" 
      << meta.ToString();
    engine->GetHandle()->AddLCIOError(meta.lc_id, IOErrorContainer::kNormalIOError, 
        IOErrorContainer::kIOWrite); 
    //  metaserver会把chunk markdown
    g_context->manager_handle()->ReportChunkFailure(g_context->config().my_id(),
                                                    common::RETCODE_AIO_ERR);
    return;
  }
  ULOG_DEBUG << "CompactMemTable response seqno=" << cb_arg->seqno << ", meta=" 
      << meta.ToString() << ", retcode=" << retcode;
  engine->CompactMemTableCb(cb_arg->seqno, meta);
}

void JournalEngine::CompactMemTableCb(uint64_t seqno, const IOMeta& meta) {
  auto it = compact_list_.find(seqno);
  if (it == compact_list_.end()) { // 这种情况是超时重试导致
    ULOG_ERROR << "pg_id=" << pg_id_ << " meta miss, must be timeout. inflight size=" 
        << compact_list_.size() << ", meta=" << meta.ToString() << ", seqno="
        << seqno << ", Must be timeout.";
    return;
  }
  compact_list_.erase(it);

  ULOG_DEBUG << "pg_id=" << pg_id_ << ", Find response succ. seqno=" << seqno 
             << ", meta=" << meta.ToString() << ", do next. inflight size=" 
             << compact_list_.size();
  if (immu_iter_->Valid() || !compact_ios_.empty()) {
    CompactMemTable();
  } else if (compact_list_.size() > 0) { // 发送结束，等待其他infight list 
    ULOG_DEBUG << "pg_id=" << pg_id_ << ", Compact memtable finish... " << 
        " wait for inflight left=" << compact_list_.size();
  } else { // compact immu finish.
    // 开始压缩日志
    ULOG_INFO << "pg_id=" << pg_id_ << ", flush memtable succ, entry compact journal.";
    UDiskJournal* udisk_journal = g_context->udisk_journal(pg_id_);
    // 只有当前线程会对immu有写操作，这里读无需加锁
    assert(udisk_journal->immu != nullptr);
    immu_iter_ = nullptr;
    EntryCompactJournal();
  }
}

// 把plainzone的journal compact到compactzone
void JournalEngine::EntryCompactJournal() { 
  InternalBatchData* batch_data = compact_batch_->SequentialRead();
  assert(batch_data != nullptr);
  auto journal_meta = g_context->journal_meta();
  auto meta = journal_meta->MutableCompactMeta(pg_id_);
  assert(meta->pg_id == pg_id_);
  ULOG_DEBUG << "Origin compact meta=" << meta->ToString();
  CompactJournal(meta, batch_data);
}

void JournalEngine::CompactJournal(PGCompactMeta* meta, 
                                   InternalBatchData* batch_data) {
  // flush keys to compact zone
  UDiskJournal* udisk_journal = g_context->udisk_journal(pg_id_);
  ULOG_DEBUG << "pg_id=" << pg_id_ << ",compact seq:[" << batch_data->min_seq 
      << "," << batch_data->max_seq << "],data_size=" << batch_data->rep.size() 
      << ",left=" << udisk_journal->compact_wfile->AvailableSpace();
  if (!udisk_journal->compact_wfile->IsSpaceAvailable(batch_data->rep.size())) {
    meta->active_id = (meta->active_id + 1) % kPGCompactJPCCount; 
    meta->active_offset = 0;
    JPCHandle* jpc_handle = nullptr;
    {
      std::lock_guard<std::mutex> lock(udisk_journal->mtx);
      uint32_t jpc_id = meta->zone[meta->active_id].jpc_id;
      jpc_handle = udisk_journal->jpc_storage->AcquireCompactJPC(jpc_id);
      assert(jpc_handle);
    }
    udisk_journal->compact_wfile.reset(new WriteableFile(jpc_handle));
    udisk_journal->compact_writer.reset(
        new JournalWriter(udisk_journal->compact_wfile.get()));
  }
  auto& zone = meta->zone[meta->active_id];
  zone.start_seqno = std::min(zone.start_seqno, batch_data->min_seq); 
  zone.end_seqno = std::max(zone.end_seqno, batch_data->max_seq); 
  ULOG_DEBUG << "Fresh compact_meta=" << meta->ToString(); 
  JournalAioArgs* journal_args = new JournalAioArgs;
  journal_args->engine = this;
  journal_args->loop = handle_->GetLoop();
  journal_args->reserved = (void*)meta;
  udisk_journal->compact_writer->AddRecord(batch_data->rep, 
                             JournalEngine::CompactJournalCbWrapper, 
                             journal_args);
}

void JournalEngine::CompactJournalCbWrapper(int32_t retcode, 
                                            void* arg) {
  auto cb_arg = 
      std::unique_ptr<JournalAioArgs>(reinterpret_cast<JournalAioArgs*>(arg));
  ULOG_TRACE << "CompactJournalCb retcode=" << retcode << ",seqno=" << cb_arg->seqno;
  JournalEngine* engine = cb_arg->engine;
  PGCompactMeta* compact_meta = reinterpret_cast<PGCompactMeta*>(cb_arg->reserved);
  if (retcode <= 0) {
    ULOG_ERROR << "aio recv ERROR, retcode=" << retcode; 
    engine->GetHandle()->AddLCIOError(UINT32_MAX, 
        IOErrorContainer::kNormalIOError, IOErrorContainer::kIOWrite); 
    //  metaserver会把chunk markdown
    g_context->manager_handle()->ReportChunkFailure(g_context->config().my_id(),
                                                    common::RETCODE_AIO_ERR);
    return;
  }
  engine->CompactJournalCb(compact_meta);
}

void JournalEngine::CompactJournalCb(PGCompactMeta* compact_meta) {
  UDiskJournal* udisk_journal = g_context->udisk_journal(pg_id_);
  if (auto batch_data = compact_batch_->SequentialRead()) {
    CompactJournal(compact_meta, batch_data);
  } else {
    // memtable 和 compact zone都更新结束
    // 这里更新元数据包括3部分：
    //  1. compact_zone 
    //  2. 每个inactive jpc reset
    //  3. thread_journal_meta_
    // 只有3.thread_journal_meta_写入数据，才认为真正的compact结束，所以thread_journal_meta_放在最后更新,
    // 否则更新完thread_journal_meta_重启，导致inactive jpc没有reset，jpc被重新分配，没有写入就再次重启的情况下，
    // 再次恢复会导致恢复老数据. 
    // 先inactive jpc reset，之后重启，数据都已经compact，不会丢失数据，恢复时inactive jpc为空
    compact_meta->active_offset = udisk_journal->compact_wfile->SeekOffset();
    ULOG_INFO << "pg_id=" << pg_id_ << " immu compact journal finish,compact_meta="
        << compact_meta->ToString();
    JournalAioArgs* journal_args = new JournalAioArgs;
    journal_args->engine = this;
    journal_args->cmd = kUMImmuCompactFinish;
    journal_args->loop = handle_->GetLoop();
    auto journal_meta = g_context->journal_meta();
    journal_meta->UMImmuCompactFinish(pg_id_,
                                compact_meta,
                                JournalEngine::UpdateJournalMetaCbWrapper, 
                                journal_args);
  }
}

void JournalEngine::UMImmuCompactFinishCb() {
  ULOG_INFO << "pg_id=" << pg_id_ << " update compact meta success.";
  ImmuCompactReset(true);
}

void JournalEngine::ImmuCompactReset(bool jpc_reset) {
  // 回调里执行 2. 每个inactive jpc reset 3. thread_journal_meta_
  ULOG_INFO << "pg_id=" << pg_id_ << " compact reset send request.";
  JournalAioArgs* journal_args = new JournalAioArgs;
  journal_args->engine = this;
  journal_args->cmd = kUMImmuCompactReset;
  journal_args->loop = handle_->GetLoop();
  auto journal_meta = g_context->journal_meta();
  journal_meta->UMImmuCompactReset(pg_id_,
                              jpc_reset,
                              JournalEngine::UpdateJournalMetaCbWrapper, 
                              journal_args);

}

void JournalEngine::UMImmuCompactResetCb() {
  compact_batch_->Clear();   
  // 更新immu和jpc_storage
  UDiskJournal* udisk_journal = g_context->udisk_journal(pg_id_);
  {
    std::unique_lock<std::mutex> lock(udisk_journal->mtx);
    udisk_journal->immu->DecRef();
    udisk_journal->immu = nullptr;
    if (manual_compact_handle_ptr_ != nullptr) {
      uint32_t lc_id = manual_compact_handle_ptr_->LcId();
      ULOG_DEBUG << "compact_handle=" << manual_compact_handle_ptr_->ToString();
      // manual compact情况下,继续迁移直到mem为空
      if (udisk_journal->mem->Empty()) { // mem empty, compact结束
        if (manual_compact_handle_ptr_->CompactType() == ManualCompactRepair) {
          // 修复模式，需要主动停止迁移相关信息
          EntryMigrateTaskFinish(nullptr, lc_id, true);
        }
        manual_compact_handle_ptr_->SendResponse(0, "success"); 
        manual_compact_handle_ptr_ = nullptr;
        SetPendingIO(lc_id, false);
      } else {
        manual_compact_handle_ptr_->IncCompactTimes();
        if (manual_compact_handle_ptr_->CompactTimes() >= 
            g_context->config().migrate_switch_limit()) {
            SetPendingIO(lc_id, true);  
        }
        // 触发重新compact mem
        ULOG_WARN << "pg_id=" << pg_id_ << ",Memtable entry manual compact swap"
          << ",compact_handle=" << manual_compact_handle_ptr_->ToString();
        udisk_journal->schedule_swap.store(true);
        TriggerSwapMemTable(lock);
      }
    }
  }
  ULOG_INFO << "pg_id=" << pg_id_ << ", compact journal complete";
}

void JournalEngine::UpdateJournalMetaCbWrapper(int32_t retcode, 
                                               void* arg) {
  auto cb_arg = reinterpret_cast<JournalAioArgs*>(arg); 
  ULOG_DEBUG << "update meta ret=" << retcode << ", type=" << cb_arg->cmd;
  JournalEngine* engine = cb_arg->engine;
  if (retcode <= 0) {
    ULOG_FATAL << "RecoverJournalCb aio ERROR, retcode=" << retcode << ", type="
        << cb_arg->cmd;
    delete (cb_arg);
    return;
  }
  -- cb_arg->req_ref;
  if (cb_arg->req_ref > 0) { // 说明此时还有请求没返回，所有都返回再处理
    assert(cb_arg->cmd == kUMImmuCompactFinish); // 目前只有UMImmuCompact存在这种情况.
    ULOG_DEBUG << "immu compact response, req_ref=" << cb_arg->req_ref;
    return;
  }
  assert (cb_arg->cmd >= kUMAppendActiveJPC && cb_arg->cmd <= kUVTEof);
  if (cb_arg->cmd == kUMAppendActiveJPC) {
    engine->UMAppendActiveJPCCb();
  } else if (cb_arg->cmd == kUMInitActiveJPC) {
    engine->UMInitActiveJPCCb();
  } else if (cb_arg->cmd == kUMImmuCompactFinish) {
    engine->UMImmuCompactFinishCb();
  } else if (cb_arg->cmd == kUMImmuCompactReset) {
    engine->UMImmuCompactResetCb();
  } else if (cb_arg->cmd == kUMSwapMemTable) {
    engine->UMSwapMemTableCb();
  }
  delete (cb_arg);
}

bool JournalEngine::CompactMetaFilter(const PGCompactMeta& meta,
                                      MigrateUDiskInfo* udisk,
                                      uint64_t seqno) {
  // 从最新开始遍历compact, 只需要zone.end_seqno >= base_seqno, 则选中
  uint32_t lc_id = udisk->lc_id;
  uint64_t base_seqno = seqno;
  std::stack<uint32_t> indexs;
  uint32_t idx = meta.active_id;
  do {
    if (base_seqno > meta.zone[idx].end_seqno) { 
      ULOG_INFO << "pg_id=" << pg_id_ << ",compact_meta=" << meta.ToString() 
          << ",lc_id=" << lc_id << ",base_seqno=" << base_seqno << ",idx=" 
          << idx << " meta filter finish.";
      break;
    }
    indexs.push(idx);
    idx = ((idx + chunk::kPGCompactJPCCount) - 1) % chunk::kPGCompactJPCCount;
  } while (idx != meta.active_id);
  if (idx == meta.active_id) {
    assert(indexs.size() == chunk::kPGCompactJPCCount);
    uint32_t last_idx = indexs.top();
    if (meta.zone[last_idx].start_seqno > base_seqno) { // 这种情况说明所有seqno都比请求大，数据base未找到
      return false;
    }
  }
  ULOG_INFO << "pg_id=" << pg_id_ << ",lc_id=" << lc_id << ",find base_seqno=" 
      << base_seqno;
  // 从最老的journal开始回放
  uint32_t last_idx = UINT32_MAX;
  uint32_t last_offset = UINT32_MAX; 
  UDiskJournal* udisk_journal = g_context->udisk_journal(pg_id_);
  while (!indexs.empty()) {
    last_idx = indexs.top();
    indexs.pop();
    uint32_t jpc_id = meta.zone[last_idx].jpc_id;
    auto jpc_handle = udisk_journal->jpc_storage->AcquireCompactJPC(jpc_id);
    std::vector<std::string> records;
    last_offset = RecoverJournalFile(jpc_handle, &records);
    for (uint32_t i = 0; i < records.size(); ++ i) {
      InternalBatch batch;
      batch.ParseContent(records[i], &udisk->migrate_meta, lc_id, base_seqno);
      ULOG_DEBUG << "pg_id=" << pg_id_ << ",i=" << i << ",base_seqno=" << base_seqno
          << ",meta_size=" << udisk->migrate_meta.size() << ", lc_id=" << lc_id;
    }
    ULOG_DEBUG << "pg_id=" << pg_id_ << ",last_idx=" << last_idx 
        << ",last_offset=" << last_offset;
  };
  assert(udisk->migrate_meta.size() > 0);
  // 这里更新udisk compact相关信息
  udisk->active_id = last_idx;
  udisk->active_offset = last_offset;
  udisk->last_seqno = udisk->migrate_meta.rbegin()->first;
  return true;
}

void JournalEngine::DoPrepareMigrateTask(PrepareMigrateHandlePtr handle_ptr,
                                         const TyrPrepareMigrateRequest& req) {
  ULOG_DEBUG << "start migrate journal for lc_id=" << req.lc_id() 
             << ", pg_id=" << pg_id_ ;
  if (InMigrate(req.lc_id())) {
    ULOG_WARN << "MigrateJournal is already scheduled. lc_id=" << req.lc_id() 
      << ", pg_id=" << pg_id_;
    return;
  }
  uint64_t seqno = MigrateSeqno();
  MigrateUDiskInfo* migrate_udisk = new MigrateUDiskInfo();
  {
    auto migrate_task = g_context->migrate_task(pg_id_);
    std::lock_guard<std::mutex> guard(migrate_task->mtx);
    migrate_task->udisks[req.lc_id()] = migrate_udisk;
    migrate_task->udisk_map.insert(std::make_pair(req.lc_id(), migrate_udisk));
    migrate_task->IsMigrate.store(true);
  }
  migrate_udisk->lc_id = req.lc_id();
  migrate_udisk->pc_size = req.pc_size();
  migrate_udisk->peer_lc_id = req.peer_lc_id();
  migrate_udisk->peer_random_id = req.peer_random_id();
  migrate_udisk->peer_pc_size = req.peer_pc_size();
  migrate_udisk->pg_id = req.pg_id();
  migrate_udisk->lc_size = req.lc_size();
  migrate_udisk->active_id = UINT32_MAX;
  migrate_udisk->active_offset = UINT32_MAX;
  migrate_udisk->last_seqno = seqno;
  migrate_udisk->tyr_ip = req.tyr_ip();
  migrate_udisk->tyr_port = req.tyr_port();
  migrate_udisk->status = kMigrateJournal; 
  migrate_udisk->peer_route = 
      std::make_shared<RouteManager>(handle_, migrate_udisk->lc_size, 
                                     migrate_udisk->peer_pc_size);
  migrate_udisk->peer_route->UpdateClusterMap(req.cluster_info(), 
                                             req.chunk_info(), 
                                             req.pg_info());
  ULOG_DEBUG << "start migrate udisk=" << migrate_udisk->ToString();

  handle_ptr->SendResponse(0, "success", seqno);
}

void JournalEngine::DoMigrateJournalTask(MigrateJournalHandlePtr handle_ptr,
                                         const TyrMigrateJournalRequest& req) {
  if (req.pg_id() != pg_id_) {
    ULOG_ERROR << "Request migrate journal pg_id=" << req.pg_id() 
        << " error,my pg_id=" << pg_id_;
    handle_ptr->SendResponse(-EC_UDISK_INTERNAL_ERROR, "pg_id not equal");
    return;
  }
  if (!InMigrate(req.lc_id())) {
    ULOG_ERROR << "Request migrate journal lc_id=" << req.lc_id() 
        << " not in migrate";
    handle_ptr->SendResponse(-EC_UDISK_INTERNAL_ERROR, "Request migrate lc not in migrate");
    return;
  }
  handle_ptr->SendResponse(0, "success");
  auto migrate_task = g_context->migrate_task(pg_id_);
  MigrateUDiskInfo* udisk = migrate_task->udisks[req.lc_id()];
  assert(udisk);
  ULOG_DEBUG << "Entry MigrateJournalTask,udisk=" << udisk->ToString();
  udisk->peer_route->ResetHandle(handle_);
  EntryMigrateJournal(udisk, req.seqno());
}

void JournalEngine::EntryMigrateJournal(MigrateUDiskInfo* udisk,
                                        uint64_t seqno) {
  // 防止判断前后immu compact结束
  UDiskJournal* udisk_journal = g_context->udisk_journal(pg_id_);
  MemTable* weak_immu = nullptr;
  {
    std::lock_guard<std::mutex> lock(udisk_journal->mtx);
    weak_immu = udisk_journal->immu;
    if (weak_immu != nullptr) {
      weak_immu->IncRef();
    }
  }
  auto journal_meta = g_context->journal_meta();
  auto compact_meta = journal_meta->GetCompactMeta(pg_id_);
  if (udisk->active_id != compact_meta.active_id || 
      udisk->active_offset != compact_meta.active_offset) { //继续迁移剩余journal
    uint64_t last_seqno = compact_meta.zone[compact_meta.active_id].end_seqno;
    assert(udisk->last_seqno <= last_seqno);
    assert(seqno <= last_seqno);
    ULOG_INFO << "New compact data. continue migrate journal...now_seqno=" 
        << last_seqno << ",finish_seqno=" << seqno 
        << ",compact_meta=" << compact_meta.ToString();
    if (seqno < last_seqno) {
      // ToDo: filter只从last_active处开始访问
      CompactMetaFilter(compact_meta, udisk, seqno);
    }
    if (udisk->migrate_meta.empty()) {
      ULOG_INFO << "ReMigrate no more meta for udisk=" << udisk->ToString();
      DoMigrateMemTableTask(udisk, weak_immu);
    } else {
      auto compact_item = udisk->compact_process.Add();
      compact_item->set_switch_times(udisk->compact_process.size() - 1);
      compact_item->set_migrate_ios(0);
      compact_item->set_migrate_bytes(0);
      ULOG_INFO << "Migrate journal for migrate udisk=" << udisk->ToString() 
          << ",switch_times=" << compact_item->switch_times();
      MigrateJournal(udisk);
    }
  } else { // journal 迁移完毕，开始迁移memtable
    ULOG_INFO << "Migrate journal finish, Entry migrate memtable for udisk=" 
      << udisk->ToString();
    DoMigrateMemTableTask(udisk, weak_immu);
  }
  {
    std::lock_guard<std::mutex> lock(udisk_journal->mtx);
    if (weak_immu != nullptr) {
      weak_immu->DecRef();
      weak_immu = nullptr;
    }
  }
}

void JournalEngine::MigrateJournal(MigrateUDiskInfo* udisk) {
  assert(udisk->compact_process.size() > 0);
  auto compact_item = 
      udisk->compact_process.Mutable(udisk->compact_process.size() - 1);
  uint32_t compact_depth = g_context->config().compact_depth();
  while (udisk->migrate_inflight.size() < compact_depth &&
        (!udisk->migrate_meta.empty())) {
    const auto& it = udisk->migrate_meta.begin();
    uint32_t length = MigrateSingleJournalIO(udisk, it->first, it->second);
    udisk->migrate_meta.erase(it);
    compact_item->set_migrate_ios(compact_item->migrate_ios() + 1);
    compact_item->set_migrate_bytes(compact_item->migrate_bytes() + length);
  }
}

uint32_t JournalEngine::MigrateSingleJournalIO(MigrateUDiskInfo* udisk, 
                                               const uint64_t seqno,
                                               const chunk::IOMeta& meta) {
  uevent::ConnectorUeventPtr target_ctor;
  MigratePcMeta migrate_pc;
  udisk->InitMigratePc(meta.pc_no, meta.offset, &target_ctor, &migrate_pc);
  ULOG_DEBUG << "seqno=" << seqno << ",udisk=" << udisk->ToString();
  if (!target_ctor || !target_ctor->HasAvailableConnection()) {
    ULOG_ERROR << "Migrate op=" << seqno << " connection has closed";
    return common::RETCODE_RESET_CONNECTION;
  }
  auto& conn = target_ctor->GetConnection(); 
  auto& op_pool = handle_->op_pool();
  OpRequest* op = op_pool.Malloc(seqno, conn, nullptr, nullptr, meta.length,
                                 common::MIGRATE_CMD_JOURNAL, pg_id_,
                                 op_pool, nullptr, nullptr, nullptr);
  if (UNLIKELY(op == nullptr)) {
    ULOG_ERROR << "Failed to malloc OpRequest,seqno=" << seqno;
    return -1;
  }   
  udisk->migrate_inflight.insert(std::make_pair(seqno, std::make_pair(op, meta)));
  ULOG_DEBUG << "pg_id=" << pg_id_ << ",migrate seqno=" << seqno << ",meta="
      << meta.ToString() << ",list size=" << udisk->migrate_inflight.size();
  OpenChunkCb cb = std::bind(&JournalEngine::MigrateOpenChunkResponse, 
                             this, _1, _2, op, meta, udisk, migrate_pc);
  int32_t ret = handle_->GetChunkStorage()->OpenChunk(
      ChunkID(pg_id_, meta.lc_id, meta.pc_no, meta.random_id), 
      true, 
      cb);
  if (ret != UDISK_OK) {
    ULOG_FATAL << "pg_id=" << pg_id_ << ",Get chunk handle fail, meta=" 
        << meta.ToString() << ", ret=" << ret;
    return ret;
  }
  return meta.length;
}

void JournalEngine::MigrateOpenChunkResponse(int retcode, 
                                      ChunkHandle* handle, 
                                      OpRequest* op, 
                                      const IOMeta meta,
                                      MigrateUDiskInfo* udisk,
                                      MigratePcMeta migrate_pc) {
  if (handle == nullptr || retcode != UDISK_OK) {
    ULOG_SYSERR << "pg_id=" << pg_id_ << ",open chunk fail,ret=" << retcode 
        << ",meta=" << meta.ToString() << ",op=" << op->trace_tag();
    return;
  }
  auto args = new JournalAioArgs();
  args->engine = this;
  args->meta = meta;
  args->seqno = op->op_seq();
  args->migrate_pc = migrate_pc;
  args->reserved = udisk;
  assert(meta.length <= UDISK_TPC_SIZE);

  void *read_buf = nullptr;
  MemorySlab *slab = nullptr;
  auto& mem_pool = handle_->mem_pool();
  std::tie(read_buf, slab) = mem_pool.Malloc(meta.length, kDefaultDevBlockSize);
  assert(read_buf);
  // 将read_buf的控制权交给op,当op操作完成后，
  // op被销毁的时候，会释放read_buf空间
  op->set_read_buffer((char*)read_buf, &mem_pool, slab);
  int32_t ret =  handle->PRead(read_buf, meta.length, meta.offset, 
      JournalEngine::MigrateReadCbWrapper, args);
  if (ret != UDISK_OK) {
    ULOG_SYSERR << "pg_id=" << pg_id_ << " submit write fail,ret=" << ret 
        << ",meta=" << meta.ToString();
    return;
  }
  op->IncRefs(); // Submit使用op的read_buffer, 需要增加引用计数
  ULOG_DEBUG << "pg_id=" << pg_id_ << ",submit read succ,seqno=" << op->op_seq()
      << ", meta=" << meta.ToString();
}

void JournalEngine::MigrateReadCbWrapper(int32_t retcode, 
                                         void* arg) {
  auto cb_arg = 
      std::unique_ptr<JournalAioArgs>(reinterpret_cast<JournalAioArgs*>(arg));
  JournalEngine* engine = cb_arg->engine;
  const IOMeta& meta = cb_arg->meta;
  const MigratePcMeta& migrate_pc = cb_arg->migrate_pc;
  MigrateUDiskInfo* udisk = reinterpret_cast<MigrateUDiskInfo*>(cb_arg->reserved);
  if (retcode != (int)meta.length) {
    ULOG_SYSERR << "aio recv ERROR: retcode=" << retcode << ",meta=" 
      << meta.ToString();
    engine->GetHandle()->AddLCIOError(meta.lc_id, 
                                      IOErrorContainer::kNormalIOError, 
                                      IOErrorContainer::kIOWrite); 
    return;
  }
  ULOG_DEBUG << "MigrateRead response seqno=" << cb_arg->seqno << ",meta=" 
      << meta.ToString() << ",retcode=" << retcode;
  engine->MigrateReadCb(cb_arg->seqno, meta, udisk, migrate_pc);
}

void JournalEngine::MigrateReadCb(uint64_t seqno, 
                                  const IOMeta& meta,
                                  MigrateUDiskInfo* udisk,
                                  const MigratePcMeta& migrate_pc) {
  auto it = udisk->migrate_inflight.find(seqno);
  if (it == udisk->migrate_inflight.end()) {
    ULOG_ERROR << "pg_id=" << pg_id_ << " Submit meta miss! seqno=" << seqno 
        << ",meta=" << meta.ToString();
    return;
  }
  OpRequest* op = it->second.first;
  op->DecRefs(); // 减去submit的引用
  ULOG_DEBUG << "pg_id=" << pg_id_ << ",Find response succ.seqno=" << seqno 
      << ",meta=" << meta.ToString() << ",data=" << values_string(op->read_buffer(), meta.length);
  auto retcode = handle_->MigrateJournalRequest(op, 
                                                meta, 
                                                udisk->pg_id,
                                                udisk->lc_size,
                                                migrate_pc);
  if (retcode == common::RETCODE_CLUSTER_VERSION_ERR) {
    ULOG_ERROR << "Migrate cluster version error.udisk=" << udisk->ToString();
    //notify tyr to abort migrate
    g_context->man_listen_loop()->RunInLoop(
        std::bind(&ManagerHandle::MigrateJournalFailRequest, 
            g_context->manager_handle(), udisk->lc_id, pg_id_, udisk->tyr_ip, udisk->tyr_port));
  }
}

void JournalEngine::MigrateJournalResponse(const common::MigrateHead* hdr) {
  uint64_t seqno = hdr->flowno;
  uint32_t lc_id = hdr->reserved_lc_id;
  uint32_t pg_id = hdr->reserved_pg_id;
  assert(pg_id == pg_id_);
  auto migrate_task = g_context->migrate_task(pg_id_);
  MigrateUDiskInfo* udisk = migrate_task->udisks[lc_id];
  if(UNLIKELY(udisk == nullptr)) {
    ULOG_WARN << "pg_id=" << pg_id_ << ",lc_id=" << lc_id << ",seqno=" << seqno 
              << ",can't find udisk.Must trigger manual compact.";
    return;
  }
  auto it = udisk->migrate_inflight.find(seqno);
  if (it == udisk->migrate_inflight.end()) {
    ULOG_ERROR << "pg_id=" << pg_id_ << ",lc_id=" << lc_id 
        << ",migrate response miss! seqno=" << seqno;
    return;
  }
  OpRequest* op = it->second.first;
  const IOMeta meta = it->second.second;
  op->DecRefs();
  udisk->migrate_inflight.erase(it);
  if (hdr->retcode != 0) {
    ULOG_ERROR << "pg_id=" << pg_id_ << ",Migrate compact resp error. head="
      << common::DumpMigrateHead(*hdr) << ", need retry";
    // 这里出错直接重试
    MigrateSingleJournalIO(udisk, seqno, meta);
    return;
  }
  ULOG_DEBUG << "pg_id=" << pg_id_ << ",lc_id=" << lc_id << " response succ." 
             << "seqno=" << seqno << ",meta=" << meta.ToString() 
             << ",do next. migrate size=" << udisk->migrate_inflight.size();
  if (!udisk->migrate_meta.empty()) {
    MigrateJournal(udisk);
  } else if (udisk->migrate_inflight.size() > 0) { // 发送结束，等待其他migrate list返回
    ULOG_DEBUG << "pg_id=" << pg_id_ << ",lc_id=" << lc_id << ",seqno=" << seqno
      << ",send migrate finish.wait for left=" << udisk->migrate_inflight.size();
  } else { // 迁移journal complete
    ULOG_INFO << "Migrate journal complete temporarily,udisk=" << udisk->ToString();
    // 异步通知tyr已经迁移结束的seqno和compact_process
    g_context->man_listen_loop()->RunInLoop(
        std::bind(&ManagerHandle::UpdateMigrateProcess, 
                  g_context->manager_handle(), *udisk));
    EntryMigrateJournal(udisk, udisk->last_seqno);
  }
}

void JournalEngine::DoMigrateMemTableTask(MigrateUDiskInfo* udisk,
                                          MemTable* weak_immu) {
  ULOG_DEBUG << "pg_id=" << pg_id_ << ",do migrate memtable task=" 
      << udisk->ToString();
  assert(udisk->migrate_immu == nullptr); 
  assert(udisk->status == kMigrateJournal); // 状态只能从migrate_journal->migrate_immutable
  udisk->status = kMigrateMemTable;

  UDiskJournal* udisk_journal = g_context->udisk_journal(pg_id_);
  udisk->migrate_immu = new MemTable(pg_id_, udisk_journal->memtable_cap);
  udisk->migrate_immu->IncRef();
  MemTable* mem = nullptr;
  MemTable* immu = nullptr;
  {
    std::lock_guard<std::mutex> guard(udisk_journal->mtx);
    mem = udisk_journal->mem;
    mem->IncRef();
    immu = udisk_journal->immu;
    if (weak_immu != nullptr) { // weak_immu记录check是否迁移完journal前的immu
      if (immu == nullptr) { // 判断前后，immu compact结束
        ULOG_WARN << "immu compact finish before migrate memtable. udisk=" 
          << udisk->ToString();
      } else { 
        if (immu->GetID() == weak_immu->GetID()) { // 这种情况，说明check前后immu没有变化
          immu = nullptr; // 只合并weak_immu即可
        } else { // immu compact结束，mem又切换了一次
          ULOG_WARN << "immu swap again before migrate memtable,weak_immu=" 
            << weak_immu->ToString() << ",immu=" << immu->ToString();
        }
      }
    } else {
      // immu check之前是null，do nothing
    }
    if (immu != nullptr) {
      immu->IncRef();
    }
  }
  ULOG_DEBUG << "pg_id=" << pg_id_ << ", Process immutable memtable";
  udisk->migrate_immu->CopyFrom(weak_immu, udisk->lc_id);
  udisk->migrate_immu->CopyFrom(immu, udisk->lc_id);
  {
    std::lock_guard<std::mutex> guard(udisk_journal->mtx);
    // CopyFrom需要对mem进行迭代，并获取node中的io_list,无法保证原子性
    ULOG_DEBUG << "pg_id=" << pg_id_ << ", Process memtable";
    udisk->migrate_immu->CopyFrom(mem, udisk->lc_id);
    mem->DecRef();
    mem = nullptr;
    if (immu != nullptr) {
      immu->DecRef();
      immu = nullptr;
    }
  }
  EntryMigrateMemTable(udisk, false);
}

void JournalEngine::MigrateMemTable(MigrateUDiskInfo* udisk) {
  assert(udisk->memtable_process.size() > 0);
  auto memtable_item = 
      udisk->memtable_process.Mutable(udisk->memtable_process.size() - 1);
  while (udisk->mem_inflight.size() < (uint32_t)g_context->config().compact_depth() &&
         (udisk->immu_iter->Valid() || !udisk->migrate_ios.empty())) {
    if (udisk->migrate_ios.empty()) {
      udisk->immu_iter->Value(&udisk->migrate_ios);
      assert(!udisk->migrate_ios.empty());
      ULOG_DEBUG << "pg_id=" << pg_id_ << "==>Switch to next meta_iter,size="
          << udisk->migrate_ios.size();
      udisk->immu_iter->Next();
    }
    auto migrate_io = udisk->migrate_ios.front();
    udisk->migrate_ios.pop_front();
    uint32_t length = MigrateSingleMemIO(udisk, migrate_io);
    memtable_item->set_migrate_ios(memtable_item->migrate_ios() + 1);
    memtable_item->set_migrate_bytes(memtable_item->migrate_bytes() + length);
  }
}

uint32_t JournalEngine::MigrateSingleMemIO(MigrateUDiskInfo* udisk, 
                                       const ExternalIO& migrate_io) {
  const uint64_t seqno = migrate_io.seqno;
  const IOMeta& meta = migrate_io.key;
  const char* value = migrate_io.value;
  uevent::ConnectorUeventPtr target_ctor;
  MigratePcMeta migrate_pc;
  udisk->InitMigratePc(meta.pc_no, meta.offset, &target_ctor, &migrate_pc);
  ULOG_DEBUG << "seqno=" << seqno << ",udisk=" << udisk->ToString();
  if (!target_ctor || !target_ctor->HasAvailableConnection()) {
    ULOG_ERROR << "Migrate op=" << seqno << " connection has closed";
    return common::RETCODE_RESET_CONNECTION;
  }
  auto& conn = target_ctor->GetConnection(); 
  const auto& peer_addr = conn->GetPeerAddress();
  ULOG_DEBUG << "migrate op=" << seqno << ",peer_addr=" << peer_addr.ToString() 
      << ",conn_id=" << conn->GetId(); 
  auto& op_pool = handle_->op_pool();
  OpRequest* op = op_pool.Malloc(seqno, conn, nullptr, value, meta.length,
                                 common::MIGRATE_CMD_MEMTABLE, pg_id_,
                                 op_pool, nullptr, nullptr, nullptr);
  if (UNLIKELY(op == nullptr)) {
    ULOG_ERROR << "Failed to malloc OpRequest,seqno=" << seqno;
    return -1;
  }   
  op->IncMsgDataRef(); // value直接使用memtable中内存，由memtable管理
  udisk->mem_inflight.insert(std::make_pair(seqno, std::make_pair(op, migrate_io)));
  ULOG_TRACE << "pg_id=" << pg_id_ << ",Migrate seqno=" << seqno << ",meta=" 
      << meta.ToString() << ",data=" << values_string(value, meta.length);
  auto retcode = handle_->MigrateJournalRequest(op, 
                                                meta, 
                                                udisk->pg_id,
                                                udisk->lc_size,
                                                migrate_pc); 
  if (retcode == common::RETCODE_CLUSTER_VERSION_ERR) {
    ULOG_ERROR << "Migrate cluster version error.udisk=" << udisk->ToString();
    //notify tyr to abort migrate
    g_context->man_listen_loop()->RunInLoop(
        std::bind(&ManagerHandle::MigrateJournalFailRequest, 
            g_context->manager_handle(), udisk->lc_id, pg_id_, udisk->tyr_ip, udisk->tyr_port));
  }
  return meta.length;
}

void JournalEngine::MigrateMemTableResponse(const common::MigrateHead* hdr) {
  uint64_t seqno = hdr->flowno;
  uint32_t lc_id = hdr->reserved_lc_id;
  uint32_t pg_id = hdr->reserved_pg_id;
  assert(pg_id == pg_id_);
  auto migrate_task = g_context->migrate_task(pg_id_);
  MigrateUDiskInfo* udisk = migrate_task->udisks[lc_id];
  if(UNLIKELY(udisk == nullptr)) {
    ULOG_WARN << "pg_id=" << pg_id_ << ",lc_id=" << lc_id << ",seqno=" << seqno 
              << ",can't find udisk.Must trigger manual compact.";
    return;
  }
  auto it = udisk->mem_inflight.find(seqno);
  if (it == udisk->mem_inflight.end()) {
    ULOG_ERROR << "pg_id=" << pg_id_ << ",lc_id=" << lc_id 
        << " migrate response miss! need seqno=" << seqno;
    return;
  }
  it->second.first->DecRefs();
  const auto migrate_io = it->second.second;
  udisk->mem_inflight.erase(it);
  if (hdr->retcode != 0) {
    ULOG_ERROR << "pg_id=" << pg_id_ << ",Migrate memtable resp error. head="
      << common::DumpMigrateHead(*hdr) << ", need retry";
    // 这里出错直接重试
    MigrateSingleMemIO(udisk, migrate_io);
    return;
  }
  ULOG_DEBUG << "pg_id=" << pg_id_ << ",lc_id=" << lc_id << " response succ." 
      << "seqno=" << seqno << ",meta=" << migrate_io.key.ToString() 
      << ",migrate size=" << udisk->mem_inflight.size();
  if (udisk->immu_iter->Valid() || !udisk->migrate_ios.empty()) {
    MigrateMemTable(udisk);
  } else if (udisk->mem_inflight.size() > 0) { // 发送结束，等待其他migrate list 
    ULOG_DEBUG << "pg_id=" << pg_id_ << ",migrate memtable finish," << 
        "wait for left back... left_size=" << udisk->mem_inflight.size();
  } else { // migrate immu finish.
    ULOG_INFO << "pg_id=" << pg_id_ << ",migrate memtable finish temp.udisk=" 
        << udisk->ToString();
    udisk->migrate_immu->DecRef();
    udisk->migrate_immu = nullptr;
    // 异步通知tyr已经迁移结束的seqno和compact_process
    g_context->man_listen_loop()->RunInLoop(
        std::bind(&ManagerHandle::UpdateMigrateProcess, 
                  g_context->manager_handle(), *udisk));
    if (udisk->memtable_process.size() >= 
        g_context->config().migrate_switch_limit()) { // memtable切换次数超过限制，block前端io
      SetPendingIO(udisk, true);
    }
    EntryMigrateMemTable(udisk, true);
  }
}

void JournalEngine::EntryMigrateMemTable(MigrateUDiskInfo* udisk,
                                         bool reenter) {
  auto migrate_task = g_context->migrate_task(pg_id_);
  {
    std::lock_guard<std::mutex> lock(migrate_task->mtx);
    if (!reenter && udisk->migrate_immu->Empty()) {
      MigrateMemTableFinish(udisk);
      return;
    }  
    if (reenter) {
      ULOG_DEBUG << "pg_id=" << pg_id_ << " Migrate memtable try again. udisk=" 
          << udisk->ToString();
      assert(udisk->migrate_immu == nullptr);
      UDiskJournal* udisk_journal = g_context->udisk_journal(pg_id_);
      udisk->migrate_immu = new MemTable(pg_id_, udisk_journal->memtable_cap);
      udisk->migrate_immu->IncRef();
      udisk->migrate_immu->SpliceFrom(migrate_task->mem, udisk->lc_id);
      if (udisk->migrate_immu->Empty()) {
        MigrateMemTableFinish(udisk);
        return;
      }
    }
  }
  udisk->migrate_immu->Shrink();
  udisk->immu_iter = udisk->migrate_immu->NewIterator(); 
  assert(udisk->immu_iter->Valid());
  auto memtable_item = udisk->memtable_process.Add();
  memtable_item->set_switch_times(udisk->memtable_process.size() - 1);
  memtable_item->set_migrate_ios(0);
  memtable_item->set_migrate_bytes(0);
  ULOG_INFO << "pg_id=" << pg_id_ << ",Migrate memtable for udisk=" << 
      udisk->ToString() << ",switch_time=" << memtable_item->switch_times();
  udisk->migrate_ios.clear();
  MigrateMemTable(udisk);
}

void JournalEngine::MigrateMemTableFinish(MigrateUDiskInfo* udisk) {
  ULOG_DEBUG << "pg_id=" << pg_id_ << " migrate UDisk finish,udisk=" << 
      udisk->ToString();
  assert(udisk->migrate_inflight.empty());
  if (udisk->migrate_immu != nullptr) {
    udisk->migrate_immu->DecRef();
    udisk->migrate_immu = nullptr;
  }
  if (CheckPendingIO(udisk)) {
    SetPendingIO(udisk, false);
  }
  assert(udisk->status == kMigrateMemTable);
    // 1.开始双写
  udisk->status = kMigrateMemTableFinish;
  // 2.异步通知tyr
  g_context->man_listen_loop()->RunInLoop(
      std::bind(&ManagerHandle::MigratePgFinishRequest, 
                g_context->manager_handle(),
                udisk->lc_id, udisk->pg_id,
                udisk->tyr_ip, udisk->tyr_port));
}

bool JournalEngine::EntryMigrateTaskFinish(MigrateTaskFinishHandlePtr handle_ptr,
                                           uint32_t lc_id,
                                           bool force) {
  auto migrate_task = g_context->migrate_task(pg_id_);
  std::lock_guard<std::mutex> lock(migrate_task->mtx);
  if (migrate_task->udisks[lc_id] == nullptr) {
    ULOG_ERROR << "pg_id=" << pg_id_ << ",lc_id=" << lc_id << " not migrate.";
    if (handle_ptr) {
      handle_ptr->SendResponse(-EC_UDISK_INTERNAL_ERROR, "lc not migrate");
    }
    return false;
  }
  const auto udisk = migrate_task->udisks[lc_id];
  if (udisk->status != kMigrateDualWrite && // 前端没有io时，保持kMigrateMemTableFinish 
      udisk->status != kMigrateMemTableFinish) {
    ULOG_ERROR << "Migrate finish error. lc_id=" << lc_id << ",udisk=" 
        << udisk->ToString();
    if (force == false) {
      if (handle_ptr) {
        handle_ptr->SendResponse(-EC_UDISK_INTERNAL_ERROR, "migrate status error");
      }
      return false;
    } else {
      ULOG_WARN << "pg_id=" << pg_id_ << ",lc_id=" << lc_id << ",force finish.";
    }
  }
  delete udisk;
  migrate_task->udisks[lc_id] = nullptr;
  migrate_task->udisk_map.erase(lc_id);
  if (migrate_task->udisk_map.empty()) {
    ULOG_INFO << "pg_id=" << pg_id_ << ",lc_id=" << lc_id << ",migrate complete,set IsMigrate false";
    migrate_task->IsMigrate.store(false);
  }
  ULOG_DEBUG << "pg_id=" << pg_id_ << ",lc_id=" << lc_id << ",enter EntryMigrateTaskFinish";
  if (handle_ptr) {
    handle_ptr->SendResponse(0, "success");
  }
  return true;
}

void JournalEngine::DoManualCompactTask(ManualCompactHandlePtr handle_ptr, 
                                        uint32_t lc_id, 
                                        uint32_t pg_id) {
  if (pg_id != pg_id_) {
    ULOG_ERROR << "Request manual compact pg_id=" << pg_id << " error,my pg_id="
        << pg_id_;
    return;
  }
  if (InMigrate(lc_id)) {
    ULOG_WARN << "Request manual compact lc_id=" << lc_id << " in migrate";
  }
  EntryManualCompact(handle_ptr, lc_id);
}

void JournalEngine::EntryManualCompact(const ManualCompactHandlePtr& handle_ptr,
                                       uint32_t lc_id) {
  UDiskJournal* udisk_journal = g_context->udisk_journal(pg_id_);
  if (udisk_journal->immu != nullptr) { // both mem and immu are full
    ULOG_WARN << "pg_id=" << pg_id_ << ",manual compact immu still compact...";
    handle_->GetLoop()->RunAfter(0.1,
        std::bind(&JournalEngine::EntryManualCompact, this, handle_ptr, lc_id));
    return;
  }
  if (udisk_journal->mem == nullptr) { //mem must not be null
    ULOG_FATAL << "pg_id=" << pg_id_ << ", mem is null";
    return;
  } 
  std::unique_lock<std::mutex> lock(udisk_journal->mtx);
  if (udisk_journal->mem->Empty()) {
    ULOG_WARN << "pg_id=" << pg_id_ << ",manual compcat mem is empty";
    handle_ptr->SendResponse(0, "success");
    return;
  }
  manual_compact_handle_ptr_ = handle_ptr;
  ULOG_WARN << "pg_id=" << pg_id_ << ",Memtable entry manual compact swap"
    << ",compact_handle=" << manual_compact_handle_ptr_->ToString();
  udisk_journal->schedule_swap.store(true);
  TriggerSwapMemTable(lock);
} 

bool JournalEngine::InMigrate(uint32_t lc_id) {
  auto migrate_task = g_context->migrate_task(pg_id_);
  return (migrate_task->IsMigrate.load() == true) && 
          (migrate_task->udisks[lc_id] != nullptr);
}

bool JournalEngine::CheckDualWrite(uint32_t lc_id, 
                                   uint32_t pc_no,
                                   uint32_t offset,
                                   ucloud::udisk::MigratePcMeta* migrate_pc,
                                   uevent::ConnectorUeventPtr* ctor) {
  auto migrate_task = g_context->migrate_task(pg_id_);
  if (migrate_task->udisks[lc_id] == nullptr) {
    return false;
  }
  std::lock_guard<std::mutex> lock(migrate_task->mtx); // 加锁防止udisk被释放
  auto udisk = migrate_task->udisks[lc_id];
  if (migrate_task->udisks[lc_id] == nullptr) {
    // 防止EntryMigrateTaskFinish先抢到锁
    return false;
  }
  if (udisk->status == kMigrateMemTableFinish) {
    // 迁移完memtable后，开始双写模式
    udisk->status = kMigrateDualWrite;
  } 
  if (udisk->status != kMigrateDualWrite) {
    return false;
  }
  udisk->peer_route->ResetHandle(handle_);
  udisk->InitMigratePc(pc_no, offset, ctor, migrate_pc);
  return true; 
}

uint64_t JournalEngine::MigrateSeqno() {
  auto journal_meta = g_context->journal_meta();
  auto compact_meta = journal_meta->GetCompactMeta(pg_id_);
  return compact_meta.zone[compact_meta.active_id].end_seqno;
}

void JournalEngine::SetPendingIO(uint32_t lc_id, bool enable) {
  auto migrate_task = g_context->migrate_task(pg_id_);
  MigrateUDiskInfo* udisk = migrate_task->udisks[lc_id];
  SetPendingIO(udisk, enable);
}

void JournalEngine::SetPendingIO(MigrateUDiskInfo* udisk, bool enable) {
  if (udisk == nullptr) {
    return;
  }
  udisk->pending_io = enable;
  ULOG_WARN << "Pending io set" << enable << ".switch_times=" 
            << udisk->memtable_process.size() << ",udisk=" << udisk->ToString();
}

bool JournalEngine::CheckPendingIO(uint32_t lc_id) {
  auto migrate_task = g_context->migrate_task(pg_id_);
  MigrateUDiskInfo* udisk = migrate_task->udisks[lc_id];
  return CheckPendingIO(udisk);
}

bool JournalEngine::CheckPendingIO(MigrateUDiskInfo* udisk) {
  if (udisk == nullptr) {
    return false;
  }
  return udisk->pending_io;
}

