#ifndef UDISK_JOURNAL_MEM_POOL_H_
#define UDISK_JOURNAL_MEM_POOL_H_

#include <stdint.h>
#include <vector>
#include <stddef.h>
#include <memory>

namespace udisk {
namespace journal {

//MemPool非线程安全，需要调用线程保证
class MemPool {
 public:
  MemPool();
  ~MemPool();
  MemPool(const MemPool&) = delete;
  void operator=(const MemPool&) = delete;

  char* Allocate(size_t bytes);
  char* AllocateIO(size_t bytes, bool& mem_shared);//align 512

 private:
  char* AllocateNewBlock(size_t bytes);
  char* AllocateNewAlignBlock(size_t bytes, bool shared);

  const size_t kBlockSize = (1 << 20);//1M

  char* alloc_ptr_ = nullptr;
  char* align_alloc_ptr_ = nullptr;
  size_t alloc_avaliable_size_ = 0;
  size_t align_alloc_avaliable_size_ = 0;
  std::vector<char*> blocks_;
  std::vector<char*> align_blocks_;

  size_t mem_usage_ = 0;
  const size_t kMaxUsage = 1073741824;//1G
};

}; // end of ns journal
}; // end of ns udisk

#endif
