#ifndef UDISK_UDISK_JOURNAL_H
#define UDISK_UDISK_JOURNAL_H

#include "memtable.h"
#include "journal_writer.h"
#include "posix_file.h"
#include "jpc_storage.h"

namespace udisk {

namespace chunk {
class OpRequest;
}

namespace journal {

typedef std::unique_ptr<WriteableFile> WriteableFilePtr;
typedef std::unique_ptr<JournalWriter> JournalWriterPtr;

struct UDiskJournal {
  UDiskJournal(uint32_t pg_id_) : mem(new MemTable(pg_id_)), immu(nullptr), 
    rcmem(new MemTable(pg_id_)), rc_inact_num(0), rcref(0), compact_wfile(nullptr), 
    compact_writer(nullptr), last_seq((uint64_t)0), schedule_swap(false), 
    pg_id(pg_id_), memtable_cap(0), is_init(false) {
    mem->IncRef();
    rcmem->IncRef();
  }
  std::mutex mtx;
  MemTable* mem;
  MemTable* immu;
  MemTable* rcmem; // recover memtable, 仅用于chunk启动恢复时
  std::atomic<uint32_t> rc_inact_num; // recover的inactive_num个数，用于异常恢复处理
  uint32_t rcref; // recover 线程个数
  WriteableFilePtr compact_wfile;
  JournalWriterPtr compact_writer;
  JPCStorage* jpc_storage;
  std::atomic<uint64_t> last_seq;
  std::atomic<bool> schedule_swap;
  uint32_t pg_id;
  uint64_t memtable_cap; // 单个memtable的容量, Byte
  std::atomic<bool> is_init;
  std::vector<std::string> records; //chunk启动恢复时用暂存所有的records
  std::map<uint64_t, std::pair<chunk::IOMeta, const char*>> rc_immu_data_; //仅用于chunk启动恢复时,暂存从journal恢复的数据
  std::map<uint64_t, std::pair<chunk::IOMeta, const char*>> rc_mem_data_; // memtable data
};

// 这里每个pg内部的UDisk，只能在固定线程，无需加锁
struct MigrateUDiskInfo {
  MigrateUDiskInfo () : 
    lc_id(UINT32_MAX), lc_size(0), pc_size(0), peer_lc_id(UINT32_MAX),
    peer_random_id(UINT32_MAX), peer_pc_size(0), pg_id(UINT32_MAX), 
    peer_route(nullptr), tyr_ip(""), tyr_port(UINT32_MAX), active_id(UINT32_MAX),
    active_offset(UINT32_MAX), last_seqno(UINT64_MAX), status(kMigrateEof),
    pending_io(false), migrate_immu(nullptr) {
    ULOG_DEBUG << "pg_id=" << pg_id << ",lc_id=" << lc_id << " Migrate Create.";
  }

  MigrateUDiskInfo (const MigrateUDiskInfo& other) {
    lc_id = other.lc_id;
    lc_size = other.lc_size;
    pg_id = other.pg_id;
    tyr_ip = other.tyr_ip;
    tyr_port = other.tyr_port;
    last_seqno = other.last_seqno;
    compact_process = other.compact_process;
    memtable_process = other.memtable_process;
    migrate_immu = nullptr;
    peer_route = nullptr;
  }
  
  ~MigrateUDiskInfo() {
    ULOG_DEBUG << "pg_id=" << pg_id << ",lc_id=" << lc_id << " Migrate Release.";
    if (migrate_immu != nullptr) {
      migrate_immu->DecRef();
      migrate_immu = nullptr;
    }
  }

  uint32_t lc_id;
  uint32_t lc_size;
  uint32_t pc_size;
  uint32_t peer_lc_id;
  uint32_t peer_random_id;
  uint32_t peer_pc_size;
  uint32_t pg_id;
  std::shared_ptr<RouteManager> peer_route;
  std::string tyr_ip;
  uint32_t tyr_port;
  uint32_t active_id;
  uint32_t active_offset;
  uint64_t last_seqno;
  std::atomic<uint32_t> status; 
  bool pending_io;

  MemTable* migrate_immu;
  std::map<uint64_t, chunk::IOMeta> migrate_meta;
  std::unordered_map<uint64_t, std::pair<chunk::OpRequest*, chunk::IOMeta>> 
      migrate_inflight;
  std::shared_ptr<MemTableIterator> immu_iter;
  ExternalIOList migrate_ios; // 记录migrate_immu中单个node里的io
  std::unordered_map<uint64_t, std::pair<chunk::OpRequest*, ExternalIO>> 
      mem_inflight;

  JournalMigrateItemArray compact_process; 
  JournalMigrateItemArray memtable_process; 

  void InitMigratePc(uint32_t pc_no,
                     uint32_t offset,
                     uevent::ConnectorUeventPtr* ctor,
                     ucloud::udisk::MigratePcMeta* migrate_pc) {
    assert(offset <= pc_size);
    uint64_t lc_offset = (uint64_t)pc_no * pc_size + offset;
    uint32_t peer_pc_no = lc_offset / peer_pc_size;
    uint32_t peer_pc_offset = lc_offset % peer_pc_size;
    ULOG_DEBUG << "pc_no=" << pc_no << ",offset=" << offset << ",lc_offset=" 
        << lc_offset << ",peer_pc_no=" << peer_pc_no << ",peer_offset=" << peer_pc_offset;
    migrate_pc->set_lc_id(peer_lc_id);
    migrate_pc->set_lc_random_id(peer_random_id);
    migrate_pc->set_pc_no(peer_pc_no);
    migrate_pc->set_pc_offset(peer_pc_offset);
    uint64_t peer_version = UINT64_MAX;
    uint32_t peer_pg_id = UINT32_MAX;
    peer_route->GetChunkRoute(peer_lc_id, peer_random_id, peer_pc_no, 
                              &peer_version, &peer_pg_id, ctor);
    migrate_pc->set_route_version(peer_version);
    migrate_pc->set_pg_id(peer_pg_id);
  } 

  std::string ToString() const {
    std::ostringstream oss;
    oss << "lc_id=" << lc_id << ",pg_id=" << pg_id << ",lc_size=" << lc_size 
        << ",pc_size=" << pc_size << ",peer_pc_size=" << peer_pc_size << ",peer_lc=" 
        << peer_lc_id << ",last_seqno=" << last_seqno << ",tyr_ip=" << tyr_ip 
        << ",active_id=" << active_id << ",active_offset=" << active_offset 
        << ",status=" << status << ",pending_io=" << pending_io << ".compact_process:";
    for (auto item : compact_process) {
      oss << "[" << item.switch_times() << "," << item.migrate_ios() << "," 
        << item.migrate_bytes() << "],";
    }
    oss << "memtable_process:";
    for (auto item : memtable_process) {
      oss << "[" << item.switch_times() << "," << item.migrate_ios() << "," 
        << item.migrate_bytes() << "],";
    }
    return oss.str();
  }
};

struct MigrateTask {
  MigrateTask(uint32_t pg_id_, uint32_t cap) : pg_id(pg_id_), 
                                 mem(new MemTable(pg_id)), 
                                 memtable_cap(0),
                                 IsMigrate(false) {
    mem->IncRef();
    udisks.resize(cap, nullptr);
  }
  std::mutex mtx;
  uint32_t pg_id;
  MemTable* mem = nullptr; // guard by mtx 这里mem用于迁移memtable时记录迁移过程中的前台io
  std::vector<journal::MigrateUDiskInfo*> udisks; 
  std::map<uint32_t, journal::MigrateUDiskInfo*> udisk_map; // guard by mtx
  uint64_t memtable_cap;
  std::atomic<bool> IsMigrate;
};

}
}

#endif
