#include "mem_pool.h"
#include "udisk_types.h"
#include <malloc.h>
#include <ustevent/base/logging.h>

namespace udisk {
namespace journal {

MemPool::MemPool() {/*{{{*/
}/*}}}*/

MemPool::~MemPool() {/*{{{*/
  for(auto it = blocks_.begin(); it != blocks_.end(); it++) {
    free (*it);
    (*it) = nullptr;
  }

  for(auto it = align_blocks_.begin(); it != align_blocks_.end(); it++) {
    free(*it);
    (*it) = nullptr;
  }
  malloc_trim(0);
  ULOG_DEBUG << "destruct mem_pool";
}/*}}}*/

char* MemPool::Allocate(size_t bytes) {/*{{{*/
  ULOG_DEBUG << "allocate bytes:" << bytes
      << " avaliable_size:" << alloc_avaliable_size_
      << " mem_usage:" << mem_usage_;

  assert(bytes > 0);
  if (bytes > (kBlockSize / 4)) {
    return AllocateNewBlock(bytes);
  }

  if (bytes < alloc_avaliable_size_) {
    char* alloc_mem = alloc_ptr_;
    alloc_avaliable_size_ -= bytes;
    alloc_ptr_ += bytes;
    return alloc_mem;
  }

  alloc_ptr_ = AllocateNewBlock(kBlockSize);
  alloc_avaliable_size_ = kBlockSize;

  char* alloc_mem = alloc_ptr_;
  alloc_avaliable_size_ -= bytes;
  alloc_ptr_ += bytes;

  return alloc_mem;
}/*}}}*/

char* MemPool::AllocateIO(size_t bytes, bool& shared) {/*{{{*/
  ULOG_DEBUG << "allocate align bytes:" << bytes
      << " align_avaliable_size:" << align_alloc_avaliable_size_
      << " mem_usage:" << mem_usage_;
  assert(bytes > 0); 
  
  if ((bytes > (kBlockSize / 4)) 
      || mem_usage_ >kMaxUsage 
      || (bytes & (BLOCK_SIZE - 1))) {
    shared = false;
    return AllocateNewAlignBlock(bytes, shared);
  }

  shared = true;
  if (bytes < align_alloc_avaliable_size_) {
    char* alloc_mem = align_alloc_ptr_;
    align_alloc_avaliable_size_ -= bytes;
    align_alloc_ptr_ += bytes;
    return alloc_mem;
  }

  align_alloc_ptr_ = AllocateNewAlignBlock(kBlockSize, shared);
  align_alloc_avaliable_size_ = kBlockSize;

  char* alloc_mem = align_alloc_ptr_;
  align_alloc_avaliable_size_ -= bytes;
  align_alloc_ptr_ += bytes;

  return alloc_mem;
}/*}}}*/

char* MemPool::AllocateNewBlock(size_t bytes) {/*{{{*/
  ULOG_DEBUG << "allocate new block bytes:" << bytes;
  char* block = (char*)malloc(sizeof(char) * bytes);
  blocks_.push_back(block);
  mem_usage_ += bytes;

  return block;
}/*}}}*/

char* MemPool::AllocateNewAlignBlock(size_t bytes, bool shared) {/*{{{*/
  ULOG_DEBUG << "allocate new align block bytes:" << bytes;
  char* align_block = nullptr;
  posix_memalign((void**)&align_block, BLOCK_SIZE, bytes);
  if (shared == true) {
    blocks_.push_back(align_block);
    mem_usage_ += bytes;
  }

  return align_block;
}/*}}}*/

} //end of ns journal
} // end of ns udisk
