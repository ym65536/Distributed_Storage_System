#include "journal_meta.h"
#include <ustevent/base/logging.h>
#include "crc32c.h"
#include "raw_jpc_handle.h"
#include "raw_jpc_storage.h"
#include "file_jpc_handle.h"
#include "file_jpc_storage.h"
#include "udisk_journal.h"
#include "chunk_context.h"
#include "chunk_loop_handle.h"
#include "kernel_raw_device_manager.h"
#include "raw_chunk_pool.h"
#include "message.h"

using namespace udisk::journal;
using namespace udisk::chunk;
using namespace udisk;

const static uint32_t JOURNAL_VERSION = 1;

static inline void CheckCRC(const char* addr, uint32_t length, uint32_t expect) {
 uint32_t actual = common::CalCRC32C(addr, length);
  if (expect != actual) {
    ULOG_FATAL << "Check Crc fail, expect=" << expect << ", actual=" << actual;
  }
}

JournalMeta::JournalMeta() : super_handle_(nullptr), is_init_(false) {
}

JournalMeta::~JournalMeta() {
}

void JournalMeta::Init() {
  assert(is_init_ == false);
  int fd = -1;
  KernelRawDeviceManager* dev_manager = nullptr;
  // 获取super_handle_
  std::string storage_type = g_context->config().storage_type();
  if (storage_type == UDiskConfig::kStorageTypeMock) {
    ULOG_ERROR << "Mock init not implement";
    return;
  } else if (storage_type == UDiskConfig::kStorageTypeFile) {
    std::string journal_meta_path = g_context->config().chunk_dir() + "/journal/metadata";
    fd = open(journal_meta_path.c_str(), O_CREAT | O_RDWR, 0777);
    if (fd < 0) {
      ULOG_FATAL << "open metadata error";
    }
    super_handle_ = new FileJPCHandle(fd, 0);
    ULOG_DEBUG << "metadata path = " << journal_meta_path << " fd: " << fd;
  } else if (storage_type == UDiskConfig::kStorageTypeRaw) {
    auto chunk_pool = dynamic_cast<RawChunkPool*>(g_context->chunk_pool());
    dev_manager = dynamic_cast<KernelRawDeviceManager*>(chunk_pool->dev_manager());
    fd = dev_manager->fd();
    assert(fd > 0);
    chunk::JPCMeta* super_jpc;
    if (dev_manager->ReadSuperJPCMeta(&super_jpc) != 0) {
      ULOG_FATAL << "read super jpc meta error";
      return;
    }
    super_handle_ = new RawJPCHandle(fd, super_jpc->jpc_id, super_jpc->offset);
    ULOG_DEBUG << "super_jpc id=" << super_jpc->jpc_id << ", offset=" 
        << super_jpc->offset << ", dev fd=" << fd;
  } else {
    ULOG_FATAL << "unknown chunk storage type=" << storage_type;
  }

  // 读取super block数据
  uint32_t jpc_offset = 0;
  char* buffer = nullptr;
  uint32_t block_offset = 0;
  posix_memalign((void**)&buffer, BLOCK_SIZE, kBlockSize);
  assert(buffer);
  uint32_t ret = super_handle_->PRead(buffer, jpc_offset, kBlockSize, 
                                      nullptr, nullptr, nullptr);
  assert(ret == 0);
  journal_meta_ = reinterpret_cast<UDiskJournalMeta*>(buffer);
  ULOG_INFO << "Read journal_meta worker_num=" << journal_meta_->worker_num 
            << ", config thread_num=" << g_context->config().thread_num()
            << ", pg_num=" << journal_meta_->pg_num; 
  block_offset += BLOCK_SIZE;
  CheckCRC((const char*)journal_meta_ + sizeof(uint32_t), 
            sizeof(UDiskJournalMeta) - sizeof(uint32_t) + 
            journal_meta_->pg_num * sizeof(uint32_t), journal_meta_->crc);
  ULOG_DEBUG << "Read journal_meta succ. crc=" << journal_meta_->crc;

  // 构建jpc storage
  std::map<uint32_t, std::vector<JPCMeta*>> pg_jpcs;
  if (storage_type == UDiskConfig::kStorageTypeRaw) {
    if (dev_manager->ReadAllJPCMeta(&pg_jpcs, journal_meta_->pg_num) != 0) {
      ULOG_FATAL << "read all jpc meta error";
      return;
    }
  } else {
    // fs模式可以通过遍历目录文件获取pg_jpcs
  }
  std::vector<UDiskJournal*> udisk_journals(chunk::MAX_PG_NUM, nullptr);
  std::vector<MigrateTask*> migrate_task(chunk::MAX_PG_NUM, nullptr);
  uint64_t memtable_cap = ((uint64_t)g_context->config().memtable_cap() << 30) 
                          / (2 * journal_meta_->pg_num);
  ULOG_INFO << "single memtable capacity=" << memtable_cap;
  for (uint32_t i = 0; i < journal_meta_->pg_num; ++ i) {
    uint32_t pg_id = journal_meta_->pg_ids[i];
    ULOG_DEBUG << "metadata pg: " << pg_id;
    assert(udisk_journals[pg_id] == nullptr);
    udisk_journals[pg_id] = new UDiskJournal(pg_id);
    if (storage_type == UDiskConfig::kStorageTypeFile) {
      udisk_journals[pg_id]->jpc_storage = new FileJPCStorage(g_context->config().chunk_dir());
      udisk_journals[pg_id]->jpc_storage->Init(fd, pg_id);
    } else {
      assert(pg_jpcs.count(pg_id));
      udisk_journals[pg_id]->jpc_storage = new RawJPCStorage();
      udisk_journals[pg_id]->jpc_storage->Init(fd, pg_id, pg_jpcs[pg_id]);
      pg_jpcs.erase(pg_id);
    }
    udisk_journals[pg_id]->memtable_cap = memtable_cap;
    udisk_journals[pg_id]->mem->ReSize(memtable_cap);
    udisk_journals[pg_id]->rcmem->ReSize(memtable_cap);
    assert(migrate_task[pg_id] == nullptr);
    migrate_task[pg_id] = new MigrateTask(pg_id, g_context->config().max_udisk_num());
    migrate_task[pg_id]->memtable_cap = (memtable_cap << 1);
    migrate_task[pg_id]->mem->ReSize(migrate_task[pg_id]->memtable_cap);
  }  
  assert(pg_jpcs.empty());
  g_context->set_migrate_tasks(migrate_task);
  
  // 读取compact meta
  compact_meta_.resize(chunk::MAX_PG_NUM, nullptr);
  for (uint32_t i = 0; i < journal_meta_->pg_num; ++ i) {
    uint32_t pg_id = journal_meta_->pg_ids[i];
    compact_meta_[pg_id] = reinterpret_cast<PGCompactMeta*>(buffer + block_offset);
    block_offset += BLOCK_SIZE;
    CheckCRC((const char*)compact_meta_[pg_id] + sizeof(uint32_t), 
              sizeof(PGCompactMeta) - sizeof(uint32_t) , compact_meta_[pg_id]->crc); 
    ULOG_DEBUG << "pg_id=" << pg_id << " Read compact succ.";
  }

  // 构建每个pg的udisk_journal
  for (uint32_t i = 0; i < journal_meta_->pg_num; ++ i) {
    uint32_t pg_id = journal_meta_->pg_ids[i];
    PGCompactMeta* compact_meta = compact_meta_[pg_id];
    uint32_t active_jpc = compact_meta->zone[compact_meta->active_id].jpc_id;
    uint32_t last_seq = compact_meta->zone[compact_meta->active_id].end_seqno;
    JPCHandle* jpc_handle = 
        udisk_journals[pg_id]->jpc_storage->AcquireCompactJPC(active_jpc);
    ULOG_DEBUG << "pg_id=" << pg_id << ", compact active jpc=" << active_jpc;
    udisk_journals[pg_id]->compact_wfile.reset(
        new WriteableFile(jpc_handle, compact_meta_[pg_id]->active_offset));
    udisk_journals[pg_id]->compact_writer.reset(
        new JournalWriter(udisk_journals[pg_id]->compact_wfile.get()));
    udisk_journals[pg_id]->last_seq.store(last_seq);
    ULOG_DEBUG << "pg_id=" << pg_id << ",construct udisk_journal,compact_meta=" 
        << compact_meta->ToString();
  }
  g_context->set_udisk_journals(udisk_journals);

  // 读取每个线程的pg数据，根据配置文件和元数据中线程数关系区分处理
  // 线程数改变，更新meta中worker_num值
  uint32_t worker_num = g_context->config().thread_num();
  uint32_t meta_worker_num = journal_meta_->worker_num;
  if (worker_num != meta_worker_num) {
    ULOG_INFO << "worker num changed: old=" << meta_worker_num
              << ", new=" << worker_num;
    journal_meta_->worker_num = worker_num;
    journal_meta_->crc = udisk::common::CalCRC32C(buffer + sizeof(uint32_t), 
        sizeof(udisk::journal::UDiskJournalMeta) - sizeof(uint32_t) 
        + journal_meta_->pg_num * sizeof(uint32_t));
    
    uint32_t ret = super_handle_->PWrite(buffer, jpc_offset, BLOCK_SIZE,
                                         nullptr, nullptr, nullptr);
    assert(ret == 0); 
    ULOG_INFO << "update worker num success";
  }

  jpc_offset += kBlockSize;
  thread_journal_meta_.resize(MAX_PG_NUM);
  for (uint32_t i = 0; i < journal_meta_->pg_num; ++ i) {
    char* buffer = nullptr;
    uint32_t offset = 0;
    posix_memalign((void**)&buffer, BLOCK_SIZE, kBlockSize);
    assert(buffer);
    uint32_t ret = super_handle_->PRead(buffer, jpc_offset, kBlockSize, 
                                        nullptr, nullptr, nullptr);
    assert(ret == 0);
    uint32_t pg_id = journal_meta_->pg_ids[i];
    uint32_t thread_num = worker_num > meta_worker_num ? worker_num : meta_worker_num;
    thread_journal_meta_[pg_id].resize(thread_num, nullptr);
    for (uint32_t j = 0; j < thread_num; ++ j) {
      //线程增加，追加pg的线程数据
      if (j >= meta_worker_num) {
        ULOG_INFO << "worker num increased, add pg meta info";
        udisk::journal::PGJournalMeta* pgj_meta = new (buffer + offset) udisk::journal::PGJournalMeta();
        pgj_meta->pg_id = pg_id;
        pgj_meta->active_num = 0;
        pgj_meta->inactive_num = 0;
        pgj_meta->crc = udisk::common::CalCRC32C(buffer + offset + sizeof(uint32_t), 
            sizeof(udisk::journal::PGJournalMeta) - sizeof(uint32_t));
      }
      thread_journal_meta_[pg_id][j] = 
          reinterpret_cast<PGJournalMeta*>(buffer + offset);
      offset += BLOCK_SIZE;
      CheckCRC((const char*)thread_journal_meta_[pg_id][j] + sizeof(uint32_t), 
                sizeof(PGJournalMeta) - sizeof(uint32_t), 
                thread_journal_meta_[pg_id][j]->crc); 
      ULOG_DEBUG << "pg_id=" << pg_id << ",worker_id=" << j << ",thread_pg_info="
          << thread_journal_meta_[pg_id][j]->ToString();
    }
    //线程数增加，持久化pg数据
    if (worker_num > meta_worker_num) {
      ULOG_INFO << "worker num increased, update PGJournalMeta data";
      uint64_t length = BLOCK_SIZE * worker_num;
      uint32_t ret = super_handle_->PWrite(buffer, jpc_offset, length,
                                           nullptr, nullptr, nullptr);
      assert(ret == 0);
    }
    jpc_offset += kBlockSize;
  }

  // 更新storage中的free_list
  for (uint32_t i = 0; i < journal_meta_->pg_num; ++ i) {
    uint32_t pg_id = journal_meta_->pg_ids[i];
    for (uint32_t worker_id = 0; worker_id < meta_worker_num; ++ worker_id) {
      auto meta = thread_journal_meta_[pg_id][worker_id];
      UDiskJournal* udisk_journal = g_context->udisk_journal(pg_id);
      udisk_journal->jpc_storage->UpdateFreeJPC(meta->active_zone, 
                                                meta->active_num,
                                                meta->inactive_zone,
                                                meta->inactive_num);
    }
  }

  // 开始恢复每个线程对应的meta数据，线程数增加、减少区分处理
  // 线程数增加时，只需随机选线程恢复原线程的meta数据
  // 线程数据减少时，每个线程可能恢复多个meta数据
  auto all_loops = g_context->io_listener()->GetAllLoops();
  for (uint32_t worker_id = 0; worker_id < journal_meta_->worker_num; ++ worker_id) {
    if (worker_id >= meta_worker_num) {
      ULOG_INFO << "worker num increased, only recover old meta data";
      break;
    }
    auto loop = all_loops[worker_id % all_loops.size()];
    worker_ids_[loop->thread_id()] = worker_id;
    std::vector<PGJournalMeta*> metas;
    for (uint32_t i = 0; i < journal_meta_->pg_num; ++ i) {
      uint32_t pg_id = journal_meta_->pg_ids[i];
      metas.emplace_back(thread_journal_meta_[pg_id][worker_id]);
      if (worker_num < meta_worker_num && 
          worker_id == journal_meta_->worker_num - 1) {
        for (uint32_t j = journal_meta_->worker_num; j < meta_worker_num; ++j) {
          ULOG_INFO << "worker num decreased, recover more than 1 meta, workerid:" << j;
          uint32_t active_num = thread_journal_meta_[pg_id][worker_id]->active_num;
          ULOG_DEBUG << "old: " << thread_journal_meta_[pg_id][worker_id]->ToString();
          ULOG_DEBUG << "add: " << thread_journal_meta_[pg_id][j]->ToString();
          for (uint32_t idx = 0; idx < thread_journal_meta_[pg_id][j]->active_num; ++idx) {
            thread_journal_meta_[pg_id][worker_id]->active_zone[active_num + idx] = thread_journal_meta_[pg_id][j]->active_zone[idx];
          }
          thread_journal_meta_[pg_id][worker_id]->active_num += thread_journal_meta_[pg_id][j]->active_num;

          uint32_t inactive_num = thread_journal_meta_[pg_id][worker_id]->inactive_num;
          for (uint32_t idx = 0; idx < thread_journal_meta_[pg_id][j]->inactive_num; ++idx) {
            thread_journal_meta_[pg_id][worker_id]->inactive_zone[inactive_num + idx] = thread_journal_meta_[pg_id][j]->inactive_zone[idx];
          }
          thread_journal_meta_[pg_id][worker_id]->inactive_num += thread_journal_meta_[pg_id][j]->inactive_num;

          ULOG_DEBUG << "new: " << thread_journal_meta_[pg_id][worker_id]->ToString();
        }
      }
    }
    loop->RunInLoop(std::bind(&ChunkLoopHandle::JournalRecover, 
                        dynamic_cast<ChunkLoopHandle*>(loop->GetLoopHandle()), 
                        metas));
  }
  is_init_ = true;
}

void JournalMeta::AppendActiveJPC(uint32_t pg_id, 
                                  pid_t thread_id,
                                  uint32_t jpc_id,
                                  uevent::DiskIOCb done, 
                                  JournalAioArgs* journal_args) {
  assert(worker_ids_.count(thread_id));
  uint32_t worker_id = worker_ids_[thread_id];
  PGJournalMeta* meta = thread_journal_meta_[pg_id][worker_id];
  meta->active_zone[meta->active_num] = jpc_id;
  ++ meta->active_num;
  assert(meta->active_num <= kPGMaxJPCNumber);
  meta->crc = common::CalCRC32C((const char*)meta + sizeof(uint32_t), 
                                  sizeof(PGJournalMeta) - sizeof (uint32_t));
  uint64_t jpc_offset = kBlockSize;
  for (uint32_t i = 0; i < journal_meta_->pg_num; ++ i) {
    if (pg_id == journal_meta_->pg_ids[i]) {
      break;
    }
    jpc_offset += kBlockSize;
  }
  uint32_t block_offset = worker_id * BLOCK_SIZE; 
  ULOG_DEBUG << "pg_id=" << pg_id << ", worker_id=" << worker_id 
    << ", Now crc=" << meta->crc << ",thread_pg_info=" << meta->ToString();
  uint32_t ret = super_handle_->PWrite(meta, jpc_offset + block_offset, 
                                       BLOCK_SIZE, done, 
                                       journal_args, journal_args->loop);
  assert(ret == 0);
}

void JournalMeta::SwapMemTable(uint32_t pg_id, 
                               const std::map<pid_t, uint32_t>& jpc_ids,
                               uevent::DiskIOCb done, 
                               JournalAioArgs* journal_args) {
  assert(jpc_ids.size() == worker_ids_.size());
  auto jit = jpc_ids.begin();
  auto wit = worker_ids_.begin();
  for ( ; jit != jpc_ids.end(); ++ jit, ++ wit) {
    assert(jit->first == wit->first);
  }
  uint32_t worker_id = 0;
  auto iter = jpc_ids.begin();
  for (auto& meta : thread_journal_meta_[pg_id]) {
    ULOG_DEBUG << "pg_id=" << pg_id << ", worker_id=" << worker_id 
      << ", swap before crc=" << meta->crc << ",thread_pg_info=" << meta->ToString();
    assert(meta->inactive_num == 0 && meta->active_num > 0 && 
           meta->active_num <= kPGMaxJPCNumber);
    meta->inactive_num = meta->active_num;
    memcpy(meta->inactive_zone, meta->active_zone, sizeof(uint32_t) * kPGMaxJPCNumber);
    memset(meta->active_zone, 0, sizeof(uint32_t) * kPGMaxJPCNumber);
    meta->active_num = 1;
    meta->active_zone[meta->active_num - 1] = iter->second;
    meta->crc = common::CalCRC32C((const char*)meta + sizeof(uint32_t), 
                                  sizeof(PGJournalMeta) - sizeof (uint32_t));
    ULOG_DEBUG << "pg_id=" << pg_id << ", worker_id=" << worker_id 
      << ", swap after crc=" << meta->crc << ",thread_pg_info=" << meta->ToString();
    ++ worker_id;
    ++ iter;
  }
  uint64_t jpc_offset = kBlockSize;
  for (uint32_t pg_index = 0; pg_index < journal_meta_->pg_num; ++ pg_index) {
    if (pg_id == journal_meta_->pg_ids[pg_index]) {
      break;
    }
    jpc_offset += kBlockSize;
  }
  uint32_t ret = super_handle_->PWrite(thread_journal_meta_[pg_id][0], jpc_offset, 
                                BLOCK_SIZE * thread_journal_meta_[pg_id].size(),
                                done, journal_args, journal_args->loop);
  assert(ret == UDISK_OK);
}

void JournalMeta::UMImmuCompactFinish(uint32_t pg_id, 
                                      PGCompactMeta* compact_meta,
                                      uevent::DiskIOCb done, 
                                      JournalAioArgs* journal_args) {
  {
    std::lock_guard<std::mutex> lock(mtx_);
    assert(pg_id < compact_meta_.size() && compact_meta_[pg_id]);
    compact_meta->crc = common::CalCRC32C(
        (const char*)compact_meta + sizeof(uint32_t), 
        sizeof(PGCompactMeta) - sizeof (uint32_t));
    memcpy(compact_meta_[pg_id], compact_meta, sizeof (PGCompactMeta));
    CheckCRC((const char*)compact_meta_[pg_id] + sizeof(uint32_t), 
            sizeof(PGCompactMeta) - sizeof(uint32_t), 
            compact_meta_[pg_id]->crc); 
    delete compact_meta;
  }
  uint32_t pg_index = 0;
  for (; pg_index < journal_meta_->pg_num; ++ pg_index) {
    if (pg_id == journal_meta_->pg_ids[pg_index]) {
      break;
    }
  }
  assert(pg_index < MAX_PG_NUM);
  // 1.更新compact meta: 相关的更新已经在journal engine里完成，这里直接更新即可
  uint32_t ret = super_handle_->PWrite((const char*)compact_meta_[pg_id], 
                                       BLOCK_SIZE + BLOCK_SIZE * pg_index, 
                                       BLOCK_SIZE, 
                                       done, journal_args, journal_args->loop);
  assert(ret == UDISK_OK);
}

void JournalMeta::UMImmuCompactReset(uint32_t pg_id, 
                                     bool jpc_reset,
                                     uevent::DiskIOCb done, 
                                     JournalAioArgs* journal_args) {
  uint32_t pg_index = 0;
  for (; pg_index < journal_meta_->pg_num; ++ pg_index) {
    if (pg_id == journal_meta_->pg_ids[pg_index]) {
      break;
    }
  }
  assert(pg_index < MAX_PG_NUM);
  std::vector<uint32_t> jpc_ids; 
  for (auto& meta : thread_journal_meta_[pg_id]) {
    for (uint32_t j = 0; j < meta->inactive_num; ++ j) {
      jpc_ids.push_back(meta->inactive_zone[j]);
      meta->inactive_zone[j] = 0;
    }
    meta->inactive_num = 0;
    assert(meta->active_num <= kPGMaxJPCNumber);
    meta->crc = common::CalCRC32C((const char*)meta + sizeof(uint32_t), 
                                  sizeof(PGJournalMeta) - sizeof (uint32_t));
  }

  // 2. inactive jpc reset
  if (jpc_reset) {
    UDiskJournal* udisk_journal = g_context->udisk_journal(pg_id);
    {
      std::lock_guard<std::mutex> lock(udisk_journal->mtx);
      ULOG_DEBUG << "pg_id=" << pg_id << " release jpc_size=" << jpc_ids.size();
      udisk_journal->jpc_storage->ReleaseJPC(jpc_ids);
    }
  }

  // 3.更新每个线程内部/inactive
  auto ret = super_handle_->PWrite(thread_journal_meta_[pg_id][0], 
                              pg_index * kBlockSize + kBlockSize, 
                              BLOCK_SIZE * thread_journal_meta_[pg_id].size(),
                              done, journal_args, journal_args->loop);
  assert(ret == 0);
}

PGCompactMeta JournalMeta::GetCompactMeta(uint32_t pg_id) {
  std::lock_guard<std::mutex> lock(mtx_);
  assert(pg_id < compact_meta_.size() && compact_meta_[pg_id]);
  PGCompactMeta meta;
  // PGCompactMeta纯struct, 值拷贝即可
  memcpy(&meta, compact_meta_[pg_id], sizeof (PGCompactMeta)); 
  CheckCRC((const char*)&meta + sizeof(uint32_t), 
            sizeof(PGCompactMeta) - sizeof(uint32_t), 
            meta.crc); 
  return meta;
}

PGCompactMeta* JournalMeta::MutableCompactMeta(uint32_t pg_id) {
  std::lock_guard<std::mutex> lock(mtx_);
  assert(pg_id < compact_meta_.size() && compact_meta_[pg_id]);
  PGCompactMeta* meta = new PGCompactMeta();
  // PGCompactMeta纯struct, 值拷贝即可
  memcpy(meta,  compact_meta_[pg_id], sizeof (PGCompactMeta)); 
  CheckCRC((const char*)meta + sizeof(uint32_t), 
            sizeof(PGCompactMeta) - sizeof(uint32_t), 
            meta->crc); 
  return meta;
}

