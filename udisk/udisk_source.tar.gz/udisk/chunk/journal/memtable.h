#ifndef UDISK_JOURNAL_MEMTABLE_H_
#define UDISK_JOURNAL_MEMTABLE_H_

#include <stdint.h>
#include <vector>
#include <stddef.h>
#include <mutex>
#include <unordered_map>
#include "mem_pool.h"
#include "skiplist.h"

namespace udisk {
namespace journal {

class MemTableIterator {
 public:
  explicit MemTableIterator(std::list<Skiplist*>& skip_list) : skips_(skip_list) {
    skip_iter_ = skips_.begin();
    if (skip_iter_ != skips_.end()) {
      node_iter_ = new Skiplist::Iterator(*skip_iter_);
    }
  }

  ~MemTableIterator() {
    if (node_iter_ != nullptr) {
      delete node_iter_;
    }
  }

  bool Valid() {
    if (node_iter_ == nullptr) {
      return false;
    }
    return node_iter_->Valid();
  }

  void Next() {
    node_iter_->Next();
    if (node_iter_->Valid() == false) {
      ++ skip_iter_;
      if (skip_iter_ != skips_.end()) {
        delete node_iter_;
        node_iter_ = new Skiplist::Iterator(*skip_iter_);
      }
    } 
  }

  void Value(ExternalIOList* external_ios) {
    node_iter_->Value(external_ios);
  }

  void Shrink() {
    node_iter_->Shrink();
  }

 private:
  Skiplist::Iterator* node_iter_ = nullptr;
  std::list<Skiplist*>::iterator skip_iter_;
  std::list<Skiplist*>& skips_;
};

class MemTable {
 public:
  explicit MemTable(uint32_t pg_id, uint64_t cap = 0);
  ~MemTable();

  bool Get(const chunk::IOMeta& meta, 
           std::vector<chunk::Interval>* intervals, 
           char* buf);

  void Put(const chunk::IOMeta& meta, 
           const char* buf, 
           uint64_t seq_no);

  //非线程安全
  bool Empty() const {
    for (auto it = lc_list_.begin(); it != lc_list_.end(); ++ it) {
      if (!((*it)->Empty())) {
        return false;
      }
    }
    return true;
  }

  // 非线程安全, 合并每个Node中的连续数据
  void Shrink();

  std::shared_ptr<MemTableIterator> NewIterator();

  // MergeFrom 和 CopyFrom 区别: merge可以seqno乱序
  void MergeFrom(MemTable* mem, uint32_t lc_id = UINT32_MAX);

  void CopyFrom(MemTable* mem, uint32_t lc_id);
    
  // splice直接skiplist转移
  void SpliceFrom(MemTable* mem, uint32_t lc_id);
  std::pair<Skiplist*, uint64_t> SpliceTo(uint32_t lc_id);

  // Increase reference count.
  void IncRef();

  // Drop reference count.  Delete if no more references exist.
  void DecRef();

  uint64_t MaxSeq() const {
    return max_seq_;
  }

  uint64_t MinSeq() const {
    return min_seq_;
  }

  bool IsFull(uint64_t space) const {
    ULOG_DEBUG << "mem_usage_=" << mem_usage_ << ", mem_cap=" << mem_cap_
        << ", need_space=" << space;
    return (mem_usage_ + space) > mem_cap_;
  }

  uint64_t Usage() const {
    return mem_usage_;
  }

  uint64_t Capacity() const {
    return mem_cap_;
  }

  void ReSize(uint64_t cap) {
    mem_cap_ = cap;
  }

  inline uint64_t GetID() const {
    return id_;
  }

  std::string ToString() const {
    std::ostringstream oss;
    oss << "Mem id=" << id_ << ",ref=" << refs_ << ",seq=[" << min_seq_ << "," 
        << max_seq_ << ",pg_id=" << pg_id_ << ",mem_usage=" << mem_usage_ << ","
        << "mem_cap=" << mem_cap_ << ".udisk_size=" << lc_list_.size();
    return oss.str();
  }

 private:
  uint64_t id_;
  std::list<Skiplist*> lc_list_;
  std::vector<Skiplist*> lc_map_;
  std::vector<uint64_t> lc_mem_usage_;
  uint32_t refs_;
  std::mutex mutex_;
  uint64_t max_seq_ = 0;
  uint64_t min_seq_ = UINT64_MAX;
  uint32_t pg_id_;
  uint64_t mem_usage_;
  uint64_t mem_cap_;
};

}; // end of ns journal
}; // end of ns udisk

#endif
