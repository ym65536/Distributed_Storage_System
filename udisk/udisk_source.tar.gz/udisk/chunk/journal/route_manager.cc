#include <ustevent/base/logging.h>
#include <ustevent/libevent/listener_libevent.h>
#include "route_manager.h"
#include "udisk_types.h"
#include "chunk_loop_handle.h"

using namespace ucloud::udisk;
using namespace udisk::journal;
using namespace udisk::chunk;
using namespace google::protobuf;

RouteManager::RouteManager(ChunkLoopHandle* handle, 
                           uint32_t lc_size, 
                           uint32_t pc_size): 
    handle_(handle), is_ready_(false), lc_size_(lc_size), pc_size_(pc_size), 
    chunk_route_cache_((lc_size << 10) / (pc_size >> 20)) {
  ULOG_DEBUG << "route manager construct, lc_size=" << lc_size << ",pc_size=" 
      << pc_size << ",catch size=" << chunk_route_cache_.size();
}

RouteManager::~RouteManager() { 
  ULOG_DEBUG << "route manager destruct,lc_size=" << lc_size_ << ",pc_size=" 
      << pc_size_; 
}

void RouteManager::UpdateClusterMap(const ClusterInfoPb& cluster_info,
                            const RepeatedPtrField<ChunkInfoPb>& chunk_info,
                            const RepeatedPtrField<PGInfoPb>& pg_info) {
  // 如果集群信息已经初始化，而且版本号相同,直接返回
  if (cluster_map_.IsInit() &&
      cluster_map_.GetClusterVersion() == cluster_info.version()) {
    return;
  }
  uint64_t old_version = 0;  // 没有初始化，上次的version显示为0
  if (cluster_map_.IsInit()) {
    old_version = cluster_map_.GetClusterVersion();
  }
  ULOG_INFO << "route version changed, old: " << old_version
            << " new: " << cluster_info.version();
  cluster_map_.Init(cluster_info);
  for (auto i = chunk_info.begin(); i != chunk_info.end(); ++i) {
    cluster_map_.ChunkAdd(*i);
  }
  for (auto i = pg_info.begin(); i != pg_info.end(); ++i) {
    cluster_map_.PGAdd(*i);
  }
  if (!is_ready_) {
    // 构建哈希环，可能比较费时, 由于不变只构建一次
    is_ready_ = true;
    hash_ring_.Init(cluster_map_);
  }
}

void RouteManager::GetChunkRoute(uint32_t lc_id, 
                                 uint32_t lc_random_id, 
                                 uint32_t pc_no,
                                 uint64_t* version,
                                 uint32_t* pg_id, 
                                 uevent::ConnectorUeventPtr* ctor) {
  // 只有在route ready 才会调用这个函数
  ULOG_TRACE << "GetRouter:lc_id=" << lc_id << ",pc_no=" << pc_no;
  assert(is_ready_ == true);
  //如果cache中存在路由, 且与集群版本号相同直接返回
  *version = cluster_map_.GetClusterVersion();
  if (chunk_route_cache_[pc_no].version == *version &&
      chunk_route_cache_[pc_no].ctor != nullptr) {
    *pg_id = chunk_route_cache_[pc_no].pg_id;
    *ctor = chunk_route_cache_[pc_no].ctor;
    ULOG_TRACE << "GetRouter:peer_pg_id=" << *pg_id;
    return;
  }
  //查找hash环获取路由，并且保存在cache中
  *pg_id = hash_ring_.GetPGId(lc_id, pc_no, lc_random_id);
  ucloud::udisk::ChunkInfoPb* chunk_info_ptr;
  bool ret = cluster_map_.GetPrimaryChunkInfoPtr(*pg_id, &chunk_info_ptr);
  assert(ret == true);
  (void)ret;
  uevent::UsockAddress chunk_addr(chunk_info_ptr->ip(),
                                  chunk_info_ptr->io_port());
  *ctor = handle_->get_out_connector(chunk_addr);
  chunk_route_cache_[pc_no].version = *version;
  chunk_route_cache_[pc_no].pg_id = *pg_id;
  chunk_route_cache_[pc_no].ctor = *ctor;
  ULOG_TRACE << "GetRouter:peer_pg_id=" << pg_id;
}

