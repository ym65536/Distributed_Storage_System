#include "write_batch.h"
#include <string.h>
#include "journal_format.h"
#include "memtable.h"

using namespace udisk::journal;
using namespace udisk::chunk;

WriteBatch::WriteBatch() {
  rep_.resize(kBatchHeader);
}

WriteBatch::~WriteBatch() {
}

void WriteBatch::Put(const IOMeta& meta, const char* buf, uint64_t seqno) {
  SetCount(1);
  rep_.append((const char*)&seqno, sizeof (seqno));
  rep_.append((const char*)&meta, sizeof (meta));
  rep_.append(buf, meta.length);
}

void WriteBatch::SetCount(uint32_t result) {
  memcpy(&rep_[0], &result, sizeof (result));
}

uint32_t WriteBatch::Count() const {
  uint32_t result;
  memcpy(&result, &rep_[0], sizeof (result));
  return result;
}

void WriteBatch::Append(const WriteBatch* batch) {
  uint32_t result = Count() + batch->Count();
  SetCount(result);
  const std::string& content = batch->Content();
  rep_.append(content.data() + kBatchHeader, content.size() - kBatchHeader);
}

const std::string& WriteBatch::Content() const {
  return rep_;
}

void WriteBatch::SetContent(std::string& record) {
  rep_.swap(record);
}

void WriteBatch::Iterator(MemTable* mem, 
                          uint64_t* last_sequence, 
                          uint32_t lc_id) {
  uint32_t pos = kBatchHeader; // skip count
  uint64_t sequence = 0;
  IOMeta meta;
  const char* buffer = nullptr;
  while (pos < rep_.size()) {
    // parse sequence
    memcpy(&sequence, &rep_[pos], sizeof (sequence));
    if ((last_sequence != nullptr) && (*last_sequence < sequence)) {
      *last_sequence = sequence;
    }
    pos += sizeof (sequence);
    //parse k-v
    memcpy(&meta, &rep_[pos], sizeof(meta));
    pos += sizeof (meta);
    buffer = &rep_[pos];
    if (lc_id == meta.lc_id || lc_id == UINT32_MAX) {
      mem->Put(meta, buffer, sequence);
      ULOG_DEBUG << "write memtable meta=" << meta.ToString() << ", data=" 
          << values_string(buffer, meta.length);
    }
    pos += meta.length;
  }
}

void WriteBatch::Slim(InternalBatch* slim) {
  uint32_t pos = kBatchHeader; // skip count
  IOMeta meta;
  uint64_t sequence = 0;
  while (pos < rep_.size()) {
    // parse sequence
    memcpy(&sequence, &rep_[pos], sizeof (sequence));
    pos += sizeof (sequence);
    //parse k-v
    memcpy(&meta, &rep_[pos], sizeof(meta));
    slim->Append(sequence, meta);
    pos += sizeof (meta);
    pos += meta.length;
  }
}

void InternalBatch::ParseContent(const std::string& record, 
                                 std::map<uint64_t, chunk::IOMeta>* migrate_meta,
                                 uint32_t lc_id,
                                 uint64_t seqno) {
  assert(record.size() % (sizeof(uint64_t) + sizeof(chunk::IOMeta)) == 0);
  uint32_t pos = 0; // skip count
  IOMeta meta;
  uint64_t sequence = 0;
  while (pos < record.size()) {
    // parse sequence
    memcpy(&sequence, &record[pos], sizeof (sequence));
    pos += sizeof (sequence);
    //parse k-v
    memcpy(&meta, &record[pos], sizeof(meta));
    pos += sizeof (meta);
    ULOG_TRACE << "Parse lc_id=" << lc_id << ", req_seq=" << seqno 
        << ", now_seq=" << sequence << ", meta=" << meta.ToString();
    if (lc_id == UINT32_MAX || lc_id == meta.lc_id) {
      if (sequence >= seqno) {
        migrate_meta->insert(std::make_pair(sequence, meta));
      }
    }
  }
}

void InternalBatch::Append(uint64_t seqno, const chunk::IOMeta& meta) {
  if (batch_blocks_.back()->rep.size() + sizeof(seqno) + sizeof (meta) > 
      kBlockSize) {
    InternalBatchDataPtr batch_data(new InternalBatchData);
    batch_blocks_.push_back(std::move(batch_data));
  }
  auto& last_block = batch_blocks_.back();
  last_block->rep.append((const char*)&seqno, sizeof (seqno));
  last_block->rep.append((const char*)&meta, sizeof (meta));
  last_block->min_seq = std::min(seqno, last_block->min_seq);
  last_block->max_seq = std::max(seqno, last_block->max_seq);
  ULOG_TRACE << "Append: block_size=" << batch_blocks_.size() << ", seqno=" 
      << seqno << ", meta=" << meta.ToString() << ", min_seq=" 
      << last_block->min_seq << ", max_seq=" << last_block->max_seq;
}

InternalBatchData* InternalBatch::SequentialRead() {
  ULOG_TRACE << "Read before: cursor_=" << cursor_;
  if (batch_blocks_.size() <= cursor_) {
    return nullptr;
  }
  InternalBatchData* batch_data = batch_blocks_[cursor_].get();
  cursor_ += 1;
  ULOG_TRACE << "Read after: cursor_=" << cursor_ << ", block_size=" 
      << batch_blocks_.size() << ", min_seq=" << batch_data->min_seq
      << ", max_seq=" << batch_data->max_seq;
  return batch_data;
}


