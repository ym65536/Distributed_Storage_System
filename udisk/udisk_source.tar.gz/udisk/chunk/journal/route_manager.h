#ifndef UDISK_JOURNAL_ROUTE_MANAGER_H_
#define UDISK_JOURNAL_ROUTE_MANAGER_H_

#include <vector>
#include <map>
#include <string>
#include <memory>
#include <ustevent/callbacks.h>
#include "udisk_message.h"
#include "cluster_map.h"
#include "cluster_hash_ring.h"

namespace udisk {
namespace chunk {
class ChunkLoopHandle;
}
}

namespace uevent {
  class EventLoop;
}

namespace udisk {
namespace journal {

class RouteManager {
 public:
  struct ChunkRouteEntry {
    ChunkRouteEntry() : version(0) {}
    uint64_t version;
    uint32_t pg_id;
    uevent::ConnectorUeventPtr ctor;
  };
  RouteManager(chunk::ChunkLoopHandle* handle, 
               uint32_t lc_size, 
               uint32_t pc_size);
  ~RouteManager();

  void UpdateClusterMap(
      const ucloud::udisk::ClusterInfoPb& cluster_info,
      const ::google::protobuf::RepeatedPtrField<::ucloud::udisk::ChunkInfoPb>& chunk_info,
      const ::google::protobuf::RepeatedPtrField<::ucloud::udisk::PGInfoPb>& pg_info);

  void GetChunkRoute(uint32_t lc_id, 
                     uint32_t lc_random_id,
                     uint32_t pc_no, 
                     uint64_t* version, 
                     uint32_t* pg_id, 
                     uevent::ConnectorUeventPtr* ctor);
  
  void inline ResetHandle(chunk::ChunkLoopHandle* handle) {
    if (handle == handle_) {
      return;
    }
    ULOG_DEBUG << "route reset,old handle=" << handle_ << ",new handle=" << handle;
    handle_ = handle;
    chunk_route_cache_.clear();
    chunk_route_cache_.resize((lc_size_ << 10) / (pc_size_ >> 20));
  }

 private:
  chunk::ChunkLoopHandle* handle_;
  bool is_ready_;
  uint32_t lc_size_;
  uint32_t pc_size_;
  std::vector<ChunkRouteEntry> chunk_route_cache_;
  cluster::ClusterMap cluster_map_;
  cluster::ClusterHashRing hash_ring_;
};

}  // namespace journal
}  // namespace udisk

#endif
