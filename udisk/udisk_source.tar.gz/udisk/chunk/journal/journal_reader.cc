#include "journal_reader.h"
#include "posix_file.h"
#include <ustevent/base/logging.h>
#include "crc32c.h"
#include "chunk_context.h"

using namespace udisk::journal;
using namespace udisk::common;
using namespace udisk::chunk;

JournalReader::JournalReader(ReadableFile* rfile) :
    journal_file_(rfile) {
  posix_memalign((void**)&buffer_, BLOCK_SIZE, kBlockSize);
}

JournalReader::~JournalReader() {
  free(buffer_);
}

int32_t JournalReader::ReadRecord(std::string* record) {
  int32_t ret = UDISK_OK;
  while (true) {
    uint32_t record_type = kZeroType;
    std::string fragment;
    ret = ReadPhysicalRecord(&fragment, &record_type);
    if (ret != UDISK_OK) {
      ULOG_WARN << "ReadPhysicalRecord finish. retcode=" << ret;
      return ret;
    }
    switch (record_type) {
      case kFullType:
        record->swap(fragment);
        return ret;
      case kFirstType:
        record->swap(fragment);
        break;
      case kMiddleType:
        record->append(fragment);
        break;
      case kLastType:
        record->append(fragment);
        return ret;
      default:
        ULOG_ERROR << "error record type=" << record_type << ", ret=" << ret;
        return ret;
    }
  }
  return ret;
}

int32_t JournalReader::ReadPhysicalRecord(std::string* fragment, 
    uint32_t* record_type) {
  uint32_t ret = 0;

  int32_t avail_space = kBlockSize - block_offset_ - kHeaderSize - kPaddingSize;
  if (avail_space < 0) { // switch to new block
    ret = journal_file_->SequentialRead(buffer_, kBlockSize);
    block_offset_ = 0;
    readable_offset_ += kBlockSize;
    avail_space = kBlockSize - block_offset_ - kHeaderSize - kPaddingSize;
    assert(readable_offset_ <= journal_file_->Size());
    assert(ret == kBlockSize);
  }

  // Parse Header
  char* header = &buffer_[block_offset_];
  if (memcmp(header, kEnding, kEndingSize) == 0) { // must be end.
    ULOG_WARN << "Reached End of File!";
    return kEOF;
  }
  const uint32_t a = static_cast<uint32_t>((uint8_t)header[4]);
  const uint32_t b = static_cast<uint32_t>((uint8_t)header[5]);
  const uint32_t c = static_cast<uint32_t>((uint8_t)header[6]);
  *record_type = static_cast<uint32_t>((uint8_t)header[7]);
  uint32_t length = ((c << 16) | (b << 8) | a);
  uint32_t expect_crc = 0;
  memcpy(&expect_crc, header, 4);
  uint32_t actual_crc = 0;
  if (g_context->config().crc_enable()) {
    actual_crc = CalCRC32C(header + 7, 1 + std::min(length, (uint32_t)avail_space));
  }
  ULOG_TRACE << "Read crc=" << expect_crc << ", acutal_crc=" << actual_crc 
    << ", length=" << length << ", type=" << *record_type << ", avail_space=" << avail_space;
  if (expect_crc != actual_crc) {
    const char* rep = header + kHeaderSize;
    uint32_t pos = 0;
    uint64_t sequence = 0;
    IOMeta meta;
    memcpy(&sequence, &rep[pos], sizeof (sequence));
    pos += sizeof (sequence);
    //parse k-v
    memcpy(&meta, &rep[pos], sizeof(meta));
    pos += sizeof (meta);
    const char* data = &rep[pos];
    ULOG_FATAL << "CRC Check fail, expect=" << expect_crc << ", actual=" 
        << actual_crc << ", length=" << length << ", type=" << *record_type
        << ", seqno=" << sequence << ", meta=" << meta.ToString() 
        << ", data=" << values_string(data, std::min((int)meta.length, 4096), true) << "\n";
    return kCRC;
  }
  
  fragment->append(header + kHeaderSize, length);
  ret = memcmp(header + kHeaderSize + length, kPadding, kPaddingSize);
  assert(ret == 0);
  block_offset_ += kHeaderSize + length + kPaddingSize;

  return UDISK_OK;
}

uint64_t JournalReader::SeekOffset() const {
  assert(readable_offset_ <= journal_file_->Size());
  uint64_t seek_offset = 0;
  if (INVALID_BLOCK_OFFSET == block_offset_) { // 没有开始读取
    assert(readable_offset_ == 0);
    seek_offset = 0;
  } else {
    assert(readable_offset_ >= kBlockSize);
    seek_offset = (readable_offset_ - kBlockSize) + block_offset_;
  }
  ULOG_DEBUG << "Readable offset=" << readable_offset_ << ", block_offset=" 
    << block_offset_ << ", seek_offset=" << seek_offset;
  return seek_offset;
}
