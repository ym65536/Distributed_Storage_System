#ifndef UDISK_JOURNAL_ENGINE_H
#define UDISK_JOURNAL_ENGINE_H

#include <set>
#include <deque>
#include <vector>
#include <memory>
#include <string>
#include <atomic>
#include <unordered_map>
#include <mutex>
#include <ustevent/base/timestamp.h>
#include <ustevent/pb_request_handle.h>
#include <ucloud.pb.h>
#include "manager_handle.h"
#include "manual_compact.h"
#include "migrate_task_finish.h"
#include "migrate_journal.h"
#include "prepare_migrate.h"
#include "udisk_message.h"
#include "journal_format.h"
#include "journal_meta.h"
#include "jpc_handle.h"
#include "jpc_storage.h"
#include "write_batch.h"
#include "udisk_journal.h"

namespace udisk {
namespace chunk {
class ChunkLoopHandle;
class ChunkHandle;
class OpRequest;
}
}

namespace udisk {
namespace journal {
enum MemtablType
{
  kImmutable = 0,
  kMemtable = 1,
};

class WriteBatch;
class MemTableIterator;
class InternalBatch;
class MemTable;

// Information kept for every waiting writer
struct Writer {
  int32_t retcode;
  WriteBatchPtr batch;
  bool done;
  std::condition_variable cond;
  uint64_t seqno;
  chunk::IOMeta meta;
  uevent::EventLoop* loop; 
  chunk::OpRequest* op;
  uint64_t mem_id;
  uint32_t jpc_id;

  Writer() : retcode(0),
             batch(nullptr),
             done(false), 
             seqno(0),
             loop(nullptr),
             op(nullptr),
             mem_id(0),
             jpc_id(UINT32_MAX) { 
  }

  ~Writer() {
    if (batch) {
      delete batch;
    }
  }
};

typedef Writer* WriterPtr;

class JournalEngine {
 public:
  JournalEngine(chunk::ChunkLoopHandle* handle, uint32_t pg_id); 
  ~JournalEngine();

  void EntryRecover(const PGJournalMeta* meta);
  int32_t Write(const chunk::IOMeta& meta, 
                const char* buf, 
                uint64_t seqno,
                chunk::OpRequest* op);
  int32_t Read(const chunk::IOMeta& meta, 
               char* buf, 
               std::vector<chunk::Interval>* intervals);

  bool IsInit();

  void ClearJournalOpRequest(int64_t conn_id);

  void TimerCb();

  chunk::ChunkLoopHandle* GetHandle() {
    return handle_;
  }

  void SwapMemTableReq(uevent::EventLoop* src_loop);
  void SwapMemTableRes(uevent::EventLoop* loop, uint32_t jpc_id); 

  // 迁移相关:
  bool InMigrate(uint32_t lc_id);
  bool EntryMigrateTaskFinish(udisk::chunk::MigrateTaskFinishHandlePtr handle_ptr, 
                              uint32_t lc_id, bool force);
  bool CheckDualWrite(uint32_t lc_id, 
                      uint32_t pc_no,
                      uint32_t offset, 
                      ucloud::udisk::MigratePcMeta* migrate_pc,
                      uevent::ConnectorUeventPtr* peer_ctor);
  uint64_t MigrateSeqno();
  void SetPendingIO(uint32_t lc_id, bool enable);
  void SetPendingIO(MigrateUDiskInfo* udisk, bool enable);
  bool CheckPendingIO(uint32_t lc_id);
  bool CheckPendingIO(MigrateUDiskInfo* udisk);
  void DoPrepareMigrateTask(udisk::chunk::PrepareMigrateHandlePtr handle_ptr,
                            const ucloud::udisk::TyrPrepareMigrateRequest& req);
  void DoMigrateJournalTask(udisk::chunk::MigrateJournalHandlePtr handle_ptr,
                            const ucloud::udisk::TyrMigrateJournalRequest& req);
  void DoManualCompactTask(udisk::chunk::ManualCompactHandlePtr handle_ptr, 
                           uint32_t lc_id, 
                           uint32_t pg_id);
  void MigrateMemTableResponse(const common::MigrateHead* hdr);
  void MigrateJournalResponse(const common::MigrateHead* hdr);

 private:
  void RecoverCompactFile(uint32_t start_compact, 
                          uint32_t lc_id, 
                          uint64_t seqno);
  bool CompactMetaFilter(const PGCompactMeta& meta, MigrateUDiskInfo* udisk, uint64_t seqno);
  void EntryMigrateJournal(MigrateUDiskInfo* udisk, uint64_t seqno);
  void MigrateJournal(MigrateUDiskInfo* udisk);
  uint32_t MigrateSingleJournalIO(MigrateUDiskInfo* udisk, 
                                  uint64_t seqno, 
                                  const chunk::IOMeta& meta);
  void MigrateOpenChunkResponse(int retcode, 
                                chunk::ChunkHandle* handle, 
                                chunk::OpRequest* op, 
                                const chunk::IOMeta meta,
                                MigrateUDiskInfo* udisk,
                                const ucloud::udisk::MigratePcMeta migrate_pc); 
  static void MigrateReadCbWrapper(int32_t retcode, 
                                   void* arg);
  void MigrateReadCb(uint64_t seqno, 
                     const chunk::IOMeta& meta,
                     MigrateUDiskInfo* udisk,
                     const ucloud::udisk::MigratePcMeta& migrate_pc);
  void DoMigrateMemTableTask(MigrateUDiskInfo* udisk, MemTable* weak_immu);
  void EntryMigrateMemTable(MigrateUDiskInfo* udisk, bool reenter);
  void MigrateMemTable(MigrateUDiskInfo* udisk);
  uint32_t MigrateSingleMemIO(MigrateUDiskInfo* udisk, 
                              const ExternalIO& migrate_io);
  void MigrateMemTableFinish(MigrateUDiskInfo* udisk);
  void EntryManualCompact(const udisk::chunk::ManualCompactHandlePtr& handle_ptr,
                          uint32_t lc_id);
  void TriggerSwapMemTable(std::unique_lock<std::mutex>& lock);
  int32_t EntryBatchWrite(const WriterPtr writer, 
                          bool reenter);
  int32_t BatchWrite(bool space_enough);
  void BatchResponse(const std::deque<WriterPtr>& writers);
  void ImmuCompactReset(bool jpc_reset); // jpcreset后恢复重启，不需要重新reset
  static void UpdateJournalMetaCbWrapper(int32_t retcode, void* arg);
  void UMAppendActiveJPCCb();
  void UMInitActiveJPCCb();
  void UMImmuCompactFinishCb();
  void UMImmuCompactResetCb();
  void UMSwapMemTableCb();
  int32_t RecoverJournalFile(JPCHandle* jpc_handle, 
                             std::vector<std::string>* records);
  void TriggerCompact();
  bool MergeInterval(std::vector<chunk::Interval>* old_intervals, 
                     const std::vector<chunk::Interval>& new_intervals, 
                     char* old_buf, 
                     const char* new_buf);
  bool MakeRoomForWriter(uint32_t batch_size);
  void BuildBatchGroup();
  void DispatchNextWriter();
  void CompactMemTable();
  static void CompactMemTableCbWrapper(int32_t retcode, 
                                       void* arg);
  void CompactMemTableCb(uint64_t seqno, 
                         const chunk::IOMeta& meta);
  void CompactSingleIO(const ExternalIO& compact_io);

  // 把plainzone的journal compact到compactzone
  void EntryCompactJournal();
  void CompactJournal(PGCompactMeta* meta, 
                      InternalBatchData* batch_data);
  static void CompactJournalCbWrapper(int32_t retcode, void* arg);
  void CompactJournalCb(PGCompactMeta* meta);
  void OpenChunkResponse(int retcode, 
                         chunk::ChunkHandle* ch, 
                         uint64_t seqno, 
                         const chunk::IOMeta& meta, 
                         const char* value);
  void AddRecordCb(int32_t retcode, uint64_t seqno);
  static void AddRecordCbWrapper(int32_t retcode, void* arg);
  void RecoverRecord(uint32_t type, uint32_t pre_cnt);

 private:
  chunk::ChunkLoopHandle* handle_;
  uint32_t pg_id_;
  uint32_t req_ref_;
  WriteableFilePtr wfile_;
  JournalWriterPtr journal_file_;
  std::deque<WriterPtr> pending_writers_; 
  std::deque<WriterPtr> inflight_writers_; 
  WriteBatch* internal_batch_; 
  std::map<pid_t, uint32_t> jpc_map_;

  /* 到compact_writer_这些变量，在某个io线程中执行，无需加锁 */
  ExternalIOList compact_ios_; // 记录immu中单个node里的io
  std::shared_ptr<MemTableIterator> immu_iter_;
  std::unordered_map<uint64_t, ExternalIO> compact_list_;
  InternalBatch* compact_batch_;

  udisk::chunk::ManualCompactHandlePtr manual_compact_handle_ptr_;
};

}
}

#endif

