#ifndef UDISK_JOURNAL_META_H
#define UDISK_JOURNAL_META_H

#include <atomic>
#include <assert.h>
#include <string.h>
#include <stdlib.h>
#include <mutex>
#include <set>
#include <condition_variable>
#include "journal_format.h"
#include "raw_chunk_storage_type.h"
#include "raw_device_manager.h"

namespace udisk {
namespace journal {

class JPCHandle;
const static uint32_t kPGMaxJPCNumber = 32; // 理论上超过8(memtable->1G/JPC->128M)个，预留32个;

struct CompactZoneInfo { // 只存储meta
  uint32_t jpc_id;            //裸盘: jpc_id；文件系统 file序号 文件命名规则jpc_id
  uint64_t start_seqno = UINT64_MAX;  //起始seqno  journal迁移相关
  uint64_t end_seqno = 0;             //结束seqno  journal迁移相关
}__attribute__((packed));

struct UDiskJournalMeta {
  uint32_t crc;
  uint32_t worker_num; // 保存上次运行时线程个数
  uint32_t pg_num;
  uint32_t pg_ids[0]; // chunk所属pg_id, 个数和set部署相关, 理论上不会超过128
}__attribute__((packed));

// compact每个pg一个，各个线程共用
struct PGCompactMeta {
  uint32_t crc;
  uint32_t pg_id;
  uint32_t active_offset;
  uint32_t active_id;
  CompactZoneInfo zone[chunk::kPGCompactJPCCount];
  std::string ToString() const {
    std::stringstream ss;
    ss << "crc=" << crc << ",pg_id=" << pg_id << ",active_id=" << active_id 
        << ",active_offset=" << active_offset << ",zone=[";
    // 从最新的到最老的开始打印
    uint32_t i = active_id;
    do {
      ss << i << "," << zone[i].jpc_id << ":" << zone[i].start_seqno << "," 
          << zone[i].end_seqno << "],";
      i = ((i + chunk::kPGCompactJPCCount) - 1) % chunk::kPGCompactJPCCount;
    } while (i != active_id);
    return ss.str();
  }
}__attribute__((packed));

// journal每个线程有各自的
struct PGJournalMeta {
  uint32_t crc;
  uint32_t pg_id;
  uint32_t active_num;
  uint32_t active_zone[kPGMaxJPCNumber];  //裸盘:jpc_id; 文件系统：文件序号
  uint32_t inactive_num;
  uint32_t inactive_zone[kPGMaxJPCNumber]; //裸盘：jpc_id；文件系统：文件序号
  std::string ToString() const {
    std::stringstream ss;
    ss << "crc=" << crc << ",pg_id=" << pg_id << ",active_num=" << active_num << "=[";
    for (uint32_t i = 0; i < active_num; ++ i) {
      ss << active_zone[i] << ",";
    }
    ss << "],inactive_num=" << inactive_num << "=[";
    for (uint32_t i = 0; i < inactive_num; ++ i) {
      ss << inactive_zone[i] << ",";
    }
    ss << "]";
    return ss.str();
  }
}__attribute__((packed));

class JournalMeta {
 public:
  JournalMeta();
  ~JournalMeta();

  void Init();

  void AppendActiveJPC(uint32_t pg_id, 
                       pid_t tid,
                       uint32_t jpc_id,
                       uevent::DiskIOCb done, 
                       JournalAioArgs* journal_args); 

  void SwapMemTable(uint32_t pg_id, 
                    const std::map<pid_t, 
                    uint32_t>& jpc_ids,
                    uevent::DiskIOCb done, 
                    JournalAioArgs* journal_args); 

  void UMImmuCompactFinish(uint32_t pg_id, 
                           PGCompactMeta* meta,
                           uevent::DiskIOCb done, 
                           JournalAioArgs* journal_args);

  void UMImmuCompactReset(uint32_t pg_id, 
                          bool jpc_reset,
                          uevent::DiskIOCb done, 
                          JournalAioArgs* journal_args);

  PGCompactMeta* MutableCompactMeta(uint32_t pg_id);

  PGCompactMeta GetCompactMeta(uint32_t pg_id);
  
 private:
  // journal信息
  UDiskJournalMeta* journal_meta_; // 初始化写，其余只读，无需mtx_
  std::vector<std::vector<PGJournalMeta*>> thread_journal_meta_; // 线程隔离，无需mtx_
  std::vector<PGCompactMeta*> compact_meta_; // guard by mtx_
  JPCHandle* super_handle_;
  bool is_init_; // 仅初始化调用，无需mtx_
  std::map<pid_t, uint32_t> worker_ids_; // 初始化写，其余只读，无需mtx_
  std::mutex mtx_;
};

};
};

#endif

