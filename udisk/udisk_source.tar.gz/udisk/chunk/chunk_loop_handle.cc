#include <cassert>
#include <ustevent/base/logging.h>
#include <ustevent/base/current_thread.h>
#include "chunk_context.h"
#include "gate_io_proto.h"
#include "ark_io_proto.h"
#include "hela_io_proto.h"
#include "likely.h"
#include "udisk_types.h"
#include "manager_handle.h"
#include "journal_format.h"
#include "chunk_loop_handle.h"
#include "create_chunk_storage.h"

namespace udisk {
namespace chunk {

using namespace uevent;

ChunkLoopHandle::ChunkLoopHandle(uevent::EventLoop* loop)
    : uevent::LoopHandle(loop), 
      op_pool_(g_context->config().max_op_pool_num()),
      msg_header_slab_(256, g_context->config().max_op_pool_num()){
  last_op_seq_ = 0;
  chunk_storage_ = CreateChunkStorage();
  assert(chunk_storage_ != nullptr);
  chunk_storage_->Init(g_context->chunk_pool(), loop);
  head_ = nullptr;
  tail_ = nullptr;
  dispatch_io_state_ = kLoopDispatchIoStateOff;
  dispatch_io_depth_ = 0;
  dispatch_io_cur_total_ = 0;
  udisks_.resize(g_context->config().max_udisk_num(), nullptr);
  conns_.reserve(g_context->config().max_conn_num_per_loop());
  my_chunk_id_ = g_context->config().my_id();
  // 从配置文件获取
  io_report_interval_ = g_context->config().io_report_interval();

  migrate_manager_ = new MigrateManager(this);
  migrate_manager_->Init();

  loop_->RunEvery(io_report_interval_,
      std::bind(&ChunkLoopHandle::IoReportTimerCb, this));

  loop_->RunEvery(g_context->config().recycle_udisk_handle_interval(),
      std::bind(&ChunkLoopHandle::RecycleUDiskHandleTimerCb, this));
  if (g_context->config().loop_dispatch_io_depth() != 0) {
    DispatchIOInLoopMode(g_context->config().loop_dispatch_io_depth());
  }

  loop_->RunEvery(0.001,
      std::bind(&ChunkLoopHandle::IOTimerCb, this));

  loop_->RunEvery(g_context->config().heartbeat_metaserver_interval(),
      std::bind(&ChunkLoopHandle::ManagerHeartbeatTimerCb, this));
}

ChunkLoopHandle::~ChunkLoopHandle() {
  ULOG_TRACE << "ChunkLoopHandle ~ChunkLoopHandle";
  delete chunk_storage_;
}

void ChunkLoopHandle::UpdateClusterMap(cluster::ClusterMap map) {
  ULOG_INFO << "MY ClusterMap will be updated";
  cluster_map_ = map;
}

void ChunkLoopHandle::RepairPCStartNotify(uint32_t pg_id, PhysicalChunkSet pcs) {
  for (PhysicalChunkSet::iterator it = pcs.begin(); it != pcs.end(); ++it) {
    uint32_t lc_id = it->lc_id;
    uint32_t lc_size = it->lc_size;
    uint32_t pc_no = it->pc_no;
    uint32_t lc_random_id = it->lc_random_id;
    ULOG_INFO << "Update pcs size=" << pcs.size() << ", lc_id="
      << lc_id << ", pc_no=" << pc_no;
    UDiskHandle* disk_handle = LookupUDiskHandle(lc_id, lc_random_id, lc_size, true);
    uint32_t retcode = 0;
    std::string errmsg("success");
    if (disk_handle != nullptr) {
      if (disk_handle->RepairPCStart(pg_id, pc_no) != 0) {
        retcode = ucloud::udisk::EC_UDISK_REPAIR_FAIL;
        errmsg = "pending io error";
        ULOG_ERROR << "pending io error, lc_id=" << lc_id << ", pc_no=" << pc_no;
      } else {
        ULOG_DEBUG << "repair pc start: lc_id=" << lc_id << ", pc_no=" << pc_no;
      }
    } else {
      retcode = ucloud::udisk::EC_UDISK_REPAIR_FAIL;
      errmsg = "pending io error";
      ULOG_ERROR << "create udisk handle error. lc_id=" << lc_id << ", pc_no=" << pc_no;
    }

    // 通知mange，pending io 完毕
    g_context->man_listen_loop()->RunInLoop(
      std::bind(&ManagerHandle::PendingIOResponseHandles,
        g_context->manager_handle(), lc_id, pc_no, retcode, errmsg));
  }
}

void ChunkLoopHandle::UpdateUDiskIODepthLimit(uint32_t lc_id, int io_depth_limit) {
  if (udisks_.size() <= lc_id) {
    return;
  }
  if (udisks_[lc_id] == nullptr) {
    return;
  }
  if (io_depth_limit <= 0) {
    return;
  }
  if (io_depth_limit > g_context->config().udisk_queue_max_depth()) {
    io_depth_limit = g_context->config().udisk_queue_max_depth();
  }
  udisks_[lc_id]->set_io_depth_limit(io_depth_limit);
  dispatch_io_state_ = kLoopDispatchIoStateOff;
  ULOG_INFO << "set lc " << lc_id << " io_depth = " << io_depth_limit;
}

void ChunkLoopHandle::DispatchIOInLoopMode(uint32_t io_depth_limit) {
  if (dispatch_io_state_ != kLoopDispatchIoStateOff
      && dispatch_io_depth_ == io_depth_limit) {
    ULOG_DEBUG << "Have been in loop dispatch mode! io_depth_limit:"
              << io_depth_limit << "dispatch_io_cur_total:" << dispatch_io_cur_total_;
    return;
  }

  dispatch_io_depth_ = io_depth_limit;
  dispatch_io_state_ = kLoopDispatchIoStateOn;
  dispatch_io_cur_total_ = 0;
  if (head_ == nullptr) {
    ULOG_INFO << "No udisk in list, io_depth_limit:" << io_depth_limit;
    return;
  }

  UDiskHandle* handle = head_;
  do {
    dispatch_io_cur_total_ += handle->current_io_depth();
    handle = handle->next();
  } while (handle != head_);

  ULOG_INFO << "io_depth_limit:" << io_depth_limit
           << "dispatch_io_cur_total:" << dispatch_io_cur_total_;
}

void ChunkLoopHandle::MigrateUDisk(uint32_t lc_id) {
  assert(lc_id < udisks_.size());
  if (udisks_[lc_id]) {
    ULOG_INFO << "connection reset for lc: " << lc_id
             << " in thread: " << std::string(base::CurrentThread::name());
    udisks_[lc_id]->connection_reset();
  } else {
    ULOG_ERROR << "udisk_handle for lc: " << lc_id
              << " not found in chunk loop handle";
  }
}

void ChunkLoopHandle::RepairPCMergeNotify(uint32_t lc_id, uint32_t lc_size, uint32_t pc_no) {
  UDiskHandle* disk_handle = LookupUDiskHandle(lc_id, 0, lc_size, false);
  if (disk_handle == nullptr) {
    ULOG_ERROR << "Can not find udisk_handle for lc_id=" << lc_id;
    return;
  }
  ULOG_DEBUG << "repair pc merge: lc_id=" << lc_id << ", pc_no=" << pc_no;
  disk_handle->RepairPCMerge(pc_no);
}

void ChunkLoopHandle::RepairPCFinishNotify(uint32_t lc_id, uint32_t lc_size, uint32_t pc_no) {
  UDiskHandle* disk_handle = LookupUDiskHandle(lc_id, 0, lc_size, false);
  if (disk_handle == nullptr) {
    ULOG_ERROR << "Can not find udisk_handle for lc_id=" << lc_id;
    return;
  }
  ULOG_DEBUG << "repair pc finish: lc_id=" << lc_id << ", pc_no=" << pc_no;
  disk_handle->RepairPCFinish(pc_no);
}

void ChunkLoopHandle::ConnectionSuccessHandle(const uevent::ConnectionUeventPtr& conn) {
  ChunkLoopHandle *loop = (ChunkLoopHandle*)conn->GetLoop()->GetLoopHandle();
  if (loop->conns_.size() <= (size_t)g_context->config().max_conn_num_per_loop()) {
    loop->conns_.insert(std::make_pair(conn->GetId(), conn));
    ULOG_DEBUG << "recv a connection, conn_id=" << conn->GetId()
              << ", " << conn->GetPeerAddress().ToString();
  } else {
    g_context->io_listener()->RemoveConnection(conn);
    ULOG_ERROR << "connection reach max size. remove a connection "
              << conn->GetPeerAddress().ToString() << " listener";
  }
}

void ChunkLoopHandle::ConnectionClosedHandle(const uevent::ConnectionUeventPtr& conn) {
  ChunkLoopHandle* loop_handle =
      (ChunkLoopHandle*)conn->GetLoop()->GetLoopHandle();
  ULOG_INFO << "remove a connection " << conn->GetPeerAddress().ToString();
  g_context->io_listener()->RemoveConnection(conn);
  loop_handle->conns_.erase(conn->GetId());
  loop_handle->ClearUDiskOpRequstByConnId(conn->GetId());
  loop_handle->ClearJournalOpRequestByConnId(conn->GetId());
}

// 这个回调会被设置成in connection和out_connetion的可读回调
void ChunkLoopHandle::MessageReadHandle(const uevent::ConnectionUeventPtr& conn) {
  ChunkLoopHandle *loop_handle = (ChunkLoopHandle*)conn->GetLoop()->GetLoopHandle();
  const size_t hdr_size = sizeof(common::MessageHeader);
  size_t readable = conn->ReadableLength();
  ULOG_TRACE << conn->GetPeerAddress().ToString() << ", before buffersize : " << conn->ReadableLength();
  while (readable > hdr_size) {
    common::MessageHeader hdr;
    conn->ReceiveData(&hdr, hdr_size);
    if (readable >= (hdr_size + hdr.data_len)) {
      common::MessageHeader *msg_hdr = nullptr;
      char *msg_data = nullptr;
      MemorySlab *slab = nullptr;
      if (DecodeMsg(conn, hdr.msg_type, &msg_hdr, &msg_data, &slab)) {
        readable -= (hdr_size + hdr.data_len);
        loop_handle->HandleMessage(msg_hdr, msg_data, conn, slab);
      } else {
        // DecodeMsg仅会再malloc head失败以及hdr类型错误时，返回false
        conn->DrainData(hdr_size + hdr.data_len);
        readable -= (hdr_size + hdr.data_len);
      }
    } else {
      break;
    }
  }
  ULOG_TRACE << conn->GetPeerAddress().ToString() << ", after buffersize : " << conn->ReadableLength();
}

bool ChunkLoopHandle::DecodeMsg(const uevent::ConnectionUeventPtr &conn,
                               uint8_t msg_type,
                               common::MessageHeader **hdr,
                               char **data,
                               MemorySlab **slab) {
  ChunkLoopHandle *loop_handle = (ChunkLoopHandle*)conn->GetLoop()->GetLoopHandle();
  switch (msg_type) {
    case common::MSG_GATE_IO_REQ: {
      constexpr size_t msg_hdr_len = sizeof(common::MessageHeader) +
                           sizeof(common::GateIORequestHead);
      char *msg_hdr = (char*)(loop_handle->msg_header_slab_.Malloc());
      if (UNLIKELY(msg_hdr == nullptr)) {
        ULOG_ERROR << "Failed to malloc msg header for GateIoReq from slab, will discard this req";
        return false;
      }
      conn->RemoveData(msg_hdr, msg_hdr_len);
      *hdr = (common::MessageHeader*)msg_hdr;
      common::GateIORequestHead *gate_hdr =
        (common::GateIORequestHead*)((*hdr)->next_header);
      assert(gate_hdr->magic == common::GATE_IO_MAGIC);
      *data = nullptr;
      if (gate_hdr->size) { // 有数据
        assert(gate_hdr->size == gate_hdr->length);
        void *msg_data = nullptr;
        std::tie(msg_data, *slab) = loop_handle->mem_pool_.Malloc(gate_hdr->size, kDefaultDevBlockSize);
        assert(msg_data);
        conn->RemoveData(msg_data, gate_hdr->size);
        *data = reinterpret_cast<char*>(msg_data);
      }
      return true;
    }
    case common::MSG_ARK_IO_REQ: {
      constexpr size_t msg_hdr_len = sizeof(common::MessageHeader) +
                           sizeof(common::ArkIORequestHead);
      char *msg_hdr = (char*)(loop_handle->msg_header_slab_.Malloc());
      if (UNLIKELY(msg_hdr == nullptr)) {
        ULOG_ERROR << "Failed to malloc msg header for ArkIoReq from slab, will discard this req";
        return false;
      }
      conn->RemoveData(msg_hdr, msg_hdr_len);
      *hdr = (common::MessageHeader*)msg_hdr;
      common::ArkIORequestHead *ark_hdr =
        (common::ArkIORequestHead*)((*hdr)->next_header);
      assert(ark_hdr->magic == common::ARK_IO_MAGIC);
      *data = nullptr;
      if (ark_hdr->size) { // 有数据
        assert(ark_hdr->size == ark_hdr->length);
        void *msg_data = nullptr;
        std::tie(msg_data, *slab) = loop_handle->mem_pool_.Malloc(ark_hdr->size, kDefaultDevBlockSize);
        assert(msg_data);
        conn->RemoveData(msg_data, ark_hdr->size);
        *data = reinterpret_cast<char*>(msg_data);
      }
      return true;
    }
    case common::MSG_CHUNK_IO_REQ: {
      constexpr size_t msg_hdr_len = sizeof(common::MessageHeader) +
                           sizeof(common::ChunkIORequestHead);
      char *msg_hdr = (char*)(loop_handle->msg_header_slab_.Malloc());
      if (UNLIKELY(msg_hdr == nullptr)) {
        ULOG_ERROR << "Failed to malloc msg header for ChunkIoReq from slab, will discard this req";
        return false;
      }
      conn->RemoveData((void*)msg_hdr, msg_hdr_len);
      *hdr = (common::MessageHeader*)msg_hdr;
      common::ChunkIORequestHead *chunk_hdr =
        (common::ChunkIORequestHead*)((*hdr)->next_header);
      assert(chunk_hdr->magic == common::CHUNK_IO_MAGIC);
      *data = nullptr;
      if (chunk_hdr->size) {
        assert(chunk_hdr->size == chunk_hdr->length);
        void *msg_data = nullptr;
        std::tie(msg_data, *slab) = loop_handle->mem_pool_.Malloc(chunk_hdr->size, kDefaultDevBlockSize);
        assert(msg_data);
        conn->RemoveData(msg_data, chunk_hdr->size);
        *data = reinterpret_cast<char*>(msg_data);
      }
      return true;
    }
    case common::MSG_MIGRATE_JOURNAL_REQ: {
      constexpr size_t msg_hdr_len = sizeof(common::MessageHeader) +
                                     sizeof(common::MigrateHead);
      char *msg_hdr = (char*)(loop_handle->msg_header_slab_.Malloc());
      conn->RemoveData((void*)msg_hdr, msg_hdr_len);
      *hdr = (common::MessageHeader*)msg_hdr;
      common::MigrateHead* migrate_hdr = (common::MigrateHead*)((*hdr)->next_header);
      assert(migrate_hdr->magic == common::MIGRATE_IO_MAGIC);
      assert(migrate_hdr->size);// 迁移journal必然是写请求
      *data = nullptr;
      assert(migrate_hdr->size == migrate_hdr->length);
      void *msg_data = nullptr;
      std::tie(msg_data, *slab) = loop_handle->mem_pool_.Malloc(migrate_hdr->size, kDefaultDevBlockSize);
      assert(msg_data);
      conn->RemoveData(msg_data, migrate_hdr->size);
      *data = reinterpret_cast<char*>(msg_data);
      return true;
    }
    case common::MSG_MIGRATE_JOURNAL_RES: {
      constexpr size_t msg_hdr_len = sizeof(common::MessageHeader) +
                           sizeof(common::MigrateHead);
      char *msg_hdr = (char*)(loop_handle->msg_header_slab_.Malloc());
      conn->RemoveData((void*)msg_hdr, msg_hdr_len);
      *hdr = (common::MessageHeader*)msg_hdr;
      common::MigrateHead* migrate_hdr =
        (common::MigrateHead*)((*hdr)->next_header);
      assert(migrate_hdr->magic == common::MIGRATE_IO_MAGIC);
      assert(migrate_hdr->size == 0); 
      *data = nullptr;
      return true;
    }
    case common::MSG_CHUNK_IO_RES: {
      constexpr size_t msg_hdr_len = sizeof(common::MessageHeader) +
                           sizeof(common::ChunkIOResponseHead);
      char *msg_hdr = (char*)(loop_handle->msg_header_slab_.Malloc());
      if (UNLIKELY(msg_hdr == nullptr)) {
        ULOG_ERROR << "Failed to malloc msg header for ChunkIoRes from slab, will discard this req";
        return false;
      }
      conn->RemoveData(msg_hdr, msg_hdr_len);
      *hdr = (common::MessageHeader*)msg_hdr;
      common::ChunkIOResponseHead *chunk_hdr =
        (common::ChunkIOResponseHead*)((*hdr)->next_header);
      assert(chunk_hdr->magic == common::CHUNK_IO_MAGIC);
      // 目前不会从 secondary chunk 读数
      assert(chunk_hdr->size == 0);
      if (chunk_hdr->size) {
        void *msg_data = nullptr;
        std::tie(msg_data, *slab) = loop_handle->mem_pool_.Malloc(chunk_hdr->size, kDefaultDevBlockSize);
        assert(msg_data);
        conn->RemoveData(msg_data, chunk_hdr->size);
        *data = reinterpret_cast<char*>(msg_data);
      }
      return true;
    }
    // Hela
    case common::MSG_HELA_CHUNK_REQ: {
      constexpr size_t msg_hdr_len = sizeof(common::MessageHeader) +
                                     sizeof(common::HelaChunkRequestHead);
      char *msg_hdr = (char*)(loop_handle->msg_header_slab_.Malloc());
      if (UNLIKELY(msg_hdr == nullptr)) {
        ULOG_ERROR << "Failed to malloc msg header for HelaChunkReq from slab, will discard this req";
        return false;
      }
      conn->RemoveData((char*)msg_hdr, msg_hdr_len);
      *hdr = (common::MessageHeader*)msg_hdr;
      common::HelaChunkRequestHead *hela_hdr =
        (common::HelaChunkRequestHead*)((*hdr)->next_header);
      assert(hela_hdr->magic == common::HELA_IO_MAGIC);
      *data = nullptr;
      if (hela_hdr->size) { // 有数据
        void *msg_data = nullptr;
        std::tie(msg_data, *slab) = loop_handle->mem_pool_.Malloc(hela_hdr->size, kDefaultDevBlockSize);
        assert(msg_data);
        conn->RemoveData(msg_data, hela_hdr->size);
        *data = reinterpret_cast<char*>(msg_data);
      }
      return true;
    }
    default: {
      ULOG_ERROR << "unknow message type: " << msg_type << ", peer_addr=" 
          << conn->GetPeerAddress().ToString();
      return false;
    }
  }
}

void ChunkLoopHandle::HandleMessage(common::MessageHeader *msg_hdr,
                                    char *msg_data,
                                    const uevent::ConnectionUeventPtr &conn,
                                    MemorySlab *slab) {
  switch (msg_hdr->msg_type) {
    case common::MSG_GATE_IO_REQ: {
      const common::GateIORequestHead* hdr =
          (const common::GateIORequestHead*)(msg_hdr->next_header);
      uint64_t seq = get_next_op_seq(hdr->pg_id);
      if (seq == UINT64_MAX) {
        ULOG_ERROR << "pg_id=" << hdr->pg_id << " engine is init...";
        break;
      }
      OpRequest* op = op_pool_.Malloc(seq, conn, msg_hdr, msg_data, hdr->length,
          hdr->cmd, hdr->pg_id, op_pool_, &mem_pool_, slab, &msg_header_slab_);
      if (UNLIKELY(op == nullptr)) {
        ULOG_ERROR << "Failed to malloc OpRequest for GateIoReq from mem pool";
        FreeMsg(msg_hdr, msg_data, slab);
        return;
      }

      UDiskHandle* udisk_handle = LookupUDiskHandle(
          hdr->lc_id, hdr->lc_random_id, hdr->lc_size, true);
      assert(udisk_handle != nullptr);
      if (UNLIKELY(!udisk_handle->DoGateOpRequest(op))) {
        op->DecRefs();
      }
      break;
    }
    case common::MSG_ARK_IO_REQ: {
      const common::ArkIORequestHead* hdr =
          (const common::ArkIORequestHead*)(msg_hdr->next_header);
      uint64_t seq = get_next_op_seq(hdr->pg_id);
      if (seq == UINT64_MAX) {
        ULOG_ERROR << "pg_id=" << hdr->pg_id << " engine is init...";
        break;
      }
      OpRequest* op = op_pool_.Malloc(seq, conn, msg_hdr, msg_data, hdr->length,
          hdr->cmd, hdr->pg_id, op_pool_, &mem_pool_, slab, &msg_header_slab_);
      if (UNLIKELY(op == nullptr)) {
        ULOG_ERROR << "Failed to malloc OpRequest for GateIoReq from mem pool";
        FreeMsg(msg_hdr, msg_data, slab);
        return;
      }

      UDiskHandle* udisk_handle = LookupUDiskHandle(
          hdr->lc_id, hdr->lc_random_id, hdr->lc_size, true);
      assert(udisk_handle != nullptr);
      if (UNLIKELY(!udisk_handle->DoArkOpRequest(op))) {
        op->DecRefs();
      }
      break;
    }
    case common::MSG_CHUNK_IO_REQ: {
      const common::ChunkIORequestHead* hdr =
          (const common::ChunkIORequestHead*)(msg_hdr->next_header);
      uint32_t pg_id = hdr->pg_id;
      if (!journal_engine_[pg_id] || !journal_engine_[pg_id]->IsInit()) {
        ULOG_ERROR << "pg_id=" << pg_id << " engine is init...";
        break;
      } 
      uint64_t seq = 
          g_context->journal_enable() ? hdr->flowno : get_next_op_seq(pg_id);
      if (seq == UINT64_MAX) {
        ULOG_ERROR << "pg_id=" << pg_id << " engine is init...";
        break;
      }
      OpRequest* op = op_pool_.Malloc(seq, conn, msg_hdr, msg_data, hdr->length,
          hdr->cmd, hdr->pg_id, op_pool_, &mem_pool_, slab, &msg_header_slab_);
      if (UNLIKELY(op == nullptr)) {
        ULOG_ERROR << "Failed to malloc OpRequest for GateIoReq from mem pool";
        FreeMsg(msg_hdr, msg_data, slab);
        return;
      }

      UDiskHandle* udisk_handle = LookupUDiskHandle(
           hdr->lc_id, hdr->lc_random_id, hdr->lc_size, true);
      assert(udisk_handle != nullptr);
      if (UNLIKELY(!udisk_handle->DoChunkOpRequest(op))) {
        op->DecRefs();
      }
      break;
    }
    case common::MSG_MIGRATE_JOURNAL_REQ: {
      const common::MigrateHead* hdr =
          (const common::MigrateHead*)(msg_hdr->next_header);
      ULOG_DEBUG << "Recv migrate_seqno=" << hdr->flowno;
      uint64_t seq = get_next_op_seq(hdr->pg_id);
      if (seq == UINT64_MAX) {
        ULOG_ERROR << "pg_id=" << hdr->pg_id << " engine is init...";
        break;
      }
      OpRequest* op = op_pool_.Malloc(seq, conn, msg_hdr, msg_data, hdr->length,
          hdr->cmd, hdr->pg_id, op_pool_, &mem_pool_, slab, &msg_header_slab_);
      if (UNLIKELY(op == nullptr)) {
        ULOG_ERROR << "Failed to malloc OpRequest for GateIoReq from mem pool";
        FreeMsg(msg_hdr, msg_data, slab);
        return;
      }

      UDiskHandle* udisk_handle = LookupUDiskHandle(hdr->lc_id, 
          hdr->lc_random_id, hdr->lc_size, true);
      assert(udisk_handle != nullptr);
      if (UNLIKELY(!udisk_handle->ProcessMigrateJournalRequest(op))) {
        op->DecRefs();
      }
      break;
    }
    case common::MSG_MIGRATE_JOURNAL_RES: {
      const common::MigrateHead* hdr =
          (const common::MigrateHead*)(msg_hdr->next_header);
      assert (msg_data == nullptr);
      ULOG_DEBUG << "Recv remote chunk response=" << DumpMigrateHead(*hdr);
      migrate_manager_->DoMigrateRemoteResponse(hdr);
      // RES不使用op释放msg_hdr,需要手动释放内存
      msg_header_slab_.Free(msg_hdr);
      break;
    }
    case common::MSG_CHUNK_IO_RES: {
      const common::ChunkIOResponseHead* hdr =
          (const common::ChunkIOResponseHead*)(msg_hdr->next_header);
      UDiskHandle* udisk_handle = LookupUDiskHandle(hdr->lc_id, 0, 0, false);
      if (udisk_handle == nullptr) {
        ULOG_ERROR << "can't find udisk handle when chunk response, lc_id: "
                  << hdr->lc_id << ", maybe connection closed";
        return;
      }
      // 不会从 Secondary chunk 读数据，如果有异常读到了数据，assert。
      assert (msg_data == nullptr);
      ULOG_DEBUG << "Recv chunk response=" << DumpChunkIOResponse(*hdr);
      udisk_handle->DoChunkResponse(hdr);
      // RES不使用op释放msg_hdr,需要手动释放内存
      msg_header_slab_.Free(msg_hdr);
      break;
    }
    // Hela
    case common::MSG_HELA_CHUNK_REQ: {
      const common::HelaChunkRequestHead* hdr =
        (const common::HelaChunkRequestHead*)(msg_hdr->next_header);

      uint64_t seq = get_next_op_seq(hdr->pg_id);
      if (seq == UINT64_MAX) {
        ULOG_ERROR << "pg_id=" << hdr->pg_id << " engine is init...";
        break;
      }
      OpRequest* op = op_pool_.Malloc(seq, conn, msg_hdr, msg_data, hdr->length,
          hdr->cmd, hdr->pg_id, op_pool_, &mem_pool_, slab, &msg_header_slab_);
      if (UNLIKELY(op == nullptr)) {
        ULOG_ERROR << "Failed to malloc OpRequest for GateIoReq from mem pool";
        FreeMsg(msg_hdr, msg_data, slab);
        return;
      }

      UDiskHandle* udisk_handle = LookupUDiskHandle(
           hdr->lc_id, hdr->lc_random_id, hdr->lc_size, true);
      assert(udisk_handle != nullptr);
      if (UNLIKELY(!udisk_handle->DoHelaOpRequest(op))) {
        op->DecRefs();
      }
      break;
    }
    default:
      // 如果是其他类型 前序逻辑不应该分配内存空间
      assert(msg_data == nullptr);
      assert(msg_hdr == nullptr);
      // 其他类型的都丢弃
      ULOG_ERROR << "unknow msg_type: " << msg_hdr->msg_type;
      break;
  }
}

void ChunkLoopHandle::FreeMsg(common::MessageHeader *msg_hdr,
                              char *msg_data, MemorySlab *slab) {
  if (msg_hdr) {
    msg_header_slab_.Free(msg_hdr);
  }

  if (msg_data) {
    mem_pool_.Free((void*)msg_data, slab);
  }
}

UDiskHandle* ChunkLoopHandle::LookupUDiskHandle(uint32_t lc_id,
                                                uint32_t lc_random_id,
                                                uint32_t lc_size,
                                                bool create) {
  assert(lc_id < udisks_.size() + 1);
  if (create == false) {  // 对于response 不需要创建
    return udisks_[lc_id];  // udisk_hande可能已经析构，返回nullptr
  }
  if (udisks_[lc_id] != nullptr) {
    if (lc_random_id == udisks_[lc_id]->lc_random_id()) {
      return udisks_[lc_id];
    } else {
      // 程序进入这个分支，表明lc id重复了，按道理不可能发生。所以程序直接退出。
      ULOG_FATAL << "this lc_id's lc_random_id is not same"
                << "lc id: " << lc_id
                << "udisk handle's random id: " << udisks_[lc_id]->lc_random_id()
                << "request's random id: " << lc_random_id;
    }
  } else {
    ULOG_DEBUG << "Create udisk handle, lc_id=" << lc_id << ", lc_random_id=" << lc_random_id
              << ", lc_size=" << lc_size;
    if (lc_size > g_context->config().lc_size_limit()) {
      ULOG_ERROR << "Create udisk handle size too large"
                << ", lc id: " << lc_id
                << ", lc_size: " << lc_size;
      return nullptr;
    }

    size_t pc_count = ((uint64_t)lc_size << GB_SHIFT) / g_context->chunk_pool()->pc_size();
    udisks_[lc_id] = new UDiskHandle(lc_id, lc_random_id, pc_count, this);
    AddUDiskHandle(udisks_[lc_id]);
    return udisks_[lc_id];
  }
  return nullptr;
}

void ChunkLoopHandle::LocalAioCb(int retcode, void* arg) {
  auto aio_arg = std::unique_ptr<AioCbArgs>(reinterpret_cast<AioCbArgs*>(arg));
  uint32_t lc_id = aio_arg->lc_id;
  uint32_t pg_id = aio_arg->pg_id;
  uint64_t op_seq = aio_arg->op_seq;
  ULOG_TRACE << "Op Seq " << op_seq << " aio cb";
  // 这里收到aio的应答后不允许创建UDiskHandle结构，如果这个
  // 时候UDiskHanle结构不存在了，则说明客户端的连接断开了,直接忽略这个应答
  UDiskHandle* udisk_handle = aio_arg->loop_handle->LookupUDiskHandle(lc_id, 0, 0, false);
  if (udisk_handle == nullptr) {
    ULOG_ERROR << "can't find udisk handle when aio response, lc_id: "
              << lc_id << " op_seq: " << op_seq;
    return;
  }
  ULOG_TRACE << "aio recv : lc_id=" << lc_id << ", op_seq=" << op_seq
            << ", retcode=" << retcode << ", pg_id=" << pg_id;
  udisk_handle->DoLocalAioResponse(pg_id, op_seq, retcode);
}

void ChunkLoopHandle::OpenChunkResCb(int retcode, ChunkHandle* ch,
                                      uint32_t lc_id, uint64_t op_seq) {
  ULOG_TRACE << "Op Seq " << op_seq << " openchunk cb";
  UDiskHandle* udisk_handle = LookupUDiskHandle(lc_id, 0, 0, false);
  if (udisk_handle == nullptr) {
    ULOG_ERROR << "can't find udisk handle when openchunk response, lc_id: "
               << lc_id << " op_seq: " << op_seq;
    return;
  }
  udisk_handle->DoOpenChunkResCb(op_seq, retcode, ch);
}

void ChunkLoopHandle::MessageWriteHandle(const ConnectionUeventPtr& conn) {
}

void ChunkLoopHandle::OutConnectionSuccessHandle(const ConnectionUeventPtr& conn) {
  ULOG_INFO << "connect to chunk success, peer addr:"
           << conn->GetPeerAddress().ToString();
}

void ChunkLoopHandle::OutConnectionCloseHandle(const ConnectionUeventPtr& conn) {
  ULOG_INFO << "connect to chunk closed, peer addr:"
             << conn->GetPeerAddress().ToString();
}

uevent::ConnectorUeventPtr ChunkLoopHandle::get_out_connector(const UsockAddress& addr) {
  this->GetLoop()->AssertInLoopThread();
  ConnectorUeventPtr ctor;
  int64_t conn_id = (static_cast<int64_t>(addr.IpNetEndian()) << 16) |
                     addr.PortNetEndian();
  auto it = chunk_connector_map_.find(conn_id);
  if (it == chunk_connector_map_.end()) {
    ctor = std::make_shared<ConnectorLibevent>(
        static_cast<uevent::PosixWorker*>(loop_->worker()), addr, "ChunkConnector");
    ctor->SetConnectionSuccessCb(
        std::bind(&ChunkLoopHandle::OutConnectionSuccessHandle, this,
        std::placeholders::_1));
    ctor->SetConnectionClosedCb(
        std::bind(&ChunkLoopHandle::OutConnectionCloseHandle, this,
        std::placeholders::_1));
    ctor->SetMessageReadCb(MessageReadHandle);
    ctor->Connect();
    chunk_connector_map_[conn_id] = ctor;
  } else {
    ctor = chunk_connector_map_[conn_id];
  }
  return ctor;
}

// 主动关闭到chunk的连接
void  ChunkLoopHandle::DestroyChunkConnection(int64_t conn_id) {
  auto it = chunk_connector_map_.find(conn_id);
  if (it != chunk_connector_map_.end()) {
    it->second->DestroyConnection();
  } else {
    ULOG_ERROR << "can't find connector of conn_id: " << conn_id;
  }
}

void ChunkLoopHandle::ArkConnectionSuccessHandle(const ConnectionUeventPtr& conn) {
  ULOG_INFO << "connect to ark success, peer addr:"
           << conn->GetPeerAddress().ToString();
}

void ChunkLoopHandle::ArkConnectionCloseHandle(const ConnectionUeventPtr& conn) {
  ULOG_INFO << "connect to ark closed, peer addr:"
             << conn->GetPeerAddress().ToString();
}

uevent::ConnectionUeventPtr ChunkLoopHandle::GetArkConnection(const UsockAddress& addr) {
  ConnectorUeventPtr ctor;
  uint64_t conn_id = (static_cast<uint64_t>(addr.IpNetEndian()) << 16) |
                     addr.PortNetEndian();
  auto it = ark_connector_map_.find(conn_id);
  if (it == ark_connector_map_.end()) {
    ctor = std::make_shared<ConnectorLibevent>(
        static_cast<uevent::PosixWorker*>(loop_->worker()), addr, "ArkConnector");
    ctor->SetConnectionSuccessCb(
        std::bind(&ChunkLoopHandle::ArkConnectionSuccessHandle, this,
        std::placeholders::_1));
    ctor->SetConnectionClosedCb(
        std::bind(&ChunkLoopHandle::ArkConnectionCloseHandle, this,
        std::placeholders::_1));
    ctor->Connect();
    ark_connector_map_[conn_id] = ctor;
  } else {
    ctor = ark_connector_map_[conn_id];
  }
  if (ctor->HasAvailableConnection() == false) {
    return uevent::ConnectionUeventPtr();
  } else {
    return ctor->GetConnection();
  }
}

int ChunkLoopHandle::GetPgRoute(uint32_t pg_id,
                               uint64_t version,
                               std::vector<ChunkRouteEntry>** chunk_routes) {
  if (pg_id + 1 > pg_route_cache_.size()) {
    pg_route_cache_.resize(pg_id + 1); //扩大的部分会调用默认的构造函数
  }
  if (pg_route_cache_[pg_id].version == version) {
    *chunk_routes = &pg_route_cache_[pg_id].chunk_routes;
    return 0;
  }
  // 如果version有变化，chunk路由就有可能变化，cache无效
  uint64_t cluster_version = cluster_map_.GetClusterVersion();
  std::vector<ucloud::udisk::ChunkInfoPb> chunk_infos;
  if (!cluster_map_.GetAvailableChunks(pg_id, chunk_infos)) {
    ULOG_ERROR << "pg not found in cluster map, pg_id: " << pg_id;
    *chunk_routes = nullptr;
    return -1;
  }
  if (chunk_infos.size() == 0) {
    ULOG_FATAL << "no avaiable chunks!!! pg_id: " << pg_id;
  }
  // 有可能所有的secondary chunk 都下线
  if (chunk_infos.size() == 1) {
    ULOG_WARN << "all secondary chunk  offline, pg_id: " << pg_id;
  }
  PgRouteEntry pg_entry;
  ChunkRouteEntry chunk_entry;
  pg_entry.version = cluster_version;
  for (uint32_t i = 1; i < chunk_infos.size(); i++) {
    UsockAddress addr(chunk_infos[i].ip(), chunk_infos[i].io_port(), false);
    chunk_entry.chunk_id = chunk_infos[i].id();
    // primary chunk id 也cache住, 因为如果不是主chunk要拒绝请求
    chunk_entry.primary_chunk_id = chunk_infos[0].id();
    chunk_entry.ctor = get_out_connector(addr);
    pg_entry.chunk_routes.push_back(chunk_entry);
  }
  pg_route_cache_[pg_id] = pg_entry;
  *chunk_routes = &pg_route_cache_[pg_id].chunk_routes;
  return 0;
}

int ChunkLoopHandle::GetHelaPgRoute(uint32_t pg_id,
                                    uint64_t version,
                                    std::vector<ChunkRouteEntry>** chunk_routes) {
  if (pg_id + 1 > hela_pg_route_cache_.size()) {
    hela_pg_route_cache_.resize(pg_id + 1); //扩大的部分会调用默认的构造函数
  }
  if (hela_pg_route_cache_[pg_id].version == version) {
    *chunk_routes = &hela_pg_route_cache_[pg_id].chunk_routes;
    return 0;
  }
  // 如果version有变化，chunk路由就有可能变化，cache无效
  uint64_t cluster_version = cluster_map_.GetClusterVersion();
  std::vector<ucloud::udisk::ChunkInfoPb> chunk_infos;
  if (!cluster_map_.GetWriteOnlyChunks(pg_id, chunk_infos)) {
    ULOG_ERROR << "pg not found in cluster map, pg_id: " << pg_id;
    *chunk_routes = nullptr;
    return -1;
  }
  // 至少也要获得一个online状态的主chunk
  if (chunk_infos.size() == 0) {
    ULOG_FATAL << "no avaiable chunks!!! pg_id: " << pg_id;
  }
  // 没有write only的chunk
  if (chunk_infos.size() == 1) {
    ULOG_TRACE << "no chunk write only, pg_id: " << pg_id;
  }
  PgRouteEntry pg_entry;
  ChunkRouteEntry chunk_entry;
  pg_entry.version = cluster_version;
  for (uint32_t i = 1; i < chunk_infos.size(); i++) {
    UsockAddress addr(chunk_infos[i].ip(), chunk_infos[i].io_port(), false);
    chunk_entry.chunk_id = chunk_infos[i].id();
    // primary chunk id 也cache住, 因为如果不是主chunk要拒绝请求
    chunk_entry.primary_chunk_id = chunk_infos[0].id();
    chunk_entry.ctor = get_out_connector(addr);
    pg_entry.chunk_routes.push_back(chunk_entry);
  }
  hela_pg_route_cache_[pg_id] = pg_entry;
  *chunk_routes = &hela_pg_route_cache_[pg_id].chunk_routes;
  return 0;
}

void ChunkLoopHandle::IoReportTimerCb() {
  // 上报io读写错误
  ReportLCIOError();

  uint64_t r_bytes = 0;
  uint64_t w_bytes = 0;
  uint64_t r_io_count = 0;
  uint64_t w_io_count = 0;
  uint64_t r_io_latency_max = 0;
  uint64_t w_io_latency_max = 0;
  uint64_t r_io_latency_count = 0;
  uint64_t w_io_latency_count = 0;
  uint64_t r_io_latency_avg = 0;
  uint64_t w_io_latency_avg = 0;
  uint32_t r_active_count = 0;
  uint32_t w_active_count = 0;
  std::string thread_name(base::CurrentThread::name());
  //清空管理线程中该线程的所有的udisk的统计信息
  g_context->manager_handle()->ClearUDiskStats(thread_name);

  if (head_ == nullptr) {
    ULOG_INFO << "No udisk in list";
    return;
  }

  UDiskHandle* handle = head_;
  do {
    ULOG_DEBUG << "static udisk " << handle->lc_id()
        << " address:" << handle << " head:" << head_
        << " next:" << handle->next();
    uint64_t lc_r_io_count = handle->r_io_count();
    uint64_t lc_w_io_count = handle->w_io_count();
    uint64_t lc_r_io_bw = handle->r_io_bytes();
    uint64_t lc_w_io_bw = handle->w_io_bytes();
    if (lc_r_io_count == 0 && lc_w_io_count == 0) {
      handle = handle->next();
      continue; // 跳过统计信息为0的udisk
    }
    if (lc_r_io_count != 0) {
      r_active_count++;
    }
    if (lc_w_io_count != 0) {
      w_active_count++;
    }
    r_bytes += handle->r_io_bytes();
    w_bytes += handle->w_io_bytes();
    r_io_count += handle->r_io_count();
    w_io_count += handle->w_io_count();
    r_io_latency_count += handle->r_io_latency();
    w_io_latency_count += handle->w_io_latency();
    if (r_io_latency_max  < handle->r_io_latency()) {
      r_io_latency_max = handle->r_io_latency();
    }
    if (w_io_latency_max  < handle->w_io_latency()) {
      w_io_latency_max = handle->w_io_latency();
    }

    uint64_t lc_r_iops = lc_r_io_count / io_report_interval_;
    uint64_t lc_w_iops = lc_w_io_count / io_report_interval_;
    uint64_t lc_r_bwps = lc_r_io_bw / io_report_interval_;
    uint64_t lc_w_bwps = lc_w_io_bw / io_report_interval_;
    g_context->manager_handle()->ReportUDiskIOCount(handle->lc_id(),
                                                    handle->lc_size(),
                                                    handle->current_io_depth(),
                                                    handle->io_depth_limit(),
                                                    lc_r_iops, lc_w_iops,
                                                    lc_r_bwps, lc_w_bwps,
                                                    thread_name);
    handle->reset_io_count(lc_r_iops, lc_w_iops);
    handle->reset_io_bytes(lc_r_bwps, lc_w_bwps);
    handle->reset_io_latency();

    handle = handle->next();
  } while (handle != head_);

  uint64_t r_iops = r_io_count / io_report_interval_;
  uint64_t w_iops = w_io_count / io_report_interval_;
  uint64_t r_byteps = r_bytes / io_report_interval_;
  uint64_t w_byteps = w_bytes / io_report_interval_;
  if (r_active_count > 0) {
    r_io_latency_avg = r_io_latency_count / r_active_count;
  }
  if (w_active_count > 0) {
    w_io_latency_avg = w_io_latency_count / w_active_count;
  }

  ULOG_DEBUG<<"r_io_latency_avg:"<<r_io_latency_avg
      <<" r_active_count:"<<r_active_count
      <<" w_io_latency_avg:"<<w_io_latency_avg
      <<" w_active_count:"<<w_active_count;

  g_context->manager_handle()->ReportThreadIOCount(r_byteps, r_iops,
                                                   r_io_latency_max, r_io_latency_avg,
                                                   w_byteps, w_iops,
                                                   w_io_latency_max, w_io_latency_avg,
                                                   thread_name);
}

void ChunkLoopHandle::RecycleUDiskHandleTimerCb() {
  ULOG_INFO << "recycle udisk handle begin";
  if (head_ == nullptr) {
    ULOG_INFO << "No udisk in list";
    return;
  }

  UDiskHandle* prev = tail_;
  UDiskHandle* cur = head_;
  UDiskHandle* next = nullptr;
  bool is_delete_head = false;
  do {
    if (cur->is_inuse()) {
      cur->reset_inuse_flag();
      prev = cur;
      cur = cur->next();
      is_delete_head = false;
    } else {
      // 检测时间段内udisk handle没有io
      // 则认为这个udisk handle不活动，销毁
      ULOG_INFO << "will recycle udisk handle, lc id: "
               << cur->lc_id();

      is_delete_head = (cur == head_ ? true : false);
      next = DeleteUDiskHandle(cur, prev);
      udisks_[cur->lc_id()] = nullptr;
      delete cur;

      // 已将所有udisk删除完毕
      if (next == nullptr) {
        return;
      }

      cur = next;
    }
  } while (is_delete_head || cur != head_);
}

void ChunkLoopHandle::DispatchNextPendingIO(UDiskHandle* udisk_handle) {
  if (UNLIKELY(udisk_handle == nullptr)) {
    ULOG_WARN << "Invalid udisk handle!";
    return;
  }

  // 等待所有udisk中处于inflying队列io的数量降低到允许派发的io队列深度
  if (dispatch_io_cur_total_ > dispatch_io_depth_) {
    ULOG_DEBUG << "The current io depth:" << dispatch_io_cur_total_
              << " > dispatch io number:" << dispatch_io_depth_;

    if (LIKELY(dispatch_io_cur_total_ > 0)) {
      --dispatch_io_cur_total_;
    }
    return;
  }

  UDiskHandle* next_handle = udisk_handle;
  do {
    next_handle = next_handle->next();
    // 循环查找到一个可派发的pending队列中的io，则退出循环
    // 若循环查找完所有的udisk，仍未找到可派发的pending，也退出循环
    if (next_handle->DispatchNextPendingIO()) {
      ULOG_TRACE << "Dispatch a pending io, "
                << "dispatch_io_cur_total:" << dispatch_io_cur_total_
                << ",dispatch_io_depth:" << dispatch_io_depth_;
      return;
    }
  } while (next_handle != udisk_handle);

  if (dispatch_io_cur_total_ > 0) {
    ULOG_TRACE << "Not dispatch pending io, dispatch_io_cur_total: "
              << dispatch_io_cur_total_;
    --dispatch_io_cur_total_;
  }
}

void ChunkLoopHandle::IOTimerCb() {
  if (head_ == nullptr) {
    return;
  }

  UDiskHandle* handle = head_;
  do {
    handle->IOTimerCb();
    handle = handle->next();
  } while (handle != head_);
}

void ChunkLoopHandle::ClearUDiskOpRequstByConnId(int64_t conn_id) {
  if (head_ == nullptr) {
    return;
  }

  UDiskHandle* handle = head_;
  do {
    handle->ClearOpRequstByConnId(conn_id);
    handle = handle->next();
  } while (handle != head_);
}

void ChunkLoopHandle::AddUDiskHandle(UDiskHandle* udisk) {
    if (tail_ == nullptr) {
      tail_ = udisk;
    } else {
      udisk->set_next(head_);
    }

    head_ = udisk;
    tail_->set_next(head_);
}

UDiskHandle* ChunkLoopHandle::DeleteUDiskHandle(UDiskHandle* handle,
                                                UDiskHandle* prev) {
  if (head_ == nullptr) {
     ULOG_ERROR << "No udisk in list";
     return nullptr;
  }

  if (prev == nullptr) {
    prev = tail_;
    UDiskHandle* cur = head_;
    do {
      if (cur == handle) {
         break;
      }

      prev = cur;
      cur = cur->next();
    } while (cur != head_);

    ULOG_ERROR << "Can't find udisk:" <<  handle->lc_id() << " in list";
    return nullptr;
  }

  UDiskHandle* next = handle->next();
  prev->set_next(next);
  // 链表中最后一个udisk被删除
  if (tail_ == head_) {
    head_ = tail_ = nullptr;
    return nullptr;
  } else if (handle == head_) {
    head_ = next;
  } else if (handle == tail_) {
    tail_ = prev;
  }

  return next;
}

void ChunkLoopHandle::ReportLCIOError() {
  if (io_error_container_.IsEmpty()) {
    return;
  }

  g_context->manager_handle()->ReportLCIOError(io_error_container_.lc_io_errors());
  io_error_container_.Clear();
}

void ChunkLoopHandle::AddLCIOError(uint32_t lc_id,
                                   IOErrorContainer::IO_ERROR_TYPE error_type,
                                   IOErrorContainer::IO_OP_TYPE op_type) {
  io_error_container_.Add(lc_id, error_type, op_type);
}

uint64_t ChunkLoopHandle::get_next_op_seq(uint32_t pg_id) {
  if (g_context->journal_enable()) {
    auto udisk_journal = g_context->udisk_journal(pg_id);
    uint64_t seqno = UINT64_MAX;
    if (journal_engine_[pg_id] && journal_engine_[pg_id]->IsInit()) {
      seqno = udisk_journal->last_seq.fetch_add(1);
    }
    return seqno; 
  } else {
    return ++last_op_seq_;
  }
}

void ChunkLoopHandle::JournalRecover(
    const std::vector<journal::PGJournalMeta*> journal_metas) {
  for (auto item : journal_metas) {
    assert(item && (journal_engine_[item->pg_id] == nullptr));
    journal_engine_[item->pg_id] = new journal::JournalEngine(this, item->pg_id);
    journal_engine_[item->pg_id]->EntryRecover(item);
    engine_list_.push_back(journal_engine_[item->pg_id]);
  }

  loop_->RunEvery(0.01, // 精度10ms
      std::bind(&ChunkLoopHandle::JournalTimerCb, this));
}

void ChunkLoopHandle::JournalSwapMemTableReq(uevent::EventLoop* src_loop,
                                             uint32_t pg_id) {
  assert(journal_engine_[pg_id]);
  journal_engine_[pg_id]->SwapMemTableReq(src_loop);
}

void ChunkLoopHandle::JournalSwapMemTableRes(uevent::EventLoop* src_loop,
                                             uint32_t jpc_id, 
                                             uint32_t pg_id) {
  assert(journal_engine_[pg_id]);
  journal_engine_[pg_id]->SwapMemTableRes(src_loop, jpc_id);
}

void ChunkLoopHandle::ClearJournalOpRequestByConnId(int64_t conn_id) {
  for (uint32_t pg_id = 0; pg_id < MAX_PG_NUM; ++ pg_id) {
    if (journal_engine_[pg_id] == nullptr) {
      continue;
    }
    journal_engine_[pg_id]->ClearJournalOpRequest(conn_id);
  }
}

void ChunkLoopHandle::JournalTimerCb() {
  for (auto engine : engine_list_) {
    assert(engine);
    engine->TimerCb();
  }
}

int ChunkLoopHandle::MigrateJournalRequest(OpRequest* op, 
                              const IOMeta& meta,
                              uint32_t pg_id,
                              uint32_t lc_size,
                              const ucloud::udisk::MigratePcMeta& migrate_pc) {
  this->GetLoop()->AssertInLoopThread();
  assert(migrate_manager_ != nullptr);
  auto retcode = migrate_manager_->DoMigrateJournalRemoteRequest(op, meta, 
                                                    pg_id, lc_size, migrate_pc);
  if (retcode != 0) {
    op->DecRefs();
  }
  return retcode;
}

void ChunkLoopHandle::ReplicaRemoteRequest(OpRequest* op) {
  if (!g_context->journal_enable()) {
    return;
  }
  const common::GateIORequestHead* gate_hdr = 
      (const common::GateIORequestHead*)op->sub_msg_hdr_offset();
  assert(UDISK_PC_COUNT_GB(gate_hdr->lc_size) > gate_hdr->pc_no);
  auto journal_engine = journal_engine_[gate_hdr->pg_id];
  assert(journal_engine && journal_engine->IsInit());
  uevent::ConnectorUeventPtr ctor = nullptr;
  ucloud::udisk::MigratePcMeta migrate_pc;
  if (journal_engine->CheckDualWrite(gate_hdr->lc_id, gate_hdr->pc_no, 
                                     gate_hdr->offset, &migrate_pc, &ctor)) {
    migrate_manager_->ReplicaRemoteRequest(op, migrate_pc, ctor);
  }
}

void ChunkLoopHandle::ReplicaRemoteResponse(const common::MigrateHead* hdr) {
  UDiskHandle* udisk_handle = LookupUDiskHandle(hdr->reserved_lc_id, 0, 0, false);
  if (udisk_handle == nullptr) {
    ULOG_ERROR << "can't find udisk handle when remote response, lc_id: "
              << hdr->lc_id << ", maybe connection closed";
    return;
  }
  ULOG_DEBUG << "Recv chunk response=" << DumpMigrateHead(*hdr);
  udisk_handle->DoReplicaRemoteResponse(hdr);
}

//向manager线程发送心跳
void ChunkLoopHandle::ManagerHeartbeatTimerCb() {
  pid_t thread_id(base::CurrentThread::tid());
  std::string thread_name(base::CurrentThread::name());
  ULOG_DEBUG << "thread_id: " << thread_id << "\t thread_name: " << thread_name;

  g_context->manager_handle()->ReportThreadInfo(thread_id, thread_name);
}

} // end of ns chunk
} // end of ns udisk
