#include "snapshot.h"
#include <sstream>
#include "access_context.h"
#include "access_loop_handle.h"
#include "umessage_common.h"
#include "umessage.h"
#include "string_util.h"
#include "likely.h"
#include "umongo.h"
#include "access_umongo.h"
#include "do_get_snapshot_extent_info.h"
#include "do_get_lc_extent_info.h"

using namespace udisk::access;
using namespace udisk::common;
using namespace ucloud::ubs2;
using namespace ucloud::udisk;
using namespace ucloud::udatabase;
using namespace std::placeholders;

void SnapshotHandle::Timeout(const std::string& task) {
  LOG_ERROR << "Snapshot time out, session=" << session_no_
            << ", task=" << task;
  if (task == FORWARD_PEER_LABEL) {  // 转发到其他access超时
    --forward_ref_;
    if (forward_ref_ == 0 && !responsed_) {
      SendResponse(-EC_UBS_TIMEOUT, "snapshot time out");
    } else {
      // 转发到peer超时，且不是最后一个回包，do nothing
    }
  } else {
    SendResponse(-EC_UBS_TIMEOUT, "snapshot time out");
  }
}

void SnapshotHandle::SendResponse(uint32_t retcode,
                                  const std::string& message) {
  resp_body_->mutable_rc()->set_retcode(retcode);
  resp_body_->mutable_rc()->set_error_message(message);
  if (retcode == 0) {
    resp_body_->set_snapshot_id(req_.custom_id());
  }
  LOG_INFO << response_.DebugString();
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void SnapshotHandle::EntryInit(const uevent::ConnectionUeventPtr& conn,
                               ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  conn_ = conn;
  session_no_ = um->head().session_no();
  request_ = *um;
  MakeResponse(&request_, ucloud::ubs2::SNAPSHOT_RESPONSE, &response_);
  resp_body_ = response_.mutable_body()->MutableExtension(
      ucloud::ubs2::snapshot_response);
  req_ = request_.body().GetExtension(ucloud::ubs2::snapshot_request);
  if (!req_.has_custom_id()) {
    LOG_ERROR << "lack snapshot id";
    SendResponse(-ucloud::ubs2::EC_UBS_INVALID_ARGUMENTS, "lack snapshot id");
    return;
  }
  if (!GetLcSetRequest()) {
    LOG_ERROR << "get set request fail";
    SendResponse(-ucloud::ubs2::EC_UBS_INTERNAL_ERROR, "get set request fail");
    return;
  }
}

bool SnapshotHandle::GetLcSetRequest() {
  ucloud::udisk::GetLCExtentInfoPb lc_extent_req;
  lc_extent_req.add_extern_id(req_.ubs_id());
  std::shared_ptr<SnapshotHandle> this_ptr =
      std::dynamic_pointer_cast<SnapshotHandle>(shared_from_this());
  std::shared_ptr<DoGetLCExtentInfoHandle> do_get_lc_extent_info_handle =
      std::make_shared<DoGetLCExtentInfoHandle>(
          std::bind(&SnapshotHandle::GetLcSetResponse, this_ptr,
                    std::placeholders::_1, std::placeholders::_2),
          session_no_, false);
  do_get_lc_extent_info_handle->Start(lc_extent_req);
  return true;
}

void SnapshotHandle::GetLcSetResponse(
    const ucloud::ResponseCode& rc,
    const std::list<ucloud::udisk::LCExtentInfoPb>& result) {
  if (rc.retcode() != 0) {
    LOG_ERROR << "get set error. msg=" << rc.error_message()
              << ", code=" << rc.retcode();
    SendResponse(rc.retcode(), rc.error_message());
    return;
  }

  if (result.size() > 0) {
    if (UNLIKELY(result.size() != 1)) {
      LOG_ERROR << "there are more than one lc id in udisk_access";
      SendResponse(-1, "get set error");
      return;
    }

    const auto& it = result.begin();
    if (UNLIKELY(it->extent_info_size() <= 0)) {
      LOG_ERROR << "get set error. not extent info in udisk_access";
      SendResponse(-1, "get set error");
      return;
    }

    for (int32_t j = 0; j < it->extent_info_size(); ++j) {
      const ucloud::udisk::ExtentInfoPb& extent = it->extent_info(j);
      set_id_ = extent.set_id();
      break;
    }

    LOG_INFO << "get set_id=" << set_id_ << ", lc_id=" << req_.ubs_id();

    CheckMigration();
    return;
  }

  if (request_.head().call_purpose() == FORWARD_PEER_LABEL) {
    // 表示从access转发来的请求，只需要本地查找
    LOG_ERROR << "cannot find this lc_id=" << req_.ubs_id();
    SendResponse(-EC_UBS_NO_SUCH_SNAPSHOT, "cannot find this lc_id");
    return;
  }

  /* 没有满足条件的Set, 跨机房查找 */
  vector<string> access_keys;
  const std::string patten("^access_[0-9a-z]{1,}$");
  g_context->mutable_config()->RawEnumKeys(UDiskConfig::kSectionName, patten,
                                           access_keys);
  for (auto& access_key : access_keys) {
    if (access_key == ("access_" + g_context->config().my_region())) {
      continue;
    }
    // 发送成功才加引用
    if (ForwardPeerRequest(access_key)) {
      ++forward_ref_;
    }
  }

  /* 没有其他机房 */
  if (0 == forward_ref_) {
    LOG_ERROR << "cannot find this lc_id=" << req_.ubs_id();
    SendResponse(-ucloud::ubs2::EC_UBS_NO_SUCH_SNAPSHOT,
                 "cannot find this lc_id");
    return;
  }
}

bool SnapshotHandle::ForwardPeerRequest(const std::string& access_key) {
  std::string access_name = g_context->mutable_config()->RawGetValue(
      ConfigParser::kSectionName, access_key);
  auto result = g_context->GetIPPort(access_key);
  std::string peer_ip = result.first;
  uint32_t peer_port = result.second;
  LOG_INFO << "Forward request to " << access_key
           << ", forward ref=" << forward_ref_ << ", peer_ip=" << peer_ip
           << ", peer_port=" << peer_port;
  if (peer_ip.empty() || peer_port == 0) {
    return false;
  }
  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  uevent::ConnectionUeventPtr conn =
      handle->GetOutConnection(peer_ip, peer_port);
  if (conn->IsClosed()) {
    return false;
  }

  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&request_, flowno, session_no_, request_.head().message_type(),
                0, false, objid, 0, FORWARD_PEER_LABEL, NULL, NULL);
  std::shared_ptr<SnapshotHandle> this_ptr =
      std::dynamic_pointer_cast<SnapshotHandle>(shared_from_this());
  LOG_INFO << request_.DebugString();
  uevent::MessageUtil::SendPbRequest(
      conn, request_,
      std::bind(&SnapshotHandle::ForwardPeerResponse, this_ptr, _1),
      std::bind(&SnapshotHandle::Timeout, this_ptr, FORWARD_PEER_LABEL),
      g_context->config().forward_timeout());
  return true;
}

void SnapshotHandle::ForwardPeerResponse(ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  --forward_ref_;
  const ucloud::ubs2::SnapshotResponse& res =
      um->body().GetExtension(ucloud::ubs2::snapshot_response);
  if (res.rc().retcode() == 0) {  // 任意peer返回成功，直接返回
    resp_body_->CopyFrom(res);
    SendResponse(0, "success");
    responsed_ = true;
    LOG_INFO << "do snapshot from peer success.";
    return;
  }
  LOG_ERROR << "do snapshot fail. errmsg=" << res.rc().error_message()
            << ", retcode=" << res.rc().retcode()
            << ", forward_ref=" << forward_ref_;
  if (forward_ref_ == 0 && !responsed_) {  // 所有peer都没有查到
    SendResponse(-EC_UBS_NO_SUCH_SNAPSHOT,
                 "cannot find this snapshot_id or lc_id");
    return;
  }
}

void SnapshotHandle::CheckMigration() {
  std::pair<std::string, int> result = g_context->GetIPPort(kUmongoName);
  std::string umongo_ip = result.first;
  uint32_t umongo_port = result.second;
  if (umongo_ip.empty() || umongo_port == 0) {
    LOG_ERROR << "choose server of umongo fail";
    SendResponse(-ucloud::ubs2::EC_UBS_INTERNAL_ERROR,
                 "choose server of umongo fail");
    return;
  }
  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  uevent::ConnectionUeventPtr conn =
      handle->GetOutConnection(umongo_ip, umongo_port);
  if (conn->IsClosed()) {
    LOG_ERROR << "can not get connection of umongo";
    SendResponse(-EC_UBS_INTERNAL_ERROR, "can not get connection of umongo");
    return;
  }
  ucloud::UMessage msg;
  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&msg, flowno, session_no_,
                ucloud::umgogate::EXECUTE_MGO_REQUEST, 0, false, objid, 0,
                "CheckMigration", NULL, NULL);
  ucloud::umgogate::ExecuteMgoRequest* req =
      msg.mutable_body()->MutableExtension(
          ucloud::umgogate::execute_mgo_request);
  construct_get_migrate_udisk_request(req, req_.ubs_id());
  std::shared_ptr<SnapshotHandle> this_ptr =
      std::dynamic_pointer_cast<SnapshotHandle>(shared_from_this());
  LOG_INFO << msg.DebugString();
  uevent::MessageUtil::SendPbRequest(
      conn, msg,
      std::bind(&SnapshotHandle::CheckMigrationResponse, this_ptr, _1),
      std::bind(&SnapshotHandle::Timeout, this_ptr, "CheckMigration"),
      g_context->config().db_timeout());
  return;
}

void SnapshotHandle::CheckMigrationResponse(ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  assert(um->head().message_type() == ucloud::umgogate::EXECUTE_MGO_RESPONSE);
  assert(um->body().HasExtension(ucloud::umgogate::execute_mgo_response));
  const ucloud::umgogate::ExecuteMgoResponse& res =
      um->body().GetExtension(ucloud::umgogate::execute_mgo_response);
  // 查找到迁移的盘
  if (!res.op_find_rsp().notfound()) {
    ucloud::udisk::MigrateUDiskTaskPb migrate_udisk;
    if (parse_get_migrate_udisk_request(&res, migrate_udisk) < 0) {
      LOG_ERROR << "parse mongo response error, extern_id=" << req_.ubs_id();
      SendResponse(-EC_UBS_INTERNAL_ERROR, "migrate udisk parse fail");
      return;
    }
    // 迁移中禁止做快照
    if (migrate_udisk.status() == ucloud::udisk::MIGRATE_INPROCESS) {
      LOG_ERROR << "udisk in migration, extern_id=" << req_.ubs_id();
      SendResponse(-ucloud::ubs2::EC_UBS_INTERNAL_ERROR, "udisk in migration");
      return;
    }
    LOG_DEBUG << "CheckMigration response: extern_id="
              << migrate_udisk.extern_id()
              << ", status=" << migrate_udisk.status();
  }
  CheckSnapshotId();
  return;
}

void SnapshotHandle::CheckSnapshotId() {
  ucloud::udisk::GetSnapshotExtentInfoPb snapshot_extent_req;
  snapshot_extent_req.add_extern_id(req_.custom_id());
  std::shared_ptr<SnapshotHandle> this_ptr =
      std::dynamic_pointer_cast<SnapshotHandle>(shared_from_this());
  std::shared_ptr<DoGetSnapshotExtentInfoHandle>
      do_get_snapshot_extent_info_handle =
          std::make_shared<DoGetSnapshotExtentInfoHandle>(
              std::bind(&SnapshotHandle::CheckSnapshotIdResponse, this_ptr,
                        std::placeholders::_1, std::placeholders::_2),
              session_no_, false);
  do_get_snapshot_extent_info_handle->Start(snapshot_extent_req);
}

void SnapshotHandle::CheckSnapshotIdResponse(
    const ucloud::ResponseCode& rc,
    const std::list<ucloud::udisk::SnapshotExtentInfoPb>& result) {
  if (rc.retcode() != 0) {
    LOG_ERROR << "check snapshot id error. msg=" << rc.error_message()
              << ", code=" << rc.retcode();
    SendResponse(rc.retcode(), rc.error_message());
    return;
  }

  if (result.size() > 0) {
    LOG_ERROR << "The SnapshotID has already used, snapshot id: "
              << req_.custom_id();
    SendResponse(-EC_UBS_INVALID_ARGUMENTS, "The SnapshotID has already used");
    return;
  }
  if (!ForwardMasterRequest()) {
    LOG_ERROR << "forward req fail, lc_id=" << req_.ubs_id();
    SendResponse(-EC_UDISK_INTERNAL_ERROR, "forward req fail");
    return;
  }
  LOG_INFO << "Forward request to master... lc_id=" << req_.ubs_id();
  return;
}

bool SnapshotHandle::ForwardMasterRequest() {
  std::stringstream stream;
  stream << "set" << set_id_;
  std::string set_key = stream.str();
  std::string set_name = g_context->mutable_config()->RawGetValue(
      ConfigParser::kSectionName, set_key);
  LOG_INFO << "Forward request " << set_key;

  std::pair<std::string, int> result = g_context->GetIPPort(set_key);
  std::string set_ip = result.first;
  uint32_t set_port = result.second;
  if (set_ip.empty() || set_port == 0) {
    return false;
  }
  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  uevent::ConnectionUeventPtr conn = handle->GetOutConnection(set_ip, set_port);
  if (conn->IsClosed()) {
    return false;
  }

  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&request_, flowno, session_no_, request_.head().message_type(),
                0, false, objid, 0, "ForwardMaster", NULL, NULL);
  std::shared_ptr<SnapshotHandle> this_ptr =
      std::dynamic_pointer_cast<SnapshotHandle>(shared_from_this());
  LOG_INFO << request_.DebugString();
  uevent::MessageUtil::SendPbRequest(
      conn, request_,
      std::bind(&SnapshotHandle::ForwardMasterResponse, this_ptr, _1),
      std::bind(&SnapshotHandle::Timeout, this_ptr, "ForwardMaster"),
      g_context->config().forward_timeout());
  return true;
}

void SnapshotHandle::ForwardMasterResponse(ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  const ucloud::ubs2::SnapshotResponse& res =
      um->body().GetExtension(ucloud::ubs2::snapshot_response);
  if (res.rc().retcode() != 0) {
    LOG_ERROR << "do snapshot fail. errmsg=" << res.rc().error_message()
              << ", retcode=" << res.rc().retcode();
    SendResponse(res.rc().retcode(), res.rc().error_message());
    return;
  }
  UpdateDB();
  return;
}

void SnapshotHandle::UpdateDB() {
  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  uevent::ConnectionUeventPtr conn = handle->GetOutConnection(kUmongoName);
  if (!conn) {
    LOG_ERROR << "can not get connection of umongo";
    SendResponse(-EC_UBS_INTERNAL_ERROR, "can not get connection of umongo");
    return;
  }

  ucloud::UMessage msg;
  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&msg, flowno, session_no_,
                ucloud::umgogate::EXECUTE_MGO_REQUEST, 0, false, objid, 0,
                "UpdateDB", NULL, NULL);
  ucloud::umgogate::ExecuteMgoRequest* req =
      msg.mutable_body()->MutableExtension(
          ucloud::umgogate::execute_mgo_request);

  vector<ucloud::udisk::ExtentInfoPb> extent_info;
  ucloud::udisk::ExtentInfoPb extent;
  extent.set_id(0);
  extent.set_set_id(set_id_);
  extent_info.push_back(extent);
  construct_insert_snapshot_extent_info_request(
      g_context->config().db_name(), req, req_.custom_id(), req_.account_id(),
      req_.company_id(), extent_info);
  std::shared_ptr<SnapshotHandle> this_ptr =
      std::dynamic_pointer_cast<SnapshotHandle>(shared_from_this());
  LOG_INFO << msg.DebugString();
  uevent::MessageUtil::SendPbRequest(
      conn, msg, std::bind(&SnapshotHandle::UpdateDBResponse, this_ptr, _1),
      std::bind(&SnapshotHandle::Timeout, this_ptr, "UpdateDB"),
      g_context->config().db_timeout());

  return;
}

void SnapshotHandle::UpdateDBResponse(ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  const ucloud::umgogate::ExecuteMgoResponse& res =
      um->body().GetExtension(ucloud::umgogate::execute_mgo_response);
  if (res.rc().retcode() != 0) {
    LOG_ERROR << "update db fail, msg=" << res.rc().error_message()
              << ", code=" << res.rc().retcode();
    SendResponse(res.rc().retcode(), res.rc().error_message());
    return;
  }

  SendResponse(0, "");
}
