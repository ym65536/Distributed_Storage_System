#ifndef UDISK_ACCESS_LIST_UBS_BASE_H
#define UDISK_ACCESS_LIST_UBS_BASE_H

#include <string>
#include <vector>
#include <set>
#include <list>
#include "pb_request_handle.h"
#include "message_util.h"
#include "udisk_message.h"
#include "ubs2_message.h"

namespace udisk {
namespace access {

class ListUBSBaseHandle : public uevent::PbRequestHandle {
 public:
  ListUBSBaseHandle(const std::string& task) : task_(task) {}
  virtual ~ListUBSBaseHandle() {}

  void SendResponse(uint32_t retcode, const std::string& message);
  void ListDisksTimeout();

  bool GetSetRequest();
  void GetSetResponse(const ucloud::ResponseCode& rc,
                      const std::list<ucloud::udisk::SetInfoPb>& result);
  void GetSetByLCResponse(
      const ucloud::ResponseCode& rc,
      const std::list<ucloud::udisk::LCExtentInfoPb>& result);
  void ListDisks();
  void ListDisksResponse(ucloud::UMessage* msg);
  void ProcessLcs();

  virtual ucloud::ResponseCode* GetRespCode() = 0;
  virtual void ConstructGetSetParam(
      bool* is_seq_req, ucloud::udisk::GetSetInfoPb* set_req,
      ucloud::udisk::GetLCExtentInfoPb* lc_extent_req) = 0;
  virtual void ConstructListDisksParam(ucloud::UMessage* msg) = 0;
  virtual bool ParseListDisksResponse(ucloud::UMessage* msg) = 0;
  virtual bool ProcessLc(uint32_t count, ucloud::ubs2::LogicalChunk* lc) = 0;

 protected:
  std::string task_;
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage request_;
  ucloud::UMessage response_;
  std::string session_no_;
  uint32_t cur_set_id_;
  std::set<uint32_t> set_ids_;
  std::string ids_;

  typedef std::map<uint32_t, std::vector<ucloud::ubs2::LogicalChunk>,
                   std::greater<uint32_t> > SetUDiskMap;
  SetUDiskMap set_udisks_;
};

};  // end of ns access
};  // end of ns udisk

#endif
