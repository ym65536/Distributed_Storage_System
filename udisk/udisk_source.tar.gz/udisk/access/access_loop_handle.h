#ifndef UDISK_ACCESS_LOOP_HANDLE_H_
#define UDISK_ACCESS_LOOP_HANDLE_H_

#include <functional>
#include <unordered_map>
#include <map>
#include "connector_libevent.h"
#include "uevent.h"
#include "udisk_types.h"
#include "umessage.h"

namespace udisk {
namespace access {
struct SetCapacity {
  int64_t calculate_cap;
  uint64_t heartbeat_cap;
  uint64_t total_cap;
  SetCapacity() : calculate_cap(0), heartbeat_cap(0), total_cap(0) {}
};

class AccessLoopHandle : public uevent::LoopHandle {
 public:
  explicit AccessLoopHandle(uevent::UeventLoop* loop);
  virtual ~AccessLoopHandle();

  static uevent::LoopHandle* CreateMyself(uevent::UeventLoop* loop) {
    return reinterpret_cast<uevent::LoopHandle*>(new AccessLoopHandle(loop));
  }

  static void ConnectionSuccessHandle(const uevent::ConnectionUeventPtr& conn);
  static void ConnectionClosedHandle(const uevent::ConnectionUeventPtr& conn);

  void OutConnSuccessCb(const uevent::ConnectionUeventPtr& conn);
  void OutConnCloseCb(const std::string& name,
                      const uevent::ConnectionUeventPtr& conn);
  const uevent::ConnectionUeventPtr& GetOutConnection(const std::string& ip,
                                                      int port);
  uevent::ConnectionUeventPtr GetOutConnection(const std::string& name);

  const SetCapacity& GetSetCapacity(int set_id);
  void SetSetCapacity(int set_id, int64_t calculate_cap = 0,
                      uint64_t heartbeat_cap = 0, uint64_t total_cap = 0);

 private:
  void DoGetSetCapacity();
  std::string DumpSetCapacity() const;
  std::unordered_map<std::string, uevent::ConnectorUeventPtr> ctors_;
  std::map<int, SetCapacity> set_cap_map_;
};

};  // namespace access
};  // namespace udisk

#endif
