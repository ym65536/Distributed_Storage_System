#ifndef UDISK_ACCESS_GET_LOGIN_GATE_H
#define UDISK_ACCESS_GET_LOGIN_GATE_H

#include <string>
#include <vector>
#include <list>
#include "uevent.h"
#include "pb_request_handle.h"
#include "message_util.h"
#include "udisk_message.h"

namespace udisk {
namespace access {

class GetLoginGateHandle : public uevent::PbRequestHandle {
 public:
  GetLoginGateHandle(uevent::UeventLoop* loop) {}
  virtual ~GetLoginGateHandle() {}

  MYSELF_CREATE(GetLoginGateHandle);

  void SendResponse(uint32_t retcode, const std::string& message);
  void Timeout(const std::string& task);
  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         ucloud::UMessage* um);

  bool GetSetRequest();
  void GetSetResponse(const ucloud::ResponseCode& rc,
                      const std::list<ucloud::udisk::LCExtentInfoPb>& result);

  bool ForwardPeerRequest(const std::string& access_key);
  void ForwardPeerResponse(ucloud::UMessage* um);

  bool CheckMigrateRequest();
  void CheckMigrateResponse(ucloud::UMessage* um);

  bool ForwardMasterRequest();
  void ForwardMasterResponse(ucloud::UMessage* um);

 private:
  uevent::ConnectionUeventPtr conn_;
  std::vector<ucloud::udisk::LCInfoPb> lcs_;

  ucloud::UMessage request_;
  ucloud::udisk::GetLoginGateRequest req_;
  ucloud::UMessage response_;
  ucloud::udisk::GetLoginGateResponse* resp_body_;
  std::string session_no_;
  uint32_t forward_ref_ = 0;
  int32_t set_id_ = 0;
  bool responsed_ = false;
};

};  // end of ns access
};  // end of ns udisk

#endif
