#include "list_snapshot_total_count.h"
#include <sstream>
#include "logging.h"
#include "timestamp.h"
#include "access_context.h"
#include "access_loop_handle.h"
#include "string_util.h"
#include "likely.h"
#include "do_get_set_info.h"
#include "do_get_lc_extent_info.h"

using namespace udisk::access;
using namespace udisk::common;
using namespace ucloud::ubs2;
using namespace ucloud::udisk;
using namespace ucloud::udatabase;
using namespace std::placeholders;

void ListSnapshotTotalCountHandle::Timeout() {
  expect_response_num_--;
  is_fail_ = true;
  LOG_ERROR << "list snapshot total count time out, session=" << session_no_;
  if (expect_response_num_ == 0) {
    SendResponse(-EC_UBS_TIMEOUT, "ListSnapshotTotalCountHandle time out");
  }
}

void ListSnapshotTotalCountHandle::SendResponse(uint32_t retcode,
                                                const std::string& message) {
  resp_body_->mutable_rc()->set_retcode(retcode);
  resp_body_->mutable_rc()->set_error_message(message);
  if (retcode == 0) {
    resp_body_->set_total_count(snapshot_total_count_);
  }
  LOG_INFO << response_.DebugString();
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void ListSnapshotTotalCountHandle::EntryInit(
    const uevent::ConnectionUeventPtr& conn, ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  conn_ = conn;
  session_no_ = um->head().session_no();
  request_ = *um;
  MakeResponse(&request_, ucloud::ubs2::LIST_SNAPSHOT_TOTAL_COUNT_RESPONSE,
               &response_);
  resp_body_ = response_.mutable_body()->MutableExtension(
      ucloud::ubs2::list_snapshot_total_count_response);
  req_ = request_.body().GetExtension(
      ucloud::ubs2::list_snapshot_total_count_request);
  if (req_.has_ubs_id()) {
    GetLcSetRequest();
  } else {
    GetValidSetRequest();
  }
}

void ListSnapshotTotalCountHandle::GetLcSetRequest() {
  ucloud::udisk::GetLCExtentInfoPb lc_extent_req;
  lc_extent_req.add_extern_id(req_.ubs_id());
  std::shared_ptr<ListSnapshotTotalCountHandle> this_ptr =
      std::dynamic_pointer_cast<ListSnapshotTotalCountHandle>(
          shared_from_this());
  std::shared_ptr<DoGetLCExtentInfoHandle> do_get_lc_extent_info_handle =
      std::make_shared<DoGetLCExtentInfoHandle>(
          std::bind(&ListSnapshotTotalCountHandle::GetLcSetResponse, this_ptr,
                    std::placeholders::_1, std::placeholders::_2),
          session_no_, false);
  do_get_lc_extent_info_handle->Start(lc_extent_req);
}

void ListSnapshotTotalCountHandle::GetLcSetResponse(
    const ucloud::ResponseCode& rc,
    const std::list<ucloud::udisk::LCExtentInfoPb>& result) {
  if (rc.retcode() != 0) {
    LOG_ERROR << "get set error. msg=" << rc.error_message()
              << ", code=" << rc.retcode();
    SendResponse(rc.retcode(), rc.error_message());
    return;
  }

  if (result.size() > 0) {
    if (UNLIKELY(result.size() != 1)) {
      LOG_ERROR << "there are more than one lc id in udisk_access";
      SendResponse(-ucloud::ubs2::EC_UBS_INTERNAL_ERROR, "get set error");
      return;
    }

    const auto& it = result.begin();
    if (UNLIKELY(it->extent_info_size() <= 0)) {
      LOG_ERROR << "get set error. not extent info in udisk_access";
      SendResponse(-ucloud::ubs2::EC_UBS_INTERNAL_ERROR, "get set error");
      return;
    }
    int set_id;
    for (int32_t j = 0; j < it->extent_info_size(); ++j) {
      const ucloud::udisk::ExtentInfoPb& extent = it->extent_info(j);
      set_id = extent.set_id();
      break;
    }

    LOG_INFO << "get set_id=" << set_id << ", lc_id=" << req_.ubs_id();

    if (!ForwardMasterRequest(set_id)) {
      LOG_ERROR << "forward req fail, lc_id=" << req_.ubs_id();
      SendResponse(-EC_UDISK_INTERNAL_ERROR, "forward req fail");
      return;
    }
    LOG_INFO << "Forward request to master... lc_id=" << req_.ubs_id();
    return;
  }
}

void ListSnapshotTotalCountHandle::GetValidSetRequest() {
  ucloud::udisk::GetSetInfoPb req;
  req.add_state(ucloud::udisk::SET_STATE_ONLINE);
  req.add_state(ucloud::udisk::SET_STATE_RESTRICTED);

  std::shared_ptr<ListSnapshotTotalCountHandle> this_ptr =
      std::dynamic_pointer_cast<ListSnapshotTotalCountHandle>(
          shared_from_this());

  std::shared_ptr<DoGetSetInfoHandle> do_get_set_info_handle =
      std::make_shared<DoGetSetInfoHandle>(
          std::bind(&ListSnapshotTotalCountHandle::GetValidSetInfoResponse,
                    this_ptr, std::placeholders::_1, std::placeholders::_2),
          session_no_);
  do_get_set_info_handle->Start(req);
}

void ListSnapshotTotalCountHandle::GetValidSetInfoResponse(
    const ucloud::ResponseCode& rc,
    const std::list<ucloud::udisk::SetInfoPb>& result) {
  if (rc.retcode() != 0) {
    LOG_ERROR << "Failed to get set info. " << rc.error_message();
    SendResponse(rc.retcode(), rc.error_message());
    return;
  }

  for (auto it = result.begin(); it != result.end(); ++it) {
    if (!ForwardMasterRequest(it->id())) {
      is_fail_ = true;
    }
  }
  if (expect_response_num_ == 0) {
    if (is_fail_) {
      SendResponse(-ucloud::ubs2::EC_UBS_INTERNAL_ERROR, "forward req fail");
    } else {
      SendResponse(0, "success");
    }
  }
}

bool ListSnapshotTotalCountHandle::ForwardMasterRequest(int set_id) {
  std::stringstream stream;
  stream << "set" << set_id;
  std::string set_key = stream.str();
  std::string set_name = g_context->mutable_config()->RawGetValue(
      ConfigParser::kSectionName, set_key);
  LOG_INFO << "Forward request " << set_key;

  std::pair<std::string, int> result = g_context->GetIPPort(set_key);
  std::string set_ip = result.first;
  uint32_t set_port = result.second;
  if (set_ip.empty() || set_port == 0) {
    return false;
  }
  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  uevent::ConnectionUeventPtr conn = handle->GetOutConnection(set_ip, set_port);
  if (conn->IsClosed()) {
    return false;
  }

  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&request_, flowno, session_no_, request_.head().message_type(),
                0, false, objid, 0, "ForwardMaster", NULL, NULL);
  std::shared_ptr<ListSnapshotTotalCountHandle> this_ptr =
      std::dynamic_pointer_cast<ListSnapshotTotalCountHandle>(
          shared_from_this());
  LOG_INFO << request_.DebugString();
  uevent::MessageUtil::SendPbRequest(
      conn, request_,
      std::bind(&ListSnapshotTotalCountHandle::ForwardMasterResponse, this_ptr,
                _1),
      std::bind(&ListSnapshotTotalCountHandle::Timeout, this_ptr),
      g_context->config().forward_timeout());
  expect_response_num_++;
  return true;
}

void ListSnapshotTotalCountHandle::ForwardMasterResponse(ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  expect_response_num_--;
  const ListSnapshotTotalCountResponse& res =
      um->body().GetExtension(ucloud::ubs2::list_snapshot_total_count_response);
  if (res.rc().retcode() != 0) {
    LOG_ERROR << "list_snapshot_total_count fail. errmsg="
              << res.rc().error_message() << ", retcode=" << res.rc().retcode();
    is_fail_ = true;
  } else {
    snapshot_total_count_ += res.total_count();
  }
  if (expect_response_num_ == 0) {
    if (is_fail_) {
      SendResponse(-ucloud::ubs2::EC_UBS_INTERNAL_ERROR,
                   res.rc().error_message());
    } else {
      SendResponse(0, "success");
    }
  }
}
