#ifndef UDISK_ACCESS_CHECK_ALLOWANCE_H
#define UDISK_ACCESS_CHECK_ALLOWANCE_H

#include <string>
#include "pb_request_handle.h"
#include "message_util.h"
#include "ubs2_message.h"

namespace udisk {
namespace access {

class CheckAllowanceHandle : public uevent::PbRequestHandle {
 public:
  CheckAllowanceHandle(uevent::UeventLoop* loop) {}
  virtual ~CheckAllowanceHandle() {}

  MYSELF_CREATE(CheckAllowanceHandle);

  void SendResponse(uint32_t retcode, const std::string& message);
  void Timeout();
  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         ucloud::UMessage* um);
  void GetAvailableSets();
  void GetAvailableSetsResponse(const ucloud::ResponseCode& rc,
                                std::vector<int32_t>& available_sets);
  void ForwardReq();
  void ForwardReqResponse(ucloud::UMessage* um);

 private:
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage request_;
  ucloud::ubs2::CheckAllowanceRequest req_;
  ucloud::UMessage response_;
  ucloud::ubs2::CheckAllowanceResponse* resp_body_;
  std::string session_no_;

  uint32_t size_;
  uint32_t total_count_;
  uint32_t oid_;
  uint32_t current_count_;
  std::vector<int32_t> available_sets_;
  std::vector<int32_t>::const_iterator working_set_;
};

};  // namespace access
};  // namespace udisk

#endif
