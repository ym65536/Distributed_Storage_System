#ifndef DO_GET_SET_INFO_H
#define DO_GET_SET_INFO_H

#include <memory>
#include <list>
#include "udisk_message.h"
#include "umessage_common.h"

namespace udisk {
namespace access {

class DoGetSetInfoHandle
    : public std::enable_shared_from_this<DoGetSetInfoHandle> {
 public:
  typedef std::function<void(const ucloud::ResponseCode&,
                             const std::list<ucloud::udisk::SetInfoPb>&)>
      ResponseHook;
  explicit DoGetSetInfoHandle(ResponseHook hook, const std::string& session_no)
      : rsp_hook_(hook), session_no_(session_no) {}
  void Start(const ucloud::udisk::GetSetInfoPb& info);

 private:
  void Finish(uint32_t retcode, const std::string& message);
  void Timeout();
  void GetSetInfoResponse(ucloud::UMessage* um);

  ResponseHook rsp_hook_;
  std::string session_no_;
  std::list<ucloud::udisk::SetInfoPb> set_info_;
};

}  // namespace access
}  // namespace udisk

#endif /* !DO_GET_SET_INFO_H */
// vim: set ts=2 sw=2 sts=2 et:
