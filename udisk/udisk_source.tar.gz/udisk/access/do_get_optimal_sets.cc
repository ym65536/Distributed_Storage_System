#include <sstream>
#include "do_get_optimal_sets.h"
#include "do_get_available_sets.h"
#include "do_get_set_info.h"
#include "access_loop_handle.h"
#include "access_context.h"

#include "logging.h"
#include "message_util.h"
#include "access_umongo.h"
#include "my_uuid.h"
#include <sstream>

namespace udisk {
namespace access {

using namespace uevent;

void DoGetOptimalSetsHandle::Timeout() {
  LOG_ERROR << "DoGetOptimalSetsHandle time out.";
  Finish(-ucloud::udisk::EC_UDISK_OPT_TIMEOUT,
         "DoGetOptimalSetsHandle time out");
}

void DoGetOptimalSetsHandle::Finish(uint32_t retcode,
                                    const std::string& message) {
  if (retcode == 0) {
    LOG_INFO << DumpResult();
  }
  ucloud::ResponseCode res;
  res.set_retcode(retcode);
  res.set_error_message(message);
  rsp_hook_(res, candidate_sets_);
}

void DoGetOptimalSetsHandle::Start(int32_t set_type, uint32_t oid,
                                   const std::string& logic_zone,
                                   uint32_t size) {
  // disk type 与 set type 值相对应
  set_type_ = ucloud::udisk::SET_TYPE(set_type);
  oid_ = oid;
  size_ = size;
  logic_zone_ = logic_zone;

  GetAvailableSets();
}

void DoGetOptimalSetsHandle::GetAvailableSets() {
  std::shared_ptr<DoGetOptimalSetsHandle> this_ptr =
      std::dynamic_pointer_cast<DoGetOptimalSetsHandle>(shared_from_this());
  std::shared_ptr<DoGetAvailableSetsHandle> do_get_available_sets_handle =
      std::make_shared<DoGetAvailableSetsHandle>(
          std::bind(&DoGetOptimalSetsHandle::GetAvailableSetsResponse, this_ptr,
                    std::placeholders::_1, std::placeholders::_2),
          session_no_);
  do_get_available_sets_handle->Start(oid_, set_type_);
}

void DoGetOptimalSetsHandle::GetAvailableSetsResponse(
    const ucloud::ResponseCode& rc, std::vector<int32_t>& available_sets) {
  if (rc.retcode() != 0) {
    LOG_ERROR << "Failed to get available sets info. " << rc.error_message();
    Finish(rc.retcode(), rc.error_message());
    return;
  }

  MakeWaterLineSets(available_sets);
}

void DoGetOptimalSetsHandle::MakeWaterLineSets(
    const std::vector<int32_t>& available_sets) {
  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  int32_t water_line = g_context->config().set_capacity_water_line();
  // 高于容量水位线set
  std::vector<int32_t> over_water_line_sets;
  for (auto& it : available_sets) {
    const SetCapacity& set_cap_info = handle->GetSetCapacity(it);
    int64_t remain_cap = set_cap_info.calculate_cap - size_;
    int64_t water_line_cap = set_cap_info.total_cap * water_line / 100;
    if (remain_cap > water_line_cap) {
      over_water_line_sets.push_back(it);
    } else {
      LOG_INFO << "add to lower_water_line_sets:" << it;
      lower_water_line_sets_.emplace(remain_cap, it);
    }
  }

  user_lc_statistic_info_rsp_num_ = 0;
  over_water_line_sets_total_ = over_water_line_sets.size();
  for (auto& it : over_water_line_sets) {
    if (GetUserLCStatisticInfo(it) == false) {
      InsertLowerWaterLineSets(it);
      --over_water_line_sets_total_;
    }
  }

  if (over_water_line_sets_total_ == 0) {
    GetSetByLogicZone();
    return;
  }
}

bool DoGetOptimalSetsHandle::GetUserLCStatisticInfo(int32_t set_id) {
  std::stringstream stream;
  stream << "set" << set_id;
  std::string set_key = stream.str();
  std::string set_name = g_context->mutable_config()->RawGetValue(
      udisk::common::ConfigParser::kSectionName, set_key);
  std::pair<std::string, int> result = g_context->GetIPPort(set_key);
  std::string set_ip = result.first;
  uint32_t set_port = result.second;
  if (set_ip.empty() || set_port == 0) {
    LOG_ERROR << "choose server of master failed, " << set_name;
    return false;
  }

  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  uevent::ConnectionUeventPtr conn = handle->GetOutConnection(set_ip, set_port);
  if (conn->IsClosed()) {
    LOG_ERROR << "get connection of master failed, " << set_name;
    return false;
  }

  ucloud::UMessage msg;
  uint32_t obj_id = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&msg, flowno, session_no_,
                ucloud::udisk::META_GET_USER_LC_STATISTIC_INFO_REQUEST, 0,
                false, obj_id, 0, "GetUserLcStatisticInfo", NULL, NULL);
  ucloud::udisk::MetaGetUserLcStatisticInfoRequest* req =
      msg.mutable_body()->MutableExtension(
          ucloud::udisk::meta_get_user_lc_statistic_info_request);
  req->set_oid(oid_);

  std::shared_ptr<DoGetOptimalSetsHandle> this_ptr =
      std::dynamic_pointer_cast<DoGetOptimalSetsHandle>(shared_from_this());
  LOG_INFO << req->DebugString();
  uevent::MessageUtil::SendPbRequest(
      conn, msg,
      std::bind(&DoGetOptimalSetsHandle::GetUserLCStatisticInfoResponse,
                this_ptr, std::placeholders::_1, set_id),
      std::bind(&DoGetOptimalSetsHandle::GetUserLCStatisticInfoTimeout,
                this_ptr, set_id),
      3);
  return true;
}

void DoGetOptimalSetsHandle::GetUserLCStatisticInfoResponse(
    ucloud::UMessage* um, int32_t set_id) {
  LOG_INFO << um->DebugString();
  assert(um->head().message_type() ==
         ucloud::udisk::META_GET_USER_LC_STATISTIC_INFO_RESPONSE);
  assert(um->body().HasExtension(
      ucloud::udisk::meta_get_user_lc_statistic_info_response));
  const ucloud::udisk::MetaGetUserLcStatisticInfoResponse& res =
      um->body().GetExtension(
          ucloud::udisk::meta_get_user_lc_statistic_info_response);
  if (res.rc().retcode() != 0) {
    LOG_ERROR << "Failed to get user lc statistic info, msg="
              << res.rc().error_message() << ", code=" << res.rc().retcode();
    InsertLowerWaterLineSets(set_id);
  } else {
    LOG_INFO << "Success to get user lc statistic info, lc_num: "
             << res.lc_num() << ", lc_total_size:" << res.lc_total_size()
             << ", on set: " << set_id << ", will insert upper_water_line_sets";
    // 按磁盘个数插入
    upper_water_line_sets_.emplace(res.lc_num(), set_id);
  }

  ++user_lc_statistic_info_rsp_num_;
  if (user_lc_statistic_info_rsp_num_ == over_water_line_sets_total_) {
    GetSetByLogicZone();
  }
}

void DoGetOptimalSetsHandle::GetUserLCStatisticInfoTimeout(int32_t set_id) {
  LOG_ERROR << "GetUserLCStatisticInfoTimeout time out.";
  InsertLowerWaterLineSets(set_id);
  ++user_lc_statistic_info_rsp_num_;
  if (user_lc_statistic_info_rsp_num_ == over_water_line_sets_total_) {
    GetSetByLogicZone();
  }
}

void DoGetOptimalSetsHandle::GetSetByLogicZone() {
  if (!g_context->mutable_config()->logic_zone_enable() || logic_zone_ == "" ||
      set_type_ == ucloud::udisk::SET_TYPE_DATA) {
    MakeCandidateSets();
    return;
  }
  ucloud::udisk::GetSetInfoPb req;
  req.set_logic_zone(logic_zone_);
  std::shared_ptr<DoGetOptimalSetsHandle> this_ptr =
      std::dynamic_pointer_cast<DoGetOptimalSetsHandle>(shared_from_this());
  std::shared_ptr<DoGetSetInfoHandle> do_get_set_info_handle =
      std::make_shared<DoGetSetInfoHandle>(
          std::bind(&DoGetOptimalSetsHandle::GetSetByLogicZoneResponse,
                    this_ptr, std::placeholders::_1, std::placeholders::_2),
          session_no_);
  do_get_set_info_handle->Start(req);
}

void DoGetOptimalSetsHandle::GetSetByLogicZoneResponse(
    const ucloud::ResponseCode& rc,
    const std::list<ucloud::udisk::SetInfoPb>& result) {
  if (rc.retcode() != 0) {
    LOG_ERROR << "Failed to get sets info. " << rc.error_message();
    Finish(rc.retcode(), rc.error_message());
    return;
  }

  if (result.empty()) {
    LOG_ERROR << "cannot find this logic zone set, " << logic_zone_;
    Finish(-ucloud::udisk::EC_UDISK_NO_SUCH_LOGIC_ZONE, "no such logic zone");
    return;
  }

  for (auto& it : result) {
    logic_zone_set_.push_back(it.id());
  }
  MakeCandidateSets();
}

void DoGetOptimalSetsHandle::MakeCandidateSets() {
  // 优先选择容量足够，且优先选择客户磁盘个数较少的set
  std::vector<int32_t> candidate_sets_tmp;
  std::ostringstream ss;
  for (auto& it : upper_water_line_sets_) {
    candidate_sets_tmp.push_back(it.second);
    ss << it.second << ",";
  }

  // 对于容量不足的set，优先选择容量较大的
  for (auto& it : lower_water_line_sets_) {
    candidate_sets_tmp.push_back(it.second);
    ss << it.second << ",";
  }

  if (!logic_zone_set_.empty()) {
    for (auto& it : candidate_sets_tmp) {
      if (find(logic_zone_set_.begin(), logic_zone_set_.end(), it) !=
          logic_zone_set_.end()) {
        candidate_sets_.push_back(it);
      }
    }
  } else {
    candidate_sets_.swap(candidate_sets_tmp);
  }

  LOG_INFO << "Get Optimal set:" << ss.str();
  Finish(0, "sucess");
}

void DoGetOptimalSetsHandle::InsertLowerWaterLineSets(int32_t set_id) {
  LOG_INFO << "add to lower_water_line_sets:" << set_id;
  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  const SetCapacity& set_cap_info = handle->GetSetCapacity(set_id);
  int64_t remain_cap = set_cap_info.calculate_cap - size_;
  lower_water_line_sets_.emplace(remain_cap, set_id);
}

std::string DoGetOptimalSetsHandle::DumpResult() {
  std::stringstream ss;
  ss << "candidate set:";
  for (auto it = candidate_sets_.begin(); it != candidate_sets_.end(); it++) {
    ss << " " << *it;
  }
  ss << "\n";
  return ss.str();
}

}  // namespace access
}  // namespace udisk
// vim: set ts=2 sw=2 sts=2 et:
