#ifndef UDISK_ACCESS_ZOOKEEPER_H_
#define UDISK_ACCESS_ZOOKEEPER_H_

#include <string>

namespace udisk {
namespace access {

void init_zkclient();
void register_myself(const std::string& zk_id = "");
}
}

#endif
