#include <sstream>
#include "do_get_available_sets.h"
#include "do_get_set_info.h"
#include "access_loop_handle.h"
#include "access_context.h"

#include "logging.h"
#include "message_util.h"
#include "access_umongo.h"

namespace udisk {
namespace access {

using namespace uevent;

void DoGetAvailableSetsHandle::Timeout() {
  LOG_ERROR << "DoGetAvailableSetsHandle time out.";
  Finish(-ucloud::udisk::EC_UDISK_OPT_TIMEOUT,
         "DoGetAvailableSetsHandle time out");
}

void DoGetAvailableSetsHandle::Finish(uint32_t retcode,
                                      const std::string& message) {
  if (retcode == 0) {
    LOG_INFO << DumpResult();
  }
  ucloud::ResponseCode res;
  res.set_retcode(retcode);
  res.set_error_message(message);
  rsp_hook_(res, whitelist_sets_);
}

void DoGetAvailableSetsHandle::Start(uint32_t oid, int32_t set_type) {
  set_type_ = set_type;
  oid_ = oid;

  GetSets();
}

void DoGetAvailableSetsHandle::GetSets() {
  ucloud::udisk::GetSetInfoPb req;
  if (set_type_ >= 0) {
    req.set_type(ucloud::udisk::SET_TYPE(set_type_));
  }

  std::shared_ptr<DoGetAvailableSetsHandle> this_ptr =
      std::dynamic_pointer_cast<DoGetAvailableSetsHandle>(shared_from_this());

  std::shared_ptr<DoGetSetInfoHandle> do_get_set_info_handle =
      std::make_shared<DoGetSetInfoHandle>(
          std::bind(&DoGetAvailableSetsHandle::GetSetsResponse, this_ptr,
                    std::placeholders::_1, std::placeholders::_2),
          session_no_);
  do_get_set_info_handle->Start(req);
}

void DoGetAvailableSetsHandle::GetSetsResponse(
    const ucloud::ResponseCode& rc,
    const std::list<ucloud::udisk::SetInfoPb>& result) {
  if (rc.retcode() != 0) {
    LOG_ERROR << "Failed to get sets info. " << rc.error_message();
    Finish(rc.retcode(), rc.error_message());
    return;
  }

  if (0 == result.size()) {
    LOG_ERROR << "No Available Sets";
    Finish(-ucloud::udisk::EC_UDISK_INTERNAL_ERROR, "No Available Sets");
    return;
  }

  for (auto it = result.begin(); it != result.end(); ++it) {
    all_sets_.insert(it->id());
    if (it->state() == ucloud::udisk::SET_STATE_ONLINE) {
      online_sets_.push_back(it->id());
    } else if (it->state() == ucloud::udisk::SET_STATE_OFFLINE) {
      offline_sets_.insert(it->id());
    }
  }

  GetWhiteLists();
}

void DoGetAvailableSetsHandle::GetWhiteLists() {
  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  uevent::ConnectionUeventPtr conn = handle->GetOutConnection(kUmongoName);
  if (!conn) {
    LOG_ERROR << "DoGetAvailableSetsHandle. Failed to get umongo connection";
    Finish(-ucloud::udisk::EC_UDISK_INTERNAL_ERROR,
           "Failed to get umongo connection");
    return;
  }

  ucloud::UMessage msg;
  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&msg, flowno, session_no_,
                ucloud::umgogate::EXECUTE_MGO_REQUEST, 0, false, objid, 0,
                "GetWhiteLists", NULL, NULL);
  ucloud::umgogate::ExecuteMgoRequest* req =
      msg.mutable_body()->MutableExtension(
          ucloud::umgogate::execute_mgo_request);
  FindPair findpair;
  findpair.int_and_selector.insert(
      std::make_pair(DB_WHITE_LIST_TABLE_COL_OID, oid_));

  construct_get_white_list_request(g_context->config().db_name(), req, findpair,
                                   fields_null, fields_null);
  std::shared_ptr<DoGetAvailableSetsHandle> this_ptr =
      std::dynamic_pointer_cast<DoGetAvailableSetsHandle>(shared_from_this());
  LOG_INFO << msg.DebugString();
  uevent::MessageUtil::SendPbRequest(
      conn, msg, std::bind(&DoGetAvailableSetsHandle::GetWhiteListsResponse,
                           this_ptr, std::placeholders::_1),
      std::bind(&DoGetAvailableSetsHandle::Timeout, this_ptr),
      g_context->config().db_timeout());

  return;
}

void DoGetAvailableSetsHandle::GetWhiteListsResponse(ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  const ucloud::umgogate::ExecuteMgoResponse& res =
      um->body().GetExtension(ucloud::umgogate::execute_mgo_response);
  if (res.rc().retcode() != 0 && !res.op_find_rsp().notfound()) {
    LOG_ERROR << "Failed to get white lists. msg=" << res.rc().error_message()
              << ", code=" << res.rc().retcode();
    Finish(res.rc().retcode(), res.rc().error_message());
    return;
  }

  std::list<ucloud::udisk::WhiteListInfoPb> white_lists;
  if (!parse_white_list_response(res, &white_lists)) {
    LOG_ERROR << "parse get white_list response error";
    Finish(-ucloud::udisk::EC_UDISK_PB_PARSE_FAIL,
           "parse get white_list response error");
    return;
  }

  bool exist_offline = false;
  for (auto it = white_lists.begin(); it != white_lists.end(); it++) {
    if (it->has_ignore_data_system() && it->ignore_data_system() == true) {
      if (InSetTypeRange(it->set_id(), set_type_) == false) {
        continue;
      }
    } else {
      // 排除白名单中不同类型的set
      if (all_sets_.find(it->set_id()) == all_sets_.end()) {
        continue;
      }
    }

    // 排除下线的set
    if (offline_sets_.find(it->set_id()) != offline_sets_.end()) {
      exist_offline = true;
      continue;
    }

    whitelist_sets_.push_back(it->set_id());
  }

  if (0 == whitelist_sets_.size()) {
    // 白名单指定的set处于offline状态
    if (exist_offline == true) {
      LOG_ERROR << "The offline sets in WhiteList";
      Finish(-ucloud::udisk::EC_UDISK_INTERNAL_ERROR,
             "The offline sets in WhiteList");
      return;
    }

    // 未指定对应set类型白名单
    if (0 == online_sets_.size()) {
      LOG_ERROR << "All Restricted Sets without WhiteList";
      Finish(-ucloud::udisk::EC_UDISK_INTERNAL_ERROR,
             "All Restricted Sets without WhiteList");
      return;
    }

    whitelist_sets_.swap(online_sets_);
  }

  Finish(0, "success");
}

std::string DoGetAvailableSetsHandle::DumpResult() {
  std::stringstream ss;
  ss << "available set:";
  for (auto it = whitelist_sets_.begin(); it != whitelist_sets_.end(); it++) {
    ss << " " << *it;
  }
  ss << "\n";
  return ss.str();
}

bool DoGetAvailableSetsHandle::InSetTypeRange(int32_t set_id,
                                              int32_t set_type) {
  switch (set_type) {
    case ucloud::udisk::SET_TYPE_DATA:
    case ucloud::udisk::SET_TYPE_SYSTEM:
      return (set_id < 3000) ? true : false;
    case ucloud::udisk::SET_TYPE_SSD_DATA:
    case ucloud::udisk::SET_TYPE_SSD_SYSTEM:
      return (set_id >= 3000 && set_id < 5000) ? true : false;
    case ucloud::udisk::SET_TYPE_RSSD_DATA:
      return (set_id >= 5000) ? true : false;
    default:
      LOG_ERROR << "set type invalid. set_type:" << set_type;
  }

  return false;
}

}  // namespace access
}  // namespace udisk
// vim: set ts=2 sw=2 sts=2 et:
