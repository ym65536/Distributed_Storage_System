#ifndef UDISK_ACCESS_FORWARD_REQUEST_H
#define UDISK_ACCESS_FORWARD_REQUEST_H

#include "pb_request_handle.h"
#include "message_util.h"
#include "ubs2_message.h"
#include "udisk_message.h"
#include <list>
#include <string>

namespace udisk {
namespace access {

class ForwardRequestBaseHandle : public uevent::PbRequestHandle {
 public:
  ForwardRequestBaseHandle(const std::string& task_name)
      : task_name_(task_name) {}
  virtual ~ForwardRequestBaseHandle() {}

  void SendResponse(uint32_t retcode, const std::string& message);
  void Timeout(const std::string& task_name);
  bool GetSetRequest(const std::string& extern_id);
  void GetSetResponse(const ucloud::ResponseCode& rc,
                      const std::list<ucloud::udisk::LCExtentInfoPb>& result,
                      const std::string& extern_id);
  void ForwardReq();

  virtual void ForwardReqResponse(ucloud::UMessage* um) = 0;
  virtual ucloud::ResponseCode* GetRespCode() = 0;

 protected:
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage request_;
  ucloud::UMessage response_;
  std::string session_no_;
  int32_t set_id_;
  std::string task_name_;
};

};  // namespace access
};  // namespace udisk

#endif
