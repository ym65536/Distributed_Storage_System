#ifndef ACCESS_UMONGO_H
#define ACCESS_UMONGO_H

#include <list>
#include <vector>
#include "udisk_message.h"
#include "umongo_common.h"

// db name
#define ACCESS_DEFAULT_DBNAME "udisk_access"

// t_set_info
#define DB_SET_TABLE_NAME "t_set_info"
#define DB_SET_TABLE_COL_ID "id"
#define DB_SET_TABLE_COL_STATE "state"
#define DB_SET_TABLE_COL_TYPE "type"
#define DB_SET_TABLE_COL_CREATE_TIME "create_time"
#define DB_SET_TABLE_COL_COMMENTS "comments"
#define DB_SET_TABLE_COL_LOGIC_ZONE "logic_zone"

// t_lc_extent_info
#define DB_LC_EXTENT_TABLE_NAME "t_lc_extent_info"
#define DB_LC_EXTENT_TABLE_COL_EXTERN_ID "extern_id"
#define DB_LC_EXTENT_TABLE_COL_OID "oid"
#define DB_LC_EXTENT_TABLE_COL_TOP_OID "top_oid"
#define DB_LC_EXTENT_TABLE_COL_EXTENT_INFO "extent_info"

// t_snapshot_extent_info
#define DB_SNAPSHOT_EXTENT_TABLE_NAME "t_snapshot_extent_info"
#define DB_SNAPSHOT_EXTENT_TABLE_COL_EXTERN_ID "extern_id"
#define DB_SNAPSHOT_EXTENT_TABLE_COL_OID "oid"
#define DB_SNAPSHOT_EXTENT_TABLE_COL_TOP_OID "top_oid"
#define DB_SNAPSHOT_EXTENT_TABLE_COL_EXTENT_INFO "extent_info"

#define EXTENT_INFO_ID "id"
#define EXTENT_INFO_SET_ID "set_id"

// t_white_list_info
#define DB_WHITE_LIST_TABLE_NAME "t_white_list_info"
#define DB_WHITE_LIST_TABLE_COL_SET_ID "set_id"
#define DB_WHITE_LIST_TABLE_COL_OID "oid"
#define DB_WHITE_LIST_TABLE_COL_CREATE_TIME "create_time"
#define DB_WHITE_LIST_TABLE_COL_IGNORE_DATA_SYSTEM "ignore_data_system"

void construct_get_set_info_request(const std::string& dbname,
                                    ucloud::umgogate::ExecuteMgoRequest* req,
                                    const FindPair& findpair,
                                    const Fields& sort_fields,
                                    const Fields& fields, uint32_t skip = 0,
                                    uint32_t limit = 0);

bool parse_set_info_response(const ucloud::umgogate::ExecuteMgoResponse& res,
                             std::list<ucloud::udisk::SetInfoPb>* results);

void construct_get_white_list_request(const std::string& dbname,
                                      ucloud::umgogate::ExecuteMgoRequest* req,
                                      const FindPair& findpair,
                                      const Fields& sort_fields,
                                      const Fields& fields, uint32_t skip = 0,
                                      uint32_t limit = 0);

bool parse_white_list_response(
    const ucloud::umgogate::ExecuteMgoResponse& res,
    std::list<ucloud::udisk::WhiteListInfoPb>* results);

void construct_get_lc_extent_info_request(
    const std::string& dbname, ucloud::umgogate::ExecuteMgoRequest* req,
    const FindPair& findpair, const Fields& sort_fields, const Fields& fields,
    uint32_t skip = 0, uint32_t limit = 0);

bool parse_lc_extent_info_response(
    const ucloud::umgogate::ExecuteMgoResponse& res,
    std::list<ucloud::udisk::LCExtentInfoPb>* results);

void construct_get_snapshot_extent_info_request(
    const std::string& dbname, ucloud::umgogate::ExecuteMgoRequest* req,
    const FindPair& findpair, const Fields& sort_fields, const Fields& fields,
    uint32_t skip = 0, uint32_t limit = 0);

bool parse_snapshot_extent_info_response(
    const ucloud::umgogate::ExecuteMgoResponse& res,
    std::list<ucloud::udisk::SnapshotExtentInfoPb>* results);

void construct_insert_lc_extent_info_request(
    const std::string& dbname, ucloud::umgogate::ExecuteMgoRequest* req,
    const std::string& extern_id, uint32_t oid, uint32_t top_oid,
    const std::vector<ucloud::udisk::ExtentInfoPb>& extent_info);

void construct_insert_snapshot_extent_info_request(
    const std::string& dbname, ucloud::umgogate::ExecuteMgoRequest* req,
    const std::string& extern_id, uint32_t oid, uint32_t top_oid,
    const std::vector<ucloud::udisk::ExtentInfoPb>& extent_info);

void construct_update_lc_extent_info_request(
    const std::string& dbname, ucloud::umgogate::ExecuteMgoRequest* req,
    const std::vector<UpdatePair>& updatepairs);

#endif /* !ACCESS_UMONGO_H */
// vim: set ts=2 sw=2 sts=2 et:
