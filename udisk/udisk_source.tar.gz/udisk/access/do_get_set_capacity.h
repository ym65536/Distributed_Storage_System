#ifndef DO_GET_SET_CAPACITY_H
#define DO_GET_SET_CAPACITY_H

#include <memory>
#include <vector>
#include <list>
#include "udisk_message.h"
#include "umessage_common.h"
#include "access_loop_handle.h"

namespace udisk {
namespace access {

class DoGetSetCapacityHandle
    : public std::enable_shared_from_this<DoGetSetCapacityHandle> {
 public:
  void Start();

 private:
  void Timeout(int set_id);
  void GetValidSetInfo();
  void GetValidSetInfoResponse(
      const ucloud::ResponseCode& rc,
      const std::list<ucloud::udisk::SetInfoPb>& result);

  void GetSetCapFromMeta();
  bool ForwardMasterRequest(int set_id);
  void ForwardMasterResponse(ucloud::UMessage* um, int set_id);
  AccessLoopHandle* handle_;
  std::vector<int> set_ids_;
};

}  // namespace access
}  // namespace udisk

#endif /* !DO_GET_SET_CAPACITY_H */
