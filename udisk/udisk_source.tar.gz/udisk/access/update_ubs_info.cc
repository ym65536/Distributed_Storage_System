#include "update_ubs_info.h"

#include "access_context.h"
#include "access_loop_handle.h"
#include "access_umongo.h"

using namespace udisk::access;
using namespace ucloud::ubs2;

ucloud::ResponseCode* UpdateUBSInfoHandle::GetRespCode() {
  return resp_body_->mutable_rc();
}

void UpdateUBSInfoHandle::EntryInit(const uevent::ConnectionUeventPtr& conn,
                                    ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  conn_ = conn;
  session_no_ = um->head().session_no();
  request_ = *um;
  MakeResponse(&request_, UPDATE_UBS_INFO_RESPONSE, &response_);
  resp_body_ =
      response_.mutable_body()->MutableExtension(update_ubs_info_response);
  req_ = request_.body().GetExtension(update_ubs_info_request);

  GetSetRequest(req_.origin_ubs_id());
}

void UpdateUBSInfoHandle::ForwardReqResponse(ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  assert(um->head().message_type() == UPDATE_UBS_INFO_RESPONSE);
  assert(um->body().HasExtension(update_ubs_info_response));
  const UpdateUBSInfoResponse& res =
      um->body().GetExtension(update_ubs_info_response);

  if (res.rc().retcode() != 0) {
    LOG_ERROR << "Failed to update ubs info request, msg="
              << res.rc().error_message() << ", code=" << res.rc().retcode()
              << ", extern_id =" << req_.origin_ubs_id();
    SendResponse(res.rc().retcode(), res.rc().error_message());
    return;
  }

  if (req_.lc_info().has_account_id() || req_.lc_info().has_company_id()) {
    UpdateLcExtentInfo();
  } else {
    SendResponse(0, "success");
  }
}

void UpdateUBSInfoHandle::UpdateLcExtentInfo() {
  std::pair<std::string, int> result = g_context->GetIPPort(kUmongoName);
  std::string umongo_ip = result.first;
  uint32_t umongo_port = result.second;
  if (umongo_ip.empty() || umongo_port == 0) {
    LOG_ERROR << "choose server of umongo fail";
    SendResponse(-EC_UBS_INTERNAL_ERROR, "choose server of umongo fail");
    return;
  }
  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  uevent::ConnectionUeventPtr conn =
      handle->GetOutConnection(umongo_ip, umongo_port);
  if (conn->IsClosed()) {
    LOG_ERROR << "can not get connection of umongo";
    SendResponse(-EC_UBS_INTERNAL_ERROR, "can not get connection of umongo");
    return;
  }
  ucloud::UMessage msg;
  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&msg, flowno, session_no_,
                ucloud::umgogate::EXECUTE_MGO_REQUEST, 0, false, objid, 0,
                "UpdateLcExtentInfo", NULL, NULL);
  ucloud::umgogate::ExecuteMgoRequest* req =
      msg.mutable_body()->MutableExtension(
          ucloud::umgogate::execute_mgo_request);

  std::vector<UpdatePair> updatepairs;
  UpdatePair updatepair;
  updatepair.string_selector.insert(
      std::make_pair(DB_LC_EXTENT_TABLE_COL_EXTERN_ID, req_.origin_ubs_id()));
  if (req_.lc_info().has_account_id()) {
    updatepair.int_doc.insert(
        std::make_pair("oid", req_.lc_info().account_id()));
  }
  if (req_.lc_info().has_company_id()) {
    updatepair.int_doc.insert(
        std::make_pair("top_oid", req_.lc_info().company_id()));
  }

  updatepairs.push_back(updatepair);
  construct_update_lc_extent_info_request(g_context->config().db_name(), req,
                                          updatepairs);
  std::shared_ptr<UpdateUBSInfoHandle> this_ptr =
      std::dynamic_pointer_cast<UpdateUBSInfoHandle>(shared_from_this());
  LOG_INFO << msg.DebugString();
  uevent::MessageUtil::SendPbRequest(
      conn, msg, std::bind(&UpdateUBSInfoHandle::UpdateLCExtentInfoResponse,
                           this_ptr, std::placeholders::_1),
      std::bind(&UpdateUBSInfoHandle::Timeout, this_ptr, "UpdateLCExtentInfo"),
      g_context->config().db_timeout());
}

void UpdateUBSInfoHandle::UpdateLCExtentInfoResponse(ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  const ucloud::umgogate::ExecuteMgoResponse& res =
      um->body().GetExtension(ucloud::umgogate::execute_mgo_response);
  if (res.rc().retcode() != 0) {
    LOG_ERROR << "update db fail, msg=" << res.rc().error_message()
              << ", code=" << res.rc().retcode();
    SendResponse(res.rc().retcode(), res.rc().error_message());
    return;
  }

  SendResponse(0, "");
}
