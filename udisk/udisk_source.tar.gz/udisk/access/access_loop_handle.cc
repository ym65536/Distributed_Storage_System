#include "access_loop_handle.h"

#include <cassert>
#include <sstream>

#include "access_context.h"
#include "message_util.h"
#include "udisk_types.h"
#include "do_get_set_capacity.h"

using namespace udisk::access;
using namespace ucloud::udisk;
using namespace std::placeholders;
using namespace uevent;

AccessLoopHandle::AccessLoopHandle(uevent::UeventLoop* loop) {
  loop_ = loop;
  loop_->RunEvery(60, std::bind(&AccessLoopHandle::DoGetSetCapacity, this));
}

AccessLoopHandle::~AccessLoopHandle() {
  LOG_DEBUG << "AccessLoopHandle Release";
}

void AccessLoopHandle::ConnectionSuccessHandle(
    const uevent::ConnectionUeventPtr& conn) {
  LOG_DEBUG << "recv a connection, conn_id=" << conn->GetId() << ", "
            << conn->GetPeerAddress().ToString();
}

void AccessLoopHandle::ConnectionClosedHandle(
    const uevent::ConnectionUeventPtr& conn) {
  LOG_DEBUG << "release a connection, conn_id=" << conn->GetId() << ", "
            << conn->GetPeerAddress().ToString();
  g_context->main_listener()->RemoveConnection(conn);
}

void AccessLoopHandle::OutConnSuccessCb(const ConnectionUeventPtr& conn) {
  LOG_DEBUG << "Get out connection=" << conn->GetId();
}

void AccessLoopHandle::OutConnCloseCb(const std::string& name,
                                      const ConnectionUeventPtr& conn) {
  LOG_DEBUG << "Release out connection=" << conn->GetId();
  ctors_.erase(name);
}

const uevent::ConnectionUeventPtr& AccessLoopHandle::GetOutConnection(
    const std::string& ip, int port) {
  LOG_DEBUG << "get out connecton for ip:" << ip << ", port:" << port;
  std::stringstream ss;
  uevent::UsockAddress addr(ip, port, false);
  std::string conn_name;
  ss << "connector-" << ip << ":" << port;
  conn_name = ss.str();
  if (ctors_.count(conn_name)) {
    return ctors_[conn_name]->GetConnection();
  }

  // new connection
  uevent::ConnectorUeventPtr connector =
      std::make_shared<uevent::ConnectorLibevent>(loop_, addr, conn_name);
  connector->SetConnectionSuccessCb(
      std::bind(&AccessLoopHandle::OutConnSuccessCb, this, _1));
  connector->SetConnectionClosedCb(
      std::bind(&AccessLoopHandle::OutConnCloseCb, this, conn_name, _1));
  connector->SetMessageReadCb(uevent::MessageUtil::ProtobufReadCallBack);
  connector->Connect();

  ctors_[conn_name] = connector;
  const uevent::ConnectionUeventPtr& conn = connector->GetConnection();
  LOG_INFO << "Create out conn: name=" << conn_name
           << ", conn_id=" << conn->GetId();
  return conn;
}

uevent::ConnectionUeventPtr AccessLoopHandle::GetOutConnection(
    const std::string& name) {
  std::pair<std::string, int> result = g_context->GetIPPort(name);
  std::string ip = result.first;
  uint32_t port = result.second;
  if (ip.empty() || port == 0) {
    return nullptr;
  }

  const uevent::ConnectionUeventPtr& conn = GetOutConnection(ip, port);
  if (conn->IsClosed()) {
    return nullptr;
  }

  return conn;
}

const SetCapacity& AccessLoopHandle::GetSetCapacity(int set_id) {
  auto it = set_cap_map_.find(set_id);
  if (it == set_cap_map_.end()) {
    set_cap_map_[set_id] = SetCapacity();
    return set_cap_map_[set_id];
  } else {
    return it->second;
  }
}

void AccessLoopHandle::SetSetCapacity(int set_id, int64_t calculate_cap,
                                      uint64_t heartbeat_cap,
                                      uint64_t total_cap) {
  struct SetCapacity set_cap;
  set_cap.calculate_cap = calculate_cap;
  set_cap.heartbeat_cap = heartbeat_cap;
  set_cap.total_cap = total_cap;
  set_cap_map_[set_id] = set_cap;
}

void AccessLoopHandle::DoGetSetCapacity() {
  LOG_INFO << DumpSetCapacity();
  std::shared_ptr<DoGetSetCapacityHandle> handle =
      std::make_shared<DoGetSetCapacityHandle>();
  handle->Start();
}

std::string AccessLoopHandle::DumpSetCapacity() const {
  std::stringstream ss;
  ss << "\n========set capacity info=============";
  for (auto it = set_cap_map_.begin(); it != set_cap_map_.end(); it++) {
    ss << "\nset id:" << it->first
       << "\ncalculate_cap:" << it->second.calculate_cap
       << "\nheartbeat_cap:" << it->second.heartbeat_cap
       << "\ntotal_cap:" << it->second.total_cap;
  }
  return ss.str();
}
