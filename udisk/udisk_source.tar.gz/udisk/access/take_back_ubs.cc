#include "take_back_ubs.h"

using namespace udisk::access;
using namespace ucloud::ubs2;

ucloud::ResponseCode* TakeBackUBSHandle::GetRespCode() {
  return resp_body_->mutable_rc();
}

void TakeBackUBSHandle::EntryInit(const uevent::ConnectionUeventPtr& conn,
                                  ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  conn_ = conn;
  session_no_ = um->head().session_no();
  request_ = *um;
  MakeResponse(&request_, TAKE_BACK_UBS_RESPONSE, &response_);
  resp_body_ =
      response_.mutable_body()->MutableExtension(take_back_ubs_response);
  req_ = request_.body().GetExtension(take_back_ubs_request);

  GetSetRequest(req_.ubs_id());
}

void TakeBackUBSHandle::ForwardReqResponse(ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  assert(um->head().message_type() == TAKE_BACK_UBS_RESPONSE);
  assert(um->body().HasExtension(take_back_ubs_response));
  const TakeBackUBSResponse& res =
      um->body().GetExtension(take_back_ubs_response);

  if (res.rc().retcode() != 0) {
    LOG_ERROR << "Failed to take back ubs request, msg="
              << res.rc().error_message() << ", code=" << res.rc().retcode()
              << ", extern_id =" << req_.ubs_id();
    SendResponse(res.rc().retcode(), res.rc().error_message());
    return;
  }

  // TODO(baoshan.ye) 暂时不更新数据库
  SendResponse(0, "success");
}
