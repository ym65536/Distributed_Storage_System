#ifndef DO_GET_AVAILABLE_SETS_H
#define DO_GET_AVAILABLE_SETS_H

#include <memory>
#include <list>
#include <set>
#include "udisk_message.h"
#include "umessage_common.h"

namespace udisk {
namespace access {

class DoGetAvailableSetsHandle
    : public std::enable_shared_from_this<DoGetAvailableSetsHandle> {
 public:
  typedef std::function<
      void(const ucloud::ResponseCode&, std::vector<int32_t>&)> ResponseHook;
  explicit DoGetAvailableSetsHandle(ResponseHook hook,
                                    const std::string& session_no)
      : rsp_hook_(hook), session_no_(session_no) {}
  void Start(uint32_t oid, int32_t set_type = -1);

 private:
  void Finish(uint32_t retcode, const std::string& message);
  void Timeout();
  void GetSets();
  void GetSetsResponse(const ucloud::ResponseCode& rc,
                       const std::list<ucloud::udisk::SetInfoPb>& result);
  void GetWhiteLists();
  void GetWhiteListsResponse(ucloud::UMessage* um);
  std::string DumpResult();
  bool InSetTypeRange(int32_t set_id, int32_t set_type);

  ResponseHook rsp_hook_;
  std::string session_no_;
  int32_t set_type_;
  uint32_t oid_;

  std::set<int32_t> all_sets_;
  std::set<int32_t> offline_sets_;
  std::vector<int32_t> online_sets_;
  std::vector<int32_t> whitelist_sets_;
};

}  // namespace access
}  // namespace udisk

#endif /* !DO_GET_AVAILABLE_SETS_H */
// vim: set ts=2 sw=2 sts=2 et:
