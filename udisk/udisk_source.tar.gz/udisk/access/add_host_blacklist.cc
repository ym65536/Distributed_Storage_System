#include "add_host_blacklist.h"

#include <sstream>
#include "access_context.h"
#include "access_loop_handle.h"
#include "logging.h"
#include "string_util.h"
#include "umessage_common.h"
#include "likely.h"
#include "do_get_lc_extent_info.h"

using namespace udisk::access;
using namespace udisk::common;
using namespace ucloud::udatabase;
using std::placeholders::_1;

void AddHostBlacklistHandle::Timeout(const std::string& task) {
  LOG_ERROR << "Add blacklist time out, session=" << session_no_
            << ", task=" << task;
  SendResponse(-ucloud::udisk::EC_UDISK_OPT_TIMEOUT, "time out");
}

void AddHostBlacklistHandle::SendResponse(uint32_t retcode,
                                          const std::string& message) {
  if (!responsed_) {
    responsed_ = true;
    ucloud::udisk::AddHostBlacklistResponse* res =
        response_.mutable_body()->MutableExtension(
            ucloud::udisk::add_host_blacklist_response);
    res->mutable_rc()->set_retcode(retcode);
    res->mutable_rc()->set_error_message(message);
    LOG_INFO << response_.DebugString();
    uevent::MessageUtil::SendPbResponse(conn_, response_);
  }
}

void AddHostBlacklistHandle::EntryInit(const uevent::ConnectionUeventPtr& conn,
                                       ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  conn_ = conn;
  session_no_ = um->head().session_no();
  MakeResponse(um, ucloud::udisk::ADD_HOST_BLACKLIST_RESPONSE, &response_);

  index_ = 0;
  req_ = um->body().GetExtension(ucloud::udisk::add_host_blacklist_request);
  if (req_.items_size() == 0) {
    LOG_WARN << "empty request";
    SendResponse(0, "empty request");
    return;
  }
  if (!GetSet()) {
    LOG_ERROR << "get set request fail";
    SendResponse(-ucloud::udisk::EC_UDISK_INTERNAL_ERROR,
                 "get set request fail");
    return;
  }
}

bool AddHostBlacklistHandle::GetSet() {
  ucloud::udisk::GetLCExtentInfoPb lc_extent_req;
  lc_extent_req.add_extern_id(req_.items(index_).udisk_id());
  std::shared_ptr<AddHostBlacklistHandle> this_ptr =
      std::dynamic_pointer_cast<AddHostBlacklistHandle>(shared_from_this());
  std::shared_ptr<DoGetLCExtentInfoHandle> do_get_lc_extent_info_handle =
      std::make_shared<DoGetLCExtentInfoHandle>(
          std::bind(&AddHostBlacklistHandle::EntryGetSet, this_ptr,
                    std::placeholders::_1, std::placeholders::_2),
          session_no_);
  do_get_lc_extent_info_handle->Start(lc_extent_req);
  return true;
}

void AddHostBlacklistHandle::EntryGetSet(
    const ucloud::ResponseCode& rc,
    const std::list<ucloud::udisk::LCExtentInfoPb>& result) {
  if (rc.retcode() != 0) {
    LOG_ERROR << "get set error.";
    SendResponse(rc.retcode(), rc.error_message());
    return;
  }

  if (0 == result.size()) {
    LOG_ERROR << "cannot find this udisk_id, " << req_.items(index_).udisk_id();
    SendResponse(-1, "cannot find this udisk_id");
    return;
  }

  /* 一条UBS对应一条记录. */
  assert(1 == result.size());
  const auto& it = result.begin();
  if (UNLIKELY(it->extent_info_size() <= 0)) {
    LOG_ERROR << "get set error. not extent info in udisk_access";
    SendResponse(-1, "get set error");
    return;
  }

  for (int32_t j = 0; j < it->extent_info_size(); ++j) {
    const ucloud::udisk::ExtentInfoPb& extent = it->extent_info(j);
    int32_t set_id = extent.set_id();
    // TODO(baoshan.ye)extent 只存在与新架构
    // 只处理新架构的盘
    if (set_id >= 1000) {
      ucloud::udisk::BlacklistItem* item = set_blacklist_[set_id].add_items();
      item->CopyFrom(req_.items(index_));
      // TODO(baoshan.ye) 需要处理跨set的情况
    }
  }

  // 尚未获取到所有盘对应的set
  if (++index_ != req_.items_size()) {
    if (!GetSet()) {
      LOG_ERROR << "get set request fail";
      SendResponse(-ucloud::udisk::EC_UDISK_INTERNAL_ERROR,
                   "get set request fail");
    }
    return;
  }

  if (set_blacklist_.empty()) {
    LOG_INFO << "empty blacklist";
    SendResponse(0, "empty blacklist");
    return;
  }

  for (auto it = set_blacklist_.begin(); it != set_blacklist_.end(); ++it) {
    if (!ForwardMaster(it->first)) {
      LOG_ERROR << "forward req fail";
      SendResponse(-ucloud::udisk::EC_UDISK_INTERNAL_ERROR, "forward req fail");
      return;
    }
    ++forward_count_;
  }
}

bool AddHostBlacklistHandle::ForwardMaster(int set_id) {
  std::stringstream stream;
  stream << "set" << set_id;
  std::string set_key = stream.str();
  std::string set_name = g_context->mutable_config()->RawGetValue(
      ConfigParser::kSectionName, set_key);

  std::pair<std::string, int> result = g_context->GetIPPort(set_key);
  std::string set_ip = result.first;
  uint32_t set_port = result.second;
  if (set_ip.empty() || set_port == 0) {
    return false;
  }
  AccessLoopHandle* handle =
      dynamic_cast<AccessLoopHandle*>(g_context->main_loop()->GetLoopHandle());
  uevent::ConnectionUeventPtr conn = handle->GetOutConnection(set_ip, set_port);
  if (!conn) {
    return false;
  }

  ucloud::UMessage msg;
  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&msg, flowno, session_no_,
                ucloud::udisk::ADD_HOST_BLACKLIST_REQUEST, 0, false, objid, 0,
                "add blacklist", NULL, NULL);
  ucloud::udisk::AddHostBlacklistRequest* req =
      msg.mutable_body()->MutableExtension(
          ucloud::udisk::add_host_blacklist_request);
  req->CopyFrom(set_blacklist_[set_id]);

  std::shared_ptr<AddHostBlacklistHandle> this_ptr =
      std::dynamic_pointer_cast<AddHostBlacklistHandle>(shared_from_this());
  LOG_INFO << msg.DebugString();
  uevent::MessageUtil::SendPbRequest(
      conn, msg,
      std::bind(&AddHostBlacklistHandle::EntryForwardMaster, this_ptr, _1),
      std::bind(&AddHostBlacklistHandle::Timeout, this_ptr, "ForwardMaster"),
      g_context->config().forward_timeout());
  return true;
}

void AddHostBlacklistHandle::EntryForwardMaster(ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  --forward_count_;
  const ucloud::udisk::AddHostBlacklistResponse& res =
      um->body().GetExtension(ucloud::udisk::add_host_blacklist_response);
  if (res.rc().retcode() != 0) {
    LOG_ERROR << "add blacklist respose fail. errmsg="
              << res.rc().error_message() << ", retcode=" << res.rc().retcode();
    SendResponse(-ucloud::udisk::EC_UDISK_DB_ERROR, res.rc().error_message());
    return;
  }
  if (forward_count_ == 0) {
    SendResponse(0, "success");
    return;
  }
}
