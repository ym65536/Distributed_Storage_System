#ifndef UDISK_ACCESS_UPDATE_UBS_INFO_H
#define UDISK_ACCESS_UPDATE_UBS_INFO_H

#include "forward_request_base.h"

namespace udisk {
namespace access {

class UpdateUBSInfoHandle : public ForwardRequestBaseHandle {
 public:
  UpdateUBSInfoHandle(uevent::UeventLoop* loop)
      : ForwardRequestBaseHandle("UpdateUBSInfo") {}
  virtual ~UpdateUBSInfoHandle() {}

  MYSELF_CREATE(UpdateUBSInfoHandle);

  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         ucloud::UMessage* um);

  virtual ucloud::ResponseCode* GetRespCode();
  virtual void ForwardReqResponse(ucloud::UMessage* um);

  void UpdateLcExtentInfo();
  void UpdateLCExtentInfoResponse(ucloud::UMessage* um);

 private:
  ucloud::ubs2::UpdateUBSInfoRequest req_;
  ucloud::ubs2::UpdateUBSInfoResponse* resp_body_;
};

};  // namespace access
};  // namespace udisk

#endif
