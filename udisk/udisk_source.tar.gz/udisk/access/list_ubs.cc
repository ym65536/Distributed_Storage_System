#include "list_ubs.h"

using namespace udisk::access;
using namespace ucloud::ubs2;

void ListUBSHandle::EntryInit(const uevent::ConnectionUeventPtr& conn,
                              ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  conn_ = conn;
  session_no_ = um->head().session_no();
  request_ = *um;
  MakeResponse(&request_, LIST_UBS_RESPONSE, &response_);
  resp_body_ = response_.mutable_body()->MutableExtension(list_ubs_response);
  req_ = request_.body().GetExtension(list_ubs_request);
  if (!GetSetRequest()) {
    LOG_ERROR << "get set request fail";
    SendResponse(-EC_UBS_INTERNAL_ERROR, "get set request fail");
    return;
  }
}

ucloud::ResponseCode* ListUBSHandle::GetRespCode() {
  return resp_body_->mutable_rc();
}

void ListUBSHandle::ConstructGetSetParam(
    bool* is_set_req, ucloud::udisk::GetSetInfoPb* set_req,
    ucloud::udisk::GetLCExtentInfoPb* lc_extent_req) {
  // 查找指定id的盘
  *is_set_req = false;
  if (req_.has_ubs_id() || req_.ubs_ids_size()) {
    for (int i = 0; i < req_.ubs_ids_size(); ++i) {
      lc_extent_req->add_extern_id(req_.ubs_ids(i));
    }
    if (req_.has_ubs_id()) {
      lc_extent_req->add_extern_id(req_.ubs_id());
    }
    // 查找指定账户的盘
  } else if (req_.has_account_id() && req_.has_company_id()) {
    lc_extent_req->set_oid(req_.account_id());
    // 查找所有盘
  } else {
    *is_set_req = true;
    set_req->add_state(ucloud::udisk::SET_STATE_ONLINE);
    set_req->add_state(ucloud::udisk::SET_STATE_RESTRICTED);
  }
}

void ListUBSHandle::ConstructListDisksParam(ucloud::UMessage* msg) {
  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(msg, flowno, session_no_, LIST_UBS_REQUEST, 0, false, objid, 0,
                "ListDisks", NULL, NULL);
  ListUBSRequest* req = msg->mutable_body()->MutableExtension(list_ubs_request);
  req->CopyFrom(req_);
  req->clear_offset();
  req->clear_max_count();
}

bool ListUBSHandle::ParseListDisksResponse(ucloud::UMessage* msg) {
  const ListUBSResponse& res = msg->body().GetExtension(list_ubs_response);
  if (res.rc().retcode() != 0) {
    LOG_ERROR << "list disks fail. errmsg=" << res.rc().error_message()
              << ", retcode=" << res.rc().retcode()
              << "set_id: " << cur_set_id_;
    // SendResponse(res.rc().retcode(), res.rc().error_message());
    // 一个set错误不影响拉列表
    return true;
  }
  for (int i = 0; i < res.lc_infos_size(); ++i) {
    set_udisks_[cur_set_id_].push_back(res.lc_infos(i));
  }
  return true;
}

bool ListUBSHandle::ProcessLc(uint32_t count, ucloud::ubs2::LogicalChunk* lc) {
  if (count > req_.offset()) {
    resp_body_->add_lc_infos()->Swap(lc);
  }

  if (req_.has_max_count() && (count - req_.offset() >= req_.max_count())) {
    return false;
  }

  return true;
}
