#ifndef UDISK_ACCESS_UPDATE_UDATAARK_MODE_H
#define UDISK_ACCESS_UPDATE_UDATAARK_MODE_H

#include "forward_request_base.h"

namespace udisk {
namespace access {

class UpdateUDataArkModeHandle : public ForwardRequestBaseHandle {
 public:
  UpdateUDataArkModeHandle(uevent::UeventLoop* loop)
      : ForwardRequestBaseHandle("UpdateUDataArkMode") {}
  virtual ~UpdateUDataArkModeHandle() {}

  MYSELF_CREATE(UpdateUDataArkModeHandle);

  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         ucloud::UMessage* um);

  virtual ucloud::ResponseCode* GetRespCode();
  virtual void ForwardReqResponse(ucloud::UMessage* um);

 private:
  ucloud::ubs2::UpdateUDataArkModeRequest req_;
  ucloud::ubs2::UpdateUDataArkModeResponse* resp_body_;
};

};  // namespace access
};  // namespace udisk

#endif
