#ifndef UDISK_ACCESS_LIST_THROWN_UBS_H
#define UDISK_ACCESS_LIST_THROWN_UBS_H

#include "list_ubs_base.h"

namespace udisk {
namespace access {

class ListThrownUBSHandle : public ListUBSBaseHandle {
 public:
  ListThrownUBSHandle(uevent::UeventLoop* loop)
      : ListUBSBaseHandle("ListThrownUBS") {}
  virtual ~ListThrownUBSHandle() {}

  MYSELF_CREATE(ListThrownUBSHandle);

  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         ucloud::UMessage* um);

  virtual ucloud::ResponseCode* GetRespCode();
  virtual void ConstructGetSetParam(
      bool* is_set_req, ucloud::udisk::GetSetInfoPb* set_req,
      ucloud::udisk::GetLCExtentInfoPb* lc_extent_req);
  virtual void ConstructListDisksParam(ucloud::UMessage* msg);
  virtual bool ParseListDisksResponse(ucloud::UMessage* msg);
  virtual bool ProcessLc(uint32_t count, ucloud::ubs2::LogicalChunk* lc);

 private:
  ucloud::ubs2::ListThrownUBSRequest req_;
  ucloud::ubs2::ListThrownUBSResponse* resp_body_;
};

};  // end of ns access
};  // end of ns udisk

#endif
