#ifndef UDISK_ACCESS_DESTROY_UBS_H
#define UDISK_ACCESS_DESTROY_UBS_H

#include "forward_request_base.h"

namespace udisk {
namespace access {

class DestroyUBSHandle : public ForwardRequestBaseHandle {
 public:
  DestroyUBSHandle(uevent::UeventLoop* loop)
      : ForwardRequestBaseHandle("DestroyUBS") {}
  virtual ~DestroyUBSHandle() {}

  MYSELF_CREATE(DestroyUBSHandle);

  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         ucloud::UMessage* um);
  virtual ucloud::ResponseCode* GetRespCode();
  virtual void ForwardReqResponse(ucloud::UMessage* um);

 private:
  ucloud::ubs2::DestroyUBSRequest req_;
  ucloud::ubs2::DestroyUBSResponse* resp_body_;
};

};  // namespace access
};  // namespace udisk

#endif
