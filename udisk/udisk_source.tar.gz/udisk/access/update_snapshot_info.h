#ifndef UDISK_ACCESS_UPDATE_SNAPSHOT_INFO_H
#define UDISK_ACCESS_UPDATE_SNAPSHOT_INFO_H

#include <string>
#include <list>
#include "pb_request_handle.h"
#include "message_util.h"
#include "ubs2_message.h"
#include "udisk_message.h"

namespace udisk {
namespace access {

class UpdateSnapshotInfoHandle : public uevent::PbRequestHandle {
 public:
  UpdateSnapshotInfoHandle(uevent::UeventLoop* loop) {}
  virtual ~UpdateSnapshotInfoHandle() {}

  MYSELF_CREATE(UpdateSnapshotInfoHandle);

  void SendResponse(uint32_t retcode, const std::string& message);
  void Timeout(const std::string& task);
  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         ucloud::UMessage* um);

  bool GetSetRequest();
  void GetSetResponse(
      const ucloud::ResponseCode& rc,
      const std::list<ucloud::udisk::SnapshotExtentInfoPb>& result);

  bool ForwardPeerRequest(const std::string& access_key);
  void ForwardPeerResponse(ucloud::UMessage* um);
  bool ForwardMasterRequest();
  void ForwardMasterResponse(ucloud::UMessage* um);

 private:
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage request_;
  ucloud::ubs2::UpdateSnapshotInfoRequest req_;
  ucloud::UMessage response_;
  ucloud::ubs2::UpdateSnapshotInfoResponse* resp_body_;
  std::string session_no_;
  uint32_t forward_ref_ = 0;
  int32_t set_id_ = 0;
  bool responsed_ = false;
};

};  // end of ns access
};  // end of ns udisk

#endif
