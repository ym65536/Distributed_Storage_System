#ifndef ACCESS_GET_UDISK_EXTENT_INFO_H
#define ACCESS_GET_UDISK_EXTENT_INFO_H

#include <memory>
#include <list>
#include "umessage_common.h"
#include "pb_request_handle.h"
#include "message_util.h"
#include "udisk_message.h"

namespace udisk {
namespace access {

class GetUDiskExtentInfoHandle : public uevent::PbRequestHandle {
 public:
  GetUDiskExtentInfoHandle(uevent::UeventLoop* loop) {}
  virtual ~GetUDiskExtentInfoHandle() {}

  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         ucloud::UMessage* um);

  MYSELF_CREATE(GetUDiskExtentInfoHandle);

  void Timeout();
  void SendResponse(int32_t retcode, const std::string& message);

 private:
  void GetLCExtentInfoRequest();
  void GetLCExtentInfoResponse(ucloud::UMessage* um);
  void GetSetInfoRequest();
  void GetSetInfoResponse(const ucloud::ResponseCode& rc,
                          const std::list<ucloud::udisk::SetInfoPb>& result);

  uevent::ConnectionUeventPtr conn_;
  std::string session_no_;
  std::map<int32_t, ucloud::udisk::SetInfoPb> set_infos_;
  ucloud::udisk::GetUDiskExtentInfoRequest req_body_;
  ucloud::UMessage response_;
  ucloud::udisk::GetUDiskExtentInfoResponse* resp_body_;
};

}  // namespace access
}  // namespace udisk

#endif /* !DO_GET_LC_EXTENT_INFO_H */
// vim: set ts=2 sw=2 sts=2 et:
