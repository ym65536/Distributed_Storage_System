#ifndef UDISK_ACCESS_DELETE_SNAPSHOT_H
#define UDISK_ACCESS_DELETE_SNAPSHOT_H

#include <string>
#include <list>
#include "pb_request_handle.h"
#include "message_util.h"
#include "ubs2_message.h"
#include "udisk_message.h"

namespace udisk {
namespace access {

class DeleteSnapshotHandle : public uevent::PbRequestHandle {
 public:
  DeleteSnapshotHandle(uevent::UeventLoop* loop) {}
  virtual ~DeleteSnapshotHandle() {}

  MYSELF_CREATE(DeleteSnapshotHandle);

  void SendResponse(uint32_t retcode, const std::string& message);
  void Timeout(const std::string& task);
  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         ucloud::UMessage* um);

  bool GetSetRequest();
  void GetSnapshotSetResponse(
      const ucloud::ResponseCode& rc,
      const std::list<ucloud::udisk::SnapshotExtentInfoPb>& result);
  void GetLcSetResponse(const ucloud::ResponseCode& rc,
                        const std::list<ucloud::udisk::LCExtentInfoPb>& result);

  bool ForwardPeerRequest(const std::string& access_key);
  void ForwardPeerResponse(ucloud::UMessage* um);
  bool ForwardMasterRequest();
  void ForwardMasterResponse(ucloud::UMessage* um);

 private:
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage request_;
  ucloud::ubs2::DeleteSnapshotRequest req_;
  ucloud::UMessage response_;
  ucloud::ubs2::DeleteSnapshotResponse* resp_body_;
  std::string session_no_;
  uint32_t forward_ref_ = 0;
  int32_t set_id_ = 0;
  bool responsed_ = false;
};

};  // end of ns access
};  // end of ns udisk

#endif
