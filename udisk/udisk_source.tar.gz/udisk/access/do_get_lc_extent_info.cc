#include "do_get_lc_extent_info.h"
#include "do_get_set_info.h"
#include "access_loop_handle.h"
#include "access_context.h"

#include "logging.h"
#include "message_util.h"
#include "access_umongo.h"

namespace udisk {
namespace access {

using namespace uevent;

void DoGetLCExtentInfoHandle::Timeout() {
  LOG_ERROR << "DoGetLCExtentInfoHandle time out";
  Finish(-ucloud::udisk::EC_UDISK_OPT_TIMEOUT,
         "DoGetLCExtentInfoHandle time out");
}

void DoGetLCExtentInfoHandle::Finish(uint32_t retcode,
                                     const std::string& message) {
  ucloud::ResponseCode res;
  res.set_retcode(retcode);
  res.set_error_message(message);
  rsp_hook_(res, lc_extent_info_);
}

void DoGetLCExtentInfoHandle::Start(
    const ucloud::udisk::GetLCExtentInfoPb& info) {
  request_ = info;
  if (ignore_offline_) {
    GetValidSetInfo();
  } else {
    GetLCExtentInfo();
  }
}

void DoGetLCExtentInfoHandle::GetValidSetInfo() {
  ucloud::udisk::GetSetInfoPb req;
  req.add_state(ucloud::udisk::SET_STATE_ONLINE);
  req.add_state(ucloud::udisk::SET_STATE_RESTRICTED);

  std::shared_ptr<DoGetLCExtentInfoHandle> this_ptr =
      std::dynamic_pointer_cast<DoGetLCExtentInfoHandle>(shared_from_this());

  std::shared_ptr<DoGetSetInfoHandle> do_get_set_info_handle =
      std::make_shared<DoGetSetInfoHandle>(
          std::bind(&DoGetLCExtentInfoHandle::GetValidSetInfoResponse, this_ptr,
                    std::placeholders::_1, std::placeholders::_2),
          session_no_);
  do_get_set_info_handle->Start(req);
}

void DoGetLCExtentInfoHandle::GetValidSetInfoResponse(
    const ucloud::ResponseCode& rc,
    const std::list<ucloud::udisk::SetInfoPb>& result) {
  if (rc.retcode() != 0) {
    LOG_ERROR << "Failed to get set info. " << rc.error_message();
    Finish(rc.retcode(), rc.error_message());
    return;
  }

  for (auto it = result.begin(); it != result.end(); ++it) {
    set_ids_.push_back(it->id());
  }

  GetLCExtentInfo();
}

void DoGetLCExtentInfoHandle::GetLCExtentInfo() {
  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  uevent::ConnectionUeventPtr conn = handle->GetOutConnection(kUmongoName);
  if (!conn) {
    LOG_ERROR << "DoGetLCExtentInfoHandle. Failed to get umongo connection";
    Finish(-ucloud::udisk::EC_UDISK_INTERNAL_ERROR,
           "Failed to get umongo connection");
    return;
  }

  ucloud::UMessage msg;
  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&msg, flowno, session_no_,
                ucloud::umgogate::EXECUTE_MGO_REQUEST, 0, false, objid, 0,
                "GetLCExtentInfo", NULL, NULL);
  ucloud::umgogate::ExecuteMgoRequest* req =
      msg.mutable_body()->MutableExtension(
          ucloud::umgogate::execute_mgo_request);
  FindPair findpair;
  if (request_.has_oid()) {
    findpair.int_and_selector.insert(
        std::make_pair(DB_LC_EXTENT_TABLE_COL_OID, request_.oid()));
  }

  if (request_.has_top_oid()) {
    findpair.int_and_selector.insert(
        std::make_pair(DB_LC_EXTENT_TABLE_COL_TOP_OID, request_.top_oid()));
  }

  for (int32_t i = 0; i < request_.extern_id_size(); ++i) {
    findpair.string_or_selector.insert(std::make_pair(
        DB_LC_EXTENT_TABLE_COL_EXTERN_ID, request_.extern_id(i)));
  }

  construct_get_lc_extent_info_request(g_context->config().db_name(), req,
                                       findpair, fields_null, fields_null);
  std::shared_ptr<DoGetLCExtentInfoHandle> this_ptr =
      std::dynamic_pointer_cast<DoGetLCExtentInfoHandle>(shared_from_this());
  LOG_INFO << msg.DebugString();
  uevent::MessageUtil::SendPbRequest(
      conn, msg, std::bind(&DoGetLCExtentInfoHandle::GetLCExtentInfoResponse,
                           this_ptr, std::placeholders::_1),
      std::bind(&DoGetLCExtentInfoHandle::Timeout, this_ptr),
      g_context->config().db_timeout());
}

void DoGetLCExtentInfoHandle::GetLCExtentInfoResponse(ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  const ucloud::umgogate::ExecuteMgoResponse& res =
      um->body().GetExtension(ucloud::umgogate::execute_mgo_response);
  if (res.rc().retcode() != 0 && !res.op_find_rsp().notfound()) {
    LOG_ERROR << res.rc().error_message();
    Finish(-ucloud::udisk::EC_UDISK_DB_ERROR, res.rc().error_message());
    return;
  }

  if (!parse_lc_extent_info_response(res, &lc_extent_info_)) {
    LOG_ERROR << "parse get lc extent info response error";
    Finish(-ucloud::udisk::EC_UDISK_PB_PARSE_FAIL,
           "parse get lc extent info response error");
    return;
  }

  if (ignore_offline_) {
    CheckSetInfo();
  }
  Finish(0, "Success");
}

void DoGetLCExtentInfoHandle::CheckSetInfo() {
  for (auto it = lc_extent_info_.begin(); it != lc_extent_info_.end();) {
    bool is_offline = false;
    for (int32_t j = 0; j < it->extent_info_size(); ++j) {
      const ucloud::udisk::ExtentInfoPb& extent = it->extent_info(j);
      if (std::find(set_ids_.begin(), set_ids_.end(), extent.set_id()) ==
          set_ids_.end()) {
        is_offline = true;
        break;
      }
    }

    if (is_offline) {
      it = lc_extent_info_.erase(it);
    } else {
      ++it;
    }
  }
}

}  // namespace access
}  // namespace udisk
// vim: set ts=2 sw=2 sts=2 et:
