#include "list_ubs_base.h"
#include <sstream>
#include "access_context.h"
#include "access_loop_handle.h"
#include "umessage_common.h"
#include "umessage.h"
#include "string_util.h"
#include "do_get_set_info.h"
#include "do_get_lc_extent_info.h"

using namespace udisk::access;
using namespace udisk::common;
using namespace ucloud::ubs2;
using namespace ucloud::udatabase;
using namespace std::placeholders;

void ListUBSBaseHandle::ListDisksTimeout() {
  LOG_ERROR << "list ubs time out, session=" << session_no_
            << ", task=" << task_ << ", set_id: " << cur_set_id_;
  // SendResponse(-EC_UBS_TIMEOUT, "list ubs time out");
  ListDisks();
}

void ListUBSBaseHandle::SendResponse(uint32_t retcode,
                                     const std::string& message) {
  ucloud::ResponseCode* rc = GetRespCode();
  rc->set_retcode(retcode);
  rc->set_error_message(message);
  LOG_INFO << response_.DebugString();
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

bool ListUBSBaseHandle::GetSetRequest() {
  ucloud::udisk::GetSetInfoPb set_req;
  ucloud::udisk::GetLCExtentInfoPb lc_extent_req;
  bool is_set_req;
  ConstructGetSetParam(&is_set_req, &set_req, &lc_extent_req);

  std::shared_ptr<ListUBSBaseHandle> this_ptr =
      std::dynamic_pointer_cast<ListUBSBaseHandle>(shared_from_this());
  if (is_set_req) {
    std::shared_ptr<DoGetSetInfoHandle> do_get_set_info_handle =
        std::make_shared<DoGetSetInfoHandle>(
            std::bind(&ListUBSBaseHandle::GetSetResponse, this_ptr,
                      std::placeholders::_1, std::placeholders::_2),
            session_no_);
    do_get_set_info_handle->Start(set_req);
  } else {
    std::shared_ptr<DoGetLCExtentInfoHandle> do_get_lc_extent_info_handle =
        std::make_shared<DoGetLCExtentInfoHandle>(
            std::bind(&ListUBSBaseHandle::GetSetByLCResponse, this_ptr,
                      std::placeholders::_1, std::placeholders::_2),
            session_no_);
    do_get_lc_extent_info_handle->Start(lc_extent_req);
  }

  return true;
}

void ListUBSBaseHandle::GetSetResponse(
    const ucloud::ResponseCode& rc,
    const std::list<ucloud::udisk::SetInfoPb>& result) {
  if (rc.retcode() != 0) {
    LOG_ERROR << "get set error.";
    SendResponse(rc.retcode(), rc.error_message());
    return;
  }

  if (0 == result.size()) {
    SendResponse(0, "cannot find udisk");
    return;
  }

  for (auto it = result.begin(); it != result.end(); ++it) {
    set_ids_.insert(it->id());
  }

  ListDisks();
}

void ListUBSBaseHandle::GetSetByLCResponse(
    const ucloud::ResponseCode& rc,
    const std::list<ucloud::udisk::LCExtentInfoPb>& result) {
  if (rc.retcode() != 0) {
    LOG_ERROR << "get set error.";
    SendResponse(rc.retcode(), rc.error_message());
    return;
  }

  if (0 == result.size()) {
    SendResponse(0, "cannot find udisk");
    return;
  }

  for (auto it = result.begin(); it != result.end(); ++it) {
    for (int32_t j = 0; j < it->extent_info_size(); ++j) {
      const ucloud::udisk::ExtentInfoPb& extent = it->extent_info(j);
      set_ids_.insert(extent.set_id());
    }
  }

  ListDisks();
}

void ListUBSBaseHandle::ListDisks() {
  // 遍历完所有满足条件的set
  if (set_ids_.empty()) {
    ProcessLcs();
    SendResponse(0, "success");
    return;
  }

  // 按set_id从小到大查找
  cur_set_id_ = *(set_ids_.begin());
  set_ids_.erase(set_ids_.begin());
  std::stringstream stream;
  stream << "set" << cur_set_id_;
  std::string set_key = stream.str();
  std::string set_name = g_context->mutable_config()->RawGetValue(
      ConfigParser::kSectionName, set_key);
  LOG_INFO << "Forward request " << set_key;

  std::pair<std::string, int> result = g_context->GetIPPort(set_key);
  std::string set_ip = result.first;
  uint32_t set_port = result.second;
  if (set_ip.empty() || set_port == 0) {
    LOG_ERROR << "GetIPPort error, set_id: " << cur_set_id_;
    ListDisks();
    return;
  }
  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  uevent::ConnectionUeventPtr conn = handle->GetOutConnection(set_ip, set_port);
  if (conn->IsClosed()) {
    LOG_ERROR << "GetConnection error, set_id: " << cur_set_id_;
    ListDisks();
    return;
  }

  ucloud::UMessage msg;
  ConstructListDisksParam(&msg);
  std::shared_ptr<ListUBSBaseHandle> this_ptr =
      std::dynamic_pointer_cast<ListUBSBaseHandle>(shared_from_this());
  LOG_INFO << request_.DebugString();
  uevent::MessageUtil::SendPbRequest(
      conn, msg, std::bind(&ListUBSBaseHandle::ListDisksResponse, this_ptr, _1),
      std::bind(&ListUBSBaseHandle::ListDisksTimeout, this_ptr),
      g_context->config().forward_timeout());
  return;
}

void ListUBSBaseHandle::ListDisksResponse(ucloud::UMessage* msg) {
  LOG_INFO << msg->DebugString();
  if (!ParseListDisksResponse(msg)) {
    return;
  }
  ListDisks();
}

void ListUBSBaseHandle::ProcessLcs() {
  if (set_udisks_.empty()) {
    return;
  }
  // 迁移可能会造成新老set中存在相同id的盘，从set_udisks_先取出新set的盘信息
  // 如果老set中存在相同盘id，则跳过
  std::set<std::string> extern_ids;
  uint32_t count = 0;
  for (auto it = set_udisks_.begin(); it != set_udisks_.end(); ++it) {
    for (uint32_t i = 0; i < it->second.size(); ++i) {
      const LogicalChunk& lc = it->second[i];
      // 迁移过程中的盘，不显示
      if (lc.id().find("_new") != std::string::npos ||
          lc.id().find("_old") != std::string::npos) {
        LOG_INFO << "udisk in migaration, extern_id: " << lc.id()
                 << ", set_id: " << it->first;
        continue;
      }
      // TODO(baoshan.ye) 后续需要考虑跨set
      // 迁移后老set中仍保留原来的盘id
      if (extern_ids.find(lc.id()) != extern_ids.end()) {
        LOG_INFO << "udisk migrated, extern_id: " << lc.id()
                 << ", set_id: " << it->first;
        continue;
      }
      extern_ids.insert(lc.id());

      count++;
      if (ProcessLc(count, &it->second[i]) == false) {
        return;
      }
    }
  }
}
