#include "access_context.h"
#include "access_zookeeper.h"
#include "access_loop_handle.h"
#include <getopt.h>
#include <sys/types.h>

using namespace udisk;
using namespace udisk::common;
using namespace std;

namespace udisk {
namespace access {

static void session_expired_cb(const std::string& zk_id) {
  LOG_INFO << "session expired " << zk_id;
  register_myself(zk_id);
}

void register_myself(const std::string& zk_id) {
  if (g_context == nullptr || ((g_context->nc("zookeeper") == nullptr) &&
                               (g_context->nc("zookeeper-1") == nullptr))) {
    LOG_SYSFATAL << "g_context or nc is null";
  }
  std::string nncstr;
  ucloud::uns::NameNodeContent nnc;
  nnc.set_ip(g_context->config().listen_ip());
  nnc.set_port(g_context->config().listen_port());
  nnc.SerializeToString(&nncstr);

  vector<string> my_keys;
  std::string patten("^myself[0-9]{1,}$");
  g_context->mutable_config()->RawEnumKeys(kSectionMap, patten, my_keys);
  for (auto& my_key : my_keys) {
    std::string id =
        g_context->mutable_config()->RawGetValue(kSectionMap, my_key);
    // session_expired_cb会指定zk_id，重新注册myself
    if (!zk_id.empty() && zk_id != id) {
      continue;
    }
    std::string zk_addr =
        g_context->mutable_config()->RawGetValue(id, kZkServer);
    std::string zk_timeout =
        g_context->mutable_config()->RawGetValue(id, kZkTimeout);
    if (g_context->nc(id) == nullptr) {
      common::NameContainer* nc = new common::NameContainer(
          zk_addr, std::bind(session_expired_cb, id), std::stoi(zk_timeout),
          g_context->config().zk_log());
      if (nc->Init() == -1) {
        LOG_SYSFATAL << "can't connect to zookeeper";
      }
      g_context->set_nc(nc, id);
    }
    int rc = g_context->nc(id)->RegisterInstance(
        g_context->config().my_name_zk_path(),
        std::to_string(g_context->config().my_id()), nncstr);
    if (rc != ZOK) {
      LOG_SYSFATAL << "register instance error: " << rc;
    }
    LOG_INFO << "register myself=" << g_context->config().my_name_zk_path()
             << " to " << id << ", addr=" << zk_addr;
  }
}

void init_zkclient() {
  // zk_id <-> vector<key, value>
  map<string, vector<pair<string, string>>> zk_maps;
  vector<string> keys;
  // udb
  // std::string zk_id =
  //     g_context->mutable_config()->RawGetValue(kSectionMap, kUDatabaseName);
  // LOG_DEBUG << "==>zk_id=" << zk_id << ", name=" << kUDatabaseName;
  // zk_maps[zk_id].push_back(
  //     make_pair(kUDatabaseName, g_context->config().udatabase_zk_path()));
  // umongo
  std::string zk_id =
      g_context->mutable_config()->RawGetValue(kSectionMap, kUmongoName);
  LOG_DEBUG << "==>zk_id=" << zk_id << ", name=" << kUmongoName;
  zk_maps[zk_id]
      .push_back(make_pair(kUmongoName, g_context->config().umongo_zk_path()));
  // utm_access
  zk_id = g_context->mutable_config()->RawGetValue(kSectionMap, kUTMAccessName);
  LOG_DEBUG << "==>zk_id=" << zk_id << ", name=" << kUTMAccessName;
  zk_maps[zk_id].push_back(
      make_pair(kUTMAccessName, g_context->config().utm_access_zk_path()));

  // sets
  vector<string> set_keys;
  std::string patten("^set[0-9]{1,}$");
  g_context->mutable_config()->RawEnumKeys(ConfigParser::kSectionName, patten,
                                           set_keys);
  LOG_INFO << "set size=" << set_keys.size();
  for (auto& set_key : set_keys) {
    std::string zk_id =
        g_context->mutable_config()->RawGetValue(kSectionMap, set_key);
    std::string set_name = g_context->mutable_config()->RawGetValue(
        ConfigParser::kSectionName, set_key);
    zk_maps[zk_id].push_back(make_pair(set_key, set_name));
  }

  // other_access
  LOG_INFO << "Start register access info...";
  vector<string> access_keys;
  patten = "^access_[0-9a-z]{1,}$";
  g_context->mutable_config()->RawEnumKeys(ConfigParser::kSectionName, patten,
                                           access_keys);
  for (auto& access_key : access_keys) {
    if (access_key == ("access_" + g_context->config().my_region())) {
      continue;
    }
    std::string zk_id =
        g_context->mutable_config()->RawGetValue(kSectionMap, access_key);
    std::string zk_path = g_context->mutable_config()->RawGetValue(
        ConfigParser::kSectionName, access_key);
    zk_maps[zk_id].push_back(make_pair(access_key, zk_path));
  }

  // register watcher
  for (auto& it : zk_maps) {
    std::string zk_addr =
        g_context->mutable_config()->RawGetValue(it.first, kZkServer);
    std::string zk_timeout =
        g_context->mutable_config()->RawGetValue(it.first, kZkTimeout);
    common::NameContainer* nc = new common::NameContainer(
        zk_addr, std::bind(session_expired_cb, it.first), std::stoi(zk_timeout),
        g_context->config().zk_log());
    if (nc->Init() == -1) {
      LOG_SYSFATAL << "can't connect to zookeeper";
    }

    std::string access_region("");
    // hard code. zk和zk1由access自身使用，zk[2, +]由其他access使用
    if (it.first == "zookeeper" || it.first == "zookeeper-1") {
      access_region = ("access_" + g_context->config().my_region());
    } else {
      access_region = it.second[0].first;
    }
    common::ZkNameOfSetPtr set_ptr =
        make_shared<common::ZkNameOfSet>(access_region);
    for (auto& item : it.second) {
      set_ptr->AddNamePath(item.first, item.second);
      LOG_DEBUG << "register watch key=" << item.first
                << ", name=" << item.second << " on zookeeper=" << it.first;
    }
    nc->AddZkNameOfSet(set_ptr);
    g_context->set_nc(nc, it.first);
  }

  // 并注册自己
  register_myself();

  LOG_INFO << "zkclient init finished";
}
}
}
