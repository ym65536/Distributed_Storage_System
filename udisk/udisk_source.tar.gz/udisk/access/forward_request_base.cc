#include "forward_request_base.h"

#include "access_context.h"
#include "access_loop_handle.h"
#include "umessage.h"
#include "umessage_common.h"
#include "logging.h"
#include "likely.h"
#include "do_get_lc_extent_info.h"
#include <sstream>

using namespace udisk::access;
using namespace udisk::common;
using namespace ucloud::ubs2;
using namespace std::placeholders;

void ForwardRequestBaseHandle::Timeout(const std::string& task_name) {
  std::ostringstream stream;
  stream << task_name << " time out";
  LOG_ERROR << stream.str() << ", session=" << session_no_;
  SendResponse(-EC_UBS_TIMEOUT, stream.str());
}

void ForwardRequestBaseHandle::SendResponse(uint32_t retcode,
                                            const std::string& message) {
  ucloud::ResponseCode* rc = GetRespCode();
  rc->set_retcode(retcode);
  rc->set_error_message(message);
  LOG_INFO << response_.DebugString();
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

bool ForwardRequestBaseHandle::GetSetRequest(const std::string& extern_id) {
  ucloud::udisk::GetLCExtentInfoPb lc_extent_req;
  lc_extent_req.add_extern_id(extern_id);
  std::shared_ptr<ForwardRequestBaseHandle> this_ptr =
      std::dynamic_pointer_cast<ForwardRequestBaseHandle>(shared_from_this());
  std::shared_ptr<DoGetLCExtentInfoHandle> do_get_lc_extent_info_handle =
      std::make_shared<DoGetLCExtentInfoHandle>(
          std::bind(&ForwardRequestBaseHandle::GetSetResponse, this_ptr,
                    std::placeholders::_1, std::placeholders::_2, extern_id),
          session_no_);
  do_get_lc_extent_info_handle->Start(lc_extent_req);

  return true;
}

void ForwardRequestBaseHandle::GetSetResponse(
    const ucloud::ResponseCode& rc,
    const std::list<ucloud::udisk::LCExtentInfoPb>& result,
    const std::string& extern_id) {
  if (rc.retcode() != 0) {
    LOG_ERROR << "get set error. msg=" << rc.error_message()
              << ", code=" << rc.retcode();
    SendResponse(rc.retcode(), rc.error_message());
    return;
  }

  if (result.size() == 0) {
    LOG_ERROR << "Could not find the set contains extern:" << extern_id;
    SendResponse(-EC_UBS_NO_SUCH_LOGICAL_CHUNK,
                 "Could not find the set contains extern ID");
    return;
  }

  /* 一条UBS对应一条记录. */
  assert(1 == result.size());
  const auto& it = result.begin();
  if (UNLIKELY(it->extent_info_size() <= 0)) {
    LOG_ERROR << "get set error. not extent info in udisk_access";
    SendResponse(-EC_UBS_INTERNAL_ERROR, "get set error");
    return;
  }

  for (int32_t j = 0; j < it->extent_info_size(); ++j) {
    const ucloud::udisk::ExtentInfoPb& extent = it->extent_info(j);
    // TODO(baoshan.ye) 之后考虑extent多个set
    set_id_ = extent.set_id();
    break;
  }

  ForwardReq();
}

void ForwardRequestBaseHandle::ForwardReq() {
  std::stringstream stream;
  stream << "set" << set_id_;
  std::string set_key = stream.str();
  std::string set_name = g_context->mutable_config()->RawGetValue(
      ConfigParser::kSectionName, set_key);

  std::pair<std::string, int> result = g_context->GetIPPort(set_key);
  std::string set_ip = result.first;
  uint32_t set_port = result.second;
  if (set_ip.empty() || set_port == 0) {
    LOG_ERROR << "choose server of master failed, " << set_name;
    SendResponse(-EC_UBS_INTERNAL_ERROR, "choose server of master failed");
    return;
  }

  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  uevent::ConnectionUeventPtr conn = handle->GetOutConnection(set_ip, set_port);
  if (conn->IsClosed()) {
    LOG_ERROR << "get connection of master failed, " << set_name;
    SendResponse(-EC_UBS_INTERNAL_ERROR, "get connection fail");
    return;
  }

  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&request_, flowno, session_no_, request_.head().message_type(),
                0, false, objid, 0, task_name_.c_str(), NULL, NULL);
  LOG_INFO << request_.DebugString();
  std::shared_ptr<ForwardRequestBaseHandle> this_ptr =
      std::dynamic_pointer_cast<ForwardRequestBaseHandle>(shared_from_this());
  uevent::MessageUtil::SendPbRequest(
      conn, request_,
      std::bind(&ForwardRequestBaseHandle::ForwardReqResponse, this_ptr, _1),
      std::bind(&ForwardRequestBaseHandle::Timeout, this_ptr, task_name_),
      g_context->config().forward_timeout());
  return;
}
