#include "clone_ubs.h"
#include <sstream>
#include "access_context.h"
#include "access_loop_handle.h"
#include "string_util.h"
#include "likely.h"
#include "umessage.h"
#include "umessage_common.h"
#include "umongo.h"
#include "access_umongo.h"
#include "do_get_optimal_sets.h"
#include "do_get_set_info.h"
#include "do_get_lc_extent_info.h"
#include "do_get_snapshot_extent_info.h"

using namespace udisk::access;
using namespace udisk::common;
using namespace ucloud::ubs2;
using namespace ucloud::udatabase;
using namespace ucloud::umgogate;
using namespace std::placeholders;

void CloneUBSHandle::Timeout(const std::string& task) {
  LOG_ERROR << "clone ubs handle time out, session=" << session_no_
            << ", task=" << task;
  SendResponse(-EC_UBS_TIMEOUT, "clone ubs handle time out");
}

void CloneUBSHandle::SendResponse(uint32_t retcode,
                                  const std::string& message) {
  resp_body_->mutable_rc()->set_retcode(retcode);
  resp_body_->mutable_rc()->set_error_message(message);
  if (retcode == 0) {
    resp_body_->set_ubs_id(dst_extern_id_);
  }
  LOG_INFO << response_.DebugString();
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void CloneUBSHandle::EntryInit(const uevent::ConnectionUeventPtr& conn,
                               ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  conn_ = conn;
  session_no_ = um->head().session_no();
  request_ = *um;
  MakeResponse(&request_, CLONE_UBS_RESPONSE, &response_);
  resp_body_ = response_.mutable_body()->MutableExtension(clone_ubs_response);
  req_ = request_.body().GetExtension(clone_ubs_request);
  dst_extern_id_ = req_.lc_info().id();

  // lc_id和snapshot_id不同时存在
  if (req_.parent_lc_id() != "" && req_.parent_snapshot_id() == "") {
    src_extern_id_ = req_.parent_lc_id();
  } else if (req_.parent_lc_id() == "" && req_.parent_snapshot_id() != "") {
    src_snapshot_id_ = req_.parent_snapshot_id();
  } else {
    LOG_ERROR << "invalid params.";
    SendResponse(-EC_UBS_INVALID_PARAMS, "invalid params");
    return;
  }
  if (req_.has_snapshot_time()) {
    snapshot_time_ = req_.snapshot_time();
    LOG_INFO << "clone from extern_id: " << src_extern_id_
             << ", snapshot_time: " << snapshot_time_;
  }

  // 是否指定克隆目的set
  if (req_.has_set_id()) {
    specified_ = true;
    specified_set_ = req_.set_id();
  }

  // 从快照克隆
  if (!src_snapshot_id_.empty()) {
    CheckExternId();
  } else {
    CheckMigration();
  }
}

void CloneUBSHandle::CheckMigration() {
  std::pair<std::string, int> result = g_context->GetIPPort(kUmongoName);
  std::string umongo_ip = result.first;
  uint32_t umongo_port = result.second;
  if (umongo_ip.empty() || umongo_port == 0) {
    LOG_ERROR << "choose server of umongo fail";
    SendResponse(-EC_UBS_INTERNAL_ERROR, "choose server of umongo fail");
    return;
  }
  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  uevent::ConnectionUeventPtr conn =
      handle->GetOutConnection(umongo_ip, umongo_port);
  if (conn->IsClosed()) {
    LOG_ERROR << "can not get connection of umongo";
    SendResponse(-EC_UBS_INTERNAL_ERROR, "can not get connection of umongo");
    return;
  }
  ucloud::UMessage msg;
  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&msg, flowno, session_no_,
                ucloud::umgogate::EXECUTE_MGO_REQUEST, 0, false, objid, 0,
                "CheckMigration", NULL, NULL);
  ExecuteMgoRequest* req =
      msg.mutable_body()->MutableExtension(execute_mgo_request);
  construct_get_migrate_udisk_request(req, src_extern_id_);
  std::shared_ptr<CloneUBSHandle> this_ptr =
      std::dynamic_pointer_cast<CloneUBSHandle>(shared_from_this());
  LOG_INFO << msg.DebugString();
  uevent::MessageUtil::SendPbRequest(
      conn, msg,
      std::bind(&CloneUBSHandle::CheckMigrationResponse, this_ptr, _1),
      std::bind(&CloneUBSHandle::Timeout, this_ptr, "CheckMigration"),
      g_context->config().db_timeout());
  return;
}

void CloneUBSHandle::CheckMigrationResponse(ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  assert(um->head().message_type() == ucloud::umgogate::EXECUTE_MGO_RESPONSE);
  assert(um->body().HasExtension(ucloud::umgogate::execute_mgo_response));
  const ucloud::umgogate::ExecuteMgoResponse& res =
      um->body().GetExtension(ucloud::umgogate::execute_mgo_response);
  // 查找到迁移的盘
  if (!res.op_find_rsp().notfound()) {
    ucloud::udisk::MigrateUDiskTaskPb migrate_udisk;
    if (parse_get_migrate_udisk_request(&res, migrate_udisk) < 0) {
      LOG_ERROR << "parse mongo response error, extern_id=" << src_extern_id_;
      SendResponse(-EC_UBS_INTERNAL_ERROR, "migrate udisk parse fail");
      return;
    }
    // 迁移中禁止克隆
    if (migrate_udisk.status() == ucloud::udisk::MIGRATE_INPROCESS) {
      LOG_ERROR << "udisk in migration, extern_id=" << src_extern_id_;
      SendResponse(-EC_UBS_INTERNAL_ERROR, "udisk in migration");
      return;
    }
    LOG_DEBUG << "CheckMigration response: extern_id="
              << migrate_udisk.extern_id()
              << ", status=" << migrate_udisk.status();
  }
  CheckExternId();
  return;
}

void CloneUBSHandle::CheckExternId() {
  ucloud::udisk::GetLCExtentInfoPb lc_extent_req;
  lc_extent_req.add_extern_id(dst_extern_id_);
  std::shared_ptr<CloneUBSHandle> this_ptr =
      std::dynamic_pointer_cast<CloneUBSHandle>(shared_from_this());
  std::shared_ptr<DoGetLCExtentInfoHandle> do_get_lc_extent_info_handle =
      std::make_shared<DoGetLCExtentInfoHandle>(
          std::bind(&CloneUBSHandle::CheckExternIdResponse, this_ptr,
                    std::placeholders::_1, std::placeholders::_2),
          session_no_, false);
  do_get_lc_extent_info_handle->Start(lc_extent_req);
}

void CloneUBSHandle::CheckExternIdResponse(
    const ucloud::ResponseCode& rc,
    const std::list<ucloud::udisk::LCExtentInfoPb>& result) {
  if (rc.retcode() != 0) {
    LOG_ERROR << "check extern id error. msg=" << rc.error_message()
              << ", code=" << rc.retcode();
    SendResponse(rc.retcode(), rc.error_message());
    return;
  }

  if (result.size() > 0) {
    LOG_ERROR << "udisk already exists, extern_id: " << req_.lc_info().id();
    SendResponse(-EC_UBS_INVALID_ARGUMENTS, "udisk already exists");
    return;
  }
  GetSrcSet();
}

void CloneUBSHandle::GetSrcSet() {
  // 从快照克隆
  if (!src_snapshot_id_.empty()) {
    ucloud::udisk::GetSnapshotExtentInfoPb snapshot_extent_req;
    snapshot_extent_req.add_extern_id(src_snapshot_id_);
    std::shared_ptr<CloneUBSHandle> this_ptr =
        std::dynamic_pointer_cast<CloneUBSHandle>(shared_from_this());
    std::shared_ptr<DoGetSnapshotExtentInfoHandle>
        do_get_snapshot_extent_info_handle =
            std::make_shared<DoGetSnapshotExtentInfoHandle>(
                std::bind(&CloneUBSHandle::GetSnapShotSrcSetResponse, this_ptr,
                          std::placeholders::_1, std::placeholders::_2),
                session_no_);
    do_get_snapshot_extent_info_handle->Start(snapshot_extent_req);
  } else {
    ucloud::udisk::GetLCExtentInfoPb lc_extent_req;
    lc_extent_req.add_extern_id(src_extern_id_);
    std::shared_ptr<CloneUBSHandle> this_ptr =
        std::dynamic_pointer_cast<CloneUBSHandle>(shared_from_this());
    std::shared_ptr<DoGetLCExtentInfoHandle> do_get_lc_extent_info_handle =
        std::make_shared<DoGetLCExtentInfoHandle>(
            std::bind(&CloneUBSHandle::GetLcSrcSetResponse, this_ptr,
                      std::placeholders::_1, std::placeholders::_2),
            session_no_, false);
    do_get_lc_extent_info_handle->Start(lc_extent_req);
  }
}

void CloneUBSHandle::GetSnapShotSrcSetResponse(
    const ucloud::ResponseCode& rc,
    const std::list<ucloud::udisk::SnapshotExtentInfoPb>& result) {
  if (rc.retcode() != 0) {
    LOG_ERROR << "get set error. msg=" << rc.error_message()
              << ", code=" << rc.retcode();
    SendResponse(rc.retcode(), rc.error_message());
    return;
  }

  if (result.size() > 0) {
    if (UNLIKELY(result.size() != 1)) {
      LOG_ERROR << "there are more than one snapshot id in udisk_access";
      SendResponse(-1, "get set error");
      return;
    }

    const auto& it = result.begin();
    if (UNLIKELY(it->extent_info_size() <= 0)) {
      LOG_ERROR << "get set error. not extent info in udisk_access";
      SendResponse(-1, "get set error");
      return;
    }

    // TODO(alan.ding) 大盘跨set
    for (int32_t j = 0; j < it->extent_info_size(); ++j) {
      const ucloud::udisk::ExtentInfoPb& extent = it->extent_info(j);
      src_set_ = extent.set_id();
      break;
    }

    LOG_INFO << "clone ubs get src set: " << src_set_;
    GetSrcSize();
    return;
  } else {
    LOG_INFO << "clone ubs get src set over region";
    GetSrcSizeOverRegion();
    return;
  }
}

void CloneUBSHandle::GetLcSrcSetResponse(
    const ucloud::ResponseCode& rc,
    const std::list<ucloud::udisk::LCExtentInfoPb>& result) {
  if (rc.retcode() != 0) {
    LOG_ERROR << "get set error. msg=" << rc.error_message()
              << ", code=" << rc.retcode();
    SendResponse(rc.retcode(), rc.error_message());
    return;
  }

  if (result.size() > 0) {
    if (UNLIKELY(result.size() != 1)) {
      LOG_ERROR << "there are more than one snapshot id in udisk_access";
      SendResponse(-1, "get set error");
      return;
    }

    const auto& it = result.begin();
    if (UNLIKELY(it->extent_info_size() <= 0)) {
      LOG_ERROR << "get set error. not extent info in udisk_access";
      SendResponse(-1, "get set error");
      return;
    }

    // TODO(alan.ding) 大盘跨set
    for (int32_t j = 0; j < it->extent_info_size(); ++j) {
      const ucloud::udisk::ExtentInfoPb& extent = it->extent_info(j);
      src_set_ = extent.set_id();
      break;
    }

    LOG_INFO << "clone ubs get src set: " << src_set_;
    GetSrcSize();
    return;
  } else {
    LOG_INFO << "clone ubs get src set over region";
    GetSrcSizeOverRegion();
  }
}

void CloneUBSHandle::GetSrcSize() {
  std::stringstream stream;
  stream << "set" << src_set_;
  std::string set_key = stream.str();
  std::string set_name = g_context->mutable_config()->RawGetValue(
      ConfigParser::kSectionName, set_key);
  std::pair<std::string, int> result = g_context->GetIPPort(set_key);
  std::string set_ip = result.first;
  uint32_t set_port = result.second;
  if (set_ip.empty() || set_port == 0) {
    LOG_ERROR << "choose server of master fail";
    SendResponse(-EC_UBS_INTERNAL_ERROR, "choose server of master fail");
    return;
  }
  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  uevent::ConnectionUeventPtr conn = handle->GetOutConnection(set_ip, set_port);
  if (conn->IsClosed()) {
    LOG_ERROR << "can not get connection of master";
    SendResponse(-EC_UBS_INTERNAL_ERROR, "can not get connection of master");
    return;
  }

  ucloud::UMessage msg;
  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  // 从快照克隆
  if (!src_snapshot_id_.empty()) {
    NewMessage_v2(&msg, flowno, session_no_, GET_SNAPSHOT_DETAIL_INFO_REQUEST,
                  0, false, objid, 0, "GetSrcSize", NULL, NULL);
    GetSnapshotDetailInfoRequest* req =
        msg.mutable_body()->MutableExtension(get_snapshot_detail_info_request);
    req->set_snapshot_id(src_snapshot_id_);
    // 从盘克隆
  } else {
    NewMessage_v2(&msg, flowno, session_no_, GET_UBS_DETAIL_INFO_REQUEST, 0,
                  false, objid, 0, "GetSrcSize", NULL, NULL);
    GetUBSDetailInfoRequest* req =
        msg.mutable_body()->MutableExtension(get_ubs_detail_info_request);
    req->set_ubs_id(src_extern_id_);
  }

  std::shared_ptr<CloneUBSHandle> this_ptr =
      std::dynamic_pointer_cast<CloneUBSHandle>(shared_from_this());
  LOG_INFO << msg.DebugString();
  uevent::MessageUtil::SendPbRequest(
      conn, msg, std::bind(&CloneUBSHandle::GetSrcSizeResponse, this_ptr, _1),
      std::bind(&CloneUBSHandle::Timeout, this_ptr, "GetSrcSize"),
      g_context->config().forward_timeout());
  return;
}

void CloneUBSHandle::GetSrcSizeResponse(ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  uint32_t src_size;
  // 从快照克隆
  if (!src_snapshot_id_.empty()) {
    assert(um->head().message_type() == GET_SNAPSHOT_DETAIL_INFO_RESPONSE);
    assert(um->body().HasExtension(get_snapshot_detail_info_response));
    const GetSnapshotDetailInfoResponse& res =
        um->body().GetExtension(get_snapshot_detail_info_response);

    if (res.rc().retcode() != 0) {
      LOG_ERROR << "get snapshot detail info fail, retcode: "
                << res.rc().retcode()
                << ", errmsg: " << res.rc().error_message();
      SendResponse(res.rc().retcode(), res.rc().error_message());
      return;
    }

    src_size = res.snapshot().size();
    udisk_version_ = res.snapshot().version();
    // 填入快照的源盘id
    request_.mutable_body()
        ->MutableExtension(clone_ubs_request)
        ->set_snapshot_src_id(res.snapshot().lc_id());
    // 从盘克隆
  } else {
    assert(um->head().message_type() == GET_UBS_DETAIL_INFO_RESPONSE);
    assert(um->body().HasExtension(get_ubs_detail_info_response));
    const GetUBSDetailInfoResponse& res =
        um->body().GetExtension(get_ubs_detail_info_response);

    if (res.rc().retcode() != 0) {
      LOG_ERROR << "get ubs detail info fail, retcode: " << res.rc().retcode()
                << ", errmsg: " << res.rc().error_message();
      SendResponse(res.rc().retcode(), res.rc().error_message());
      return;
    }

    // 非正常状态的方舟盘紧致克隆
    if (res.lc().utm_mode() && res.lc().utm_status() != UTM_NORMAL &&
        res.lc().utm_status() != UTM_RUNNING) {
      LOG_ERROR << "can not clone ubs from " << src_extern_id_ << " to "
                << dst_extern_id_ << ", because utm status is not supported";
      SendResponse(-EC_UBS_UNSUPPORT, "utm status unsupported");
      return;
    }

    src_size = res.lc().size();
    udisk_version_ = res.lc().version();
  }

  if (src_size != req_.lc_info().size()) {
    LOG_ERROR << "input size invalid, src size: " << src_size
              << ", dst size: " << req_.lc_info().size();
    SendResponse(-EC_UBS_INVALID_CLONE_SIZE, "size not the same");
    return;
  }

  ChooseDstSet();
}

void CloneUBSHandle::GetSrcSizeOverRegion() {
  vector<string> access_keys;
  const std::string patten("^access_[0-9a-z]{1,}$");
  g_context->mutable_config()->RawEnumKeys(UDiskConfig::kSectionName, patten,
                                           access_keys);
  for (auto& access_key : access_keys) {
    if (access_key == ("access_" + g_context->config().my_region())) {
      continue;
    }
    // 发送成功才加引用
    if (GetSrcSizePeer(access_key)) {
      ++forward_ref_;
    }
  }

  /* 没有其他机房 */
  if (0 == forward_ref_) {
    GetSrcSizeFromUTM();
    return;
  }
}

bool CloneUBSHandle::GetSrcSizePeer(const std::string& access_key) {
  std::string access_name = g_context->mutable_config()->RawGetValue(
      ConfigParser::kSectionName, access_key);
  auto result = g_context->GetIPPort(access_key);
  std::string peer_ip = result.first;
  uint32_t peer_port = result.second;
  LOG_INFO << "Get src size from " << access_key
           << ", forward ref=" << forward_ref_ << ", peer_ip=" << peer_ip
           << ", peer_port=" << peer_port;
  if (peer_ip.empty() || peer_port == 0) {
    return false;
  }
  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  uevent::ConnectionUeventPtr conn =
      handle->GetOutConnection(peer_ip, peer_port);
  if (conn->IsClosed()) {
    return false;
  }

  ucloud::UMessage msg;
  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  // 从快照克隆
  if (!src_snapshot_id_.empty()) {
    NewMessage_v2(&msg, flowno, session_no_, GET_SNAPSHOT_DETAIL_INFO_REQUEST,
                  0, false, objid, 0, FORWARD_PEER_LABEL, NULL, NULL);
    GetSnapshotDetailInfoRequest* req =
        msg.mutable_body()->MutableExtension(get_snapshot_detail_info_request);
    req->set_snapshot_id(src_snapshot_id_);
    // 从盘克隆
  } else {
    NewMessage_v2(&msg, flowno, session_no_, GET_UBS_DETAIL_INFO_REQUEST, 0,
                  false, objid, 0, FORWARD_PEER_LABEL, NULL, NULL);
    GetUBSDetailInfoRequest* req =
        msg.mutable_body()->MutableExtension(get_ubs_detail_info_request);
    req->set_ubs_id(src_extern_id_);
  }

  std::shared_ptr<CloneUBSHandle> this_ptr =
      std::dynamic_pointer_cast<CloneUBSHandle>(shared_from_this());
  LOG_INFO << msg.DebugString();
  uevent::MessageUtil::SendPbRequest(
      conn, msg,
      std::bind(&CloneUBSHandle::GetSrcSizePeerResponse, this_ptr, _1),
      std::bind(&CloneUBSHandle::GetSrcSizePeerTimeout, this_ptr),
      g_context->config().forward_timeout());
  return true;
}

void CloneUBSHandle::GetSrcSizePeerResponse(ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  --forward_ref_;
  uint32_t src_size;
  // 从快照克隆
  if (!src_snapshot_id_.empty()) {
    assert(um->head().message_type() == GET_SNAPSHOT_DETAIL_INFO_RESPONSE);
    assert(um->body().HasExtension(get_snapshot_detail_info_response));
    const GetSnapshotDetailInfoResponse& res =
        um->body().GetExtension(get_snapshot_detail_info_response);

    if (res.rc().retcode() != 0) {
      // 从其他机房获取源盘信息全部超时或失败，尝试从UTM获取
      if (forward_ref_ == 0 && !responsed_) {
        GetSrcSizeFromUTM();
      }
      return;
    }
    responsed_ = true;

    src_size = res.snapshot().size();
    // 填入快照的源盘id
    request_.mutable_body()
        ->MutableExtension(clone_ubs_request)
        ->set_snapshot_src_id(res.snapshot().lc_id());
    // 从盘克隆
  } else {
    assert(um->head().message_type() == GET_UBS_DETAIL_INFO_RESPONSE);
    assert(um->body().HasExtension(get_ubs_detail_info_response));
    const GetUBSDetailInfoResponse& res =
        um->body().GetExtension(get_ubs_detail_info_response);

    if (res.rc().retcode() != 0) {
      // 从其他机房获取源盘信息全部超时或失败，尝试从UTM获取
      if (forward_ref_ == 0 && !responsed_) {
        GetSrcSizeFromUTM();
      }
      return;
    }
    responsed_ = true;

    // 非正常状态的方舟盘紧致克隆
    if (res.lc().utm_mode() && res.lc().utm_status() != UTM_NORMAL &&
        res.lc().utm_status() != UTM_RUNNING) {
      LOG_ERROR << "can not clone ubs from " << src_extern_id_ << " to "
                << dst_extern_id_ << ", because utm status is not supported";
      SendResponse(-EC_UBS_UNSUPPORT, "utm status unsupported");
      return;
    }

    src_size = res.lc().size();
  }

  if (src_size != req_.lc_info().size()) {
    LOG_ERROR << "input size invalid, src size: " << src_size
              << ", dst size: " << req_.lc_info().size();
    SendResponse(-EC_UBS_INVALID_CLONE_SIZE, "size not the same");
    return;
  }

  ChooseDstSet();
}

void CloneUBSHandle::GetSrcSizePeerTimeout() {
  LOG_ERROR << "clone ubs get src size time out, session=" << session_no_;
  --forward_ref_;
  // 从其他机房获取源盘信息全部超时或失败，尝试从UTM获取
  if (forward_ref_ == 0 && !responsed_) {
    GetSrcSizeFromUTM();
    return;
  }
}

void CloneUBSHandle::GetSrcSizeFromUTM() {
  std::pair<std::string, int> result = g_context->GetIPPort(kUTMAccessName);
  std::string ip = result.first;
  uint32_t port = result.second;
  if (ip.empty() || port == 0) {
    LOG_ERROR << "choose server of utm_access fail";
    SendResponse(-EC_UBS_INTERNAL_ERROR, "choose server of utm_access fail");
    return;
  }
  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  uevent::ConnectionUeventPtr conn = handle->GetOutConnection(ip, port);
  if (conn->IsClosed()) {
    LOG_ERROR << "can not get connection of utm_access";
    SendResponse(-EC_UBS_INTERNAL_ERROR,
                 "can not get connection of utm_access");
    return;
  }
  ucloud::UMessage msg;
  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();

  // 从快照克隆
  if (!src_snapshot_id_.empty()) {
    NewMessage_v2(&msg, flowno, session_no_,
                  ucloud::utimemachine::ACCESS_DESCRIBE_SNAPSHOTS_REQUEST, 0,
                  false, objid, 0, "GetUTMSnapshotInfo", NULL, NULL);
    ucloud::utimemachine::AccessDescribeSnapshotsRequest* req =
        msg.mutable_body()->MutableExtension(
            ucloud::utimemachine::access_describe_snapshots_request);
    req->set_top_oid("0");
    req->set_oid("0");
    req->add_snapshots(src_snapshot_id_);
    // 从盘克隆
  } else {
    NewMessage_v2(&msg, flowno, session_no_,
                  ucloud::utimemachine::ACCESS_FETCH_VDISK_CAP_BYTICK_REQUEST,
                  0, false, objid, 0, "GetUTMDiskInfo", NULL, NULL);
    ucloud::utimemachine::AccessFetchVDiskCapByTickRequest* req =
        msg.mutable_body()->MutableExtension(
            ucloud::utimemachine::access_fetch_vdisk_cap_bytick_request);
    req->set_vdisk_id(src_extern_id_);
    req->set_tick(snapshot_time_);
  }

  std::shared_ptr<CloneUBSHandle> this_ptr =
      std::dynamic_pointer_cast<CloneUBSHandle>(shared_from_this());
  LOG_INFO << msg.DebugString();
  uevent::MessageUtil::SendPbRequest(
      conn, msg,
      std::bind(&CloneUBSHandle::GetSrcSizeFromUTMResponse, this_ptr, _1),
      std::bind(&CloneUBSHandle::Timeout, this_ptr, "GetUTMInfo"),
      g_context->config().forward_timeout());
  return;
}

void CloneUBSHandle::GetSrcSizeFromUTMResponse(ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  uint32_t src_size;
  // 从快照克隆
  if (!src_snapshot_id_.empty()) {
    assert(um->head().message_type() ==
           ucloud::utimemachine::ACCESS_DESCRIBE_SNAPSHOTS_RESPONSE);
    assert(um->body().HasExtension(
        ucloud::utimemachine::access_describe_snapshots_response));
    const ucloud::utimemachine::AccessDescribeSnapshotsResponse& res =
        um->body().GetExtension(
            ucloud::utimemachine::access_describe_snapshots_response);

    if (res.rc().retcode() != 0) {
      LOG_ERROR << "get utm snapshot info fail, retcode: " << res.rc().retcode()
                << ", errmsg: " << res.rc().error_message();
      SendResponse(res.rc().retcode(), res.rc().error_message());
      return;
    }

    if (res.snapshots().size() != 1) {
      LOG_ERROR << "snapshot is not unique";
      SendResponse(-1, "snapshot is not unique");
      return;
    }

    if (!res.snapshots(0).has_vdisk_id()) {
      LOG_ERROR << "snapshot do not has vdisk id";
      SendResponse(-1, "snapshot do not has vdisk id");
      return;
    }

    // B转成GB
    src_size = res.snapshots(0).size() >> 30;
    request_.mutable_body()
        ->MutableExtension(clone_ubs_request)
        ->set_snapshot_src_id(res.snapshots(0).vdisk_id());
    // 从盘克隆
  } else {
    assert(um->head().message_type() ==
           ucloud::utimemachine::ACCESS_FETCH_VDISK_CAP_BYTICK_RESPONSE);
    assert(um->body().HasExtension(
        ucloud::utimemachine::access_fetch_vdisk_cap_bytick_response));
    const ucloud::utimemachine::AccessFetchVDiskCapByTickResponse& res =
        um->body().GetExtension(
            ucloud::utimemachine::access_fetch_vdisk_cap_bytick_response);

    if (res.rc().retcode() != 0) {
      LOG_ERROR << "get utm local disk fail, retcode: " << res.rc().retcode()
                << ", errmsg: " << res.rc().error_message();
      SendResponse(res.rc().retcode(), res.rc().error_message());
      return;
    }

    src_size = res.vdisk_cap();
  }

  if (src_size != req_.lc_info().size()) {
    LOG_ERROR << "input size invalid, src size: " << src_size
              << ", dst size: " << req_.lc_info().size();
    SendResponse(-EC_UBS_INVALID_CLONE_SIZE, "size not the same");
    return;
  }

  ChooseDstSet();
}

void CloneUBSHandle::ChooseDstSet() {
  if (specified_) {
    CheckInputSet();
  } else {
    // 1.05版本
    if (udisk_version_ == 1) {
      candidate_sets_.push_back(src_set_);
      candidate_ = candidate_sets_.begin();
      CloneUBS();
      return;
    }
    GetOptimalSets();
  }
}

void CloneUBSHandle::GetOptimalSets() {
  std::shared_ptr<CloneUBSHandle> this_ptr =
      std::dynamic_pointer_cast<CloneUBSHandle>(shared_from_this());
  std::shared_ptr<DoGetOptimalSetsHandle> do_get_optimal_sets_handle =
      std::make_shared<DoGetOptimalSetsHandle>(
          std::bind(&CloneUBSHandle::GetOptimalSetsResponse, this_ptr,
                    std::placeholders::_1, std::placeholders::_2),
          session_no_);
  do_get_optimal_sets_handle->Start(req_.lc_info().disk_type(),
                                    req_.lc_info().account_id(),
                                    req_.logic_zone(), req_.lc_info().size());
}

void CloneUBSHandle::GetOptimalSetsResponse(const ucloud::ResponseCode& rc,
                                            std::vector<int32_t>& sets) {
  if (rc.retcode() != 0) {
    LOG_ERROR << "Failed to get optimal sets info. " << rc.error_message();
    SendResponse(rc.retcode(), rc.error_message());
    return;
  }
  candidate_sets_.swap(sets);
  candidate_ = candidate_sets_.begin();
  CloneUBS();
}

void CloneUBSHandle::CheckInputSet() {
  ucloud::udisk::GetSetInfoPb req;
  req.set_set_id(specified_set_);
  req.add_state(ucloud::udisk::SET_STATE_ONLINE);
  req.add_state(ucloud::udisk::SET_STATE_RESTRICTED);

  std::shared_ptr<CloneUBSHandle> this_ptr =
      std::dynamic_pointer_cast<CloneUBSHandle>(shared_from_this());
  std::shared_ptr<DoGetSetInfoHandle> do_get_set_info_handle =
      std::make_shared<DoGetSetInfoHandle>(
          std::bind(&CloneUBSHandle::CheckInputSetResponse, this_ptr,
                    std::placeholders::_1, std::placeholders::_2),
          session_no_);
  do_get_set_info_handle->Start(req);
}

void CloneUBSHandle::CheckInputSetResponse(
    const ucloud::ResponseCode& rc,
    const std::list<ucloud::udisk::SetInfoPb>& result) {
  if (rc.retcode() != 0) {
    LOG_ERROR << "check input set error. msg= " << rc.error_message()
              << ", code=" << rc.retcode();
    SendResponse(rc.retcode(), rc.error_message());
    return;
  }

  if (result.size() != 1) {
    LOG_ERROR << "input set is invalid, set " << specified_set_ << ", row_size "
              << result.size();
    SendResponse(-EC_UBS_INVALID_ARGUMENTS, "input set is invalid");
    return;
  }

  candidate_sets_.push_back(specified_set_);
  candidate_ = candidate_sets_.begin();
  CloneUBS();
}

void CloneUBSHandle::CloneUBS() {
  if (candidate_ == candidate_sets_.end()) {
    // 请求列表内的set全部尝试失败
    LOG_ERROR << "Clone UBS failed on all candidates";
    SendResponse(-EC_UBS_RESOURCE_NOT_ENOUGTH,
                 "Clone UBS failed on all candidates");
    return;
  }

  std::stringstream stream;
  stream << "set" << *candidate_;
  std::string set_key = stream.str();
  std::string set_name = g_context->mutable_config()->RawGetValue(
      ConfigParser::kSectionName, set_key);

  std::pair<std::string, int> result = g_context->GetIPPort(set_key);
  std::string set_ip = result.first;
  uint32_t set_port = result.second;
  if (set_ip.empty() || set_port == 0) {
    LOG_ERROR << "choose server of master failed, " << set_name;
    ++candidate_;
    CloneUBS();
    return;
  }
  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  uevent::ConnectionUeventPtr conn = handle->GetOutConnection(set_ip, set_port);
  if (conn->IsClosed()) {
    LOG_ERROR << "get connection of master failed, " << set_name;
    ++candidate_;
    CloneUBS();
    return;
  }

  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&request_, flowno, session_no_, request_.head().message_type(),
                0, false, objid, 0, "CloneUBS", NULL, NULL);

  std::shared_ptr<CloneUBSHandle> this_ptr =
      std::dynamic_pointer_cast<CloneUBSHandle>(shared_from_this());
  LOG_INFO << request_.DebugString();
  uevent::MessageUtil::SendPbRequest(
      conn, request_,
      std::bind(&CloneUBSHandle::CloneUBSResponse, this_ptr, _1),
      std::bind(&CloneUBSHandle::Timeout, this_ptr, "CloneUBS"),
      g_context->config().forward_timeout());
  return;
}

void CloneUBSHandle::CloneUBSResponse(ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  assert(um->head().message_type() == CLONE_UBS_RESPONSE);
  assert(um->body().HasExtension(clone_ubs_response));
  const ucloud::ubs2::CloneUBSResponse& res =
      um->body().GetExtension(clone_ubs_response);

  if (res.rc().retcode() != 0) {

    if (abs(res.rc().retcode()) == ucloud::ubs2::EC_UBS_RESOURCE_NOT_ENOUGTH) {
      LOG_WARN << "clone ubs fail, capacity not enough in set: " << *candidate_
               << ", will try next set";

      ++candidate_;
      CloneUBS();
      return;
    }

    LOG_ERROR << "clone ubs fail, msg=" << res.rc().error_message()
              << ", code=" << res.rc().retcode();
    SendResponse(res.rc().retcode(), res.rc().error_message());
    return;
  }
  LOG_INFO << "clone success, new ubs id " << res.ubs_id() << ", on set "
           << dst_set_;
  UpdateDB(res.ubs_id());
}

void CloneUBSHandle::UpdateDB(const std::string& extern_id) {
  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  uevent::ConnectionUeventPtr conn = handle->GetOutConnection(kUmongoName);
  if (!conn) {
    LOG_ERROR << "can not get connection of umongo";
    SendResponse(-EC_UBS_INTERNAL_ERROR, "can not get connection of umongo");
    return;
  }

  ucloud::UMessage msg;
  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&msg, flowno, session_no_,
                ucloud::umgogate::EXECUTE_MGO_REQUEST, 0, false, objid, 0,
                "UpdateDB", NULL, NULL);
  ucloud::umgogate::ExecuteMgoRequest* req =
      msg.mutable_body()->MutableExtension(
          ucloud::umgogate::execute_mgo_request);

  vector<ucloud::udisk::ExtentInfoPb> extent_info;
  ucloud::udisk::ExtentInfoPb extent;
  extent.set_id(0);
  extent.set_set_id(*candidate_);
  extent_info.push_back(extent);
  construct_insert_lc_extent_info_request(
      g_context->config().db_name(), req, extern_id,
      req_.lc_info().account_id(), req_.lc_info().company_id(), extent_info);
  std::shared_ptr<CloneUBSHandle> this_ptr =
      std::dynamic_pointer_cast<CloneUBSHandle>(shared_from_this());
  LOG_INFO << msg.DebugString();
  uevent::MessageUtil::SendPbRequest(
      conn, msg, std::bind(&CloneUBSHandle::UpdateDBResponse, this_ptr, _1),
      std::bind(&CloneUBSHandle::Timeout, this_ptr, "UpdateDB"),
      g_context->config().db_timeout());

  return;
}

void CloneUBSHandle::UpdateDBResponse(ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  const ucloud::umgogate::ExecuteMgoResponse& res =
      um->body().GetExtension(ucloud::umgogate::execute_mgo_response);
  if (res.rc().retcode() != 0) {
    LOG_ERROR << "update db fail, msg=" << res.rc().error_message()
              << ", code=" << res.rc().retcode();
    SendResponse(res.rc().retcode(), res.rc().error_message());
    return;
  }

  SendResponse(0, "");
}
