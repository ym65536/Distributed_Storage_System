#ifndef UDISK_ACCESS_LIST_UBS_TOTAL_COUNT_H
#define UDISK_ACCESS_LIST_UBS_TOTAL_COUNT_H

#include <string>
#include <list>
#include "uevent.h"
#include "pb_request_handle.h"
#include "message_util.h"
#include "ubs2_message.h"
#include "udisk_message.h"

namespace udisk {
namespace access {

class ListUBSTotalCountHandle : public uevent::PbRequestHandle {
 public:
  ListUBSTotalCountHandle(uevent::UeventLoop* loop) {}
  virtual ~ListUBSTotalCountHandle() {}

  MYSELF_CREATE(ListUBSTotalCountHandle);

  void SendResponse(uint32_t retcode, const std::string& message);
  void Timeout();
  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         ucloud::UMessage* um);

  void GetValidSetRequest();
  void GetValidSetInfoResponse(
      const ucloud::ResponseCode& rc,
      const std::list<ucloud::udisk::SetInfoPb>& result);

  bool ForwardMasterRequest(int set_id);
  void ForwardMasterResponse(ucloud::UMessage* um);

 private:
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage request_;
  ucloud::ubs2::ListUBSTotalCountRequest req_;
  ucloud::UMessage response_;
  ucloud::ubs2::ListUBSTotalCountResponse* resp_body_;
  std::string session_no_;
  uint32_t expect_response_num_ = 0;
  bool is_fail_ = false;
  uint32_t ubs_total_count_ = 0;
};

};  // end of ns access
};  // end of ns udisk

#endif
