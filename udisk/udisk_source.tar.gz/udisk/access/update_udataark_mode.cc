#include "update_udataark_mode.h"

using namespace udisk::access;
using namespace ucloud::ubs2;

ucloud::ResponseCode* UpdateUDataArkModeHandle::GetRespCode() {
  return resp_body_->mutable_rc();
}

void UpdateUDataArkModeHandle::EntryInit(
    const uevent::ConnectionUeventPtr& conn, ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  conn_ = conn;
  session_no_ = um->head().session_no();
  request_ = *um;
  MakeResponse(&request_, UPDATE_UDATAARK_MODE_RESPONSE, &response_);
  resp_body_ =
      response_.mutable_body()->MutableExtension(update_udataark_mode_response);
  req_ = request_.body().GetExtension(update_udataark_mode_request);

  GetSetRequest(req_.ubs_id());
}

void UpdateUDataArkModeHandle::ForwardReqResponse(ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  assert(um->head().message_type() == UPDATE_UDATAARK_MODE_RESPONSE);
  assert(um->body().HasExtension(update_udataark_mode_response));
  const UpdateUDataArkModeResponse& res =
      um->body().GetExtension(update_udataark_mode_response);
  if (res.rc().retcode() != 0) {
    LOG_ERROR << "Failed to update udata ark mode request, msg="
              << res.rc().error_message() << ", code=" << res.rc().retcode()
              << ", extern_id =" << req_.ubs_id();
    SendResponse(res.rc().retcode(), res.rc().error_message());
    return;
  }

  SendResponse(0, "success");
}
