#ifndef UDISK_ACCESS_RESIZE_UBS_H
#define UDISK_ACCESS_RESIZE_UBS_H

#include <string>
#include <list>
#include "pb_request_handle.h"
#include "message_util.h"
#include "ubs2_message.h"
#include "udisk_message.h"

namespace udisk {
namespace access {

class ResizeUBSHandle : public uevent::PbRequestHandle {
 public:
  ResizeUBSHandle(uevent::UeventLoop* loop) {}
  virtual ~ResizeUBSHandle() {}

  MYSELF_CREATE(ResizeUBSHandle);

  void SendResponse(uint32_t retcode, const std::string& message);
  void Timeout(const std::string& task);
  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         ucloud::UMessage* um);

  bool GetSetRequest();
  void GetSetResponse(const ucloud::ResponseCode& rc,
                      const std::list<ucloud::udisk::LCExtentInfoPb>& result);

  bool CheckMigrateRequest();
  void CheckMigrateResponse(ucloud::UMessage* um);

  bool ForwardMasterRequest();
  void ForwardMasterResponse(ucloud::UMessage* um);

 private:
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage request_;
  ucloud::ubs2::ResizeUBSRequest req_;
  ucloud::UMessage response_;
  ucloud::ubs2::ResizeUBSResponse* resp_body_;
  std::string session_no_;
  int32_t set_id_ = 0;
};

};  // end of ns access
};  // end of ns udisk

#endif
