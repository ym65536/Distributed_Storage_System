#include "finish_migrate_udisk_task.h"
#include <sstream>
#include "access_context.h"
#include "access_loop_handle.h"
#include "umessage_common.h"
#include "umessage.h"
#include "udisk_types.h"
#include "string_util.h"
#include "likely.h"
#include "umongo.h"
#include "access_umongo.h"
#include "do_get_lc_extent_info.h"

using namespace udisk::access;
using namespace udisk::common;
using namespace ucloud::ubs2;
using namespace ucloud::udisk;
using namespace ucloud::udatabase;
using namespace std::placeholders;

void FinishMigrateUDiskTaskHandle::Timeout() {
  LOG_ERROR << "finish_migrate_udisk_task time out, session=" << session_no_;
  SendResponse(-EC_UBS_TEMPORARILY_UNAVAILABLE,
               "finish_migrate_udisk_task time out");
}

void FinishMigrateUDiskTaskHandle::SendResponse(uint32_t retcode,
                                                const std::string& message) {
  resp_body_->mutable_rc()->set_retcode(retcode);
  resp_body_->mutable_rc()->set_error_message(message);
  LOG_INFO << response_.DebugString();
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void FinishMigrateUDiskTaskHandle::EntryInit(
    const uevent::ConnectionUeventPtr& conn, ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  conn_ = conn;
  session_no_ = um->head().session_no();
  request_ = *um;
  MakeResponse(&request_, ucloud::udisk::FINISH_MIGRATE_UDISK_TASK_RESPONSE,
               &response_);
  resp_body_ = response_.mutable_body()->MutableExtension(
      ucloud::udisk::finish_migrate_udisk_task_response);
  req_ = request_.body().GetExtension(
      ucloud::udisk::finish_migrate_udisk_task_request);
  if (req_.has_migrate_version() && req_.migrate_version() == 2) {
    GetLcSetRequest();
  } else {
    CheckMigration();
  }
}

void FinishMigrateUDiskTaskHandle::CheckMigration() {
  std::pair<std::string, int> result = g_context->GetIPPort(kUmongoName);
  std::string umongo_ip = result.first;
  uint32_t umongo_port = result.second;
  if (umongo_ip.empty() || umongo_port == 0) {
    LOG_ERROR << "choose server of umongo fail";
    SendResponse(-ucloud::ubs2::EC_UBS_INTERNAL_ERROR,
                 "choose server of umongo fail");
    return;
  }
  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  uevent::ConnectionUeventPtr conn =
      handle->GetOutConnection(umongo_ip, umongo_port);
  if (conn->IsClosed()) {
    LOG_ERROR << "can not get connection of umongo";
    SendResponse(-EC_UBS_INTERNAL_ERROR, "can not get connection of umongo");
    return;
  }
  ucloud::UMessage msg;
  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&msg, flowno, session_no_,
                ucloud::umgogate::EXECUTE_MGO_REQUEST, 0, false, objid, 0,
                "CheckMigration", NULL, NULL);
  ucloud::umgogate::ExecuteMgoRequest* req =
      msg.mutable_body()->MutableExtension(
          ucloud::umgogate::execute_mgo_request);
  construct_get_migrate_udisk_request(req, req_.extern_id());
  std::shared_ptr<FinishMigrateUDiskTaskHandle> this_ptr =
      std::dynamic_pointer_cast<FinishMigrateUDiskTaskHandle>(
          shared_from_this());
  LOG_INFO << msg.DebugString();
  uevent::MessageUtil::SendPbRequest(
      conn, msg,
      std::bind(&FinishMigrateUDiskTaskHandle::CheckMigrationResponse, this_ptr,
                _1),
      std::bind(&FinishMigrateUDiskTaskHandle::Timeout, this_ptr),
      g_context->config().db_timeout());
  return;
}

void FinishMigrateUDiskTaskHandle::CheckMigrationResponse(
    ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  assert(um->head().message_type() == ucloud::umgogate::EXECUTE_MGO_RESPONSE);
  assert(um->body().HasExtension(ucloud::umgogate::execute_mgo_response));
  const ucloud::umgogate::ExecuteMgoResponse& res =
      um->body().GetExtension(ucloud::umgogate::execute_mgo_response);
  // 查找到迁移的盘
  ucloud::udisk::MigrateUDiskTaskPb migrate_udisk;
  if (res.op_find_rsp().notfound() ||
      parse_get_migrate_udisk_request(&res, migrate_udisk) < 0) {
    LOG_ERROR << "parse mongo response error, extern_id=" << req_.extern_id();
    SendResponse(-EC_UBS_INTERNAL_ERROR, "migrate udisk parse fail");
    return;
  }
  if (migrate_udisk.status() != ucloud::udisk::MIGRATE_COMPLETE) {
    LOG_ERROR << "udisk migrate not finish, extern_id=" << req_.extern_id();
    SendResponse(-ucloud::ubs2::EC_UBS_INTERNAL_ERROR,
                 "udisk migrate not finish");
    return;
  }
  LOG_DEBUG << "CheckMigration response: extern_id="
            << migrate_udisk.extern_id()
            << ", status=" << migrate_udisk.status();
  GetLcSetRequest();
  return;
}

void FinishMigrateUDiskTaskHandle::GetLcSetRequest() {
  ucloud::udisk::GetLCExtentInfoPb lc_extent_req;
  lc_extent_req.add_extern_id(req_.extern_id());
  lc_extent_req.add_extern_id(req_.extern_id() + "_new");
  std::shared_ptr<FinishMigrateUDiskTaskHandle> this_ptr =
      std::dynamic_pointer_cast<FinishMigrateUDiskTaskHandle>(
          shared_from_this());
  std::shared_ptr<DoGetLCExtentInfoHandle> do_get_lc_extent_info_handle =
      std::make_shared<DoGetLCExtentInfoHandle>(
          std::bind(&FinishMigrateUDiskTaskHandle::GetLcSetResponse, this_ptr,
                    std::placeholders::_1, std::placeholders::_2),
          session_no_, false);
  do_get_lc_extent_info_handle->Start(lc_extent_req);
}

void FinishMigrateUDiskTaskHandle::GetLcSetResponse(
    const ucloud::ResponseCode& rc,
    const std::list<ucloud::udisk::LCExtentInfoPb>& result) {
  if (rc.retcode() != 0) {
    LOG_ERROR << "get set error. msg=" << rc.error_message()
              << ", code=" << rc.retcode();
    SendResponse(rc.retcode(), rc.error_message());
    return;
  }

  if (result.size() > 0) {
    if (UNLIKELY(result.size() != 2)) {
      LOG_ERROR << "there are more than one lc id in udisk_access";
      SendResponse(-1, "get set error");
      return;
    }

    for (auto it = result.begin(); it != result.end(); it++) {
      if (UNLIKELY(it->extent_info_size() <= 0)) {
        LOG_ERROR << "get set error. not extent info in udisk_access";
        SendResponse(-1, "get set error");
        return;
      }

      for (int32_t j = 0; j < it->extent_info_size(); ++j) {
        const ucloud::udisk::ExtentInfoPb& extent = it->extent_info(j);
        set_lcs_.insert(std::make_pair(extent.set_id(), it->extern_id()));
        break;
      }
    }

    for (auto it = set_lcs_.begin(); it != set_lcs_.end(); it++) {
      if (UDISK_V4_SET(it->first)) {
        if (!ForwardMasterRequest(it->first, it->second)) {
          LOG_ERROR << "forward req fail, lc_id=" << req_.extern_id();
          SendResponse(-EC_UDISK_INTERNAL_ERROR, "forward req fail");
          return;
        }
        LOG_INFO << "ForwardMasterRequest set_id=" << it->first
                 << ", lc_id=" << it->second;
      }
    }

    return;
  } else {
    LOG_ERROR << "get set error. msg=" << rc.error_message()
              << ", code=" << rc.retcode();
    SendResponse(rc.retcode(), rc.error_message());
    return;
  }
}

bool FinishMigrateUDiskTaskHandle::ForwardMasterRequest(
    int set_id, std::string& extern_id) {
  std::stringstream stream;
  stream << "set" << set_id;
  std::string set_key = stream.str();
  std::string set_name = g_context->mutable_config()->RawGetValue(
      ConfigParser::kSectionName, set_key);
  LOG_INFO << "Forward request " << set_key;

  std::pair<std::string, int> result = g_context->GetIPPort(set_key);
  std::string set_ip = result.first;
  uint32_t set_port = result.second;
  if (set_ip.empty() || set_port == 0) {
    return false;
  }
  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  uevent::ConnectionUeventPtr conn = handle->GetOutConnection(set_ip, set_port);
  if (conn->IsClosed()) {
    return false;
  }

  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  ucloud::UMessage msg;
  NewMessage_v2(&msg, flowno, session_no_, request_.head().message_type(), 0,
                false, objid, 0, "ForwardMaster", NULL, NULL);
  std::shared_ptr<FinishMigrateUDiskTaskHandle> this_ptr =
      std::dynamic_pointer_cast<FinishMigrateUDiskTaskHandle>(
          shared_from_this());
  ucloud::udisk::FinishMigrateUDiskTaskRequest* sReq =
      msg.mutable_body()->MutableExtension(
          ucloud::udisk::finish_migrate_udisk_task_request);
  sReq->set_extern_id(extern_id);
  sReq->set_migrate_version(req_.migrate_version());
  LOG_INFO << msg.DebugString();
  uevent::MessageUtil::SendPbRequest(
      conn, msg, std::bind(&FinishMigrateUDiskTaskHandle::ForwardMasterResponse,
                           this_ptr, _1),
      std::bind(&FinishMigrateUDiskTaskHandle::Timeout, this_ptr),
      g_context->config().forward_timeout());
  return true;
}

void FinishMigrateUDiskTaskHandle::ForwardMasterResponse(ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  const ucloud::udisk::FinishMigrateUDiskTaskResponse& res =
      um->body().GetExtension(
          ucloud::udisk::finish_migrate_udisk_task_response);
  if (res.rc().retcode() != 0) {
    LOG_ERROR << "finish_migrate_udisk_task fail. errmsg="
              << res.rc().error_message() << ", retcode=" << res.rc().retcode();
    SendResponse(res.rc().retcode(), res.rc().error_message());
    return;
  }
  UpdateDB();
  return;
}

void FinishMigrateUDiskTaskHandle::UpdateDB() {
  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  uevent::ConnectionUeventPtr conn = handle->GetOutConnection(kUmongoName);
  if (!conn) {
    LOG_ERROR << "can not get connection of umongo";
    SendResponse(-EC_UBS_INTERNAL_ERROR, "can not get connection of umongo");
    return;
  }

  ucloud::UMessage msg;
  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&msg, flowno, session_no_,
                ucloud::umgogate::EXECUTE_MGO_REQUEST, 0, false, objid, 0,
                "UpdateDB", NULL, NULL);
  ucloud::umgogate::ExecuteMgoRequest* req =
      msg.mutable_body()->MutableExtension(
          ucloud::umgogate::execute_mgo_request);

  std::vector<UpdatePair> updatepairs;
  UpdatePair updatepair;
  updatepair.string_selector.insert(
      std::make_pair(DB_LC_EXTENT_TABLE_COL_EXTERN_ID, req_.extern_id()));
  updatepair.string_doc.insert(std::make_pair(DB_LC_EXTENT_TABLE_COL_EXTERN_ID,
                                              req_.extern_id() + "_old"));
  updatepairs.push_back(updatepair);
  updatepair.Clear();
  updatepair.string_selector.insert(std::make_pair(
      DB_LC_EXTENT_TABLE_COL_EXTERN_ID, req_.extern_id() + "_new"));
  updatepair.string_doc.insert(
      std::make_pair(DB_LC_EXTENT_TABLE_COL_EXTERN_ID, req_.extern_id()));
  updatepairs.push_back(updatepair);
  construct_update_lc_extent_info_request(g_context->config().db_name(), req,
                                          updatepairs);
  std::shared_ptr<FinishMigrateUDiskTaskHandle> this_ptr =
      std::dynamic_pointer_cast<FinishMigrateUDiskTaskHandle>(
          shared_from_this());
  LOG_INFO << msg.DebugString();
  uevent::MessageUtil::SendPbRequest(
      conn, msg,
      std::bind(&FinishMigrateUDiskTaskHandle::UpdateDBResponse, this_ptr, _1),
      std::bind(&FinishMigrateUDiskTaskHandle::Timeout, this_ptr),
      g_context->config().db_timeout());

  return;
}

void FinishMigrateUDiskTaskHandle::UpdateDBResponse(ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  const ucloud::umgogate::ExecuteMgoResponse& res =
      um->body().GetExtension(ucloud::umgogate::execute_mgo_response);
  if (res.rc().retcode() != 0) {
    LOG_ERROR << "update db fail, msg=" << res.rc().error_message()
              << ", code=" << res.rc().retcode();
    SendResponse(res.rc().retcode(), res.rc().error_message());
    return;
  }

  SendResponse(0, "");
}
