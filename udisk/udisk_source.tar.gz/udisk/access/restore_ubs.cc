#include "restore_ubs.h"
#include <sstream>
#include "access_context.h"
#include "access_loop_handle.h"
#include "string_util.h"
#include "umongo.h"
#include "udisk_message.h"
#include "likely.h"
#include "do_get_lc_extent_info.h"

using namespace udisk::access;
using namespace udisk::common;
using namespace ucloud::ubs2;
using namespace ucloud::udatabase;
using namespace ucloud::umgogate;
using namespace std::placeholders;

void RestoreUBSHandle::Timeout() {
  LOG_ERROR << "RestoreUBSHandle time out, session=" << session_no_;
  SendResponse(-EC_UBS_TIMEOUT, "RestoreUBSHandle time out");
}

void RestoreUBSHandle::SendResponse(uint32_t retcode,
                                    const std::string& message) {
  resp_body_->mutable_rc()->set_retcode(retcode);
  resp_body_->mutable_rc()->set_error_message(message);
  LOG_INFO << response_.DebugString();
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void RestoreUBSHandle::EntryInit(const uevent::ConnectionUeventPtr& conn,
                                 ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  conn_ = conn;
  session_no_ = um->head().session_no();
  request_ = *um;
  MakeResponse(&request_, RESTORE_UBS_RESPONSE, &response_);
  resp_body_ = response_.mutable_body()->MutableExtension(restore_ubs_response);
  req_ = request_.body().GetExtension(restore_ubs_request);

  if (!GetSetRequest()) {
    LOG_ERROR << "get set request fail";
    SendResponse(-EC_UBS_INTERNAL_ERROR, "get set request fail");
    return;
  }
}

bool RestoreUBSHandle::GetSetRequest() {
  ucloud::udisk::GetLCExtentInfoPb lc_extent_req;
  lc_extent_req.add_extern_id(req_.ubs_id());
  std::shared_ptr<RestoreUBSHandle> this_ptr =
      std::dynamic_pointer_cast<RestoreUBSHandle>(shared_from_this());
  std::shared_ptr<DoGetLCExtentInfoHandle> do_get_lc_extent_info_handle =
      std::make_shared<DoGetLCExtentInfoHandle>(
          std::bind(&RestoreUBSHandle::GetSetResponse, this_ptr,
                    std::placeholders::_1, std::placeholders::_2),
          session_no_);
  do_get_lc_extent_info_handle->Start(lc_extent_req);

  return true;
}

void RestoreUBSHandle::GetSetResponse(
    const ucloud::ResponseCode& rc,
    const std::list<ucloud::udisk::LCExtentInfoPb>& result) {
  if (rc.retcode() != 0) {
    LOG_ERROR << "get set error. msg=" << rc.error_message()
              << ", code=" << rc.retcode();
    SendResponse(rc.retcode(), rc.error_message());
    return;
  }

  if (result.size() > 0) {
    if (UNLIKELY(result.size() != 1)) {
      LOG_ERROR << "there are more than one extern id in udisk_access";
      SendResponse(-1, "get set error");
      return;
    }

    const auto& it = result.begin();
    if (UNLIKELY(it->extent_info_size() <= 0)) {
      LOG_ERROR << "get set error. not extent info in udisk_access";
      SendResponse(-1, "get set error");
      return;
    }

    // TODO(alan.ding) 大盘跨set恢复
    for (int32_t j = 0; j < it->extent_info_size(); ++j) {
      const ucloud::udisk::ExtentInfoPb& extent = it->extent_info(j);
      set_id_ = extent.set_id();
      break;
    }

    LOG_INFO << "get set_id=" << set_id_ << ", extern_id=" << req_.ubs_id();
    if (!CheckMigrateRequest()) {
      LOG_ERROR << "check migrate udisk fail. extern_id=" << req_.ubs_id();
      SendResponse(-EC_UBS_INTERNAL_ERROR, "check migrate udisk fail");
      return;
    }
  } else {
    LOG_ERROR << "cannot find this extern_id=" << req_.ubs_id();
    SendResponse(-EC_UBS_NO_SUCH_LOGICAL_CHUNK, "cannot find this extern_id");
    return;
  }
}

bool RestoreUBSHandle::CheckMigrateRequest() {
  std::pair<std::string, int> result = g_context->GetIPPort(kUmongoName);
  std::string umongo_ip = result.first;
  uint32_t umongo_port = result.second;
  if (umongo_ip.empty() || umongo_port == 0) {
    return false;
  }
  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  uevent::ConnectionUeventPtr conn =
      handle->GetOutConnection(umongo_ip, umongo_port);
  if (conn->IsClosed()) {
    return false;
  }
  ucloud::UMessage msg;
  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&msg, flowno, session_no_,
                ucloud::umgogate::EXECUTE_MGO_REQUEST, 0, false, objid, 0,
                "GetLCInfo", NULL, NULL);
  ExecuteMgoRequest* req =
      msg.mutable_body()->MutableExtension(execute_mgo_request);
  construct_get_migrate_udisk_request(req, req_.ubs_id());
  std::shared_ptr<RestoreUBSHandle> this_ptr =
      std::dynamic_pointer_cast<RestoreUBSHandle>(shared_from_this());
  LOG_INFO << msg.DebugString();
  uevent::MessageUtil::SendPbRequest(
      conn, msg,
      std::bind(&RestoreUBSHandle::CheckMigrateResponse, this_ptr, _1),
      std::bind(&RestoreUBSHandle::Timeout, this_ptr),
      g_context->config().db_timeout());
  return true;
}

void RestoreUBSHandle::CheckMigrateResponse(ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  assert(um->head().message_type() == ucloud::umgogate::EXECUTE_MGO_RESPONSE);
  assert(um->body().HasExtension(ucloud::umgogate::execute_mgo_response));
  const ucloud::umgogate::ExecuteMgoResponse& res =
      um->body().GetExtension(ucloud::umgogate::execute_mgo_response);
  if (!res.op_find_rsp().notfound()) {
    ucloud::udisk::MigrateUDiskTaskPb migrate_udisk;
    if (parse_get_migrate_udisk_request(&res, migrate_udisk) < 0) {
      LOG_ERROR << "parse mongo response error, extern_id=" << req_.ubs_id();
      SendResponse(-1, "udisk migrate parse fail");
      return;
    }
    if (migrate_udisk.status() == ucloud::udisk::MIGRATE_INPROCESS) {
      LOG_ERROR << "udisk in migration, extern_id=" << req_.ubs_id();
      SendResponse(-EC_UBS_INTERNAL_ERROR, "udisk in migration");
      return;
    }
    LOG_DEBUG << "CheckMigrate response: extern_id="
              << migrate_udisk.extern_id()
              << ", status=" << migrate_udisk.status();
  }
  ForwardMasterRequest();
  return;
}

void RestoreUBSHandle::ForwardMasterRequest() {
  std::stringstream stream;
  stream << "set" << set_id_;
  std::string set_key = stream.str();
  std::string set_name = g_context->mutable_config()->RawGetValue(
      ConfigParser::kSectionName, set_key);
  LOG_INFO << "Forward request " << set_id_ << ", extern_id=" << req_.ubs_id();

  std::pair<std::string, int> result = g_context->GetIPPort(set_key);
  std::string set_ip = result.first;
  uint32_t set_port = result.second;
  if (set_ip.empty() || set_port == 0) {
    LOG_ERROR << "choose server of master fail";
    SendResponse(-EC_UBS_INTERNAL_ERROR, "choose server of master fail");
    return;
  }
  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  uevent::ConnectionUeventPtr conn = handle->GetOutConnection(set_ip, set_port);
  if (conn->IsClosed()) {
    LOG_ERROR << "get connection of master fail";
    SendResponse(-EC_UBS_INTERNAL_ERROR, "get connection of master fail");
    return;
  }

  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&request_, flowno, session_no_, request_.head().message_type(),
                0, false, objid, 0, "ForwardMaster", NULL, NULL);
  std::shared_ptr<RestoreUBSHandle> this_ptr =
      std::dynamic_pointer_cast<RestoreUBSHandle>(shared_from_this());
  LOG_INFO << request_.DebugString();
  uevent::MessageUtil::SendPbRequest(
      conn, request_,
      std::bind(&RestoreUBSHandle::ForwardMasterResponse, this_ptr, _1),
      std::bind(&RestoreUBSHandle::Timeout, this_ptr),
      g_context->config().forward_timeout());
  return;
}

void RestoreUBSHandle::ForwardMasterResponse(ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  const RestoreUBSResponse& res = um->body().GetExtension(restore_ubs_response);
  if (res.rc().retcode() != 0) {
    LOG_ERROR << "restore ubs respose fail. errmsg=" << res.rc().error_message()
              << ", retcode=" << res.rc().retcode()
              << ", extern_id=" << req_.ubs_id();
    SendResponse(res.rc().retcode(), res.rc().error_message());
    return;
  }
  SendResponse(0, "success");
  return;
}
