#include "get_udisk_extent_info.h"
#include "do_get_set_info.h"
#include "access_loop_handle.h"
#include "access_context.h"

#include "logging.h"
#include "message_util.h"
#include "access_umongo.h"

using namespace udisk::access;
using namespace ucloud::udisk;
using namespace ucloud::umgogate;
using namespace std::placeholders;
using namespace uevent;

void GetUDiskExtentInfoHandle::Timeout() {
  LOG_ERROR << "GetUDiskExtentInfoHandle time out";
  SendResponse(-EC_UDISK_OPT_TIMEOUT, "GetUDiskExtentInfoHandle time out");
}

void GetUDiskExtentInfoHandle::SendResponse(int32_t retcode,
                                            const std::string& message) {
  resp_body_->mutable_rc()->set_retcode(retcode);
  resp_body_->mutable_rc()->set_error_message(message);
  LOG_INFO << response_.DebugString();
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void GetUDiskExtentInfoHandle::EntryInit(
    const uevent::ConnectionUeventPtr& conn, ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  conn_ = conn;
  session_no_ = um->head().session_no();
  MakeResponse(um, GET_UDISK_EXTENT_INFO_RESPONSE, &response_);
  resp_body_ = response_.mutable_body()->MutableExtension(
      get_udisk_extent_info_response);
  req_body_ = um->body().GetExtension(get_udisk_extent_info_request);
  GetSetInfoRequest();
}

void GetUDiskExtentInfoHandle::GetSetInfoRequest() {
  GetSetInfoPb req;
  req.add_state(SET_STATE_ONLINE);
  req.add_state(SET_STATE_RESTRICTED);
  auto this_ptr =
      std::dynamic_pointer_cast<GetUDiskExtentInfoHandle>(shared_from_this());
  auto do_get_set_info_handle = std::make_shared<DoGetSetInfoHandle>(
      std::bind(&GetUDiskExtentInfoHandle::GetSetInfoResponse, this_ptr, _1,
                _2),
      session_no_);
  do_get_set_info_handle->Start(req);
}

void GetUDiskExtentInfoHandle::GetSetInfoResponse(
    const ucloud::ResponseCode& rc,
    const std::list<ucloud::udisk::SetInfoPb>& result) {
  if (rc.retcode() != 0) {
    LOG_ERROR << "Failed to get set info. " << rc.error_message();
    SendResponse(rc.retcode(), rc.error_message());
    return;
  }
  for (auto it = result.begin(); it != result.end(); ++it) {
    set_infos_.insert(std::make_pair(it->id(), *it));
  }
  GetLCExtentInfoRequest();
}

void GetUDiskExtentInfoHandle::GetLCExtentInfoRequest() {
  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  uevent::ConnectionUeventPtr conn = handle->GetOutConnection(kUmongoName);
  if (!conn) {
    LOG_ERROR << "GetUDiskExtentInfoHandle. Failed to get umongo connection";
    SendResponse(-EC_UDISK_INTERNAL_ERROR, "Failed to get umongo connection");
    return;
  }

  ucloud::UMessage msg;
  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&msg, flowno, session_no_, EXECUTE_MGO_REQUEST, 0, false, objid,
                0, "GetLCExtentInfo", NULL, NULL);
  ExecuteMgoRequest* req =
      msg.mutable_body()->MutableExtension(execute_mgo_request);
  FindPair findpair;
  for (int32_t i = 0; i < req_body_.extern_ids_size(); ++i) {
    findpair.string_or_selector.insert(std::make_pair(
        DB_LC_EXTENT_TABLE_COL_EXTERN_ID, req_body_.extern_ids(i)));
  }
  construct_get_lc_extent_info_request(g_context->config().db_name(), req,
                                       findpair, fields_null, fields_null);
  auto this_ptr =
      std::dynamic_pointer_cast<GetUDiskExtentInfoHandle>(shared_from_this());
  LOG_INFO << msg.DebugString();
  uevent::MessageUtil::SendPbRequest(
      conn, msg, std::bind(&GetUDiskExtentInfoHandle::GetLCExtentInfoResponse,
                           this_ptr, _1),
      std::bind(&GetUDiskExtentInfoHandle::Timeout, this_ptr),
      g_context->config().db_timeout());
}

void GetUDiskExtentInfoHandle::GetLCExtentInfoResponse(ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  const ExecuteMgoResponse& res = um->body().GetExtension(execute_mgo_response);
  if (res.rc().retcode() != 0 && !res.op_find_rsp().notfound()) {
    LOG_ERROR << res.rc().error_message();
    SendResponse(-EC_UDISK_DB_ERROR, res.rc().error_message());
    return;
  }
  std::list<LCExtentInfoPb> lc_extent_info_;
  if (!parse_lc_extent_info_response(res, &lc_extent_info_)) {
    LOG_ERROR << "parse get lc extent info response error";
    SendResponse(-EC_UDISK_PB_PARSE_FAIL, "parse lc extent info error");
    return;
  }

  for (const auto& item : lc_extent_info_) {
    bool offline = false;
    for (int32_t i = 0; i < item.extent_info_size(); ++i) {
      if (set_infos_.count(item.extent_info(i).set_id()) == 0) {
        offline = true;
        break;
      }
    }
    if (offline) {
      LOG_WARN << "lc offline.extent_info=" << item.DebugString();
      continue;
    }
    LCExtentInfoPb* info = resp_body_->add_extent_infos();
    info->CopyFrom(item);
  }
  SendResponse(0, "Success");
}
