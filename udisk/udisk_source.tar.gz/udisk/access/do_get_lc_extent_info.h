#ifndef DO_GET_LC_EXTENT_INFO_H
#define DO_GET_LC_EXTENT_INFO_H

#include <memory>
#include <list>
#include "udisk_message.h"
#include "umessage_common.h"

namespace udisk {
namespace access {

class DoGetLCExtentInfoHandle
    : public std::enable_shared_from_this<DoGetLCExtentInfoHandle> {
 public:
  typedef std::function<void(const ucloud::ResponseCode&,
                             const std::list<ucloud::udisk::LCExtentInfoPb>&)>
      ResponseHook;
  explicit DoGetLCExtentInfoHandle(ResponseHook hook,
                                   const std::string& session_no,
                                   bool ignore_offline = true)
      : rsp_hook_(hook),
        session_no_(session_no),
        ignore_offline_(ignore_offline) {}
  void Start(const ucloud::udisk::GetLCExtentInfoPb& info);

 private:
  void Timeout();
  void Finish(uint32_t retcode, const std::string& message);
  void CheckSetInfo();
  void GetLCExtentInfo();
  void GetLCExtentInfoResponse(ucloud::UMessage* um);
  void GetValidSetInfo();
  void GetValidSetInfoResponse(
      const ucloud::ResponseCode& rc,
      const std::list<ucloud::udisk::SetInfoPb>& result);

  ResponseHook rsp_hook_;
  std::string session_no_;
  bool ignore_offline_;
  vector<int32_t> set_ids_;
  ucloud::udisk::GetLCExtentInfoPb request_;
  std::list<ucloud::udisk::LCExtentInfoPb> lc_extent_info_;
};

}  // namespace access
}  // namespace udisk

#endif /* !DO_GET_LC_EXTENT_INFO_H */
// vim: set ts=2 sw=2 sts=2 et:
