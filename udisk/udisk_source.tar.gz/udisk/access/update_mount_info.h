#ifndef UDISK_ACCESS_UPDATE_MOUNT_INFO_H
#define UDISK_ACCESS_UPDATE_MOUNT_INFO_H

#include "forward_request_base.h"

namespace udisk {
namespace access {

class UpdateMountInfoHandle : public ForwardRequestBaseHandle {
 public:
  UpdateMountInfoHandle(uevent::UeventLoop* loop)
      : ForwardRequestBaseHandle("UpdateMountInfo") {}
  virtual ~UpdateMountInfoHandle() {}

  MYSELF_CREATE(UpdateMountInfoHandle);

  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         ucloud::UMessage* um);
  virtual ucloud::ResponseCode* GetRespCode();
  virtual void ForwardReqResponse(ucloud::UMessage* um);

 private:
  ucloud::ubs2::UpdateMountInfoRequest req_;
  ucloud::ubs2::UpdateMountInfoResponse* resp_body_;
};

};  // end of ns access
};  // end of ns udisk

#endif
