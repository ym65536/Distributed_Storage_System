#include "check_allowance.h"

#include "access_context.h"
#include "access_loop_handle.h"
#include "umessage.h"
#include "umessage_common.h"
#include "do_get_available_sets.h"
#include "logging.h"
#include <sstream>

using namespace udisk::access;
using namespace udisk::common;
using namespace ucloud::ubs2;
// using namespace ucloud::udatabase;
using namespace std::placeholders;

void CheckAllowanceHandle::Timeout() {
  LOG_ERROR << "CheckAllowanceHandle Time out on when forwarding Req to Set("
            << *working_set_ << ") Retry the next Set if had...";
  ++working_set_;
  ForwardReq();
}

void CheckAllowanceHandle::SendResponse(uint32_t retcode,
                                        const std::string& message) {
  resp_body_->mutable_rc()->set_retcode(retcode);
  resp_body_->mutable_rc()->set_error_message(message);
  resp_body_->set_count(current_count_);
  LOG_INFO << response_.DebugString();
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void CheckAllowanceHandle::EntryInit(const uevent::ConnectionUeventPtr& conn,
                                     ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  conn_ = conn;
  session_no_ = um->head().session_no();
  request_ = *um;
  MakeResponse(&request_, CHECK_ALLOWANCE_RESPONSE, &response_);
  resp_body_ =
      response_.mutable_body()->MutableExtension(check_allowance_response);
  req_ = request_.body().GetExtension(check_allowance_request);

  size_ = req_.size();
  total_count_ = req_.count();
  oid_ = req_.account_id();
  current_count_ = 0;
  GetAvailableSets();
}

void CheckAllowanceHandle::GetAvailableSets() {
  std::shared_ptr<CheckAllowanceHandle> this_ptr =
      std::dynamic_pointer_cast<CheckAllowanceHandle>(shared_from_this());
  std::shared_ptr<DoGetAvailableSetsHandle> do_get_available_sets_handle =
      std::make_shared<DoGetAvailableSetsHandle>(
          std::bind(&CheckAllowanceHandle::GetAvailableSetsResponse, this_ptr,
                    _1, _2),
          session_no_);
  do_get_available_sets_handle->Start(oid_);
}

void CheckAllowanceHandle::GetAvailableSetsResponse(
    const ucloud::ResponseCode& rc, std::vector<int32_t>& available_sets) {
  if (rc.retcode() != 0) {
    LOG_ERROR << "Failed to get available sets info. " << rc.error_message();
    SendResponse(rc.retcode(), rc.error_message());
    return;
  }

  available_sets_.swap(available_sets);
  working_set_ = available_sets_.begin();
  ForwardReq();
}

void CheckAllowanceHandle::ForwardReq() {
  if (working_set_ == available_sets_.end()) {
    // 请求列表内的set全部尝试失败
    LOG_ERROR
    << "Hydra CheckAllowance: could not be satisfied in all available sets."
    << " still_count:" << total_count_ - current_count_ << " size:" << size_;
    SendResponse(-EC_UBS_RESOURCE_NOT_ENOUGTH,
                 "Not enough resource to allocate all request.");
    return;
  }

  LOG_INFO << "Checking Allowance to Set " << *working_set_;
  std::stringstream stream;
  stream << "set" << *working_set_;
  std::string set_key = stream.str();
  std::string set_name = g_context->mutable_config()->RawGetValue(
      ConfigParser::kSectionName, set_key);

  std::pair<std::string, int> result = g_context->GetIPPort(set_key);
  std::string set_ip = result.first;
  uint32_t set_port = result.second;
  if (set_ip.empty() || set_port == 0) {
    LOG_ERROR << "choose server of master failed, " << set_name;
    ++working_set_;
    ForwardReq();
    return;
  }

  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  uevent::ConnectionUeventPtr conn = handle->GetOutConnection(set_ip, set_port);
  if (conn->IsClosed()) {
    LOG_ERROR << "get connection of master failed, " << set_name;
    ++working_set_;
    ForwardReq();
    return;
  }

  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&request_, flowno, session_no_, request_.head().message_type(),
                0, false, objid, 0, "CheckAllowance", NULL, NULL);
  LOG_INFO << request_.DebugString();
  std::shared_ptr<CheckAllowanceHandle> this_ptr =
      std::dynamic_pointer_cast<CheckAllowanceHandle>(shared_from_this());
  uevent::MessageUtil::SendPbRequest(
      conn, request_,
      std::bind(&CheckAllowanceHandle::ForwardReqResponse, this_ptr, _1),
      std::bind(&CheckAllowanceHandle::Timeout, this_ptr),
      g_context->config().forward_timeout());
  return;
}

void CheckAllowanceHandle::ForwardReqResponse(ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  assert(um->head().message_type() == CHECK_ALLOWANCE_RESPONSE);
  assert(um->body().HasExtension(check_allowance_response));
  const CheckAllowanceResponse& res =
      um->body().GetExtension(check_allowance_response);

  if (res.rc().retcode() == 0) {
    // 在这个Set里可以全部申请成功。
    LOG_INFO << "CheckAllowance request could succeed."
             << " count:" << current_count_ << "; size:" << size_
             << "; set:" << *working_set_;
    current_count_ = total_count_;
    SendResponse(0, "success");
    return;
  }

  if (res.rc().retcode() == -EC_UBS_RESOURCE_NOT_ENOUGTH) {
    LOG_INFO << "CheckAllowance, Set:" << *working_set_
             << " ;only fit for count:" << res.count() << " ;size:" << size_;
    current_count_ += res.count();
    if (current_count_ >= total_count_) {
      LOG_INFO << "CheckAllowance, Request Could be Satisfied in several Sets.";
      SendResponse(0, "All request should be satisfied.");
      return;
    }

    // 这个set可以满足部分请求。
    LOG_INFO << "CheckAllowance, Still left:" << total_count_ - current_count_;
  } else {
    LOG_ERROR << "Failed to check allowance, msg=" << res.rc().error_message()
              << ", code=" << res.rc().retcode() << ", set=" << *working_set_;
  }

  ++working_set_;
  ForwardReq();
}
