#ifndef UDISK_ACCESS_TAKE_BACK_UBS_H
#define UDISK_ACCESS_TAKE_BACK_UBS_H

#include "forward_request_base.h"

namespace udisk {
namespace access {

class TakeBackUBSHandle : public ForwardRequestBaseHandle {
 public:
  TakeBackUBSHandle(uevent::UeventLoop* loop)
      : ForwardRequestBaseHandle("TakeBackUBS") {}
  virtual ~TakeBackUBSHandle() {}

  MYSELF_CREATE(TakeBackUBSHandle);

  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         ucloud::UMessage* um);
  virtual ucloud::ResponseCode* GetRespCode();
  virtual void ForwardReqResponse(ucloud::UMessage* um);

 private:
  ucloud::ubs2::TakeBackUBSRequest req_;
  ucloud::ubs2::TakeBackUBSResponse* resp_body_;
};

};  // namespace access
};  // namespace udisk

#endif
