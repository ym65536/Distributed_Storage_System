#ifndef DO_GET_OPTIMAL_SETS_H
#define DO_GET_OPTIMAL_SETS_H

#include <memory>
#include <list>
#include <set>
#include "udisk_message.h"
#include "umessage_common.h"

namespace udisk {
namespace access {

class DoGetOptimalSetsHandle
    : public std::enable_shared_from_this<DoGetOptimalSetsHandle> {
 public:
  typedef std::function<
      void(const ucloud::ResponseCode&, std::vector<int32_t>&)> ResponseHook;
  explicit DoGetOptimalSetsHandle(ResponseHook hook,
                                  const std::string& session_no)
      : rsp_hook_(hook), session_no_(session_no) {}
  void Start(int32_t set_type, uint32_t oid, const std::string& logic_zone,
             uint32_t size = 0);

 private:
  void Finish(uint32_t retcode, const std::string& message);
  void Timeout();
  void GetAvailableSets();
  void GetAvailableSetsResponse(const ucloud::ResponseCode& rc,
                                std::vector<int32_t>& available_sets);
  void MakeWaterLineSets(const std::vector<int32_t>& available_sets);
  bool GetUserLCStatisticInfo(int32_t set_id);
  void GetUserLCStatisticInfoResponse(ucloud::UMessage* um, int32_t set_id);
  void GetUserLCStatisticInfoTimeout(int32_t set_id);
  void GetSetByLogicZone();
  void GetSetByLogicZoneResponse(
      const ucloud::ResponseCode& rc,
      const std::list<ucloud::udisk::SetInfoPb>& result);
  void MakeCandidateSets();
  void InsertLowerWaterLineSets(int32_t set_id);
  std::string DumpResult();

  ResponseHook rsp_hook_;
  std::string session_no_;
  ucloud::udisk::SET_TYPE set_type_;
  uint32_t oid_;
  uint32_t size_;
  std::string logic_zone_;

  uint32_t user_lc_statistic_info_rsp_num_;
  uint32_t over_water_line_sets_total_;
  std::vector<int32_t> logic_zone_set_;
  // 高于容量水位线set(udisk_num=>set)
  std::multimap<uint32_t, int32_t> upper_water_line_sets_;
  // 低于容量水位线set(remain_cap=>set)
  std::multimap<int64_t, int32_t, std::greater<int64_t>> lower_water_line_sets_;
  std::vector<int32_t> candidate_sets_;
};

}  // namespace access
}  // namespace udisk

#endif /* !DO_GET_OPTIMAL_SETS_H */
// vim: set ts=2 sw=2 sts=2 et:
