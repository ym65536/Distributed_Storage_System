#include "update_mount_info.h"

using namespace udisk::access;
using namespace ucloud::ubs2;

ucloud::ResponseCode* UpdateMountInfoHandle::GetRespCode() {
  return resp_body_->mutable_rc();
}

void UpdateMountInfoHandle::EntryInit(const uevent::ConnectionUeventPtr& conn,
                                      ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  conn_ = conn;
  session_no_ = um->head().session_no();
  request_ = *um;
  MakeResponse(&request_, UPDATE_MOUNT_INFO_RESPONSE, &response_);
  resp_body_ =
      response_.mutable_body()->MutableExtension(update_mount_info_response);
  req_ = request_.body().GetExtension(update_mount_info_request);
  GetSetRequest(req_.ubs_id());
}

void UpdateMountInfoHandle::ForwardReqResponse(ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  const UpdateMountInfoResponse& res =
      um->body().GetExtension(update_mount_info_response);
  if (res.rc().retcode() != 0) {
    LOG_ERROR << "update mount info fail. errmsg=" << res.rc().error_message()
              << ", retcode=" << res.rc().retcode()
              << ", extern_id=" << req_.ubs_id();
    SendResponse(res.rc().retcode(), res.rc().error_message());
    return;
  }

  resp_body_->CopyFrom(res);
  SendResponse(0, "success");
  return;
}
