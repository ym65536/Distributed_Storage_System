#include "list_ubs_total_count.h"
#include <sstream>
#include "logging.h"
#include "timestamp.h"
#include "access_context.h"
#include "access_loop_handle.h"
#include "string_util.h"
#include "likely.h"
#include "do_get_set_info.h"

using namespace udisk::access;
using namespace udisk::common;
using namespace ucloud::ubs2;
using namespace ucloud::udisk;
using namespace ucloud::udatabase;
using namespace std::placeholders;

void ListUBSTotalCountHandle::Timeout() {
  expect_response_num_--;
  is_fail_ = true;
  LOG_ERROR << "list ubs total count time out, session=" << session_no_;
  if (expect_response_num_ == 0) {
    SendResponse(-EC_UBS_TIMEOUT, "ListUBSTotalCountHandle time out");
  }
}

void ListUBSTotalCountHandle::SendResponse(uint32_t retcode,
                                           const std::string& message) {
  resp_body_->mutable_rc()->set_retcode(retcode);
  resp_body_->mutable_rc()->set_error_message(message);
  if (retcode == 0) {
    resp_body_->set_total_count(ubs_total_count_);
  }
  LOG_INFO << response_.DebugString();
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void ListUBSTotalCountHandle::EntryInit(const uevent::ConnectionUeventPtr& conn,
                                        ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  conn_ = conn;
  session_no_ = um->head().session_no();
  request_ = *um;
  MakeResponse(&request_, ucloud::ubs2::LIST_UBS_TOTAL_COUNT_RESPONSE,
               &response_);
  resp_body_ = response_.mutable_body()->MutableExtension(
      ucloud::ubs2::list_ubs_total_count_response);
  req_ =
      request_.body().GetExtension(ucloud::ubs2::list_ubs_total_count_request);
  GetValidSetRequest();
}

void ListUBSTotalCountHandle::GetValidSetRequest() {
  ucloud::udisk::GetSetInfoPb req;
  req.add_state(ucloud::udisk::SET_STATE_ONLINE);
  req.add_state(ucloud::udisk::SET_STATE_RESTRICTED);

  std::shared_ptr<ListUBSTotalCountHandle> this_ptr =
      std::dynamic_pointer_cast<ListUBSTotalCountHandle>(shared_from_this());

  std::shared_ptr<DoGetSetInfoHandle> do_get_set_info_handle =
      std::make_shared<DoGetSetInfoHandle>(
          std::bind(&ListUBSTotalCountHandle::GetValidSetInfoResponse, this_ptr,
                    std::placeholders::_1, std::placeholders::_2),
          session_no_);
  do_get_set_info_handle->Start(req);
}

void ListUBSTotalCountHandle::GetValidSetInfoResponse(
    const ucloud::ResponseCode& rc,
    const std::list<ucloud::udisk::SetInfoPb>& result) {
  if (rc.retcode() != 0) {
    LOG_ERROR << "Failed to get set info. " << rc.error_message();
    SendResponse(rc.retcode(), rc.error_message());
    return;
  }

  for (auto it = result.begin(); it != result.end(); ++it) {
    expect_response_num_++;
    if (!ForwardMasterRequest(it->id())) {
      expect_response_num_--;
      is_fail_ = true;
    }
  }
  if (expect_response_num_ == 0) {
    if (is_fail_) {
      SendResponse(-ucloud::ubs2::EC_UBS_INTERNAL_ERROR, "forward req fail");
    } else {
      SendResponse(0, "success");
    }
  }
}

bool ListUBSTotalCountHandle::ForwardMasterRequest(int set_id) {
  std::stringstream stream;
  stream << "set" << set_id;
  std::string set_key = stream.str();
  std::string set_name = g_context->mutable_config()->RawGetValue(
      ConfigParser::kSectionName, set_key);
  LOG_INFO << "Forward request " << set_key;

  std::pair<std::string, int> result = g_context->GetIPPort(set_key);
  std::string set_ip = result.first;
  uint32_t set_port = result.second;
  if (set_ip.empty() || set_port == 0) {
    return false;
  }
  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  uevent::ConnectionUeventPtr conn = handle->GetOutConnection(set_ip, set_port);
  if (conn->IsClosed()) {
    return false;
  }

  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&request_, flowno, session_no_, request_.head().message_type(),
                0, false, objid, 0, "ForwardMaster", NULL, NULL);
  std::shared_ptr<ListUBSTotalCountHandle> this_ptr =
      std::dynamic_pointer_cast<ListUBSTotalCountHandle>(shared_from_this());
  LOG_INFO << request_.DebugString();
  uevent::MessageUtil::SendPbRequest(
      conn, request_,
      std::bind(&ListUBSTotalCountHandle::ForwardMasterResponse, this_ptr, _1),
      std::bind(&ListUBSTotalCountHandle::Timeout, this_ptr),
      g_context->config().forward_timeout());
  return true;
}

void ListUBSTotalCountHandle::ForwardMasterResponse(ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  expect_response_num_--;
  const ListUBSTotalCountResponse& res =
      um->body().GetExtension(ucloud::ubs2::list_ubs_total_count_response);
  if (res.rc().retcode() != 0) {
    LOG_ERROR << "list_ubs_total_count fail. errmsg="
              << res.rc().error_message() << ", retcode=" << res.rc().retcode();
    is_fail_ = true;
  } else {
    ubs_total_count_ += res.total_count();
  }
  if (expect_response_num_ == 0) {
    if (is_fail_) {
      SendResponse(-ucloud::ubs2::EC_UBS_INTERNAL_ERROR,
                   res.rc().error_message());
    } else {
      SendResponse(0, "success");
    }
  }
}
