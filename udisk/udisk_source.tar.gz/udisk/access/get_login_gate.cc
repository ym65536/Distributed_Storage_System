#include "get_login_gate.h"
#include <sstream>
#include "logging.h"
#include "timestamp.h"

#include "message_util.h"
#include "access_context.h"
#include "access_loop_handle.h"
#include "umessage_common.h"
#include "umessage.h"
#include "string_util.h"
#include "umongo.h"
#include "udisk_types.h"
#include "likely.h"
#include "do_get_lc_extent_info.h"

using namespace udisk::access;
using namespace udisk::common;
using namespace ucloud::udisk;
using namespace ucloud::udatabase;
using namespace ucloud::umgogate;
using namespace std::placeholders;

void GetLoginGateHandle::Timeout(const std::string& task) {
  LOG_ERROR << "GetLoginGateHandle time out, session=" << session_no_
            << ", task=" << task;
  if (task == FORWARD_PEER_LABEL) {  // 转发到其他access超时
    --forward_ref_;
    if (forward_ref_ == 0 && !responsed_) {
      SendResponse(-EC_UDISK_OPT_TIMEOUT, "GetLoginGate time out");
    } else {
      // 转发到peer超时，且不是最后一个回包，do nothing
    }
  } else {
    SendResponse(-EC_UDISK_OPT_TIMEOUT, "GetLoginGate time out");
  }
}

void GetLoginGateHandle::SendResponse(uint32_t retcode,
                                      const std::string& message) {
  resp_body_->mutable_rc()->set_retcode(retcode);
  resp_body_->mutable_rc()->set_error_message(message);
  LOG_INFO << response_.DebugString();
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void GetLoginGateHandle::EntryInit(const uevent::ConnectionUeventPtr& conn,
                                   ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  conn_ = conn;
  session_no_ = um->head().session_no();
  request_ = *um;
  MakeResponse(&request_, ucloud::udisk::GET_LOGIN_GATE_RESPONSE, &response_);
  resp_body_ = response_.mutable_body()->MutableExtension(
      ucloud::udisk::get_login_gate_response);
  req_ = request_.body().GetExtension(get_login_gate_request);

  if (!GetSetRequest()) {
    LOG_ERROR << "get set request fail";
    SendResponse(-EC_UDISK_INTERNAL_ERROR, "get set request fail");
    return;
  }
}

bool GetLoginGateHandle::GetSetRequest() {
  ucloud::udisk::GetLCExtentInfoPb lc_extent_req;
  lc_extent_req.add_extern_id(req_.extern_id());
  std::shared_ptr<GetLoginGateHandle> this_ptr =
      std::dynamic_pointer_cast<GetLoginGateHandle>(shared_from_this());
  std::shared_ptr<DoGetLCExtentInfoHandle> do_get_lc_extent_info_handle =
      std::make_shared<DoGetLCExtentInfoHandle>(
          std::bind(&GetLoginGateHandle::GetSetResponse, this_ptr,
                    std::placeholders::_1, std::placeholders::_2),
          session_no_);
  do_get_lc_extent_info_handle->Start(lc_extent_req);
  return true;
}

void GetLoginGateHandle::GetSetResponse(
    const ucloud::ResponseCode& rc,
    const std::list<ucloud::udisk::LCExtentInfoPb>& result) {

  if (rc.retcode() != 0) {
    LOG_ERROR << "get set error. msg=" << rc.error_message()
              << ", code=" << rc.retcode();
    SendResponse(rc.retcode(), rc.error_message());
    return;
  }

  if (result.size() > 0) {
    /* 一条UBS对应一条记录. */
    assert(1 == result.size());
    const auto& it = result.begin();
    if (UNLIKELY(it->extent_info_size() <= 0)) {
      LOG_ERROR << "get set error. not extent info in udisk_access";
      SendResponse(-1, "get set error");
      return;
    }

    for (int32_t j = 0; j < it->extent_info_size(); ++j) {
      const ucloud::udisk::ExtentInfoPb& extent = it->extent_info(j);
      set_id_ = extent.set_id();
      // TODO(baoshan.ye) 后续考虑跨set
      break;
    }

    LOG_INFO << "get set_id=" << set_id_ << ", extern_id=" << req_.extern_id();
    if (!CheckMigrateRequest()) {
      LOG_ERROR << "check migrate udisk fail. extern_id=" << req_.extern_id();
      SendResponse(-EC_UDISK_INTERNAL_ERROR, "check migrate udisk fail");
      return;
    }
    return;
  }

  if (request_.head().call_purpose() == FORWARD_PEER_LABEL) {
    // 表示从peer转发来的请求，只需要本地查找
    LOG_ERROR << "cannot find this extern_id=" << req_.extern_id();
    SendResponse(-1, "cannot find this extern_id");
    return;
  }

  /* 没有满足条件的Set, 跨机房查找 */
  vector<string> access_keys;
  const std::string patten("^access_[0-9a-z]{1,}$");
  g_context->mutable_config()->RawEnumKeys(UDiskConfig::kSectionName, patten,
                                           access_keys);
  for (auto& access_key : access_keys) {
    if (access_key == ("access_" + g_context->config().my_region())) {
      continue;
    }
    // 发送成功才加引用
    if (ForwardPeerRequest(access_key)) {
      ++forward_ref_;
    }
  }

  /* 没有其他机房 */
  if (0 == forward_ref_) {
    LOG_ERROR << "cannot find this extern_id=" << req_.extern_id();
    SendResponse(-1, "cannot find this extern_id");
    return;
  }
}

bool GetLoginGateHandle::ForwardPeerRequest(const std::string& access_key) {
  std::string access_name = g_context->mutable_config()->RawGetValue(
      ConfigParser::kSectionName, access_key);
  auto result = g_context->GetIPPort(access_key);
  std::string peer_ip = result.first;
  uint32_t peer_port = result.second;
  LOG_INFO << "Forward request to " << access_key
           << ", extern_id=" << req_.extern_id()
           << ", forward ref=" << forward_ref_ << ", peer_ip=" << peer_ip
           << ", peer_port=" << peer_port;
  if (peer_ip.empty() || peer_port == 0) {
    return false;
  }
  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  uevent::ConnectionUeventPtr conn =
      handle->GetOutConnection(peer_ip, peer_port);
  if (conn->IsClosed()) {
    return false;
  }

  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&request_, flowno, session_no_, GET_LOGIN_GATE_REQUEST, 0,
                false, objid, 0, FORWARD_PEER_LABEL, NULL, NULL);
  std::shared_ptr<GetLoginGateHandle> this_ptr =
      std::dynamic_pointer_cast<GetLoginGateHandle>(shared_from_this());
  LOG_INFO << request_.DebugString();
  uevent::MessageUtil::SendPbRequest(
      conn, request_,
      std::bind(&GetLoginGateHandle::ForwardPeerResponse, this_ptr, _1),
      std::bind(&GetLoginGateHandle::Timeout, this_ptr, FORWARD_PEER_LABEL),
      g_context->config().forward_timeout());
  return true;
}

void GetLoginGateHandle::ForwardPeerResponse(ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  --forward_ref_;
  const GetLoginGateResponse& res =
      um->body().GetExtension(get_login_gate_response);
  if (res.rc().retcode() == 0 ||
      res.rc().retcode() ==
          EC_UDISK_NO_GRAY_GATE) {  // 任意peer返回成功(包括gray_gate不存在)，直接返回
    resp_body_->CopyFrom(res);
    SendResponse(res.rc().retcode(), res.rc().error_message());
    responsed_ = true;
    return;
  }
  LOG_ERROR << "udisk login respose fail. errmsg=" << res.rc().error_message()
            << ", retcode=" << res.rc().retcode()
            << ", extern_id=" << req_.extern_id()
            << ", forward_ref=" << forward_ref_;
  if (forward_ref_ == 0 && !responsed_) {  // 所有peer都没有查到
    SendResponse(-EC_UDISK_DB_ERROR, "cannot find this extern_id");
    return;
  }
}

bool GetLoginGateHandle::CheckMigrateRequest() {
  std::pair<std::string, int> result = g_context->GetIPPort(kUmongoName);
  std::string umongo_ip = result.first;
  uint32_t umongo_port = result.second;
  if (umongo_ip.empty() || umongo_port == 0) {
    return false;
  }
  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  uevent::ConnectionUeventPtr conn =
      handle->GetOutConnection(umongo_ip, umongo_port);
  if (conn->IsClosed()) {
    return false;
  }
  ucloud::UMessage msg;
  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&msg, flowno, session_no_,
                ucloud::umgogate::EXECUTE_MGO_REQUEST, 0, false, objid, 0,
                "GetLCInfo", NULL, NULL);
  ExecuteMgoRequest* req =
      msg.mutable_body()->MutableExtension(execute_mgo_request);
  construct_get_migrate_udisk_request(req, req_.extern_id());
  std::shared_ptr<GetLoginGateHandle> this_ptr =
      std::dynamic_pointer_cast<GetLoginGateHandle>(shared_from_this());
  LOG_INFO << msg.DebugString();
  uevent::MessageUtil::SendPbRequest(
      conn, msg,
      std::bind(&GetLoginGateHandle::CheckMigrateResponse, this_ptr, _1),
      std::bind(&GetLoginGateHandle::Timeout, this_ptr, "CheckMigrate"),
      g_context->config().db_timeout());
  return true;
}

void GetLoginGateHandle::CheckMigrateResponse(ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  assert(um->head().message_type() == ucloud::umgogate::EXECUTE_MGO_RESPONSE);
  assert(um->body().HasExtension(ucloud::umgogate::execute_mgo_response));
  const ucloud::umgogate::ExecuteMgoResponse& res =
      um->body().GetExtension(ucloud::umgogate::execute_mgo_response);
  ucloud::udisk::MigrateUDiskTaskPb migrate_udisk;
  if (parse_get_migrate_udisk_request(&res, migrate_udisk) < 0) {
    LOG_ERROR << "parse mongo response error, extern_id=" << req_.extern_id();
    SendResponse(-1, "udisk migrate parse fail");
    return;
  }
  LOG_DEBUG << "CheckMigrate response: extern_id=" << migrate_udisk.extern_id()
            << ", status=" << migrate_udisk.status();

  resp_body_->mutable_migrate_udisk()->CopyFrom(migrate_udisk);
  if (UDISK_V4_SET(set_id_)) {
    resp_body_->set_version(ucloud::udisk::VER_UDISK_V4);
    ForwardMasterRequest();  // udisk_v4，获取gray_gate
  } else {
    resp_body_->set_version(ucloud::udisk::VER_UBS2);
    SendResponse(0, "success");
  }
  return;
}

bool GetLoginGateHandle::ForwardMasterRequest() {
  std::stringstream stream;
  stream << "set" << set_id_;
  std::string set_key = stream.str();
  std::string set_name = g_context->mutable_config()->RawGetValue(
      ConfigParser::kSectionName, set_key);
  LOG_INFO << "Forward request " << set_id_
           << ", extern_id=" << req_.extern_id();

  std::pair<std::string, int> result = g_context->GetIPPort(set_key);
  std::string set_ip = result.first;
  uint32_t set_port = result.second;
  if (set_ip.empty() || set_port == 0) {
    return false;
  }
  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  uevent::ConnectionUeventPtr conn = handle->GetOutConnection(set_ip, set_port);
  if (conn->IsClosed()) {
    return false;
  }

  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&request_, flowno, session_no_, request_.head().message_type(),
                0, false, objid, 0, "ForwardMaster", NULL, NULL);
  std::shared_ptr<GetLoginGateHandle> this_ptr =
      std::dynamic_pointer_cast<GetLoginGateHandle>(shared_from_this());
  LOG_INFO << request_.DebugString();
  uevent::MessageUtil::SendPbRequest(
      conn, request_,
      std::bind(&GetLoginGateHandle::ForwardMasterResponse, this_ptr, _1),
      std::bind(&GetLoginGateHandle::Timeout, this_ptr, "ForwardMaster"),
      g_context->config().forward_timeout());
  return true;
}

void GetLoginGateHandle::ForwardMasterResponse(ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  const GetLoginGateResponse& res =
      um->body().GetExtension(get_login_gate_response);
  if (res.rc().retcode() != 0) {
    LOG_ERROR << "udisk login respose fail. errmsg=" << res.rc().error_message()
              << ", retcode=" << res.rc().retcode()
              << ", extern_id=" << req_.extern_id();
    SendResponse(EC_UDISK_NO_GRAY_GATE, "metaserver response fail");
    return;
  }
  resp_body_->CopyFrom(res);
  SendResponse(0, "success");

  return;
}
