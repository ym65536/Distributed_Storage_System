#include "do_get_set_capacity.h"
#include <sstream>
#include "access_context.h"
#include "do_get_set_info.h"

#include "logging.h"
#include "message_util.h"
#include "access_umongo.h"
#include "my_uuid.h"

namespace udisk {
namespace access {

using namespace uevent;

void DoGetSetCapacityHandle::Timeout(int set_id) {
  LOG_ERROR << "DoGetSetCapacityHandle time out, set_id: " << set_id;
  handle_->SetSetCapacity(set_id);
}

void DoGetSetCapacityHandle::Start() {
  handle_ = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  GetValidSetInfo();
}

void DoGetSetCapacityHandle::GetValidSetInfo() {
  ucloud::udisk::GetSetInfoPb req;
  req.add_state(ucloud::udisk::SET_STATE_ONLINE);
  req.add_state(ucloud::udisk::SET_STATE_RESTRICTED);

  std::string session_no = base::MyUuid::NewUuid();
  std::shared_ptr<DoGetSetInfoHandle> do_get_set_info_handle =
      std::make_shared<DoGetSetInfoHandle>(
          std::bind(&DoGetSetCapacityHandle::GetValidSetInfoResponse,
                    shared_from_this(), std::placeholders::_1,
                    std::placeholders::_2),
          session_no);
  do_get_set_info_handle->Start(req);
}

void DoGetSetCapacityHandle::GetValidSetInfoResponse(
    const ucloud::ResponseCode& rc,
    const std::list<ucloud::udisk::SetInfoPb>& result) {
  if (rc.retcode() != 0) {
    LOG_ERROR << "Failed to get set info. " << rc.error_message();
    return;
  }

  set_ids_.clear();
  for (auto it = result.begin(); it != result.end(); ++it) {
    set_ids_.push_back(it->id());
  }

  GetSetCapFromMeta();
}

void DoGetSetCapacityHandle::GetSetCapFromMeta() {
  for (auto it = set_ids_.begin(); it != set_ids_.end(); it++) {
    if (UDISK_V4_SET(*it)) {
      if (!ForwardMasterRequest(*it)) {
        LOG_ERROR << "get set capacity error, set_id: " << *it;
        handle_->SetSetCapacity(*it);
      } else {
        LOG_INFO << "begin get set capacity, set_id: " << *it;
      }
    }
  }
}

bool DoGetSetCapacityHandle::ForwardMasterRequest(int set_id) {
  std::stringstream stream;
  stream << "set" << set_id;
  std::string set_key = stream.str();
  std::string set_name = g_context->mutable_config()->RawGetValue(
      common::ConfigParser::kSectionName, set_key);

  std::pair<std::string, int> result = g_context->GetIPPort(set_key);
  std::string set_ip = result.first;
  uint32_t set_port = result.second;
  if (set_ip.empty() || set_port == 0) {
    return false;
  }
  uevent::ConnectionUeventPtr conn =
      handle_->GetOutConnection(set_ip, set_port);
  if (conn->IsClosed()) {
    return false;
  }

  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  std::string session_no = base::MyUuid::NewUuid();
  ucloud::UMessage request;
  NewMessage_v2(&request, flowno, session_no,
                ucloud::udisk::META_GET_SET_CAPACITY_REQUEST, 0, false, objid,
                0, "ForwardMaster", NULL, NULL);
  request.mutable_body()->MutableExtension(
      ucloud::udisk::meta_get_set_capacity_request);

  LOG_INFO << request.DebugString();
  uevent::MessageUtil::SendPbRequest(
      conn, request,
      std::bind(&DoGetSetCapacityHandle::ForwardMasterResponse,
                shared_from_this(), std::placeholders::_1, set_id),
      std::bind(&DoGetSetCapacityHandle::Timeout, shared_from_this(), set_id),
      g_context->config().forward_timeout());
  return true;
}

void DoGetSetCapacityHandle::ForwardMasterResponse(ucloud::UMessage* um,
                                                   int set_id) {
  LOG_INFO << um->DebugString();
  const ucloud::udisk::MetaGetSetCapacityResponse& res =
      um->body().GetExtension(ucloud::udisk::meta_get_set_capacity_response);
  if (res.rc().retcode() != 0) {
    LOG_ERROR << "get set capacity error. errmsg=" << res.rc().error_message()
              << ", retcode=" << res.rc().retcode() << ", set_id=" << set_id;
    handle_->SetSetCapacity(set_id);
  } else {
    LOG_INFO << "get set capacity end, set_id: " << set_id;
    handle_->SetSetCapacity(set_id, res.calculate_cap(), res.heartbeat_cap(),
                            res.total_cap());
  }
  return;
}

}  // namespace access
}  // namespace udisk
