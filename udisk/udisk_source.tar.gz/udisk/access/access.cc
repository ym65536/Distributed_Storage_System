#include <getopt.h>
#include <signal.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <iostream>

#include "async_logging.h"
#include "listener_libevent.h"
#include "eventloop_libevent.h"
#include "message_util.h"
#include "ubs2_message.h"
#include "udisk_message.h"

#include "access_context.h"
#include "access_loop_handle.h"
#include "access_zookeeper.h"

#include "clone_ubs.h"
#include "get_attach_param.h"
#include "get_login_gate.h"
#include "get_proxy.h"
#include "get_attach_ip.h"
#include "get_snapshot_detail_info.h"
#include "get_ubs_detail_info.h"
#include "list_ubs.h"
#include "restore_ubs.h"
#include "udisk_login.h"
#include "update_mount_info.h"
#include "add_host_blacklist.h"
#include "remove_host_blacklist.h"
#include "resize_ubs.h"
#include "allocate_ubs.h"
#include "check_allowance.h"
#include "delete_snapshot.h"
#include "update_snapshot_info.h"
#include "get_avalon.h"
#include "snapshot.h"
#include "list_ubs_total_count.h"
#include "list_snapshot_total_count.h"
#include "list_snapshot.h"
#include "list_thrown_ubs.h"
#include "list_ubs_by_host.h"
#include "finish_migrate_udisk_task.h"
#include "get_udisk_extent_info.h"
#include "delete_ubs.h"
#include "destroy_ubs.h"
#include "update_udataark_mode.h"
#include "update_ubs_name.h"
#include "update_ubs_info.h"
#include "take_back_ubs.h"

using namespace std;
using namespace ucloud::udisk;
using namespace ucloud::ubs2;
using namespace udisk;
using namespace udisk::access;
using namespace udisk::common;

#define str(a) (#a)
#define xstr(a) (str(a))

#ifdef VERSION_TAG
//用于标识版本号，可以用nm -C 查看
const char *version_tag = xstr(VERSION_TAG);  //两次转换将宏的值转成字符串
#else
const char *version_tag = "unknown";
#endif

static struct option long_options[] = {{"help", 0, nullptr, 'h'},
                                       {"version", 0, nullptr, 'v'},
                                       {"conf", 1, nullptr, 'c'},
                                       {"foregroud", 0, nullptr, 'f'}, };

static void print_help(const char *name) {
  std::cout << name << " Usage: \n"
            << "-h | --help, print this\n"
            << "-c | --conf config file, conf file\n"
            << "-v | --version, get the version\n"
            << "-f | --foregroud, run this on front end\n";
}

static const char *short_options = "hvfc:";

static void print_version(const char *name) {
  printf("version tag: %s\n", version_tag);
}

static void context_init(const std::string &conf_file) {
  UDiskContext *context = new UDiskContext(conf_file);
  std::tuple<int, std::string> result = context->Init();
  if (std::get<0>(result)) {
    std::cerr << "Init Failed," << std::get<1>(result) << std::endl;
    std::exit(-1);
  }
  //初始化成功
  g_context = context;
}

static void init_daemon() {
  pid_t pid = fork();
  if (pid < 0) exit(EXIT_FAILURE);
  if (pid > 0) exit(EXIT_SUCCESS);
  if (setsid() < 0) exit(EXIT_FAILURE);

  signal(SIGCHLD, SIG_IGN);
  signal(SIGHUP, SIG_IGN);

  pid = fork();
  if (pid < 0) exit(EXIT_FAILURE);
  if (pid > 0) exit(EXIT_SUCCESS);

  umask(0);
  chdir("/");

  close(STDOUT_FILENO);
  close(STDIN_FILENO);
}

static base::AsyncLogging *logger = nullptr;
static void logger_putfn(const char *msg, int len) {
  if (logger) {
    logger->append(msg, len);
  }
}

static void init_logging(const char *argv0, bool foreground) {
  char name[256];
  strncpy(name, argv0, 256);
  std::string name_str = g_context->config().log_common_path() +
                         std::string(::basename(name));  // 加上程序名
  base::Logger::setLogLevel(g_context->config().log_level());
  if (!foreground) {
    logger =
        new base::AsyncLogging(name_str, g_context->config().log_roll_size());
    logger->start();
    base::Logger::setOutput(logger_putfn);
  }
}

void register_proto() {
  REGISTE_PROTO_HANDLER(g_context->main_loop(), UDISK_LOGIN_REQUEST,
                        UDiskLoginHandle);
  REGISTE_PROTO_HANDLER(g_context->main_loop(), GET_LOGIN_GATE_REQUEST,
                        GetLoginGateHandle);
  REGISTE_PROTO_HANDLER(g_context->main_loop(),
                        GET_SNAPSHOT_DETAIL_INFO_REQUEST,
                        GetSnapshotDetailInfoHandle);
  REGISTE_PROTO_HANDLER(g_context->main_loop(), GET_UBS_DETAIL_INFO_REQUEST,
                        GetUBSDetailInfoHandle);
  REGISTE_PROTO_HANDLER(g_context->main_loop(), GET_ATTACH_PARAM_REQUEST,
                        GetAttachParamHandle);
  REGISTE_PROTO_HANDLER(g_context->main_loop(), UPDATE_MOUNT_INFO_REQUEST,
                        UpdateMountInfoHandle);
  REGISTE_PROTO_HANDLER(g_context->main_loop(), LIST_UBS_REQUEST,
                        ListUBSHandle);
  REGISTE_PROTO_HANDLER(g_context->main_loop(), CLONE_UBS_REQUEST,
                        CloneUBSHandle);
  REGISTE_PROTO_HANDLER(g_context->main_loop(), RESTORE_UBS_REQUEST,
                        RestoreUBSHandle);
  REGISTE_PROTO_HANDLER(g_context->main_loop(), ADD_HOST_BLACKLIST_REQUEST,
                        AddHostBlacklistHandle);
  REGISTE_PROTO_HANDLER(g_context->main_loop(), REMOVE_HOST_BLACKLIST_REQUEST,
                        RemoveHostBlacklistHandle);
  REGISTE_PROTO_HANDLER(g_context->main_loop(), GET_PROXY_REQUEST,
                        GetProxyHandle);
  REGISTE_PROTO_HANDLER(g_context->main_loop(), GET_ATTACH_IP_REQUEST,
                        GetAttachIPHandle);
  REGISTE_PROTO_HANDLER(g_context->main_loop(), RESIZE_UBS_REQUEST,
                        ResizeUBSHandle);
  REGISTE_PROTO_HANDLER(g_context->main_loop(), ALLOCATE_UBS_REQUEST,
                        AllocateUBSHandle);
  REGISTE_PROTO_HANDLER(g_context->main_loop(),
                        ucloud::ubs2::CHECK_ALLOWANCE_REQUEST,
                        CheckAllowanceHandle);
  REGISTE_PROTO_HANDLER(g_context->main_loop(),
                        ucloud::ubs2::DELETE_UBS_REQUEST, DeleteUBSHandle);
  REGISTE_PROTO_HANDLER(g_context->main_loop(),
                        ucloud::ubs2::DESTROY_UBS_REQUEST, DestroyUBSHandle);
  REGISTE_PROTO_HANDLER(g_context->main_loop(),
                        ucloud::ubs2::LIST_THROWN_UBS_REQUEST,
                        ListThrownUBSHandle);
  REGISTE_PROTO_HANDLER(g_context->main_loop(),
                        ucloud::ubs2::LIST_UBS_BY_HOST_REQUEST,
                        ListUBSByHostHandle);
  REGISTE_PROTO_HANDLER(g_context->main_loop(),
                        ucloud::ubs2::UPDATE_UDATAARK_MODE_REQUEST,
                        UpdateUDataArkModeHandle);
  REGISTE_PROTO_HANDLER(g_context->main_loop(),
                        ucloud::ubs2::UPDATE_UBS_NAME_REQUEST,
                        UpdateUBSNameHandle);
  REGISTE_PROTO_HANDLER(g_context->main_loop(),
                        ucloud::ubs2::UPDATE_UBS_INFO_REQUEST,
                        UpdateUBSInfoHandle);
  REGISTE_PROTO_HANDLER(g_context->main_loop(),
                        ucloud::ubs2::TAKE_BACK_UBS_REQUEST, TakeBackUBSHandle);
  REGISTE_PROTO_HANDLER(g_context->main_loop(),
                        ucloud::ubs2::DELETE_SNAPSHOT_REQUEST,
                        DeleteSnapshotHandle);
  REGISTE_PROTO_HANDLER(g_context->main_loop(),
                        ucloud::ubs2::UPDATE_SNAPSHOT_INFO_REQUEST,
                        UpdateSnapshotInfoHandle);
  REGISTE_PROTO_HANDLER(g_context->main_loop(),
                        ucloud::ubs2::GET_UBS_AVALON_REQUEST, GetAvalonHandle);
  REGISTE_PROTO_HANDLER(g_context->main_loop(), ucloud::ubs2::SNAPSHOT_REQUEST,
                        SnapshotHandle);
  REGISTE_PROTO_HANDLER(g_context->main_loop(),
                        ucloud::ubs2::LIST_UBS_TOTAL_COUNT_REQUEST,
                        ListUBSTotalCountHandle);
  REGISTE_PROTO_HANDLER(g_context->main_loop(),
                        ucloud::ubs2::LIST_SNAPSHOT_TOTAL_COUNT_REQUEST,
                        ListSnapshotTotalCountHandle);
  REGISTE_PROTO_HANDLER(g_context->main_loop(),
                        ucloud::ubs2::LIST_SNAPSHOT_REQUEST,
                        ListSnapshotHandle);
  REGISTE_PROTO_HANDLER(g_context->main_loop(),
                        ucloud::udisk::FINISH_MIGRATE_UDISK_TASK_REQUEST,
                        FinishMigrateUDiskTaskHandle);
  REGISTE_PROTO_HANDLER(g_context->main_loop(),
                        ucloud::udisk::GET_UDISK_EXTENT_INFO_REQUEST,
                        GetUDiskExtentInfoHandle);
}

int main(int argc, char **argv) {
  std::string conf_file;
  bool foreground(false);
  // 解析命令行输入
  while (true) {
    int c = -1;
    int index = -1;
    c = getopt_long(argc, argv, short_options, long_options, &index);
    if (c == -1) {
      break;
    }
    switch (c) {
      case 'v':
        print_version(argv[0]);
        std::exit(0);
      case 'c':
        conf_file = std::string(optarg);
        break;
      case 'h':
        print_help(argv[0]);
        std::exit(0);
      case 'f':
        foreground = true;
        break;
      default:
        print_help(argv[0]);
        std::exit(-1);
    }
  }
  if (conf_file.empty()) {
    conf_file = "/etc/udisk/access.conf";
  }
  context_init(conf_file);

  if (!foreground) {
    init_daemon();
  }
  // 初始化日志模块
  init_logging(argv[0], foreground);
  // zkclient启动
  init_zkclient();

  // main模块启动, accept和管理流都在主线程
  uevent::Option option;
  option.loop_strategy = uevent::Option::kRoundRobin;
  option.reuse_port = true;
  uevent::UsockAddress addr(g_context->config().listen_ip(),
                            g_context->config().listen_port(), false);

  uevent::EventLoopLibevent *loop =
      new uevent::EventLoopLibevent("MainLoop", AccessLoopHandle::CreateMyself);
  uevent::ListenerLibevent *listener =
      new uevent::ListenerLibevent(loop, addr, "MainListener", option);
  listener->SetConnectionSuccessCb(AccessLoopHandle::ConnectionSuccessHandle);
  listener->SetConnectionClosedCb(AccessLoopHandle::ConnectionClosedHandle);
  listener->SetMessageReadCb(uevent::MessageUtil::ProtobufReadCallBack);
  listener->SetCreateLoopHandleCb(AccessLoopHandle::CreateMyself);
  g_context->set_main_loop(loop);
  g_context->set_main_listener(listener);

  register_proto();

  LOG_INFO << "IO Listener started on " << g_context->config().listen_ip()
           << ":" << g_context->config().listen_port();
  listener->Start();

  return 0;
}
