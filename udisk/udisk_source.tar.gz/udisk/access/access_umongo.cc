#include "access_umongo.h"
#include "rapidjson/stringbuffer.h"
#include "rapidjson/writer.h"

void construct_get_set_info_request(const std::string& dbname,
                                    ucloud::umgogate::ExecuteMgoRequest* req,
                                    const FindPair& findpair,
                                    const Fields& sort_fields,
                                    const Fields& fields, uint32_t skip,
                                    uint32_t limit) {
  construct_common_get_request(dbname, DB_SET_TABLE_NAME, req, findpair,
                               sort_fields, fields, skip, limit);
}

void construct_get_white_list_request(const std::string& dbname,
                                      ucloud::umgogate::ExecuteMgoRequest* req,
                                      const FindPair& findpair,
                                      const Fields& sort_fields,
                                      const Fields& fields, uint32_t skip,
                                      uint32_t limit) {
  construct_common_get_request(dbname, DB_WHITE_LIST_TABLE_NAME, req, findpair,
                               sort_fields, fields, skip, limit);
}

void construct_get_lc_extent_info_request(
    const std::string& dbname, ucloud::umgogate::ExecuteMgoRequest* req,
    const FindPair& findpair, const Fields& sort_fields, const Fields& fields,
    uint32_t skip, uint32_t limit) {
  construct_common_get_request(dbname, DB_LC_EXTENT_TABLE_NAME, req, findpair,
                               sort_fields, fields, skip, limit);
}

void construct_get_snapshot_extent_info_request(
    const std::string& dbname, ucloud::umgogate::ExecuteMgoRequest* req,
    const FindPair& findpair, const Fields& sort_fields, const Fields& fields,
    uint32_t skip, uint32_t limit) {
  construct_common_get_request(dbname, DB_SNAPSHOT_EXTENT_TABLE_NAME, req,
                               findpair, sort_fields, fields, skip, limit);
}

static bool parse_set_info_doc(rapidjson::Document& doc,
                               ucloud::udisk::SetInfoPb* info) {
  if (doc.HasMember(DB_SET_TABLE_COL_ID)) {
    info->set_id(doc[DB_SET_TABLE_COL_ID].GetInt());
  } else {
    return false;
  }

  if (doc.HasMember(DB_SET_TABLE_COL_STATE)) {
    info->set_state(
        ucloud::udisk::SET_STATE(doc[DB_SET_TABLE_COL_STATE].GetInt()));
  } else {
    return false;
  }

  if (doc.HasMember(DB_SET_TABLE_COL_TYPE)) {
    info->set_type(
        ucloud::udisk::SET_TYPE(doc[DB_SET_TABLE_COL_TYPE].GetInt()));
  } else {
    return false;
  }

  if (doc.HasMember(DB_SET_TABLE_COL_CREATE_TIME)) {
    info->set_create_time(doc[DB_SET_TABLE_COL_CREATE_TIME].GetInt64());
  }

  if (doc.HasMember(DB_SET_TABLE_COL_COMMENTS)) {
    info->set_comments(doc[DB_SET_TABLE_COL_COMMENTS].GetString());
  }

  if (doc.HasMember(DB_SET_TABLE_COL_LOGIC_ZONE)) {
    info->set_logic_zone(doc[DB_SET_TABLE_COL_LOGIC_ZONE].GetString());
  }

  return true;
}

bool parse_set_info_response(const ucloud::umgogate::ExecuteMgoResponse& res,
                             std::list<ucloud::udisk::SetInfoPb>* results) {
  results->clear();
  for (int i = 0; i < res.op_find_rsp().results_size(); ++i) {
    rapidjson::Document doc;
    rapidjson::ParseResult ok = doc.Parse(res.op_find_rsp().results(i).c_str());
    ucloud::udisk::SetInfoPb set_info;
    if (!ok || !parse_set_info_doc(doc, &set_info)) {
      results->clear();
      return false;
    }

    results->push_back(set_info);
  }

  return true;
}

static bool parse_white_list_doc(rapidjson::Document& doc,
                                 ucloud::udisk::WhiteListInfoPb* info) {
  if (doc.HasMember(DB_WHITE_LIST_TABLE_COL_SET_ID)) {
    info->set_set_id(doc[DB_WHITE_LIST_TABLE_COL_SET_ID].GetInt());
  } else {
    return false;
  }

  if (doc.HasMember(DB_WHITE_LIST_TABLE_COL_OID)) {
    info->set_oid(doc[DB_WHITE_LIST_TABLE_COL_OID].GetInt());
  } else {
    return false;
  }

  if (doc.HasMember(DB_WHITE_LIST_TABLE_COL_CREATE_TIME)) {
    info->set_create_time(doc[DB_WHITE_LIST_TABLE_COL_CREATE_TIME].GetInt64());
  }

  if (doc.HasMember(DB_WHITE_LIST_TABLE_COL_IGNORE_DATA_SYSTEM)) {
    info->set_ignore_data_system(
        doc[DB_WHITE_LIST_TABLE_COL_IGNORE_DATA_SYSTEM].GetBool());
  }

  return true;
}

bool parse_white_list_response(
    const ucloud::umgogate::ExecuteMgoResponse& res,
    std::list<ucloud::udisk::WhiteListInfoPb>* results) {
  results->clear();
  for (int i = 0; i < res.op_find_rsp().results_size(); ++i) {
    rapidjson::Document doc;
    rapidjson::ParseResult ok = doc.Parse(res.op_find_rsp().results(i).c_str());
    ucloud::udisk::WhiteListInfoPb white_list;
    if (!ok || !parse_white_list_doc(doc, &white_list)) {
      results->clear();
      return false;
    }

    results->push_back(white_list);
  }

  return true;
}

static bool parse_extent_info_value(const rapidjson::Value& value,
                                    ucloud::udisk::ExtentInfoPb* info) {
  if (value.HasMember(EXTENT_INFO_ID)) {
    info->set_id(value[EXTENT_INFO_ID].GetInt());
  } else {
    return false;
  }

  if (value.HasMember(EXTENT_INFO_SET_ID)) {
    info->set_set_id(value[EXTENT_INFO_SET_ID].GetInt());
  } else {
    return false;
  }

  return true;
}

static bool parse_lc_extent_info_doc(rapidjson::Document& doc,
                                     ucloud::udisk::LCExtentInfoPb* info) {
  if (doc.HasMember(DB_LC_EXTENT_TABLE_COL_EXTERN_ID)) {
    info->set_extern_id(doc[DB_LC_EXTENT_TABLE_COL_EXTERN_ID].GetString());
  } else {
    return false;
  }

  if (doc.HasMember(DB_LC_EXTENT_TABLE_COL_OID)) {
    info->set_oid(doc[DB_LC_EXTENT_TABLE_COL_OID].GetInt());
  } else {
    return false;
  }

  if (doc.HasMember(DB_LC_EXTENT_TABLE_COL_TOP_OID)) {
    info->set_top_oid(doc[DB_LC_EXTENT_TABLE_COL_TOP_OID].GetInt());
  } else {
    return false;
  }

  if (doc.HasMember(DB_LC_EXTENT_TABLE_COL_EXTENT_INFO)) {
    const rapidjson::Value& extent_infos =
        doc[DB_LC_EXTENT_TABLE_COL_EXTENT_INFO];
    for (auto& val : extent_infos.GetArray()) {
      assert(val.IsObject());
      ucloud::udisk::ExtentInfoPb* extent_info = info->add_extent_info();
      if (parse_extent_info_value(val, extent_info) == false) {
        return false;
      }
    }
  } else {
    return false;
  }

  return true;
}

bool parse_lc_extent_info_response(
    const ucloud::umgogate::ExecuteMgoResponse& res,
    std::list<ucloud::udisk::LCExtentInfoPb>* results) {
  results->clear();
  for (int i = 0; i < res.op_find_rsp().results_size(); ++i) {
    rapidjson::Document doc;
    rapidjson::ParseResult ok = doc.Parse(res.op_find_rsp().results(i).c_str());
    ucloud::udisk::LCExtentInfoPb info;
    if (!ok || !parse_lc_extent_info_doc(doc, &info)) {
      results->clear();
      return false;
    }

    results->push_back(info);
  }

  return true;
}

static bool parse_snapshot_extent_info_doc(
    rapidjson::Document& doc, ucloud::udisk::SnapshotExtentInfoPb* info) {
  if (doc.HasMember(DB_SNAPSHOT_EXTENT_TABLE_COL_EXTERN_ID)) {
    info->set_extern_id(
        doc[DB_SNAPSHOT_EXTENT_TABLE_COL_EXTERN_ID].GetString());
  } else {
    return false;
  }

  if (doc.HasMember(DB_SNAPSHOT_EXTENT_TABLE_COL_OID)) {
    info->set_oid(doc[DB_SNAPSHOT_EXTENT_TABLE_COL_OID].GetInt());
  } else {
    return false;
  }

  if (doc.HasMember(DB_SNAPSHOT_EXTENT_TABLE_COL_TOP_OID)) {
    info->set_top_oid(doc[DB_SNAPSHOT_EXTENT_TABLE_COL_TOP_OID].GetInt());
  } else {
    return false;
  }

  if (doc.HasMember(DB_SNAPSHOT_EXTENT_TABLE_COL_EXTENT_INFO)) {
    const rapidjson::Value& extent_infos =
        doc[DB_SNAPSHOT_EXTENT_TABLE_COL_EXTENT_INFO];
    for (auto& val : extent_infos.GetArray()) {
      assert(val.IsObject());
      ucloud::udisk::ExtentInfoPb* extent_info = info->add_extent_info();
      if (parse_extent_info_value(val, extent_info) == false) {
        return false;
      }
    }
  } else {
    return false;
  }

  return true;
}

bool parse_snapshot_extent_info_response(
    const ucloud::umgogate::ExecuteMgoResponse& res,
    std::list<ucloud::udisk::SnapshotExtentInfoPb>* results) {
  results->clear();
  for (int i = 0; i < res.op_find_rsp().results_size(); ++i) {
    rapidjson::Document doc;
    rapidjson::ParseResult ok = doc.Parse(res.op_find_rsp().results(i).c_str());
    ucloud::udisk::SnapshotExtentInfoPb info;
    if (!ok || !parse_snapshot_extent_info_doc(doc, &info)) {
      results->clear();
      return false;
    }

    results->push_back(info);
  }

  return true;
}

void construct_insert_lc_extent_info_request(
    const std::string& dbname, ucloud::umgogate::ExecuteMgoRequest* req,
    const std::string& extern_id, uint32_t oid, uint32_t top_oid,
    const std::vector<ucloud::udisk::ExtentInfoPb>& extent_info) {
  req->set_db(dbname);
  req->set_collection(DB_LC_EXTENT_TABLE_NAME);
  req->set_optype(ucloud::umgogate::OP_INSERT);
  rapidjson::Document doc;
  doc.SetObject();
  rapidjson::Document::AllocatorType& allocator = doc.GetAllocator();

  rapidjson::Value value;
  value.SetString(extern_id.c_str(), extern_id.length());
  doc.AddMember(DB_LC_EXTENT_TABLE_COL_EXTERN_ID, value, allocator);
  value.SetInt(oid);
  doc.AddMember(DB_LC_EXTENT_TABLE_COL_OID, value, allocator);
  value.SetInt(top_oid);
  doc.AddMember(DB_LC_EXTENT_TABLE_COL_TOP_OID, value, allocator);

  rapidjson::Value array;
  rapidjson::Value obj;
  rapidjson::Value key;
  array.SetArray();
  for (auto& it : extent_info) {
    obj.SetObject();
    value.SetInt(it.id());
    key.SetString(EXTENT_INFO_ID, strlen(EXTENT_INFO_ID));
    obj.AddMember(key, value, allocator);

    value.SetInt(it.set_id());
    key.SetString(EXTENT_INFO_SET_ID, strlen(EXTENT_INFO_SET_ID));
    obj.AddMember(key, value, allocator);
    array.PushBack(obj, allocator);
  }

  doc.AddMember(DB_LC_EXTENT_TABLE_COL_EXTENT_INFO, array, allocator);
  std::string str = format_json_string(doc);
  req->mutable_op_insert_req()->add_doc(str);
}

void construct_insert_snapshot_extent_info_request(
    const std::string& dbname, ucloud::umgogate::ExecuteMgoRequest* req,
    const std::string& extern_id, uint32_t oid, uint32_t top_oid,
    const std::vector<ucloud::udisk::ExtentInfoPb>& extent_info) {
  req->set_db(dbname);
  req->set_collection(DB_SNAPSHOT_EXTENT_TABLE_NAME);
  req->set_optype(ucloud::umgogate::OP_INSERT);
  rapidjson::Document doc;
  doc.SetObject();
  rapidjson::Document::AllocatorType& allocator = doc.GetAllocator();

  rapidjson::Value value;
  value.SetString(extern_id.c_str(), extern_id.length());
  doc.AddMember(DB_SNAPSHOT_EXTENT_TABLE_COL_EXTERN_ID, value, allocator);
  value.SetInt(oid);
  doc.AddMember(DB_SNAPSHOT_EXTENT_TABLE_COL_OID, value, allocator);
  value.SetInt(top_oid);
  doc.AddMember(DB_SNAPSHOT_EXTENT_TABLE_COL_TOP_OID, value, allocator);

  rapidjson::Value array;
  rapidjson::Value obj;
  rapidjson::Value key;
  array.SetArray();
  for (auto& it : extent_info) {
    obj.SetObject();
    value.SetInt(it.id());
    key.SetString(EXTENT_INFO_ID, strlen(EXTENT_INFO_ID));
    obj.AddMember(key, value, allocator);

    value.SetInt(it.set_id());
    key.SetString(EXTENT_INFO_SET_ID, strlen(EXTENT_INFO_SET_ID));
    obj.AddMember(key, value, allocator);
    array.PushBack(obj, allocator);
  }

  doc.AddMember(DB_SNAPSHOT_EXTENT_TABLE_COL_EXTENT_INFO, array, allocator);
  std::string str = format_json_string(doc);
  req->mutable_op_insert_req()->add_doc(str);
}

void construct_update_lc_extent_info_request(
    const std::string& dbname, ucloud::umgogate::ExecuteMgoRequest* req,
    const std::vector<UpdatePair>& updatepairs) {
  construct_common_update_request(dbname, DB_LC_EXTENT_TABLE_NAME, req,
                                  updatepairs);
}
// vim: set ts=2 sw=2 sts=2 et:
