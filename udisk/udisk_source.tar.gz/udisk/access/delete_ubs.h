#ifndef UDISK_ACCESS_DELETE_UBS_H
#define UDISK_ACCESS_DELETE_UBS_H

#include "forward_request_base.h"

namespace udisk {
namespace access {

class DeleteUBSHandle : public ForwardRequestBaseHandle {
 public:
  DeleteUBSHandle(uevent::UeventLoop* loop)
      : ForwardRequestBaseHandle("DeleteUBS") {}
  virtual ~DeleteUBSHandle() {}

  MYSELF_CREATE(DeleteUBSHandle);

  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         ucloud::UMessage* um);
  virtual ucloud::ResponseCode* GetRespCode();
  virtual void ForwardReqResponse(ucloud::UMessage* um);

 private:
  ucloud::ubs2::DeleteUBSRequest req_;
  ucloud::ubs2::DeleteUBSResponse* resp_body_;
};

};  // namespace access
};  // namespace udisk

#endif
