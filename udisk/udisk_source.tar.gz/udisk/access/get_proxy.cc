#include "get_proxy.h"
#include <sstream>
#include "logging.h"
#include "timestamp.h"
#include "access_context.h"
#include "access_loop_handle.h"
#include "string_util.h"
#include "likely.h"
#include "do_get_lc_extent_info.h"

using namespace udisk::access;
using namespace udisk::common;
using namespace ucloud::ubs2;
using namespace ucloud::udisk;
using namespace ucloud::udatabase;
using namespace std::placeholders;

void GetProxyHandle::Timeout(const std::string& task) {
  LOG_ERROR << "get proxy time out, session=" << session_no_
            << ", task=" << task;
  if (task == FORWARD_PEER_LABEL) {  // 转发到其他access超时
    --forward_ref_;
    if (forward_ref_ == 0 && !responsed_) {
      SendResponse(-EC_UBS_TIMEOUT, "GetProxyHandle time out");
    } else {
      // 转发到peer超时，且不是最后一个回包，do nothing
    }
  } else {
    SendResponse(-EC_UBS_TIMEOUT, "GetProxyHandle time out");
  }
}

void GetProxyHandle::SendResponse(uint32_t retcode,
                                  const std::string& message) {
  resp_body_->mutable_rc()->set_retcode(retcode);
  resp_body_->mutable_rc()->set_error_message(message);
  LOG_INFO << response_.DebugString();
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void GetProxyHandle::EntryInit(const uevent::ConnectionUeventPtr& conn,
                               ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  conn_ = conn;
  session_no_ = um->head().session_no();
  request_ = *um;
  MakeResponse(&request_, ucloud::ubs2::GET_PROXY_RESPONSE, &response_);
  resp_body_ = response_.mutable_body()->MutableExtension(
      ucloud::ubs2::get_proxy_response);
  req_ = request_.body().GetExtension(get_proxy_request);
  if (!GetSetRequest()) {
    LOG_ERROR << "get set request fail";
    SendResponse(-EC_UBS_INTERNAL_ERROR, "get set request fail");
    return;
  }
}

bool GetProxyHandle::GetSetRequest() {
  ucloud::udisk::GetLCExtentInfoPb lc_extent_req;
  lc_extent_req.add_extern_id(req_.ubs_id());
  std::shared_ptr<GetProxyHandle> this_ptr =
      std::dynamic_pointer_cast<GetProxyHandle>(shared_from_this());
  std::shared_ptr<DoGetLCExtentInfoHandle> do_get_lc_extent_info_handle =
      std::make_shared<DoGetLCExtentInfoHandle>(
          std::bind(&GetProxyHandle::GetSetResponse, this_ptr,
                    std::placeholders::_1, std::placeholders::_2),
          session_no_);
  do_get_lc_extent_info_handle->Start(lc_extent_req);

  return true;
}

void GetProxyHandle::GetSetResponse(
    const ucloud::ResponseCode& rc,
    const std::list<ucloud::udisk::LCExtentInfoPb>& result) {
  if (rc.retcode() != 0) {
    LOG_ERROR << "get set error. msg=" << rc.error_message()
              << ", code=" << rc.retcode();
    SendResponse(rc.retcode(), rc.error_message());
    return;
  }

  if (result.size() > 0) {
    if (UNLIKELY(result.size() != 1)) {
      LOG_ERROR << "there are more than one extern id in udisk_access";
      SendResponse(-1, "get set error");
      return;
    }

    const auto& it = result.begin();
    if (UNLIKELY(it->extent_info_size() <= 0)) {
      LOG_ERROR << "get set error. not extent info in udisk_access";
      SendResponse(-1, "get set error");
      return;
    }

    // 只有老架构才会接受该请求，老架构不会跨set。
    for (int32_t j = 0; j < it->extent_info_size(); ++j) {
      const ucloud::udisk::ExtentInfoPb& extent = it->extent_info(j);
      set_id_ = extent.set_id();
      break;
    }

    LOG_INFO << "get set_id=" << set_id_ << ", extern_id=" << req_.ubs_id();

    if (!ForwardMasterRequest()) {
      LOG_ERROR << "forward req fail, extern_id=" << req_.ubs_id();
      SendResponse(-EC_UDISK_INTERNAL_ERROR, "forward req fail");
      return;
    }
    LOG_INFO << "Forward request to master... extern_id=" << req_.ubs_id();
    return;
  }

  if (request_.head().call_purpose() == FORWARD_PEER_LABEL) {
    // 表示从access转发来的请求，只需要本地查找
    LOG_ERROR << "cannot find this extern_id=" << req_.ubs_id();
    SendResponse(-1, "cannot find this extern_id");
    return;
  }

  /* 没有满足条件的Set, 跨机房查找 */
  vector<string> access_keys;
  const std::string patten("^access_[0-9a-z]{1,}$");
  g_context->mutable_config()->RawEnumKeys(UDiskConfig::kSectionName, patten,
                                           access_keys);
  for (auto& access_key : access_keys) {
    if (access_key == ("access_" + g_context->config().my_region())) {
      continue;
    }
    // 发送成功才加引用
    if (ForwardPeerRequest(access_key)) {
      ++forward_ref_;
    }
  }

  /* 没有其他机房 */
  if (0 == forward_ref_) {
    LOG_ERROR << "cannot find this extern_id=" << req_.ubs_id();
    SendResponse(-1, "cannot find this extern_id");
    return;
  }
}

bool GetProxyHandle::ForwardPeerRequest(const std::string& access_key) {
  std::string access_name = g_context->mutable_config()->RawGetValue(
      ConfigParser::kSectionName, access_key);
  auto result = g_context->GetIPPort(access_key);
  std::string peer_ip = result.first;
  uint32_t peer_port = result.second;
  LOG_INFO << "Forward request to " << access_key
           << ", extern_id=" << req_.ubs_id()
           << ", forward ref=" << forward_ref_ << ", peer_ip=" << peer_ip
           << ", peer_port=" << peer_port;
  if (peer_ip.empty() || peer_port == 0) {
    return false;
  }
  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  uevent::ConnectionUeventPtr conn =
      handle->GetOutConnection(peer_ip, peer_port);
  if (conn->IsClosed()) {
    return false;
  }

  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&request_, flowno, session_no_, GET_PROXY_REQUEST, 0, false,
                objid, 0, FORWARD_PEER_LABEL, NULL, NULL);
  std::shared_ptr<GetProxyHandle> this_ptr =
      std::dynamic_pointer_cast<GetProxyHandle>(shared_from_this());
  LOG_INFO << request_.DebugString();
  uevent::MessageUtil::SendPbRequest(
      conn, request_,
      std::bind(&GetProxyHandle::ForwardPeerResponse, this_ptr, _1),
      std::bind(&GetProxyHandle::Timeout, this_ptr, FORWARD_PEER_LABEL),
      g_context->config().forward_timeout());
  return true;
}

void GetProxyHandle::ForwardPeerResponse(ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  --forward_ref_;
  const GetProxyResponse& res = um->body().GetExtension(get_proxy_response);
  if (res.rc().retcode() == 0) {  // 任意peer返回成功，直接返回
    responsed_ = true;
    resp_body_->CopyFrom(res);
    SendResponse(0, "success");
    LOG_INFO << "get proxy from peer success. extern_id=" << req_.ubs_id();
    return;
  }
  LOG_ERROR << "get proxy respose fail. errmsg=" << res.rc().error_message()
            << ", retcode=" << res.rc().retcode()
            << ", extern_id=" << req_.ubs_id()
            << ", forward_ref=" << forward_ref_;
  if (forward_ref_ == 0 && !responsed_) {  // 所有peer都没有查到
    SendResponse(-EC_UBS_INTERNAL_ERROR, "cannot find this extern_id");
    return;
  }
}

bool GetProxyHandle::ForwardMasterRequest() {
  std::stringstream stream;
  stream << "set" << set_id_;
  std::string set_key = stream.str();
  std::string set_name = g_context->mutable_config()->RawGetValue(
      ConfigParser::kSectionName, set_key);
  LOG_INFO << "Forward request " << set_key << ", extern_id=" << req_.ubs_id();

  std::pair<std::string, int> result = g_context->GetIPPort(set_key);
  std::string set_ip = result.first;
  uint32_t set_port = result.second;
  if (set_ip.empty() || set_port == 0) {
    return false;
  }
  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  uevent::ConnectionUeventPtr conn = handle->GetOutConnection(set_ip, set_port);
  if (conn->IsClosed()) {
    return false;
  }

  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&request_, flowno, session_no_, request_.head().message_type(),
                0, false, objid, 0, "ForwardMaster", NULL, NULL);
  std::shared_ptr<GetProxyHandle> this_ptr =
      std::dynamic_pointer_cast<GetProxyHandle>(shared_from_this());
  LOG_INFO << request_.DebugString();
  uevent::MessageUtil::SendPbRequest(
      conn, request_,
      std::bind(&GetProxyHandle::ForwardMasterResponse, this_ptr, _1),
      std::bind(&GetProxyHandle::Timeout, this_ptr, "ForwardMaster"),
      g_context->config().forward_timeout());
  return true;
}

void GetProxyHandle::ForwardMasterResponse(ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  const GetProxyResponse& res = um->body().GetExtension(get_proxy_response);
  if (res.rc().retcode() != 0) {
    LOG_ERROR << "get proxy respose fail. errmsg=" << res.rc().error_message()
              << ", retcode=" << res.rc().retcode()
              << ", extern_id=" << req_.ubs_id();
    SendResponse(-EC_UBS_INTERNAL_ERROR, res.rc().error_message());
    return;
  }
  resp_body_->CopyFrom(res);
  SendResponse(0, "success");

  return;
}
