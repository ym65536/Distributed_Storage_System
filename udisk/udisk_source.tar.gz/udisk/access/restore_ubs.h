#ifndef UDISK_ACCESS_RESTORE_UBS_H
#define UDISK_ACCESS_RESTORE_UBS_H

#include <string>
#include <list>
#include "pb_request_handle.h"
#include "message_util.h"
#include "ubs2_message.h"
#include "udisk_message.h"

namespace udisk {
namespace access {

class RestoreUBSHandle : public uevent::PbRequestHandle {
 public:
  RestoreUBSHandle(uevent::UeventLoop* loop) {}
  virtual ~RestoreUBSHandle() {}

  MYSELF_CREATE(RestoreUBSHandle);

  void SendResponse(uint32_t retcode, const std::string& message);
  void Timeout();
  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         ucloud::UMessage* um);

  bool GetSetRequest();
  void GetSetResponse(const ucloud::ResponseCode& rc,
                      const std::list<ucloud::udisk::LCExtentInfoPb>& result);

  bool CheckMigrateRequest();
  void CheckMigrateResponse(ucloud::UMessage* um);

  void ForwardMasterRequest();
  void ForwardMasterResponse(ucloud::UMessage* um);

 private:
  uevent::ConnectionUeventPtr conn_;

  ucloud::UMessage request_;
  ucloud::ubs2::RestoreUBSRequest req_;
  ucloud::UMessage response_;
  ucloud::ubs2::RestoreUBSResponse* resp_body_;
  std::string session_no_;
  int set_id_ = 0;
};

};  // end of ns access
};  // end of ns udisk

#endif
