#ifndef UDISK_ACCESS_LIST_UBS_BY_HOST_H
#define UDISK_ACCESS_LIST_UBS_BY_HOST_H

#include "list_ubs_base.h"

namespace udisk {
namespace access {

class ListUBSByHostHandle : public ListUBSBaseHandle {
 public:
  ListUBSByHostHandle(uevent::UeventLoop* loop)
      : ListUBSBaseHandle("ListUBSByHost") {}
  virtual ~ListUBSByHostHandle() {}

  MYSELF_CREATE(ListUBSByHostHandle);

  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         ucloud::UMessage* um);

  virtual ucloud::ResponseCode* GetRespCode();
  virtual void ConstructGetSetParam(
      bool* is_set_req, ucloud::udisk::GetSetInfoPb* set_req,
      ucloud::udisk::GetLCExtentInfoPb* lc_extent_req);
  virtual void ConstructListDisksParam(ucloud::UMessage* msg);
  virtual bool ParseListDisksResponse(ucloud::UMessage* msg);
  virtual bool ProcessLc(uint32_t count, ucloud::ubs2::LogicalChunk* lc);

 private:
  ucloud::ubs2::ListUBSByHostRequest req_;
  ucloud::ubs2::ListUBSByHostResponse* resp_body_;
};

};  // end of ns access
};  // end of ns udisk

#endif
