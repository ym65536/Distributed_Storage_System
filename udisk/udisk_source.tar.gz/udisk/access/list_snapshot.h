#ifndef UDISK_ACCESS_LIST_SNAPSHOT_H
#define UDISK_ACCESS_LIST_SNAPSHOT_H

#include <string>
#include <vector>
#include <set>
#include <list>
#include "pb_request_handle.h"
#include "message_util.h"
#include "udisk_message.h"
#include "ubs2_message.h"

namespace udisk {
namespace access {

class ListSnapshotHandle : public uevent::PbRequestHandle {
 public:
  ListSnapshotHandle(uevent::UeventLoop* loop) {}
  virtual ~ListSnapshotHandle() {}

  MYSELF_CREATE(ListSnapshotHandle);

  void SendResponse(uint32_t retcode, const std::string& message);
  void ListSnapshotsTimeout();

  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         ucloud::UMessage* um);

  void ConstructGetSetParam(
      bool* is_set_req, ucloud::udisk::GetSetInfoPb* set_req,
      ucloud::udisk::GetSnapshotExtentInfoPb* snapshot_extent_req);

  void GetSetRequest();
  void GetSetResponse(const ucloud::ResponseCode& rc,
                      const std::list<ucloud::udisk::SetInfoPb>& result);
  void GetSetBySnapshotResponse(
      const ucloud::ResponseCode& rc,
      const std::list<ucloud::udisk::SnapshotExtentInfoPb>& result);
  void ListSnapshots();
  void ListSnapshotsResponse(ucloud::UMessage* msg);
  void ProcessSnapshots();
  bool ProcessSnapshot(uint32_t count, ucloud::ubs2::Snapshot* sp);

  void ConstructListSnapshotsParam(ucloud::UMessage* msg);
  void ParseListSnapshotsResponse(ucloud::UMessage* msg);

 private:
  std::string task_;
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage request_;
  ucloud::UMessage response_;
  ucloud::ubs2::ListSnapshotRequest req_;
  ucloud::ubs2::ListSnapshotResponse* resp_body_;
  std::string session_no_;
  uint32_t cur_set_id_;
  std::set<uint32_t> set_ids_;

  typedef std::map<uint32_t, std::vector<ucloud::ubs2::Snapshot>,
                   std::greater<uint32_t> > SetSnapshotMap;
  SetSnapshotMap set_snapshots_;
};

};  // end of ns access
};  // end of ns udisk

#endif
