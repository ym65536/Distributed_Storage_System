#include "list_ubs_by_host.h"

using namespace udisk::access;
using namespace ucloud::ubs2;

void ListUBSByHostHandle::EntryInit(const uevent::ConnectionUeventPtr& conn,
                                    ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  conn_ = conn;
  session_no_ = um->head().session_no();
  request_ = *um;
  MakeResponse(&request_, LIST_UBS_BY_HOST_RESPONSE, &response_);
  resp_body_ =
      response_.mutable_body()->MutableExtension(list_ubs_by_host_response);
  req_ = request_.body().GetExtension(list_ubs_by_host_request);
  if (!GetSetRequest()) {
    LOG_ERROR << "get set request fail";
    SendResponse(-EC_UBS_INTERNAL_ERROR, "get set request fail");
    return;
  }
}

ucloud::ResponseCode* ListUBSByHostHandle::GetRespCode() {
  return resp_body_->mutable_rc();
}

void ListUBSByHostHandle::ConstructGetSetParam(
    bool* is_set_req, ucloud::udisk::GetSetInfoPb* set_req,
    ucloud::udisk::GetLCExtentInfoPb* lc_extent_req) {
  *is_set_req = true;
  set_req->add_state(ucloud::udisk::SET_STATE_ONLINE);
  set_req->add_state(ucloud::udisk::SET_STATE_RESTRICTED);
}

void ListUBSByHostHandle::ConstructListDisksParam(ucloud::UMessage* msg) {
  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(msg, flowno, session_no_, LIST_UBS_BY_HOST_REQUEST, 0, false,
                objid, 0, "ListUBSByHost", NULL, NULL);
  ListUBSByHostRequest* req =
      msg->mutable_body()->MutableExtension(list_ubs_by_host_request);
  req->CopyFrom(req_);
}

bool ListUBSByHostHandle::ParseListDisksResponse(ucloud::UMessage* msg) {
  const ListUBSByHostResponse& res =
      msg->body().GetExtension(list_ubs_by_host_response);
  if (res.rc().retcode() != 0) {
    LOG_ERROR << "list disks by host fail. errmsg=" << res.rc().error_message()
              << ", retcode=" << res.rc().retcode()
              << "set id: " << cur_set_id_;
    // SendResponse(res.rc().retcode(), res.rc().error_message());
    // 一个set失败不影响结果
    return true;
  }

  for (int i = 0; i < res.lc_infos_size(); ++i) {
    set_udisks_[cur_set_id_].push_back(res.lc_infos(i));
  }
  return true;
}

bool ListUBSByHostHandle::ProcessLc(uint32_t count,
                                    ucloud::ubs2::LogicalChunk* lc) {
  resp_body_->add_lc_infos()->Swap(lc);
  return true;
}
