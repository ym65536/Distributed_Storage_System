#include "access_context.h"
#include <cerrno>
#include <cstring>
#include <cstdlib>
#include "zk_name_container.h"
#include "config_parser.h"
#include "access_umongo.h"

using namespace udisk::access;

std::tuple<int, std::string> UDiskConfig::init() {
  ConfigParser::Init();
  //必要部分为填无法启动
  if (listen_ip().empty()) {
    LOG_FATAL << "listen_ip is empty";
  }
  if (listen_port() == 0) {
    LOG_FATAL << "listen_port is empty";
  }
  if (zk_server().empty()) {
    LOG_FATAL << "zk server is empty";
  }
  if (my_name_zk_path().empty()) {
    LOG_FATAL << "my_name_zk_path is empty";
  }
  std::tuple<int, std::string> ret = load();
  if (std::get<0>(ret)) {
    std::string msg =
        "load conf " + config_file_ + " failed for " + std::get<1>(ret);
    return std::make_tuple(std::get<0>(ret), msg);
  }
  return std::make_tuple(0, "");
}

std::tuple<int, std::string> UDiskConfig::load() {
  int ret = 0;
  std::string msg("");
  std::string my_id = parser_.GetValue(kSectionCommon, kMyId);
  if (my_id.empty()) {
    ret = -1;
    msg = "my id is empty";
    return std::make_tuple(ret, msg);
  } else {
    my_id_ = std::atoi(my_id.c_str());
    LOG_INFO << "my chunk id: " << my_id_;
  }

  db_timeout_ = parser_.IntValue(kSectionCommon, kDbTimeout);
  if (db_timeout_ == 0) {
    db_timeout_ = 10;
    LOG_INFO << "db_timeout is empty or 0, set default value 2";
  }
  LOG_INFO << "db_timeout : " << db_timeout_;

  db_name_ = parser_.GetValue(kSectionCommon, kDbName);
  if (db_name_.empty()) {
    db_name_ = ACCESS_DEFAULT_DBNAME;
    LOG_INFO << "db_name is empty , set default value udisk";
  }

  LOG_INFO << "db_timeout : " << db_timeout_;
  forward_timeout_ = parser_.IntValue(kSectionCommon, kForwardTimeout);
  if (forward_timeout_ == 0) {
    forward_timeout_ = 10;
    LOG_INFO << "forward_timeout is empty or 0, set default value 2";
  }
  LOG_INFO << "forward_timeout : " << forward_timeout_;

  if (listen_ip().empty()) {
    ret = -1;
    msg = "listen_ip is empty";
    return std::make_tuple(ret, msg);
  }

  my_region_ = parser_.GetValue(kSectionCommon, kMyRegion);
  if (my_region_.empty()) {
    LOG_ERROR << "my region error.";
    ret = -1;
    msg = "my region error";
    return std::make_tuple(ret, msg);
  }
  LOG_INFO << "my_region: " << my_region_;

  std::string umongo_path = parser_.GetValue(kSectionName, kUmongoName);
  if (umongo_path.empty()) {
    ret = -1;
    msg = "no name/umongo";
    return std::make_tuple(ret, msg);
  }
  umongo_path_ = umongo_path;

  // udatabase_path_ = parser_.GetValue(kSectionName, kUDatabaseName);
  // if (udatabase_path_.empty()) {
  //   ret = -1;
  //   msg = "no name/udatabase";
  //   return std::make_tuple(ret, msg);
  // }
  // LOG_INFO << "udatabase name=" << udatabase_path_;

  utm_access_ = parser_.GetValue(kSectionName, kUTMAccessName);
  if (utm_access_.empty()) {
    ret = 01;
    msg = "no name/utm_access";
    return std::make_tuple(ret, msg);
  }
  LOG_INFO << "utm_access name=" << utm_access_;

  set_capacity_water_line_ = parser_.IntValue(kSectionCommon, kSetCapWaterLine);
  if (set_capacity_water_line_ == 0) {
    set_capacity_water_line_ = 20;
    LOG_INFO << "set_capacity_water_line is empty or 0, set default value 20";
  }
  LOG_INFO << "set_capacity_water_line: " << set_capacity_water_line_;

  int logic_zone_enable = parser_.IntValue(kSectionCommon, kLogicZoneEnable);
  if (logic_zone_enable == 0) {
    logic_zone_enable_ = false;
    LOG_INFO << "logic_zone_enable is empty or 0, set default value false";
  } else {
    logic_zone_enable_ = true;
  }
  LOG_INFO << "logic_zone_enable: " << logic_zone_enable_;

  return std::make_tuple(ret, msg);
}

std::string UDiskConfig::RawGetValue(const std::string& section,
                                     const std::string& key) {
  return parser_.GetValue(section, key);
}

void UDiskConfig::RawEnumKeys(const std::string& section,
                              const std::string& patten,
                              std::vector<std::string>& keys) {
  keys = parser_.EnumKeys(section, patten);
  for (auto key : keys) {
    LOG_INFO << "==>Key=" << key;
  }
  return;
}

UDiskContext::UDiskContext(const std::string& conf_file)
    : config_(conf_file), main_loop_(nullptr), main_listener_(nullptr) {}

std::tuple<int, std::string> UDiskContext::Init() { return config_.init(); }

std::pair<std::string, int> UDiskContext::GetIPPort(const std::string& name,
                                                    bool get_leader) {
  std::string zk_id = mutable_config()->RawGetValue(kSectionMap, name);
  if (zk_id.empty()) {
    LOG_DEBUG << "key=" << name << " use default zookeeper";
    zk_id = "zookeeper";
  }
  assert(ncs_[zk_id] != nullptr);
  ucloud::uns::NameNodeContent namenode;
  std::string access_key = (zk_id == "zookeeper" || zk_id == "zookeeper-1")
                               ? ("access_" + config_.my_region())
                               : name;
  LOG_DEBUG << "zk_id=" << zk_id << ", access_key=" << access_key;
  if (ncs_[zk_id]->GetNNCForName(access_key, name, namenode, get_leader)) {
    return std::make_pair("", 0);
  }
  return std::make_pair(namenode.ip(), namenode.port());
}

// 在进程启动后，初始化成功后，设置
udisk::access::UDiskContext* g_context = nullptr;
