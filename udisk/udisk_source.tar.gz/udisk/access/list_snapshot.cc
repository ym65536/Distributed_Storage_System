#include "list_snapshot.h"
#include <sstream>
#include "access_context.h"
#include "access_loop_handle.h"
#include "umessage_common.h"
#include "umessage.h"
#include "string_util.h"
#include "do_get_set_info.h"
#include "do_get_snapshot_extent_info.h"

using namespace udisk::access;
using namespace std::placeholders;
using namespace udisk::common;

void ListSnapshotHandle::ListSnapshotsTimeout() {
  LOG_ERROR << "list snapshot time out, session=" << session_no_
            << "set_id: " << cur_set_id_;
  // SendResponse(-ucloud::ubs2::EC_UBS_TIMEOUT, "list snapshot time out");
  ListSnapshots();
}

void ListSnapshotHandle::SendResponse(uint32_t retcode,
                                      const std::string& message) {
  ucloud::ResponseCode* rc = resp_body_->mutable_rc();
  rc->set_retcode(retcode);
  rc->set_error_message(message);
  LOG_INFO << response_.DebugString();
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void ListSnapshotHandle::EntryInit(const uevent::ConnectionUeventPtr& conn,
                                   ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  conn_ = conn;
  session_no_ = um->head().session_no();
  request_ = *um;
  MakeResponse(&request_, ucloud::ubs2::LIST_SNAPSHOT_RESPONSE, &response_);
  resp_body_ = response_.mutable_body()->MutableExtension(
      ucloud::ubs2::list_snapshot_response);
  req_ = request_.body().GetExtension(ucloud::ubs2::list_snapshot_request);
  GetSetRequest();
}

void ListSnapshotHandle::GetSetRequest() {
  ucloud::udisk::GetSetInfoPb set_req;
  ucloud::udisk::GetSnapshotExtentInfoPb snapshot_extent_req;
  bool is_set_req;
  ConstructGetSetParam(&is_set_req, &set_req, &snapshot_extent_req);

  std::shared_ptr<ListSnapshotHandle> this_ptr =
      std::dynamic_pointer_cast<ListSnapshotHandle>(shared_from_this());
  if (is_set_req) {
    std::shared_ptr<DoGetSetInfoHandle> do_get_set_info_handle =
        std::make_shared<DoGetSetInfoHandle>(
            std::bind(&ListSnapshotHandle::GetSetResponse, this_ptr,
                      std::placeholders::_1, std::placeholders::_2),
            session_no_);
    do_get_set_info_handle->Start(set_req);
  } else {
    std::shared_ptr<
        DoGetSnapshotExtentInfoHandle> do_get_snapshot_extent_info_handle =
        std::make_shared<DoGetSnapshotExtentInfoHandle>(
            std::bind(&ListSnapshotHandle::GetSetBySnapshotResponse, this_ptr,
                      std::placeholders::_1, std::placeholders::_2),
            session_no_);
    do_get_snapshot_extent_info_handle->Start(snapshot_extent_req);
  }
}

void ListSnapshotHandle::GetSetResponse(
    const ucloud::ResponseCode& rc,
    const std::list<ucloud::udisk::SetInfoPb>& result) {
  if (rc.retcode() != 0) {
    LOG_ERROR << "get set error.";
    SendResponse(rc.retcode(), rc.error_message());
    return;
  }

  if (0 == result.size()) {
    LOG_ERROR << "there is no avaliable set";
    SendResponse(-ucloud::ubs2::EC_UBS_INTERNAL_ERROR,
                 "there is no avaliable set");
    return;
  }

  for (auto it = result.begin(); it != result.end(); ++it) {
    set_ids_.insert(it->id());
  }

  ListSnapshots();
}

void ListSnapshotHandle::GetSetBySnapshotResponse(
    const ucloud::ResponseCode& rc,
    const std::list<ucloud::udisk::SnapshotExtentInfoPb>& result) {
  if (rc.retcode() != 0) {
    LOG_ERROR << "get set error.";
    SendResponse(rc.retcode(), rc.error_message());
    return;
  }

  if (0 == result.size()) {
    LOG_ERROR << "cannot find this snapshot, snapshot id: "
              << req_.snapshot_id();
    SendResponse(-ucloud::ubs2::EC_UBS_NO_SUCH_SNAPSHOT,
                 "cannot find this snapshot");
    return;
  }

  for (auto it = result.begin(); it != result.end(); ++it) {
    for (int32_t j = 0; j < it->extent_info_size(); ++j) {
      const ucloud::udisk::ExtentInfoPb& extent = it->extent_info(j);
      set_ids_.insert(extent.set_id());
    }
  }

  ListSnapshots();
}

void ListSnapshotHandle::ListSnapshots() {
  // 遍历完所有满足条件的set
  if (set_ids_.empty()) {
    ProcessSnapshots();
    SendResponse(0, "success");
    return;
  }

  // 按set_id从小到大查找
  cur_set_id_ = *(set_ids_.begin());
  set_ids_.erase(set_ids_.begin());
  std::stringstream stream;
  stream << "set" << cur_set_id_;
  std::string set_key = stream.str();
  std::string set_name = g_context->mutable_config()->RawGetValue(
      ConfigParser::kSectionName, set_key);
  LOG_INFO << "Forward request " << set_key;

  std::pair<std::string, int> result = g_context->GetIPPort(set_key);
  std::string set_ip = result.first;
  uint32_t set_port = result.second;
  if (set_ip.empty() || set_port == 0) {
    LOG_ERROR << "GetIPPort error, set_id: " << cur_set_id_;
    ListSnapshots();
    return;
  }
  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  uevent::ConnectionUeventPtr conn = handle->GetOutConnection(set_ip, set_port);
  if (conn->IsClosed()) {
    LOG_ERROR << "GetConnection error, set_id: " << cur_set_id_;
    ListSnapshots();
    return;
  }

  ucloud::UMessage msg;
  ConstructListSnapshotsParam(&msg);
  std::shared_ptr<ListSnapshotHandle> this_ptr =
      std::dynamic_pointer_cast<ListSnapshotHandle>(shared_from_this());
  LOG_INFO << request_.DebugString();
  uevent::MessageUtil::SendPbRequest(
      conn, msg,
      std::bind(&ListSnapshotHandle::ListSnapshotsResponse, this_ptr, _1),
      std::bind(&ListSnapshotHandle::ListSnapshotsTimeout, this_ptr),
      g_context->config().forward_timeout());
  return;
}

void ListSnapshotHandle::ListSnapshotsResponse(ucloud::UMessage* msg) {
  LOG_INFO << msg->DebugString();
  ParseListSnapshotsResponse(msg);
  ListSnapshots();
}

void ListSnapshotHandle::ProcessSnapshots() {
  if (set_snapshots_.empty()) {
    return;
  }
  // 迁移可能会造成新老set中存在相同id的快照，从set_snapshots_先取出新set的块照信息
  // 如果老set中存在相同快照，则跳过
  std::set<std::string> snapshot_ids;
  uint32_t count = 0;
  for (auto it = set_snapshots_.begin(); it != set_snapshots_.end(); ++it) {
    for (uint32_t i = 0; i < it->second.size(); ++i) {
      const ucloud::ubs2::Snapshot& sp = it->second[i];
      // TODO(alan.ding) 后续需要考虑跨set
      if (snapshot_ids.find(sp.id()) != snapshot_ids.end()) {
        LOG_INFO << "udisk migrated, snapshot_id: " << sp.id()
                 << ", set_id: " << it->first;
        continue;
      }
      snapshot_ids.insert(sp.id());

      count++;
      if (ProcessSnapshot(count, &it->second[i]) == false) {
        return;
      }
    }
  }
}

void ListSnapshotHandle::ConstructGetSetParam(
    bool* is_set_req, ucloud::udisk::GetSetInfoPb* set_req,
    ucloud::udisk::GetSnapshotExtentInfoPb* snapshot_extent_req) {
  *is_set_req = false;
  if (req_.has_snapshot_id()) {
    snapshot_extent_req->add_extern_id(req_.snapshot_id());
  } else {
    *is_set_req = true;
    set_req->add_state(ucloud::udisk::SET_STATE_ONLINE);
    set_req->add_state(ucloud::udisk::SET_STATE_RESTRICTED);
  }
}

void ListSnapshotHandle::ConstructListSnapshotsParam(ucloud::UMessage* msg) {
  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(msg, flowno, session_no_, ucloud::ubs2::LIST_SNAPSHOT_REQUEST,
                0, false, objid, 0, "ListSnapshots", NULL, NULL);
  ucloud::ubs2::ListSnapshotRequest* req =
      msg->mutable_body()->MutableExtension(
          ucloud::ubs2::list_snapshot_request);
  req->CopyFrom(req_);
  req->clear_offset();
  req->clear_limit();
}

void ListSnapshotHandle::ParseListSnapshotsResponse(ucloud::UMessage* msg) {
  const ucloud::ubs2::ListSnapshotResponse& res =
      msg->body().GetExtension(ucloud::ubs2::list_snapshot_response);
  if (res.rc().retcode() != 0) {
    LOG_ERROR << "list disks fail. errmsg=" << res.rc().error_message()
              << ", retcode=" << res.rc().retcode()
              << "set_id: " << cur_set_id_;
    // SendResponse(res.rc().retcode(), res.rc().error_message());
    return;
  }
  for (int i = 0; i < res.ubs_snapshots_size(); ++i) {
    set_snapshots_[cur_set_id_].push_back(res.ubs_snapshots(i));
  }
}

bool ListSnapshotHandle::ProcessSnapshot(uint32_t count,
                                         ucloud::ubs2::Snapshot* sp) {
  if (count > req_.offset()) {
    resp_body_->add_ubs_snapshots()->Swap(sp);
  }

  if (req_.has_limit() && (count - req_.offset() >= req_.limit())) {
    return false;
  }

  return true;
}
