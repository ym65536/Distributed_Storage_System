#ifndef UDISK_ACCESS_ALLOCATE_UBS_H
#define UDISK_ACCESS_ALLOCATE_UBS_H

#include <string>
#include "pb_request_handle.h"
#include "message_util.h"
#include "ubs2_message.h"
#include "udisk_message.h"
#include <list>

namespace udisk {
namespace access {

class AllocateUBSHandle : public uevent::PbRequestHandle {
 public:
  AllocateUBSHandle(uevent::UeventLoop* loop) {}
  virtual ~AllocateUBSHandle() {}

  MYSELF_CREATE(AllocateUBSHandle);

  void SendResponse(uint32_t retcode, const std::string& message);
  void Timeout(const std::string& task);
  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         ucloud::UMessage* um);

  void CheckExternId();
  void CheckExternIdResponse(
      const ucloud::ResponseCode& rc,
      const std::list<ucloud::udisk::LCExtentInfoPb>& result);
  void GetOptimalSets();
  void GetOptimalSetsResponse(const ucloud::ResponseCode& rc,
                              std::vector<int32_t>& sets);
  void CheckInputSet();
  void CheckInputSetResponse(const ucloud::ResponseCode& rc,
                             const std::list<ucloud::udisk::SetInfoPb>& result);
  void CheckAllowance();
  void CheckAllowanceResponse(ucloud::UMessage* um);
  void AllocateUBS();
  void AllocateUBSResponse(ucloud::UMessage* um);
  void UpdateDB(const std::string& extern_id);
  void UpdateDBResponse(ucloud::UMessage* um);

 private:
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage request_;
  ucloud::ubs2::AllocateUBSRequest req_;
  ucloud::UMessage response_;
  ucloud::ubs2::AllocateUBSResponse* resp_body_;
  std::string session_no_;

  bool specified_ = false;
  int specified_set_;
  std::vector<int32_t> candidate_sets_;
  std::vector<int32_t>::const_iterator candidate_;
};

};  // namespace access
};  // namespace udisk

#endif
