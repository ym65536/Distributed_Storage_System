#ifndef UDISK_ACCESS_FINISH_MIGRATE_UDISK_H
#define UDISK_ACCESS_FINISH_MIGRATE_UDISK_H

#include <string>
#include <list>
#include <vector>
#include "pb_request_handle.h"
#include "message_util.h"
#include "ubs2_message.h"
#include "udisk_message.h"

namespace udisk {
namespace access {

class FinishMigrateUDiskTaskHandle : public uevent::PbRequestHandle {
 public:
  FinishMigrateUDiskTaskHandle(uevent::UeventLoop* loop) {}
  virtual ~FinishMigrateUDiskTaskHandle() {}

  MYSELF_CREATE(FinishMigrateUDiskTaskHandle);

  void SendResponse(uint32_t retcode, const std::string& message);
  void Timeout();
  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         ucloud::UMessage* um);

  void CheckMigration();
  void CheckMigrationResponse(ucloud::UMessage* um);

  void GetLcSetRequest();
  void GetLcSetResponse(const ucloud::ResponseCode& rc,
                        const std::list<ucloud::udisk::LCExtentInfoPb>& result);

  bool ForwardMasterRequest(int set_id, std::string& extern_id);
  void ForwardMasterResponse(ucloud::UMessage* um);

  void UpdateDB();
  void UpdateDBResponse(ucloud::UMessage* um);

 private:
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage request_;
  ucloud::udisk::FinishMigrateUDiskTaskRequest req_;
  ucloud::UMessage response_;
  ucloud::udisk::FinishMigrateUDiskTaskResponse* resp_body_;
  std::string session_no_;
  std::map<int, std::string> set_lcs_;
};

};  // end of ns access
};  // end of ns udisk

#endif
