#include "allocate_ubs.h"
#include <sstream>
#include "access_context.h"
#include "access_loop_handle.h"
#include "string_util.h"
#include "umessage.h"
#include "umessage_common.h"
#include "access_umongo.h"
#include "do_get_optimal_sets.h"
#include "do_get_set_info.h"
#include "do_get_lc_extent_info.h"

using namespace udisk::access;
using namespace udisk::common;
using namespace ucloud::ubs2;
using namespace ucloud::udatabase;
using namespace std::placeholders;

void AllocateUBSHandle::Timeout(const std::string& task) {
  LOG_ERROR << "allocate ubs handle time out, session=" << session_no_
            << ", task=" << task;
  SendResponse(-EC_UBS_TIMEOUT, "allocate ubs handle time out");
}

void AllocateUBSHandle::SendResponse(uint32_t retcode,
                                     const std::string& message) {
  resp_body_->mutable_rc()->set_retcode(retcode);
  resp_body_->mutable_rc()->set_error_message(message);
  if (retcode == 0) {
    resp_body_->set_ubs_id(req_.lc_info().id());
  }
  LOG_INFO << response_.DebugString();
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void AllocateUBSHandle::EntryInit(const uevent::ConnectionUeventPtr& conn,
                                  ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  conn_ = conn;
  session_no_ = um->head().session_no();
  request_ = *um;
  MakeResponse(&request_, ALLOCATE_UBS_RESPONSE, &response_);
  resp_body_ =
      response_.mutable_body()->MutableExtension(allocate_ubs_response);
  req_ = request_.body().GetExtension(allocate_ubs_request);

  // 缺少extern_id
  if (!req_.lc_info().has_id()) {
    SendResponse(-EC_UBS_INVALID_PARAMS, "no extern id");
    return;
  }

  // 是否指定set
  if (req_.has_set_id()) {
    specified_ = true;
    specified_set_ = req_.set_id();
  }

  CheckExternId();
}

void AllocateUBSHandle::CheckExternId() {
  ucloud::udisk::GetLCExtentInfoPb lc_extent_req;
  lc_extent_req.add_extern_id(req_.lc_info().id());
  std::shared_ptr<AllocateUBSHandle> this_ptr =
      std::dynamic_pointer_cast<AllocateUBSHandle>(shared_from_this());
  std::shared_ptr<DoGetLCExtentInfoHandle> do_get_lc_extent_info_handle =
      std::make_shared<DoGetLCExtentInfoHandle>(
          std::bind(&AllocateUBSHandle::CheckExternIdResponse, this_ptr,
                    std::placeholders::_1, std::placeholders::_2),
          session_no_, false);
  do_get_lc_extent_info_handle->Start(lc_extent_req);
}

void AllocateUBSHandle::CheckExternIdResponse(
    const ucloud::ResponseCode& rc,
    const std::list<ucloud::udisk::LCExtentInfoPb>& result) {
  if (rc.retcode() != 0) {
    LOG_ERROR << "check extern id error. msg=" << rc.error_message()
              << ", code=" << rc.retcode();
    SendResponse(rc.retcode(), rc.error_message());
    return;
  }

  if (result.size() > 0) {
    LOG_ERROR << "udisk already exists, extern_id: " << req_.lc_info().id();
    SendResponse(-EC_UBS_INVALID_ARGUMENTS, "udisk already exists");
    return;
  }

  if (specified_) {
    CheckInputSet();
  } else {
    GetOptimalSets();
  }
}

void AllocateUBSHandle::GetOptimalSets() {
  std::shared_ptr<AllocateUBSHandle> this_ptr =
      std::dynamic_pointer_cast<AllocateUBSHandle>(shared_from_this());
  std::shared_ptr<DoGetOptimalSetsHandle> do_get_optimal_sets_handle =
      std::make_shared<DoGetOptimalSetsHandle>(
          std::bind(&AllocateUBSHandle::GetOptimalSetsResponse, this_ptr,
                    std::placeholders::_1, std::placeholders::_2),
          session_no_);
  do_get_optimal_sets_handle->Start(req_.lc_info().disk_type(),
                                    req_.lc_info().account_id(),
                                    req_.logic_zone(), req_.lc_info().size());
}

void AllocateUBSHandle::GetOptimalSetsResponse(const ucloud::ResponseCode& rc,
                                               std::vector<int32_t>& sets) {
  if (rc.retcode() != 0) {
    LOG_ERROR << "Failed to get optimal sets info. " << rc.error_message();
    SendResponse(rc.retcode(), rc.error_message());
    return;
  }
  candidate_sets_.swap(sets);
  candidate_ = candidate_sets_.begin();
  AllocateUBS();
}

void AllocateUBSHandle::CheckInputSet() {
  ucloud::udisk::GetSetInfoPb req;
  req.set_set_id(specified_set_);
  req.add_state(ucloud::udisk::SET_STATE_ONLINE);
  req.add_state(ucloud::udisk::SET_STATE_RESTRICTED);

  std::shared_ptr<AllocateUBSHandle> this_ptr =
      std::dynamic_pointer_cast<AllocateUBSHandle>(shared_from_this());
  std::shared_ptr<DoGetSetInfoHandle> do_get_set_info_handle =
      std::make_shared<DoGetSetInfoHandle>(
          std::bind(&AllocateUBSHandle::CheckInputSetResponse, this_ptr,
                    std::placeholders::_1, std::placeholders::_2),
          session_no_);
  do_get_set_info_handle->Start(req);
}

void AllocateUBSHandle::CheckInputSetResponse(
    const ucloud::ResponseCode& rc,
    const std::list<ucloud::udisk::SetInfoPb>& result) {
  if (rc.retcode() != 0) {
    LOG_ERROR << "check input set error. msg= " << rc.error_message()
              << ", code=" << rc.retcode();
    SendResponse(rc.retcode(), rc.error_message());
    return;
  }

  if (result.size() != 1) {
    LOG_ERROR << "input set is invalid, set " << specified_set_ << ", row_size "
              << result.size();
    SendResponse(-EC_UBS_INVALID_ARGUMENTS, "input set is invalid");
    return;
  }
  candidate_sets_.push_back(specified_set_);
  candidate_ = candidate_sets_.begin();
  AllocateUBS();
}

void AllocateUBSHandle::AllocateUBS() {
  if (candidate_ == candidate_sets_.end()) {
    // 请求列表内的set全部尝试失败
    LOG_ERROR << "Allocate UBS failed on all candidates";
    SendResponse(-EC_UBS_RESOURCE_NOT_ENOUGTH,
                 "Allocate UBS failed on all candidates");
    return;
  }

  std::stringstream stream;
  stream << "set" << *candidate_;
  std::string set_key = stream.str();
  std::string set_name = g_context->mutable_config()->RawGetValue(
      ConfigParser::kSectionName, set_key);

  std::pair<std::string, int> result = g_context->GetIPPort(set_key);
  std::string set_ip = result.first;
  uint32_t set_port = result.second;
  if (set_ip.empty() || set_port == 0) {
    LOG_ERROR << "choose server of master failed, " << set_name;
    ++candidate_;
    AllocateUBS();
    return;
  }
  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  uevent::ConnectionUeventPtr conn = handle->GetOutConnection(set_ip, set_port);
  if (conn->IsClosed()) {
    LOG_ERROR << "get connection of master failed, " << set_name;
    ++candidate_;
    AllocateUBS();
    return;
  }

  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&request_, flowno, session_no_, request_.head().message_type(),
                0, false, objid, 0, "AllocateUBS", NULL, NULL);

  std::shared_ptr<AllocateUBSHandle> this_ptr =
      std::dynamic_pointer_cast<AllocateUBSHandle>(shared_from_this());
  LOG_INFO << request_.DebugString();
  uevent::MessageUtil::SendPbRequest(
      conn, request_,
      std::bind(&AllocateUBSHandle::AllocateUBSResponse, this_ptr, _1),
      std::bind(&AllocateUBSHandle::Timeout, this_ptr, "AllocateUBS"),
      g_context->config().forward_timeout());
  return;
}

void AllocateUBSHandle::AllocateUBSResponse(ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  assert(um->head().message_type() == ALLOCATE_UBS_RESPONSE);
  assert(um->body().HasExtension(allocate_ubs_response));
  const ucloud::ubs2::AllocateUBSResponse& res =
      um->body().GetExtension(allocate_ubs_response);

  if (res.rc().retcode() != 0) {
    if (abs(res.rc().retcode()) == ucloud::ubs2::EC_UBS_CREATE_FAIL_NOT_RETRY ||
        abs(res.rc().retcode()) == ucloud::ubs2::EC_UBS_TIMEOUT ||
        abs(res.rc().retcode()) == ucloud::ubs2::EC_UBS_INVALID_PARAMS) {
      LOG_ERROR << "allocate ubs fail, msg=" << res.rc().error_message()
                << ", code=" << res.rc().retcode();
      SendResponse(res.rc().retcode(), res.rc().error_message());
      return;
    }

    LOG_WARN << "allocate ubs fail, msg=" << res.rc().error_message()
             << ", code=" << res.rc().retcode() << ", in set: " << *candidate_
             << ", will try next set";
    ++candidate_;
    AllocateUBS();
    return;
  }
  LOG_INFO << "allocate success, ubs id " << res.ubs_id() << ", on set "
           << *candidate_;
  UpdateDB(res.ubs_id());
}

void AllocateUBSHandle::UpdateDB(const std::string& extern_id) {
  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  uevent::ConnectionUeventPtr conn = handle->GetOutConnection(kUmongoName);
  if (!conn) {
    LOG_ERROR << "can not get connection of umongo";
    SendResponse(-EC_UBS_INTERNAL_ERROR, "can not get connection of umongo");
    return;
  }

  ucloud::UMessage msg;
  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&msg, flowno, session_no_,
                ucloud::umgogate::EXECUTE_MGO_REQUEST, 0, false, objid, 0,
                "UpdateDB", NULL, NULL);
  ucloud::umgogate::ExecuteMgoRequest* req =
      msg.mutable_body()->MutableExtension(
          ucloud::umgogate::execute_mgo_request);

  vector<ucloud::udisk::ExtentInfoPb> extent_info;
  ucloud::udisk::ExtentInfoPb extent;
  extent.set_id(0);
  extent.set_set_id(*candidate_);
  extent_info.push_back(extent);
  construct_insert_lc_extent_info_request(
      g_context->config().db_name(), req, extern_id,
      req_.lc_info().account_id(), req_.lc_info().company_id(), extent_info);
  std::shared_ptr<AllocateUBSHandle> this_ptr =
      std::dynamic_pointer_cast<AllocateUBSHandle>(shared_from_this());
  LOG_INFO << msg.DebugString();
  uevent::MessageUtil::SendPbRequest(
      conn, msg, std::bind(&AllocateUBSHandle::UpdateDBResponse, this_ptr, _1),
      std::bind(&AllocateUBSHandle::Timeout, this_ptr, "UpdateDB"),
      g_context->config().db_timeout());

  return;
}

void AllocateUBSHandle::UpdateDBResponse(ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  const ucloud::umgogate::ExecuteMgoResponse& res =
      um->body().GetExtension(ucloud::umgogate::execute_mgo_response);
  if (res.rc().retcode() != 0) {
    LOG_ERROR << "update db fail, msg=" << res.rc().error_message()
              << ", code=" << res.rc().retcode();
    SendResponse(res.rc().retcode(), res.rc().error_message());
    return;
  }

  SendResponse(0, "");
}
