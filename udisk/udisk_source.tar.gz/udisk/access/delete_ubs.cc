#include "delete_ubs.h"

using namespace udisk::access;
using namespace ucloud::ubs2;

ucloud::ResponseCode* DeleteUBSHandle::GetRespCode() {
  return resp_body_->mutable_rc();
}

void DeleteUBSHandle::EntryInit(const uevent::ConnectionUeventPtr& conn,
                                ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  conn_ = conn;
  session_no_ = um->head().session_no();
  request_ = *um;
  MakeResponse(&request_, DELETE_UBS_RESPONSE, &response_);
  resp_body_ = response_.mutable_body()->MutableExtension(delete_ubs_response);
  req_ = request_.body().GetExtension(delete_ubs_request);

  GetSetRequest(req_.ubs_id());
}

void DeleteUBSHandle::ForwardReqResponse(ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  assert(um->head().message_type() == DELETE_UBS_RESPONSE);
  assert(um->body().HasExtension(delete_ubs_response));
  const DeleteUBSResponse& res = um->body().GetExtension(delete_ubs_response);

  if (res.rc().retcode() != 0) {
    LOG_ERROR << "Failed to delete udisk request, msg="
              << res.rc().error_message() << ", code=" << res.rc().retcode()
              << ", extern_id =" << req_.ubs_id();
    SendResponse(res.rc().retcode(), res.rc().error_message());
    return;
  }

  SendResponse(0, "success");
}
