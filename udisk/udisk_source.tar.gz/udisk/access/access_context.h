#ifndef UDISK_ACCESS_CONTEXT_H_
#define UDISK_ACCESS_CONTEXT_H_

#include <string>
#include <cassert>
#include <tuple>
#include <map>
#include "uevent.h"
#include "zk_name_container.h"
#include "config_parser.h"

namespace udisk {
namespace access {

#define FORWARD_PEER_LABEL ("ForwardPeerLable")

static const std::string kMyId = "my_id";
static const std::string kMyRegion = "my_region";
static const std::string kDbTimeout = "db_timeout";
static const std::string kForwardTimeout = "forward_timeout";
static const std::string kUmongoName = "umongo";
// static const std::string kUDatabaseName = "udatabase";
static const std::string kUTMAccessName = "utm_access";
static const std::string kSectionMap = "names-map";
static const std::string kZkServer = "server";
static const std::string kZkTimeout = "timeout";
static const std::string DefaultZookeeper = "zookeeper";
static const std::string kDbName = "db_name";
static const std::string kSetCapWaterLine = "set_capacity_water_line";
static const std::string kLogicZoneEnable = "logic_zone_enable";

class UDiskConfig : public common::ConfigParser {
 public:
  // 加载配置文件
  std::tuple<int, std::string> init();
  int my_id() const { return my_id_; }
  int db_timeout() const { return db_timeout_; }
  int forward_timeout() const { return forward_timeout_; }
  int set_capacity_water_line() const { return set_capacity_water_line_; }
  bool logic_zone_enable() const { return logic_zone_enable_; }
  std::string my_region() const { return my_region_; }
  // std::string udatabase_zk_path() const { return udatabase_path_; }
  std::string utm_access_zk_path() const { return utm_access_; }
  std::string db_name() const { return db_name_; }

  std::string RawGetValue(const std::string &section, const std::string &key);
  void RawEnumKeys(const std::string &section, const std::string &patten,
                   std::vector<std::string> &keys);

  // 从文件加载配置项,覆盖当前内容
  // 失败的话返回(非0,错误消息),
  // 否则返回(0,"")
  std::tuple<int, std::string> load();

 private:
  explicit UDiskConfig(const std::string &file) : ConfigParser(file) {}
  UDiskConfig(const UDiskConfig &) = delete;
  UDiskConfig &operator=(const UDiskConfig &) = delete;

  // 只允许UDiskContext构造对象
  friend class UDiskContext;

  std::string config_file_;

  int my_id_ = 0;
  int db_timeout_ = 0;
  int forward_timeout_ = 0;
  int set_capacity_water_line_;
  bool logic_zone_enable_;
  std::string my_region_;
  std::string umongo_path_;
  // std::string udatabase_path_;
  std::string utm_access_;
  std::string db_name_;
};

// 这个类管理所有的全局
// 变量，包括日志对象，配置
// 文件对象等等
class UDiskContext {
 public:
  explicit UDiskContext(const std::string &conf_file);

  UDiskContext(const UDiskContext &) = delete;
  UDiskContext &operator=(const UDiskContext &) = delete;

  // 初始化开始
  std::tuple<int, std::string> Init();

  const UDiskConfig &config() const {
    return config_;
  };

  UDiskConfig *mutable_config() { return &config_; }

  void set_main_listener(uevent::ListenerUevent *listener) {
    main_listener_ = listener;
  }
  uevent::ListenerUevent *main_listener() { return main_listener_; }

  void set_main_loop(uevent::UeventLoop *loop) { main_loop_ = loop; }

  uevent::UeventLoop *main_loop() { return main_loop_; }

  void set_nc(common::NameContainer *nc, const string &zk_id = "zookeeper") {
    LOG_DEBUG << "Set zk_id=" << zk_id << ", nc=" << nc;
    ncs_[zk_id] = nc;
  }
  common::NameContainer *nc(const string &zk_id = "zookeeper") {
    return ncs_[zk_id];
  }

  // 当路径对应的服务不存在时，返回("",0)
  std::pair<std::string, int> GetIPPort(const std::string &path,
                                        bool get_leader = false);

 private:
  UDiskConfig config_;

  uevent::UeventLoop *main_loop_;
  uevent::ListenerUevent *main_listener_;

  std::map<std::string, common::NameContainer *> ncs_;
};

};  // end of ns access
};  // end of ns udisk

extern udisk::access::UDiskContext *g_context;

#endif
