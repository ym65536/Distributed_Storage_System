#ifndef UDISK_ACCESS_UPDATE_UBS_NAME_H
#define UDISK_ACCESS_UPDATE_UBS_NAME_H

#include "forward_request_base.h"

namespace udisk {
namespace access {

class UpdateUBSNameHandle : public ForwardRequestBaseHandle {
 public:
  UpdateUBSNameHandle(uevent::UeventLoop* loop)
      : ForwardRequestBaseHandle("UpdateUBSName") {}
  virtual ~UpdateUBSNameHandle() {}

  MYSELF_CREATE(UpdateUBSNameHandle);

  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         ucloud::UMessage* um);
  virtual ucloud::ResponseCode* GetRespCode();
  virtual void ForwardReqResponse(ucloud::UMessage* um);

 private:
  ucloud::ubs2::UpdateUBSNameRequest req_;
  ucloud::ubs2::UpdateUBSNameResponse* resp_body_;
};

};  // namespace access
};  // namespace udisk

#endif
