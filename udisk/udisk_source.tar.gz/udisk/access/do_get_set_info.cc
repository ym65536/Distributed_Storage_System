#include "do_get_set_info.h"
#include "access_loop_handle.h"
#include "access_context.h"

#include "logging.h"
#include "message_util.h"
#include "access_umongo.h"

namespace udisk {
namespace access {

using namespace uevent;

void DoGetSetInfoHandle::Timeout() {
  LOG_ERROR << "DoGetSetInfoHandle time out";
  Finish(-ucloud::udisk::EC_UDISK_OPT_TIMEOUT, "DoGetSetInfoHandle time out");
}

void DoGetSetInfoHandle::Finish(uint32_t retcode, const std::string& message) {
  ucloud::ResponseCode res;
  res.set_retcode(retcode);
  res.set_error_message(message);
  rsp_hook_(res, set_info_);
}

void DoGetSetInfoHandle::Start(const ucloud::udisk::GetSetInfoPb& info) {
  AccessLoopHandle* handle = reinterpret_cast<AccessLoopHandle*>(
      g_context->main_loop()->GetLoopHandle());
  uevent::ConnectionUeventPtr conn = handle->GetOutConnection(kUmongoName);
  if (!conn) {
    LOG_ERROR << "DoGetSetInfoHandle. Failed to get umongo connection";
    Finish(-ucloud::udisk::EC_UDISK_INTERNAL_ERROR,
           "Failed to get umongo connection");
    return;
  }

  ucloud::UMessage msg;
  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&msg, flowno, session_no_,
                ucloud::umgogate::EXECUTE_MGO_REQUEST, 0, false, objid, 0,
                "GetSetInfo", NULL, NULL);
  ucloud::umgogate::ExecuteMgoRequest* req =
      msg.mutable_body()->MutableExtension(
          ucloud::umgogate::execute_mgo_request);
  FindPair findpair;
  if (info.has_set_id()) {
    findpair.int_and_selector.insert(
        std::make_pair(DB_SET_TABLE_COL_ID, info.set_id()));
  }

  if (info.has_type()) {
    findpair.int_and_selector.insert(
        std::make_pair(DB_SET_TABLE_COL_TYPE, info.type()));
  }

  if (info.has_logic_zone()) {
    findpair.string_and_selector.insert(
        std::make_pair(DB_SET_TABLE_COL_LOGIC_ZONE, info.logic_zone()));
  }

  for (int32_t i = 0; i < info.state_size(); ++i) {
    findpair.int_or_selector.insert(
        std::make_pair(DB_SET_TABLE_COL_STATE, info.state(i)));
  }

  construct_get_set_info_request(g_context->config().db_name(), req, findpair,
                                 fields_null, fields_null);
  std::shared_ptr<DoGetSetInfoHandle> this_ptr =
      std::dynamic_pointer_cast<DoGetSetInfoHandle>(shared_from_this());
  LOG_INFO << msg.DebugString();
  uevent::MessageUtil::SendPbRequest(
      conn, msg, std::bind(&DoGetSetInfoHandle::GetSetInfoResponse, this_ptr,
                           std::placeholders::_1),
      std::bind(&DoGetSetInfoHandle::Timeout, this_ptr),
      g_context->config().db_timeout());
}

void DoGetSetInfoHandle::GetSetInfoResponse(ucloud::UMessage* um) {
  LOG_INFO << um->DebugString();
  const ucloud::umgogate::ExecuteMgoResponse& res =
      um->body().GetExtension(ucloud::umgogate::execute_mgo_response);
  if (res.rc().retcode() != 0 && !res.op_find_rsp().notfound()) {
    LOG_ERROR << res.rc().error_message();
    Finish(-ucloud::udisk::EC_UDISK_DB_ERROR, res.rc().error_message());
    return;
  }

  if (!parse_set_info_response(res, &set_info_)) {
    LOG_ERROR << "parse get set_info response error";
    Finish(-ucloud::udisk::EC_UDISK_PB_PARSE_FAIL,
           "parse get set_info response error");
    return;
  }

  Finish(0, "Success");
}

}  // namespace access
}  // namespace udisk
// vim: set ts=2 sw=2 sts=2 et:
