#ifndef UDISK_ACCESS_REMOVE_HOST_BLACKLIST_H
#define UDISK_ACCESS_REMOVE_HOST_BLACKLIST_H

#include "message_util.h"
#include "pb_request_handle.h"
#include "uevent.h"
#include "umessage.h"
#include <list>
#include <string>

namespace udisk {
namespace access {

class RemoveHostBlacklistHandle : public uevent::PbRequestHandle {
 public:
  RemoveHostBlacklistHandle(uevent::UeventLoop* loop) {}
  virtual ~RemoveHostBlacklistHandle() {}

  MYSELF_CREATE(RemoveHostBlacklistHandle);

  void SendResponse(uint32_t retcode, const std::string& message);
  void Timeout(const std::string& task);
  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         ucloud::UMessage* um);

  bool GetSet();
  void EntryGetSet(const ucloud::ResponseCode& rc,
                   const std::list<ucloud::udisk::LCExtentInfoPb>& result);

  bool ForwardMaster(int set_id);
  void EntryForwardMaster(ucloud::UMessage* um);

 private:
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage response_;
  std::string session_no_;
  ucloud::udisk::RemoveHostBlacklistRequest req_;
  int index_;
  std::map<int, ucloud::udisk::RemoveHostBlacklistRequest> set_blacklist_;
  uint32_t forward_count_ = 0;
  bool responsed_ = false;
};

};  // namespace access
};  // namespace udisk

#endif
