#ifndef UDISK_CLUSTER_HASH_RING_H_
#define UDISK_CLUSTER_HASH_RING_H_

#include "hash_ring.h"
#include "hash_ring_simple.h"

namespace udisk {
namespace cluster {

class ClusterMap;

class ClusterHashRing {
public:
  ClusterHashRing():hash_ring_(0),isinit_(false) {}
  ClusterHashRing(const ClusterHashRing &) = delete;
  ClusterHashRing & operator =(const ClusterHashRing &) = delete;

  void Init(const ClusterMap &clustermap);
  uint32_t GetPGId(uint32_t lcid, uint32_t pc, uint32_t lcrandomid) const;

  bool IsInit() const {
    return isinit_;
  }

  typedef hash_ring::HashRingSimple::VirtualNodeMap VirtualNodeMap;

  // for debug
  const VirtualNodeMap& NodeMap() const {
    return hash_ring_.virtual_node_map();
  }

  void SetVirtualNodeMap(const VirtualNodeMap& node_map) {
    hash_ring_.set_virtual_node_map(node_map);
    isinit_ = true;
  }

private:
  hash_ring::HashRingSimple hash_ring_;
  //hash_ring::HashRing hash_ring_;
  bool isinit_;
};

};  // end of ns cluster
};  // end of ns udisk
#endif
