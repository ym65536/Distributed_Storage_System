#include "cluster_hash_ring.h"

#include <assert.h>
#include <iostream>
#include "hash_ring.h"
#include "hash_ring_types.h"
#include "cluster_map.h"

namespace udisk {
namespace cluster {

const int kBuffSize = 128;

void ClusterHashRing::Init(const ClusterMap &clustermap) {
  hash_ring_.clear(); // 清空hash环
  uint32_t pgnum = clustermap.cluster().pg_num();
  uint32_t scalenum = clustermap.cluster().scale_num();
  uint32_t conflicta = clustermap.cluster().conflict_a();
  uint32_t conflictb = clustermap.cluster().conflict_b();
  char buff[kBuffSize] = {0};
  int size = 0;
  for (uint32_t i = 0; i < pgnum; ++i) {
    for (uint32_t j = 0; j < scalenum; ++j) {
      size = snprintf(buff, kBuffSize, "pg_%u-%u", i, j);
      //hash_ring::HashRingVirtualNode node(i, buff, j);
      hash_ring::HashRingVirtualNodeSimple node(i);
      uint32_t base = i;
      //while(!hash_ring_.add_node(node)) {
      while(!hash_ring_.add_node(node, buff, size)) {
        //base = hash_ring::HashRing::conflict(conflicta, conflictb, base);
        base = hash_ring::HashRingSimple::conflict(conflicta, conflictb, base);
        size = snprintf(buff, kBuffSize, "pg_%u-%u*%u", i, j, base);
        //node = hash_ring::HashRingVirtualNode(i, buff, j);
      }
    }
  }
  isinit_ = true;
}

uint32_t ClusterHashRing::GetPGId(uint32_t lcid, uint32_t pc, uint32_t lcrandomid) const {
  assert(isinit_);
  char buff[kBuffSize] = {0};
  int size = snprintf(buff, kBuffSize, "%u-%u-%u", lcid, pc, lcrandomid);
  // std::stringstream ss;
  // ss << lcid << "-" << pc << "-" << lcrandomid;
  return hash_ring_.hash(buff, size).id();
}

}; // end of ns cluster
}; // end of ns udisk
