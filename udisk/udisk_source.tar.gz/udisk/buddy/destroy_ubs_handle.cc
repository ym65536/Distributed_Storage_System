#include "destroy_ubs_handle.h"
#include "logging.h"
#include "umessage_common.h"
#include "protocol_conversion.h"
#include "buddy_context.h"
#include "message_util.h"
#include <time.h>
#include <sstream>

namespace udisk {
namespace buddy {

void DestroyUBSHandle::TimeOut() {
  LOG_ERROR << "DestroyUBSHandle " << session_no_ << "time out";
  SendResponse(-ucloud::ubs2::EC_UBS_TIMEOUT, "DestroyUBSHandle time out");
}

void DestroyUBSHandle::SendResponse(uint32_t retcode, const char* message) {
  ucloud::ubs2::DestroyUBSResponse* res = 
    response_.mutable_body()->MutableExtension(ucloud::ubs2::destroy_ubs_response);
  res->mutable_rc()->set_retcode(retcode);
  if (retcode) {
    res->mutable_rc()->set_error_message(message);
  }
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void DestroyUBSHandle::ProtocolTranslate(const ucloud::UMessage &src, ucloud::UMessage *dst) {
  uint32_t objid = uevent::MessageUtil::ObjId();
  NewMessage_v2(dst, src.head().flow_no(), session_no_,
                ucloud::udisk::DELETE_UDISK_REQUEST, 
                src.head().worker_index(),
                src.head().tint_flag(), objid, 0,
                src.head().call_purpose().c_str(),
                src.head().access_token().c_str(), NULL);

  const ucloud::ubs2::DestroyUBSRequest &srcReq =
    src.body().GetExtension(ucloud::ubs2::destroy_ubs_request);
  ucloud::udisk::DeleteUDiskRequest *dstReq =
    dst->mutable_body()->MutableExtension(ucloud::udisk::delete_udisk_request);
  dstReq->set_extern_id(srcReq.ubs_id());
  if (srcReq.has_company_id()) {
    dstReq->set_top_oid(srcReq.company_id());
  }
  if (srcReq.has_account_id()) {
    dstReq->set_oid(srcReq.account_id());
  }
  dstReq->set_destroy(true);
}

void DestroyUBSHandle::EntryInit(const uevent::ConnectionUeventPtr& conn, ucloud::UMessage* um) {
  conn_ = conn;
  session_no_ = um->head().session_no();
  MakeResponse(um, ucloud::ubs2::DESTROY_UBS_RESPONSE, &response_);

  ucloud::UMessage dstReqMsg;
  ProtocolTranslate(*um, &dstReqMsg);

  if (!g_context->SendMsgToMeta(dstReqMsg,
      std::bind(&DestroyUBSHandle::EntryMetaResponse, This(), std::placeholders::_1),
      std::bind(&DestroyUBSHandle::TimeOut, This()),
      g_context->config().metaserver_timeout())) {
    const char *msg = "forward msg failed";
    LOG_ERROR << "DestroyUBSHandle " << session_no_ << " failed: " << msg;
    SendResponse(-ucloud::ubs2::EC_UBS_NOT_READY, msg);
    return;
  }
}

void DestroyUBSHandle::EntryMetaResponse(ucloud::UMessage *msg) {
  const ucloud::udisk::DeleteUDiskResponse &res =
    msg->body().GetExtension(ucloud::udisk::delete_udisk_response);
  LOG_INFO << msg->DebugString();
  if (res.rc().retcode()) {
    LOG_ERROR << "DestroyUBSHandle " << session_no_ << " error: "
              << res.rc().error_message();
    if (res.rc().retcode() == -ucloud::udisk::EC_UDISK_LC_IN_USED) {
      SendResponse(-ucloud::ubs2::EC_UBS_CANNOT_DELETE_INUSED_UBS,
          res.rc().error_message().c_str());
    } else {
      SendResponse(ConstructErrorCodeFromUDiskToUBS2(res.rc().retcode()),
          res.rc().error_message().c_str());
    }
    return;
  }
  SendResponse(0, "");
}

}; // end of ns buddy
}; // end of ns udisk
