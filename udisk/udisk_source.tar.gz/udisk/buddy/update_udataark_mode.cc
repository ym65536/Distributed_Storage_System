#include "update_udataark_mode.h"
#include "buddy_context.h"
#include "logging.h"
#include "message_util.h"
#include "protocol_conversion.h"
#include "umessage_common.h"

namespace udisk {
namespace buddy {

void UpdateUDataarkModeHandle::TimeOut() {
  LOG_ERROR << "UpdateUDataarkModeHandle " << session_no_ << " time out";
  SendResponse(-ucloud::ubs2::EC_UBS_TIMEOUT,
               "UpdateUDataarkModeHandle time out");
}

void UpdateUDataarkModeHandle::SendResponse(uint32_t retcode,
                                            const std::string &message) {
  ucloud::ubs2::UpdateUDataArkModeResponse *res =
      response_.mutable_body()->MutableExtension(
          ucloud::ubs2::update_udataark_mode_response);
  res->mutable_rc()->set_retcode(retcode);
  if (retcode) {
    res->mutable_rc()->set_error_message(message);
  }
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void UpdateUDataarkModeHandle::ProtocolTranslate(const ucloud::UMessage &src,
                                                 ucloud::UMessage *dst) {
  uint32_t objid = uevent::MessageUtil::ObjId();
  NewMessage_v2(dst, src.head().flow_no(), session_no_,
                ucloud::udisk::UPDATE_UDATAARK_MODE_REQUEST,
                src.head().worker_index(), src.head().tint_flag(), objid, 0,
                src.head().call_purpose().c_str(),
                src.head().access_token().c_str(), NULL);

  const ucloud::ubs2::UpdateUDataArkModeRequest &srcReq =
      src.body().GetExtension(ucloud::ubs2::update_udataark_mode_request);
  ucloud::udisk::UpdateUDataArkModeRequest *dstReq =
      dst->mutable_body()->MutableExtension(
          ucloud::udisk::update_udataark_mode_request);
  dstReq->set_extern_id(srcReq.ubs_id());
  dstReq->set_utm_mode(
      ucloud::udisk::UTM_MODE(UtmModeUBS2ToUDisk(srcReq.utm_mode())));
}

void UpdateUDataarkModeHandle::EntryInit(
    const uevent::ConnectionUeventPtr &conn, ucloud::UMessage *um) {
  conn_ = conn;
  session_no_ = um->head().session_no();
  MakeResponse(um, ucloud::ubs2::UPDATE_UDATAARK_MODE_RESPONSE, &response_);

  ucloud::UMessage dstReqMsg;
  ProtocolTranslate(*um, &dstReqMsg);

  if (!g_context->SendMsgToMeta(
           dstReqMsg, std::bind(&UpdateUDataarkModeHandle::EntryMetaResponse,
                                This(), std::placeholders::_1),
           std::bind(&UpdateUDataarkModeHandle::TimeOut, This()),
           g_context->config().metaserver_timeout())) {
    LOG_ERROR << "UpdateUDataarkModeHandle " << session_no_
              << " forward msg failed";
    SendResponse(-ucloud::ubs2::EC_UBS_NOT_READY, "forward msg failed");
    return;
  }
}

void UpdateUDataarkModeHandle::EntryMetaResponse(ucloud::UMessage *msg) {
  const ucloud::udisk::UpdateUDataArkModeResponse &res =
      msg->body().GetExtension(ucloud::udisk::update_udataark_mode_response);
  if (res.rc().retcode()) {
    LOG_ERROR << "UpdateUDataarkModeHandle " << session_no_
              << " error: " << res.rc().error_message();
    SendResponse(ConstructErrorCodeFromUDiskToUBS2(res.rc().retcode()),
                 res.rc().error_message());
    return;
  }
  SendResponse(0, "");
}

};  // namespace buddy
};  // namespace udisk
