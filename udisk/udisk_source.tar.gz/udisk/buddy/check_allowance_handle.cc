#include "check_allowance_handle.h"
#include "logging.h"
#include "umessage_common.h"
#include "protocol_conversion.h"
#include "buddy_context.h"
#include "message_util.h"

#include <time.h>
#include <sstream>

namespace udisk {
namespace buddy {

void CheckAllowanceHandle::TimeOut() {
  LOG_ERROR << "CheckAllowanceHandle " << session_no_ << "time out";
  SendResponse(-ucloud::ubs2::EC_UBS_TIMEOUT, "CheckAllowanceHandle time out");
}

void CheckAllowanceHandle::SendResponse(uint32_t retcode, const char* message) {
  ucloud::ubs2::CheckAllowanceResponse* res = 
    response_.mutable_body()->MutableExtension(ucloud::ubs2::check_allowance_response);
  res->mutable_rc()->set_retcode(retcode);
  if (retcode) {
    res->mutable_rc()->set_error_message(message);
  }
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void CheckAllowanceHandle::ProtocolTranslate(const ucloud::UMessage &src, ucloud::UMessage *dst) {
  uint32_t objid = uevent::MessageUtil::ObjId();
  NewMessage_v2(dst, src.head().flow_no(), session_no_,
                ucloud::udisk::META_CHECK_ALLOWANCE_REQUEST, src.head().worker_index(),
                src.head().tint_flag(), objid, 0,
                src.head().call_purpose().c_str(),
                src.head().access_token().c_str(), NULL);

  const ucloud::ubs2::CheckAllowanceRequest &srcReq =
    src.body().GetExtension(ucloud::ubs2::check_allowance_request);
  ucloud::udisk::MetaCheckAllowanceRequest *dstReq =
    dst->mutable_body()->MutableExtension(ucloud::udisk::meta_check_allowance_request);
  dstReq->set_size(srcReq.size());
  dstReq->set_count(srcReq.count());
  if (srcReq.has_account_id()) {
    dstReq->set_oid(srcReq.account_id());
  }
}

void CheckAllowanceHandle::EntryInit(const uevent::ConnectionUeventPtr &conn, ucloud::UMessage* um) {
  conn_ = conn;
  session_no_ = um->head().session_no();
  MakeResponse(um, ucloud::ubs2::CHECK_ALLOWANCE_RESPONSE, &response_);

  ucloud::UMessage dstReqMsg;
  ProtocolTranslate(*um, &dstReqMsg);

  if (!g_context->SendMsgToMeta(dstReqMsg,
      std::bind(&CheckAllowanceHandle::EntryMetaResponse, This(), std::placeholders::_1),
      std::bind(&CheckAllowanceHandle::TimeOut, This()),
      g_context->config().metaserver_timeout())) {
    const char *msg = "forward msg failed";
    LOG_ERROR << "CheckAllowanceHandle " << session_no_ << " failed: " << msg;
    SendResponse(-ucloud::ubs2::EC_UBS_NOT_READY, msg);
    return;
  }
}

void CheckAllowanceHandle::EntryMetaResponse(ucloud::UMessage *msg) {
  const ucloud::udisk::MetaCheckAllowanceResponse &res =
    msg->body().GetExtension(ucloud::udisk::meta_check_allowance_response);
  ucloud::ubs2::CheckAllowanceResponse* dstRes = 
    response_.mutable_body()->MutableExtension(ucloud::ubs2::check_allowance_response);
  if (res.rc().retcode()) {
    LOG_ERROR << "CheckAllowanceHandle " << session_no_ << " error: "
              << res.rc().error_message();
    dstRes->set_count(0);
    SendResponse(ConstructErrorCodeFromUDiskToUBS2(res.rc().retcode()),
        res.rc().error_message().c_str());
    return;
  }
  dstRes->set_count(res.count());
  SendResponse(0, "");
}

}; // end of ns buddy
}; // end of ns udisk
