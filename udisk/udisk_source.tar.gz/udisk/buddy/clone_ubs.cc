#include "clone_ubs.h"
#include "buddy_context.h"
#include "logging.h"
#include "message_util.h"
#include "protocol_conversion.h"
#include "umessage_common.h"

namespace udisk {
namespace buddy {

inline void FillPosition(ucloud::UMessage *um,
                         ucloud::udisk::DATA_POSITION pos) {
  ucloud::udisk::CloneUDiskRequest *dstReq =
      um->mutable_body()->MutableExtension(ucloud::udisk::clone_udisk_request);
  dstReq->set_position(pos);
}

void CloneUBSHandle::TimeOut() {
  LOG_ERROR << "CloneUBSHandle " << session_no_ << "time out";
  SendResponse(-ucloud::ubs2::EC_UBS_TIMEOUT, "CloneUBSHandle time out");
}

void CloneUBSHandle::SendResponse(uint32_t retcode,
                                  const std::string &message) {
  ucloud::ubs2::CloneUBSResponse *res =
      response_.mutable_body()->MutableExtension(
          ucloud::ubs2::clone_ubs_response);
  res->mutable_rc()->set_retcode(retcode);
  if (retcode) {
    res->mutable_rc()->set_error_message(message);
  }
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void CloneUBSHandle::EntryGetSrcInfoLocalRegion(ucloud::UMessage *msg) {
  const ucloud::ubs2::GetUBSDetailInfoResponse &res =
      msg->body().GetExtension(ucloud::ubs2::get_ubs_detail_info_response);
  if (res.rc().retcode()) {
    LOG_INFO << "can not found src ubs " << extern_id_ << "in local set";
    GetSrcInfoOverRegion();
    return;
  }
  if (res.has_lc()) {
    FillPosition(&request_, ucloud::udisk::DATA_POSITION_LOCAL_REGION);
    ForwardRequest();
    return;
  }
  SendResponse(-ucloud::ubs2::EC_UBS_NOT_READY, "lc info miss");
}

void CloneUBSHandle::GetSrcInfoLocalRegion() {
  ucloud::UMessage um;
  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&um, flowno, session_no_,
                ucloud::ubs2::GET_UBS_DETAIL_INFO_REQUEST, 0, false, objid, 0,
                "get src ubs info", NULL, NULL);
  ucloud::ubs2::GetUBSDetailInfoRequest *req =
      um.mutable_body()->MutableExtension(
          ucloud::ubs2::get_ubs_detail_info_request);
  req->set_ubs_id(extern_id_);
  if (!g_context->SendMsgToHydra(
           um, std::bind(&CloneUBSHandle::EntryGetSrcInfoLocalRegion, This(),
                         std::placeholders::_1),
           std::bind(&CloneUBSHandle::TimeOut, This()), 10.0)) {
    LOG_ERROR << "CloneUBSHandle " << session_no_ << " can't connect to hydra";
    SendResponse(-ucloud::ubs2::EC_UBS_NOT_READY, "can't connect to hydra");
    return;
  }
}

void CloneUBSHandle::EntryGetSrcInfoOverRegion(ucloud::UMessage *msg) {
  const ucloud::ubs2::GetUBSDetailInfoResponse &res =
      msg->body().GetExtension(ucloud::ubs2::get_ubs_detail_info_response);
  if (res.rc().retcode()) {
    LOG_INFO << "can not found src ubs " << extern_id_ << "over region";
    FillPosition(&request_, ucloud::udisk::DATA_POSITION_LOCAL_DISK);
    ForwardRequest();
    return;
  }
  if (res.has_lc()) {
    FillPosition(&request_, ucloud::udisk::DATA_POSITION_CROSS_REGION);
    ForwardRequest();
    return;
  }
  SendResponse(-ucloud::ubs2::EC_UBS_NOT_READY, "lc info miss");
}

void CloneUBSHandle::GetSrcInfoOverRegion() {
  std::string ip;
  int port;
  if (!g_context->GetRedSkullAddress(&ip, &port)) {
    LOG_INFO << "can not found red skull config";
    FillPosition(&request_, ucloud::udisk::DATA_POSITION_LOCAL_DISK);
    ForwardRequest();
    return;
  }

  ucloud::UMessage um;
  uint32_t objid = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&um, flowno, session_no_,
                ucloud::ubs2::GET_UBS_DETAIL_INFO_REQUEST, 0, false, objid, 0,
                "get src ubs info over red skull", NULL, NULL);
  ucloud::ubs2::GetUBSDetailInfoRequest *req =
      um.mutable_body()->MutableExtension(
          ucloud::ubs2::get_ubs_detail_info_request);
  req->set_ubs_id(extern_id_);
  if (!g_context->SendMsg(ip, port, um,
                          std::bind(&CloneUBSHandle::EntryGetSrcInfoOverRegion,
                                    This(), std::placeholders::_1),
                          std::bind(&CloneUBSHandle::TimeOut, This()), 10.0)) {
    LOG_ERROR << "CloneUBSHandle " << session_no_
              << " can't connect to red skull";
    SendResponse(-ucloud::ubs2::EC_UBS_NOT_READY, "can't connect to red skull");
    return;
  }
}

void CloneUBSHandle::ProtocolTranslate(const ucloud::UMessage &src,
                                       ucloud::UMessage *dst) {
  uint32_t objid = uevent::MessageUtil::ObjId();
  NewMessage_v2(dst, src.head().flow_no(), session_no_,
                ucloud::udisk::CLONE_UDISK_REQUEST, src.head().worker_index(),
                src.head().tint_flag(), objid, 0,
                src.head().call_purpose().c_str(),
                src.head().access_token().c_str(), NULL);

  const ucloud::ubs2::CloneUBSRequest &srcReq =
      src.body().GetExtension(ucloud::ubs2::clone_ubs_request);
  ucloud::udisk::CloneUDiskRequest *dstReq =
      dst->mutable_body()->MutableExtension(ucloud::udisk::clone_udisk_request);
  const ucloud::ubs2::LogicalChunk &ubslc = srcReq.lc_info();
  dstReq->set_dst_extern_id(ubslc.id());
  dstReq->set_name(ubslc.lc_name());
  dstReq->set_size(ubslc.size());
  if (ubslc.has_account_id()) {
    dstReq->set_oid(ubslc.account_id());
  }
  if (ubslc.has_company_id()) {
    dstReq->set_top_oid(ubslc.company_id());
  }
  if (ubslc.has_utm_mode()) {
    dstReq->set_utm_mode(
        ucloud::udisk::UTM_MODE(UtmModeUBS2ToUDisk(ubslc.utm_mode())));
  }
  if (ubslc.has_disk_type()) {
    dstReq->set_disk_type(
        ucloud::udisk::DISK_TYPE(TypeUBS2ToUDisk(ubslc.disk_type())));
  }
  if (srcReq.has_comment()) {
    dstReq->set_comment(srcReq.comment());
  }
  // 非快照克隆的源盘extern_id
  if (srcReq.has_parent_lc_id()) {
    dstReq->set_src_extern_id(srcReq.parent_lc_id());
  }
  // 判断数据源
  if (srcReq.has_parent_snapshot_id()) {
    dstReq->set_snapshot_id(srcReq.parent_snapshot_id());
    dstReq->set_type(ucloud::udisk::DATA_SOURCE_TYPE_SNAPSHOT);
    //快照源盘extern_id
    if (srcReq.has_snapshot_src_id()) {
      dstReq->set_src_extern_id(srcReq.snapshot_src_id());
    }
  } else if (srcReq.has_snapshot_time()) {
    dstReq->set_snapshot_time(srcReq.snapshot_time());
    dstReq->set_type(ucloud::udisk::DATA_SOURCE_TYPE_TIMEPOINT);
  } else {
    dstReq->set_type(ucloud::udisk::DATA_SOURCE_TYPE_UDISK);
  }
  if (srcReq.has_udataark_id()) {
    dstReq->set_udataark_id(srcReq.udataark_id());
  }
  if (srcReq.has_set_id()) {
    dstReq->set_set_id(srcReq.set_id());
  }
  if (ubslc.has_cmk_id()) {
    dstReq->set_cmk_id(ubslc.cmk_id());
  }
  if (ubslc.has_data_key()) {
    dstReq->set_data_key(ubslc.data_key());
  }

  //保存源盘id用于查找源盘位置
  extern_id_ = dstReq->src_extern_id();
}

void CloneUBSHandle::ForwardRequest() {
  if (!g_context->SendMsgToMeta(request_,
                                std::bind(&CloneUBSHandle::EntryMetaResponse,
                                          This(), std::placeholders::_1),
                                std::bind(&CloneUBSHandle::TimeOut, This()),
                                g_context->config().metaserver_timeout())) {
    LOG_ERROR << "CloneUBSHandle " << session_no_ << " forward msg failed";
    SendResponse(-ucloud::ubs2::EC_UBS_NOT_READY, "forward msg failed");
    return;
  }
}

void CloneUBSHandle::EntryInit(const uevent::ConnectionUeventPtr &conn,
                               ucloud::UMessage *um) {
  conn_ = conn;
  session_no_ = um->head().session_no();
  MakeResponse(um, ucloud::ubs2::CLONE_UBS_RESPONSE, &response_);

  ProtocolTranslate(*um, &request_);
  // check data position
  GetSrcInfoLocalRegion();
}

void CloneUBSHandle::EntryMetaResponse(ucloud::UMessage *msg) {
  const ucloud::udisk::CloneUDiskResponse &res =
      msg->body().GetExtension(ucloud::udisk::clone_udisk_response);
  if (res.rc().retcode()) {
    LOG_ERROR << "CloneUBSHandle " << session_no_
              << " error: " << res.rc().error_message();
    SendResponse(ConstructErrorCodeFromUDiskToUBS2(res.rc().retcode()),
                 res.rc().error_message());
    return;
  }
  if (res.has_extern_id()) {
    ucloud::ubs2::CloneUBSResponse *dstRes =
        response_.mutable_body()->MutableExtension(
            ucloud::ubs2::clone_ubs_response);
    dstRes->set_ubs_id(res.extern_id());
  }
  SendResponse(0, "");
}

};  // namespace buddy
};  // namespace udisk
