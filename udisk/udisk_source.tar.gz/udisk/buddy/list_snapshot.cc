#include "list_snapshot.h"
#include "buddy_context.h"
#include "logging.h"
#include "message_util.h"
#include "protocol_conversion.h"
#include "umessage_common.h"

namespace udisk {
namespace buddy {

void ListSnapshotHandle::TimeOut() {
  LOG_ERROR << "ListSnapshotHandle " << session_no_ << "time out";
  SendResponse(-ucloud::ubs2::EC_UBS_TIMEOUT, "ListSnapshotHandle time out");
}

void ListSnapshotHandle::SendResponse(uint32_t retcode,
                                      const std::string &message) {
  ucloud::ubs2::ListSnapshotResponse *res =
      response_.mutable_body()->MutableExtension(
          ucloud::ubs2::list_snapshot_response);
  res->mutable_rc()->set_retcode(retcode);
  if (retcode) {
    res->mutable_rc()->set_error_message(message);
  }
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void ListSnapshotHandle::ProtocolTranslate(const ucloud::UMessage &src,
                                           ucloud::UMessage *dst) {
  uint32_t objid = uevent::MessageUtil::ObjId();
  NewMessage_v2(dst, src.head().flow_no(), session_no_,
                ucloud::udisk::LIST_SNAPSHOT_REQUEST, src.head().worker_index(),
                src.head().tint_flag(), objid, 0,
                src.head().call_purpose().c_str(),
                src.head().access_token().c_str(), NULL);

  const ucloud::ubs2::ListSnapshotRequest &srcReq =
      src.body().GetExtension(ucloud::ubs2::list_snapshot_request);
  ucloud::udisk::ListSnapshotRequest *dstReq =
      dst->mutable_body()->MutableExtension(
          ucloud::udisk::list_snapshot_request);
  if (srcReq.has_company_id()) {
    dstReq->set_top_oid(srcReq.company_id());
  }
  if (srcReq.has_account_id()) {
    dstReq->set_oid(srcReq.account_id());
  }
  if (srcReq.has_ubs_id()) {
    dstReq->set_extern_id(srcReq.ubs_id());
  }
  if (srcReq.has_snapshot_id()) {
    dstReq->set_snapshot_id(srcReq.snapshot_id());
  }
  if (srcReq.has_offset()) {
    dstReq->set_offset(srcReq.offset());
  }
  if (srcReq.has_limit()) {
    dstReq->set_limit(srcReq.limit());
  }
}

void ListSnapshotHandle::EntryInit(const uevent::ConnectionUeventPtr &conn,
                                   ucloud::UMessage *um) {
  conn_ = conn;
  session_no_ = um->head().session_no();
  MakeResponse(um, ucloud::ubs2::LIST_SNAPSHOT_RESPONSE, &response_);

  ucloud::UMessage dstReqMsg;
  ProtocolTranslate(*um, &dstReqMsg);

  if (!g_context->SendMsgToMeta(
           dstReqMsg, std::bind(&ListSnapshotHandle::EntryMetaResponse, This(),
                                std::placeholders::_1),
           std::bind(&ListSnapshotHandle::TimeOut, This()),
           g_context->config().metaserver_timeout())) {
    LOG_ERROR << "ListSnapshotHandle " << session_no_ << " forward msg failed";
    SendResponse(-ucloud::ubs2::EC_UBS_NOT_READY, "forward msg failed");
    return;
  }
}

void ListSnapshotHandle::EntryMetaResponse(ucloud::UMessage *msg) {
  const ucloud::udisk::ListSnapshotResponse &res =
      msg->body().GetExtension(ucloud::udisk::list_snapshot_response);
  if (res.rc().retcode()) {
    LOG_ERROR << "ListSnapshotHandle " << session_no_
              << " error: " << res.rc().error_message();
    SendResponse(ConstructErrorCodeFromUDiskToUBS2(res.rc().retcode()),
                 res.rc().error_message());
    return;
  }
  ucloud::ubs2::ListSnapshotResponse *dstRes =
      response_.mutable_body()->MutableExtension(
          ucloud::ubs2::list_snapshot_response);
  for (int i = 0; i < res.snapshots_size(); ++i) {
    ucloud::ubs2::Snapshot *dstSnapshot = dstRes->add_ubs_snapshots();
    ConstructSnapshotFromUDiskToUBS2(dstSnapshot, res.snapshots(i));
  }
  SendResponse(0, "");
}

};  // namespace buddy
};  // namespace udisk
