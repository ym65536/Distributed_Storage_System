#include "get_ubs_detail_info_handle.h"
#include "logging.h"
#include "umessage_common.h"
#include "protocol_conversion.h"
#include "buddy_context.h"
#include "message_util.h"

#include <time.h>
#include <sstream>

namespace udisk {
namespace buddy {

void GetUBSDetailInfoHandle::TimeOut() {
  LOG_ERROR << "GetUBSDetailInfoHandle " << session_no_ << "time out";
  SendResponse(-ucloud::ubs2::EC_UBS_TIMEOUT, "GetUBSDetailInfoHandle time out");
}

void GetUBSDetailInfoHandle::SendResponse(uint32_t retcode, const char* message) {
  ucloud::ubs2::GetUBSDetailInfoResponse* res = 
    response_.mutable_body()->MutableExtension(ucloud::ubs2::get_ubs_detail_info_response);
  res->mutable_rc()->set_retcode(retcode);
  if (retcode) {
    res->mutable_rc()->set_error_message(message);
  }
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void GetUBSDetailInfoHandle::ProtocolTranslate(const ucloud::UMessage &src, ucloud::UMessage *dst) {
  uint32_t objid = uevent::MessageUtil::ObjId();
  NewMessage_v2(dst, src.head().flow_no(), session_no_,
                ucloud::udisk::META_GET_UDISK_INFO_REQUEST, src.head().worker_index(),
                src.head().tint_flag(), objid, 0,
                src.head().call_purpose().c_str(),
                src.head().access_token().c_str(), NULL);

  const ucloud::ubs2::GetUBSDetailInfoRequest &srcReq =
    src.body().GetExtension(ucloud::ubs2::get_ubs_detail_info_request);
  ucloud::udisk::MetaGetUDiskInfoRequest *dstReq =
    dst->mutable_body()->MutableExtension(ucloud::udisk::meta_get_udisk_info_request);
  dstReq->set_extern_id(srcReq.ubs_id());
}

void GetUBSDetailInfoHandle::EntryInit(const uevent::ConnectionUeventPtr &conn, ucloud::UMessage* um) {
  conn_ = conn;
  session_no_ = um->head().session_no();
  MakeResponse(um, ucloud::ubs2::GET_UBS_DETAIL_INFO_RESPONSE, &response_);

  ucloud::UMessage dstReqMsg;
  ProtocolTranslate(*um, &dstReqMsg);

  if (!g_context->SendMsgToMeta(dstReqMsg,
      std::bind(&GetUBSDetailInfoHandle::EntryMetaResponse, This(), std::placeholders::_1),
      std::bind(&GetUBSDetailInfoHandle::TimeOut, This()),
      g_context->config().metaserver_timeout())) {
    const char *msg = "forward msg failed";
    LOG_ERROR << "GetUBSDetailInfoHandle " << session_no_ << " failed: " << msg;
    SendResponse(-ucloud::ubs2::EC_UBS_NOT_READY, msg);
    return;
  }
}

void GetUBSDetailInfoHandle::EntryMetaResponse(ucloud::UMessage *msg) {
  const ucloud::udisk::MetaGetUDiskInfoResponse &res =
    msg->body().GetExtension(ucloud::udisk::meta_get_udisk_info_response);
  if (res.rc().retcode()) {
    LOG_ERROR << "GetUBSDetailInfoHandle " << session_no_ << " error: "
              << res.rc().error_message();
    SendResponse(ConstructErrorCodeFromUDiskToUBS2(res.rc().retcode()),
        res.rc().error_message().c_str());
    return;
  }
  if (res.has_lc()) {
    ucloud::ubs2::GetUBSDetailInfoResponse *ret =
      response_.mutable_body()->MutableExtension(ucloud::ubs2::get_ubs_detail_info_response);
    ucloud::ubs2::LogicalChunk *ubs_lc = ret->mutable_lc();
    ConstructLogicalChunkFromUDiskToUBS2(ubs_lc, res.lc());
  }
  SendResponse(0, "");
}

}; // end of ns buddy
}; // end of ns udisk
