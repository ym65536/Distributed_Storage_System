#include "add_host_blacklist.h"

#include "buddy_context.h"
#include "logging.h"
#include "umessage_common.h"

namespace udisk {
namespace buddy {

void AddHostBlacklistHandle::TimeOut() {
  LOG_ERROR << "AddHostBlacklistHandle time out";
  SendResponse(-1, "AddHostBlacklistHandle time out");
}

void AddHostBlacklistHandle::SendResponse(uint32_t retcode,
                                          const std::string& message) {
  ucloud::udisk::AddHostBlacklistResponse* res =
      response_.mutable_body()->MutableExtension(
          ucloud::udisk::add_host_blacklist_response);
  res->mutable_rc()->set_retcode(retcode);
  res->mutable_rc()->set_error_message(message);
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void AddHostBlacklistHandle::EntryInit(const uevent::ConnectionUeventPtr& conn,
                                       ucloud::UMessage* um) {
  conn_ = conn;
  MakeResponse(um, ucloud::udisk::ADD_HOST_BLACKLIST_RESPONSE, &response_);

  ucloud::UMessage dstReqMsg;
  uint32_t objid = uevent::MessageUtil::ObjId();
  NewMessage_v2(&dstReqMsg, um->head().flow_no(), um->head().session_no(),
                ucloud::udisk::ADD_HOST_BLACKLIST_REQUEST,
                um->head().worker_index(), um->head().tint_flag(), objid, 0,
                um->head().call_purpose().c_str(),
                um->head().access_token().c_str(), NULL);

  dstReqMsg.mutable_body()
      ->MutableExtension(ucloud::udisk::add_host_blacklist_request)
      ->CopyFrom(
            um->body().GetExtension(ucloud::udisk::add_host_blacklist_request));

  if (!g_context->SendMsgToMeta(
           dstReqMsg, std::bind(&AddHostBlacklistHandle::EntryMetaResponse,
                                This(), std::placeholders::_1),
           std::bind(&AddHostBlacklistHandle::TimeOut, This()),
           g_context->config().metaserver_timeout())) {
    LOG_ERROR << "AddHostBlacklistHandle " << um->head().session_no()
              << ", forward msg failed";
    SendResponse(-ucloud::udisk::EC_UDISK_INTERNAL_ERROR, "forward msg failed");
    return;
  }
}

void AddHostBlacklistHandle::EntryMetaResponse(ucloud::UMessage* msg) {
  const ucloud::udisk::AddHostBlacklistResponse& res =
      msg->body().GetExtension(ucloud::udisk::add_host_blacklist_response);
  SendResponse(res.rc().retcode(), res.rc().error_message());
}

};  // namespace buddy
};  // namespace udisk
