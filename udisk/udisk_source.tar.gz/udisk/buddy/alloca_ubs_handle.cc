#include "alloca_ubs_handle.h"
#include "logging.h"
#include "umessage_common.h"
#include "udisk_message.h"
#include "protocol_conversion.h"
#include "buddy_context.h"
#include "message_util.h"

#include <time.h>
#include <sstream>

namespace udisk {
namespace buddy {

void AllocaUBSHandle::TimeOut() {
  LOG_ERROR << "AllocaUBSHandle " << session_no_ << "time out";
  SendResponse(-ucloud::ubs2::EC_UBS_TIMEOUT, "AllocaUBSHandle time out");
}

void AllocaUBSHandle::SendResponse(uint32_t retcode, const char* message) {
  ucloud::ubs2::AllocateUBSResponse* res = 
    response_.mutable_body()->MutableExtension(ucloud::ubs2::allocate_ubs_response);
  res->mutable_rc()->set_retcode(retcode);
  if (retcode) {
    res->mutable_rc()->set_error_message(message);
  } else {
    res->set_ubs_id(extern_id_);
  }
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void AllocaUBSHandle::ProtocolTranslate(const ucloud::UMessage &src, ucloud::UMessage *dst) {
  uint32_t objid = uevent::MessageUtil::ObjId();
  NewMessage_v2(dst, src.head().flow_no(), session_no_,
                ucloud::udisk::CREATE_UDISK_REQUEST, src.head().worker_index(),
                src.head().tint_flag(), objid, 0,
                src.head().call_purpose().c_str(),
                src.head().access_token().c_str(), NULL);

  const ucloud::ubs2::AllocateUBSRequest &srcReq =
    src.body().GetExtension(ucloud::ubs2::allocate_ubs_request);
  ucloud::udisk::CreateUDiskRequest *dstReq =
    dst->mutable_body()->MutableExtension(ucloud::udisk::create_udisk_request);

  dstReq->set_top_oid(srcReq.lc_info().company_id());
  dstReq->set_oid(srcReq.lc_info().account_id());
  // 创建请求指定的外部id是通过id字段传的
  dstReq->set_extern_id(srcReq.lc_info().id());
  extern_id_ = srcReq.lc_info().id();

  dstReq->set_size(srcReq.lc_info().size());
  dstReq->set_name(srcReq.lc_info().lc_name());
  int disk_type = TypeUBS2ToUDisk(srcReq.lc_info().disk_type());
  if (srcReq.lc_info().has_disk_type()) {
    disk_type = TypeUBS2ToUDisk(srcReq.lc_info().disk_type());
    if (disk_type < 0) {
      disk_type = ucloud::udisk::DISK_TYPE_SSD_DATA;
    }
  } else {
    disk_type = ucloud::udisk::DISK_TYPE_SSD_DATA;
  }
  dstReq->set_disk_type(ucloud::udisk::DISK_TYPE(disk_type));
  if (srcReq.lc_info().has_utm_mode()) {
    dstReq->set_utm_mode(ucloud::udisk::UTM_MODE(UtmModeUBS2ToUDisk(srcReq.lc_info().utm_mode())));
  }
  if (srcReq.has_udataark_id()) {
    dstReq->set_udataark_id(srcReq.udataark_id());
  }
  if (srcReq.lc_info().has_cmk_id()) {
    dstReq->set_cmk_id(srcReq.lc_info().cmk_id());
  }
  if (srcReq.lc_info().has_data_key()) {
    dstReq->set_data_key(srcReq.lc_info().data_key());
  }
}

void AllocaUBSHandle::EntryInit(const uevent::ConnectionUeventPtr &conn, ucloud::UMessage* um) {
  conn_ = conn;
  session_no_ = um->head().session_no();
  MakeResponse(um, ucloud::ubs2::ALLOCATE_UBS_RESPONSE, &response_);

  ucloud::UMessage dstReqMsg;
  ProtocolTranslate(*um, &dstReqMsg);

  if (!g_context->SendMsgToMeta(dstReqMsg,
      std::bind(&AllocaUBSHandle::EntryMetaResponse, This(), std::placeholders::_1),
      std::bind(&AllocaUBSHandle::TimeOut, This()),
      g_context->config().metaserver_timeout())) {
    const char *msg = "forward msg failed";
    LOG_ERROR << "AllocaUBSHandle " << session_no_ << " failed: " << msg;
    SendResponse(-ucloud::ubs2::EC_UBS_NOT_READY, msg);
    return;
  }
}

void AllocaUBSHandle::EntryMetaResponse(ucloud::UMessage *msg) {
  const ucloud::udisk::CreateUDiskResponse &res =
    msg->body().GetExtension(ucloud::udisk::create_udisk_response);
  if (res.rc().retcode()) {
    LOG_ERROR << "AllocaUBSHandle " << session_no_ << " error: "
              << res.rc().error_message();
    SendResponse(ConstructErrorCodeFromUDiskToUBS2(res.rc().retcode()),
        res.rc().error_message().c_str());
    return;
  }
  SendResponse(0, "");
}

}; // end of ns buddy
}; // end of ns udisk
