#ifndef UDISK_BUDDY_GET_UDISK_INFO_H
#define UDISK_BUDDY_GET_UDISK_INFO_H

#include "message_util.h"
#include "pb_request_handle.h"
#include "umessage_common.h"

namespace uevent {
class UeventLoop;
class ConnectionUevent;
};  // namespace uevent

namespace udisk {
namespace buddy {

class GetUDiskInfoHandle : public uevent::PbRequestHandle {
 public:
  GetUDiskInfoHandle(uevent::UeventLoop *loop) {}
  virtual ~GetUDiskInfoHandle() {}

  MYSELF_CREATE(GetUDiskInfoHandle);

  std::shared_ptr<GetUDiskInfoHandle> This() {
    return std::dynamic_pointer_cast<GetUDiskInfoHandle>(shared_from_this());
  }

  void TimeOut();
  void SendResponse(uint32_t retcode, const std::string &message);
  virtual void EntryInit(const uevent::ConnectionUeventPtr &conn,
                         ucloud::UMessage *um);
  bool ForwardHydra();
  void ProtocolTranslate(const ucloud::UMessage &src, ucloud::UMessage *dst);
  void EntryForwardHydra(ucloud::UMessage *msg);

 private:
  uevent::ConnectionUeventPtr conn_;

  ucloud::UMessage forward_req_;
  ucloud::UMessage response_;
  std::string session_no_;
};

};  // namespace buddy
};  // namespace udisk

#endif
