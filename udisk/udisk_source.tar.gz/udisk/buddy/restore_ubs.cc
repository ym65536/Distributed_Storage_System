#include "restore_ubs.h"
#include "buddy_context.h"
#include "logging.h"
#include "message_util.h"
#include "protocol_conversion.h"
#include "umessage_common.h"

namespace udisk {
namespace buddy {

void RestoreUBSHandle::TimeOut() {
  LOG_ERROR << "RestoreUBSHandle " << session_no_ << "time out";
  SendResponse(-ucloud::ubs2::EC_UBS_TIMEOUT, "RestoreUBSHandle time out");
}

void RestoreUBSHandle::SendResponse(uint32_t retcode,
                                    const std::string &message) {
  ucloud::ubs2::RestoreUBSResponse *res =
      response_.mutable_body()->MutableExtension(
          ucloud::ubs2::restore_ubs_response);
  res->mutable_rc()->set_retcode(retcode);
  if (retcode) {
    res->mutable_rc()->set_error_message(message);
  }
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void RestoreUBSHandle::ProtocolTranslate(const ucloud::UMessage &src,
                                         ucloud::UMessage *dst) {
  uint32_t objid = uevent::MessageUtil::ObjId();
  NewMessage_v2(dst, src.head().flow_no(), session_no_,
                ucloud::udisk::RESTORE_UDISK_REQUEST, src.head().worker_index(),
                src.head().tint_flag(), objid, 0,
                src.head().call_purpose().c_str(),
                src.head().access_token().c_str(), NULL);

  const ucloud::ubs2::RestoreUBSRequest &srcReq =
      src.body().GetExtension(ucloud::ubs2::restore_ubs_request);
  ucloud::udisk::RestoreUDiskRequest *dstReq =
      dst->mutable_body()->MutableExtension(
          ucloud::udisk::restore_udisk_request);
  dstReq->set_extern_id(srcReq.ubs_id());
  if (srcReq.has_snapshot_id()) {
    dstReq->set_snapshot_id(srcReq.snapshot_id());
    dstReq->set_type(ucloud::udisk::DATA_SOURCE_TYPE_SNAPSHOT);
  } else if (srcReq.has_snapshot_time()) {
    dstReq->set_snapshot_time(srcReq.snapshot_time());
    dstReq->set_type(ucloud::udisk::DATA_SOURCE_TYPE_TIMEPOINT);
  }
}

void RestoreUBSHandle::EntryInit(const uevent::ConnectionUeventPtr &conn,
                                 ucloud::UMessage *um) {
  conn_ = conn;
  session_no_ = um->head().session_no();
  MakeResponse(um, ucloud::ubs2::RESTORE_UBS_RESPONSE, &response_);

  ucloud::UMessage dstReqMsg;
  ProtocolTranslate(*um, &dstReqMsg);

  if (!g_context->SendMsgToMeta(dstReqMsg,
                                std::bind(&RestoreUBSHandle::EntryMetaResponse,
                                          This(), std::placeholders::_1),
                                std::bind(&RestoreUBSHandle::TimeOut, This()),
                                g_context->config().metaserver_timeout())) {
    LOG_ERROR << "RestoreUBSHandle " << session_no_ << " forward msg failed";
    SendResponse(-ucloud::ubs2::EC_UBS_NOT_READY, "forward msg failed");
    return;
  }
}

void RestoreUBSHandle::EntryMetaResponse(ucloud::UMessage *msg) {
  const ucloud::udisk::RestoreUDiskResponse &res =
      msg->body().GetExtension(ucloud::udisk::restore_udisk_response);
  if (res.rc().retcode()) {
    LOG_ERROR << "RestoreUBSHandle " << session_no_
              << " error: " << res.rc().error_message();
    SendResponse(ConstructErrorCodeFromUDiskToUBS2(res.rc().retcode()),
                 res.rc().error_message());
    return;
  }
  SendResponse(0, "");
}

};  // namespace buddy
};  // namespace udisk
