#ifndef UDISK_BUDDY_LIST_UBS_TOTAL_COUNT_H
#define UDISK_BUDDY_LIST_UBS_TOTAL_COUNT_H

#include <string>
#include "pb_request_handle.h"
#include "message_util.h"
#include "ubs2_message.h"

namespace uevent {
  class UeventLoop;
  class ConnectionUevent;
};

namespace udisk {
namespace buddy {

class ListUBSTotalCountHandle: public uevent::PbRequestHandle {
public:
  ListUBSTotalCountHandle(uevent::UeventLoop* loop) {}
  virtual ~ListUBSTotalCountHandle() {}

  MYSELF_CREATE(ListUBSTotalCountHandle);

  std::shared_ptr<ListUBSTotalCountHandle> This() {
    return std::dynamic_pointer_cast<ListUBSTotalCountHandle>(shared_from_this());
  }

  void TimeOut();
  void SendResponse(uint32_t retcode, const char* message);

  void ProtocolTranslate(const ucloud::UMessage &src, ucloud::UMessage *dst);
  
  void EntryMetaResponse(ucloud::UMessage *msg);

  virtual void EntryInit(const uevent::ConnectionUeventPtr &conn, ucloud::UMessage* um);
  
private:
  uevent::ConnectionUeventPtr conn_;

  ucloud::UMessage response_;
  std::string session_no_;
};

}; // end of ns buddy
}; // end of ns udisk

#endif
