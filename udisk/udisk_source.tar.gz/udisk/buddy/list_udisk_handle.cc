#include "list_udisk_handle.h"
#include "logging.h"
#include "umessage_common.h"
#include "udisk_message.h"
#include "protocol_conversion.h"
#include "buddy_context.h"
#include "message_util.h"

#include <time.h>
#include <sstream>

namespace udisk {
namespace buddy {

void ListUDiskHandle::TimeOut() {
  LOG_ERROR << "ListUDiskHandle " << session_no_ << "time out";
  SendResponse(-ucloud::udisk::EC_UDISK_OPT_TIMEOUT, "ListUDiskHandle time out");
}

void ListUDiskHandle::SendResponse(uint32_t retcode, const char* message) {
  ucloud::udisk::ListUDiskResponse* res = 
    response_.mutable_body()->MutableExtension(ucloud::udisk::list_udisk_response);
  res->mutable_rc()->set_retcode(retcode);
  if (retcode) {
    res->mutable_rc()->set_error_message(message);
  }
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void ListUDiskHandle::ProtocolTranslate(const ucloud::UMessage &src, ucloud::UMessage *dst) {
  uint32_t objid = uevent::MessageUtil::ObjId();
  NewMessage_v2(dst, src.head().flow_no(), session_no_,
                ucloud::udisk::LIST_UDISK_REQUEST, src.head().worker_index(),
                src.head().tint_flag(), objid, 0,
                src.head().call_purpose().c_str(),
                src.head().access_token().c_str(), NULL);

  const ucloud::udisk::ListUDiskRequest &srcReq =
    src.body().GetExtension(ucloud::udisk::list_udisk_request);
  ucloud::udisk::ListUDiskRequest *dstReq =
    dst->mutable_body()->MutableExtension(ucloud::udisk::list_udisk_request);

  *dstReq = srcReq;
}

void ListUDiskHandle::EntryInit(const uevent::ConnectionUeventPtr& conn, ucloud::UMessage* um) {
  conn_ = conn;
  session_no_ = um->head().session_no();
  MakeResponse(um, ucloud::udisk::LIST_UDISK_RESPONSE, &response_);

  ucloud::UMessage dstReqMsg;
  ProtocolTranslate(*um, &dstReqMsg);

  if (!g_context->SendMsgToMeta(dstReqMsg,
      std::bind(&ListUDiskHandle::EntryMetaResponse, This(), std::placeholders::_1),
      std::bind(&ListUDiskHandle::TimeOut, This()),
      g_context->config().metaserver_timeout())) {
    const char *msg = "forward msg failed";
    LOG_ERROR << "ListUBSHanlde " << session_no_ << " failed: " << msg;
    SendResponse(-ucloud::udisk::EC_UDISK_META_NOT_READY, msg);
    return;
  }
}

void ListUDiskHandle::EntryMetaResponse(ucloud::UMessage *msg) {
  const ucloud::udisk::ListUDiskResponse &res =
    msg->body().GetExtension(ucloud::udisk::list_udisk_response);
  if (res.rc().retcode()) {
    LOG_ERROR << "ListUDiskHandle " << session_no_ << " error: "
              << res.rc().error_message();
    SendResponse(ConstructErrorCodeFromUDiskToUBS2(res.rc().retcode()),
        res.rc().error_message().c_str());
    return;
  }
  ucloud::udisk::ListUDiskResponse *dstRes =
    response_.mutable_body()->MutableExtension(ucloud::udisk::list_udisk_response);
  *dstRes = res;
  SendResponse(0, "");
}

}; // end of ns buddy
}; // end of ns udisk
