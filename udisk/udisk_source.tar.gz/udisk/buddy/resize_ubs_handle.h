#ifndef UDISK_BUDDY_RESIZE_UBS_H
#define UDISK_BUDDY_RESIZE_UBS_H

#include <string>
#include "pb_request_handle.h"
#include "message_util.h"
#include "ubs2_message.h"

namespace uevent {
  class UeventLoop;
  class ConnectionUevent;
};

namespace udisk {
namespace buddy {

class ResizeUBSHandle: public uevent::PbRequestHandle {
public:
  ResizeUBSHandle(uevent::UeventLoop* loop) {}
  virtual ~ResizeUBSHandle() {}

  MYSELF_CREATE(ResizeUBSHandle);

  std::shared_ptr<ResizeUBSHandle> This() {
    return std::dynamic_pointer_cast<ResizeUBSHandle>(shared_from_this());
  }

  void TimeOut();
  void SendResponse(uint32_t retcode, const char* message);
  
  void ProtocolTranslate(const ucloud::UMessage &src, ucloud::UMessage *dst);
  void EntryMetaResponse(ucloud::UMessage *msg);
  virtual void EntryInit(const uevent::ConnectionUeventPtr &conn, ucloud::UMessage* um);
  
private:
  uevent::ConnectionUeventPtr conn_;

  ucloud::UMessage response_;
  std::string session_no_;
};

}; // end of ns buddy
}; // end of ns udisk

#endif
