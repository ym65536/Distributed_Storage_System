#include "get_snapshot_info.h"
#include "buddy_context.h"
#include "logging.h"
#include "message_util.h"
#include "protocol_conversion.h"
#include "umessage_common.h"

namespace udisk {
namespace buddy {

void GetSnapshotInfoHandle::TimeOut() {
  LOG_ERROR << "GetSnapshotInfoHandle " << session_no_ << "time out";
  SendResponse(-ucloud::ubs2::EC_UBS_TIMEOUT, "GetSnapshotInfoHandle time out");
}

void GetSnapshotInfoHandle::SendResponse(uint32_t retcode,
                                         const std::string &message) {
  ucloud::ubs2::GetSnapshotDetailInfoResponse *res =
      response_.mutable_body()->MutableExtension(
          ucloud::ubs2::get_snapshot_detail_info_response);
  res->mutable_rc()->set_retcode(retcode);
  if (retcode) {
    res->mutable_rc()->set_error_message(message);
  }
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void GetSnapshotInfoHandle::ProtocolTranslate(const ucloud::UMessage &src,
                                              ucloud::UMessage *dst) {
  uint32_t objid = uevent::MessageUtil::ObjId();
  NewMessage_v2(dst, src.head().flow_no(), session_no_,
                ucloud::udisk::GET_SNAPSHOT_INFO_REQUEST,
                src.head().worker_index(), src.head().tint_flag(), objid, 0,
                src.head().call_purpose().c_str(),
                src.head().access_token().c_str(), NULL);

  const ucloud::ubs2::GetSnapshotDetailInfoRequest &srcReq =
      src.body().GetExtension(ucloud::ubs2::get_snapshot_detail_info_request);
  ucloud::udisk::GetSnapshotInfoRequest *dstReq =
      dst->mutable_body()->MutableExtension(
          ucloud::udisk::get_snapshot_info_request);
  dstReq->set_snapshot_id(srcReq.snapshot_id());
}

void GetSnapshotInfoHandle::EntryInit(const uevent::ConnectionUeventPtr &conn,
                                      ucloud::UMessage *um) {
  conn_ = conn;
  session_no_ = um->head().session_no();
  MakeResponse(um, ucloud::ubs2::GET_SNAPSHOT_DETAIL_INFO_RESPONSE, &response_);

  ucloud::UMessage dstReqMsg;
  ProtocolTranslate(*um, &dstReqMsg);

  if (!g_context->SendMsgToMeta(
           dstReqMsg, std::bind(&GetSnapshotInfoHandle::EntryMetaResponse,
                                This(), std::placeholders::_1),
           std::bind(&GetSnapshotInfoHandle::TimeOut, This()),
           g_context->config().metaserver_timeout())) {
    LOG_ERROR << "GetSnapshotInfoHandle " << session_no_
              << " forward msg failed";
    SendResponse(-ucloud::ubs2::EC_UBS_NOT_READY, "forward msg failed");
    return;
  }
}

void GetSnapshotInfoHandle::EntryMetaResponse(ucloud::UMessage *msg) {
  const ucloud::udisk::GetSnapshotInfoResponse &res =
      msg->body().GetExtension(ucloud::udisk::get_snapshot_info_response);
  if (res.rc().retcode()) {
    LOG_ERROR << "GetSnapshotInfoHandle " << session_no_
              << " error: " << res.rc().error_message();
    SendResponse(ConstructErrorCodeFromUDiskToUBS2(res.rc().retcode()),
                 res.rc().error_message());
    return;
  }
  if (res.has_snapshot()) {
    ucloud::ubs2::GetSnapshotDetailInfoResponse *dstRes =
        response_.mutable_body()->MutableExtension(
            ucloud::ubs2::get_snapshot_detail_info_response);
    ucloud::ubs2::Snapshot *dstSnapshot = dstRes->mutable_snapshot();
    ConstructSnapshotFromUDiskToUBS2(dstSnapshot, res.snapshot());
  }
  SendResponse(0, "");
}

};  // namespace buddy
};  // namespace udisk
