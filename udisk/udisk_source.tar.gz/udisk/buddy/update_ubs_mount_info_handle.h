#ifndef UDISK_BUDDY_UPDATE_UBS_MOUNT_INFO_H
#define UDISK_BUDDY_UPDATE_UBS_MOUNT_INFO_H

#include <string>
#include "pb_request_handle.h"
#include "message_util.h"
#include "ubs2_message.h"

namespace uevent {
  class UeventLoop;
  class ConnectionUevent;
};

namespace udisk {
namespace buddy {

class UpdateUBSMountInfoHandle: public uevent::PbRequestHandle {
public:
  UpdateUBSMountInfoHandle(uevent::UeventLoop* loop) {}
  virtual ~UpdateUBSMountInfoHandle() {}

  MYSELF_CREATE(UpdateUBSMountInfoHandle);

  std::shared_ptr<UpdateUBSMountInfoHandle> This() {
    return std::dynamic_pointer_cast<UpdateUBSMountInfoHandle>(shared_from_this());
  }

  void TimeOut();
  void SendResponse(uint32_t retcode, const char* message);

  std::string ProtocolTranslate(const ucloud::UMessage &src, ucloud::UMessage *dst);
  
  void EntryMetaResponse(ucloud::UMessage *msg);
  virtual void EntryInit(const uevent::ConnectionUeventPtr &conn, ucloud::UMessage* um);
  
private:
  uevent::ConnectionUeventPtr conn_;

  ucloud::UMessage response_;
  std::string session_no_;
};

}; // end of ns buddy
}; // end of ns udisk

#endif
