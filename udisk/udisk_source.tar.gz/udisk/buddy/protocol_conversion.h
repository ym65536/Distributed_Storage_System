#ifndef PROTOCOL_CONVERSION_UBS2_UDISK_H_
#define PROTOCOL_CONVERSION_UBS2_UDISK_H_

#include <map>
#include <string>
#include "ubs2_message.h"
#include "udisk_message.h"

int TypeUDiskToUBS2(int type);
int TypeUBS2ToUDisk(int type);

int StatusUDiskToUBS2(int status);

int StatusUBS2ToUDisk(int status);

int MountStatusUDiskToUBS2(int mount_status);

int MountStatusUBS2ToUDisk(int mount_status);

int UtmStatusUDiskToUBS2(int utm_status);

int UtmStatusUBS2ToUDisk(int utm_status);

int UtmModeUBS2ToUDisk(int utm_mode);

int UtmModeUDiskToUBS2(int utm_mode);
/**
 * @brief 协议转换，将 udisk::LogicalChunk 转换为 ucloud::ubs2::LogicalChunk。
 * @param [in]ubslc(指针)：转换后的ucloud::ubs2::LogicalChunk；
 *            udisklc(常量,引用)：转换前的udisk::LogicalChunk。
 * @return void
 */
void ConstructLogicalChunkFromUDiskToUBS2(
    ucloud::ubs2::LogicalChunk* ubslc, const ucloud::udisk::LCInfoPb& udisklc);

void ConstructLogicalChunkFromUBS2ToUDisk(
    ucloud::udisk::LCInfoPb* udisklc, const ucloud::ubs2::LogicalChunk& ubslc);
/**
 * @brief 协议转换，将 udisk::Snapshot 转换为 ucloud::ubs2::Snapshot
 * @param [in]ubsSnapshot(指针)：转换后的ucloud::ubs2::Snapshot
 *            udiskSnapshot(常量,引用)：转换前的udisk::Snapshot
 * @return void
 */
void ConstructSnapshotFromUDiskToUBS2(
    ucloud::ubs2::Snapshot* ubsSnapshot,
    const ucloud::udisk::Snapshot& udiskSnapshot);
/**
 * @brief 将uint32类型转为string
 * @param [in]in：待转换的uint32类型变量
 * @return 转换后的string类型结果。
 */
std::string Uint32ToString(::google::protobuf::uint32 in);

/**
 * @brief 协议转换，将 udisk::ErrorCode 转换为 ucloud::ubs2::ErrorCode。
 * @param [in]udiskec:udisk类型错误码。
 * @return ubs2类型错误码。此时错误码为非负数。如果对应错误码未找到，返回-1。
 */
int ConstructErrorCodeFromUDiskToUBS2(int udiskec);

int ConstructErrorCodeFromUBS2ToUDisk(int ubsec);

void initEcMap();

#endif
