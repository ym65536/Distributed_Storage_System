#ifndef UDISK_BUDDY_GET_SET_CAPACITY_H
#define UDISK_BUDDY_GET_SET_CAPACITY_H

#include <string>
#include "pb_request_handle.h"
#include "message_util.h"
#include "udisk_message.h"

namespace uevent {
class UeventLoop;
class ConnectionUevent;
};

namespace udisk {
namespace buddy {

class GetSetCapacityHandle : public uevent::PbRequestHandle {
 public:
  GetSetCapacityHandle(uevent::UeventLoop* loop) {}
  virtual ~GetSetCapacityHandle() {}

  MYSELF_CREATE(GetSetCapacityHandle);

  std::shared_ptr<GetSetCapacityHandle> This() {
    return std::dynamic_pointer_cast<GetSetCapacityHandle>(shared_from_this());
  }

  void TimeOut();
  void SendResponse(uint32_t retcode, const char* message);

  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         ucloud::UMessage* um);
  void EntryMetaResponse(ucloud::UMessage* msg);

 private:
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage response_;
  std::string session_no_;
};

};  // end of ns buddy
};  // end of ns udisk

#endif
