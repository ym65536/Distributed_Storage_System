#ifndef UDISK_BUDDY_LIST_UDISK_H
#define UDISK_BUDDY_LIST_UDISK_H

#include <string>
#include "pb_request_handle.h"
#include "message_util.h"

namespace uevent {
  class UeventLoop;
  class ConnectionUevent;
};

namespace udisk {
namespace buddy {

class ListUDiskHandle: public uevent::PbRequestHandle {
public:
  ListUDiskHandle(uevent::UeventLoop* loop) {}
  virtual ~ListUDiskHandle() {}

  MYSELF_CREATE(ListUDiskHandle);

  std::shared_ptr<ListUDiskHandle> This() {
    return std::dynamic_pointer_cast<ListUDiskHandle>(shared_from_this());
  }

  void TimeOut();
  void SendResponse(uint32_t retcode, const char* message);

  void ProtocolTranslate(const ucloud::UMessage &src, ucloud::UMessage *dst);
  
  void EntryMetaResponse(ucloud::UMessage *msg);

  virtual void EntryInit(const uevent::ConnectionUeventPtr &conn, ucloud::UMessage* um);
  
private:
  uevent::ConnectionUeventPtr conn_;

  ucloud::UMessage response_;
  std::string session_no_;
};

}; // end of ns buddy
}; // end of ns udisk

#endif
