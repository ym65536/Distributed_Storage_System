#include "udisk_login_handle.h"

#include "logging.h"
#include "umessage_common.h"
#include "buddy_context.h"
#include "ubs2_message.h"
#include "message_util.h"

namespace udisk {
namespace buddy {

void UDiskLoginHandle::TimeOut() {
  LOG_ERROR << "UDiskLoginHandle time out";
  SendResponse(-2, "UDiskLoginHandle time out");
}

void UDiskLoginHandle::SendResponse(uint32_t retcode, const char* message) {
  ucloud::udisk::UDiskLoginResponse* res = 
    response_.mutable_body()->MutableExtension(ucloud::udisk::udisk_login_response);
  res->mutable_rc()->set_retcode(retcode);
  res->mutable_rc()->set_error_message(message);
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void UDiskLoginHandle::EntryInit(const uevent::ConnectionUeventPtr &conn, ucloud::UMessage* um) {
  conn_ = conn;
  session_no_ = um->head().session_no();
  MakeResponse(um, ucloud::udisk::UDISK_LOGIN_RESPONSE, &response_);

  ucloud::UMessage dstReqMsg;

  uint32_t objid = uevent::MessageUtil::ObjId();
  NewMessage_v2(&dstReqMsg, um->head().flow_no(), session_no_,
                ucloud::udisk::UDISK_LOGIN_REQUEST,
                um->head().worker_index(),
                um->head().tint_flag(), objid, 0,
                um->head().call_purpose().c_str(),
                um->head().access_token().c_str(), NULL);
  dstReqMsg.mutable_body()->MutableExtension(ucloud::udisk::udisk_login_request)->CopyFrom(
      um->body().GetExtension(ucloud::udisk::udisk_login_request));

  if (!g_context->SendMsgToMeta(dstReqMsg,
      std::bind(&UDiskLoginHandle::EntryMetaResponse, This(), std::placeholders::_1),
      std::bind(&UDiskLoginHandle::TimeOut, This()),
      g_context->config().metaserver_timeout())) {
    const char *msg = "forward msg failed";
    LOG_ERROR << "UDiskLoginHandle " << session_no_ << " failed: " << msg;
    SendResponse(-ucloud::ubs2::EC_UBS_NOT_READY, msg);
    return;
  }
}

void UDiskLoginHandle::EntryMetaResponse(ucloud::UMessage *msg) {
  const ucloud::udisk::UDiskLoginResponse &res = 
    msg->body().GetExtension(ucloud::udisk::udisk_login_response);
  ucloud::udisk::UDiskLoginResponse *dstRes =
    response_.mutable_body()->MutableExtension(ucloud::udisk::udisk_login_response);
  *dstRes = res;
  SendResponse(res.rc().retcode(), res.rc().error_message().c_str());
}

}; // end of ns buddy
}; // end of ns udisk
