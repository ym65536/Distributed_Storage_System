#include "protocol_conversion.h"
#include <stdlib.h>
#include <cmath>
#include <sstream>
#include <string>

// 保存udisk到ubs2错误码的映射。
static std::map<int, int> ecMapUDiskUBS2;
// 保存ubs2到udisk错误码的映射。
static std::map<int, int> ecMapUBS2UDisk;
void initEcMap() {
  ecMapUDiskUBS2.clear();
  ecMapUDiskUBS2[ucloud::udisk::EC_UDISK_INTERNAL_ERROR] =
      ucloud::ubs2::EC_UBS_INTERNAL_ERROR;
  ecMapUDiskUBS2[ucloud::udisk::EC_UDISK_META_NOT_READY] =
      ucloud::ubs2::EC_UBS_NOT_READY;
  ecMapUDiskUBS2[ucloud::udisk::EC_UDISK_PARAM_INVALID] =
      ucloud::ubs2::EC_UBS_INVALID_PARAMS;
  ecMapUDiskUBS2[ucloud::udisk::EC_UDISK_DB_ERROR] =
      ucloud::ubs2::EC_UBS_DB_ERROR;
  ecMapUDiskUBS2[ucloud::udisk::EC_UDISK_OPT_TIMEOUT] =
      ucloud::ubs2::EC_UBS_TIMEOUT;
  ecMapUDiskUBS2[ucloud::udisk::EC_UDISK_CAP_ERROR] =
      ucloud::ubs2::EC_UBS_RESOURCE_NOT_ENOUGTH;
  ecMapUDiskUBS2[ucloud::udisk::EC_UDISK_EXCEED_LIMIT] =
      ucloud::ubs2::EC_UBS_EXCEED_LIMIT;
  ecMapUDiskUBS2[ucloud::udisk::EC_UDISK_DOING_SNAPSHOT] =
      ucloud::ubs2::EC_UBS_DOING_SNAPSHOT;
  ecMapUDiskUBS2[ucloud::udisk::EC_UDISK_MAKING_CLONE] =
      ucloud::ubs2::EC_UBS_MAKING_CLONE;
  ecMapUDiskUBS2[ucloud::udisk::EC_UDISK_ARK_MODIFY_INTERVAL_LIMIT] =
      ucloud::ubs2::EC_UBS_UTM_MODIFY_INTERVAL_LIMIT;
  ecMapUDiskUBS2[ucloud::udisk::EC_UDISK_RESTORING] =
      ucloud::ubs2::EC_UBS_RESTORE_IN_HANDLING;
  ecMapUDiskUBS2[ucloud::udisk::EC_UDISK_CREATE_FAIL_NOT_RETRY] =
      ucloud::ubs2::EC_UBS_CREATE_FAIL_NOT_RETRY;

  ecMapUBS2UDisk.clear();
  ecMapUBS2UDisk[ucloud::ubs2::EC_UBS_INTERNAL_ERROR] =
      ucloud::udisk::EC_UDISK_INTERNAL_ERROR;
  ecMapUBS2UDisk[ucloud::ubs2::EC_UBS_NOT_READY] =
      ucloud::udisk::EC_UDISK_META_NOT_READY;
  ecMapUBS2UDisk[ucloud::ubs2::EC_UBS_INVALID_PARAMS] =
      ucloud::udisk::EC_UDISK_PARAM_INVALID;
  ecMapUBS2UDisk[ucloud::ubs2::EC_UBS_DB_ERROR] =
      ucloud::udisk::EC_UDISK_DB_ERROR;
  ecMapUBS2UDisk[ucloud::ubs2::EC_UBS_TIMEOUT] =
      ucloud::udisk::EC_UDISK_OPT_TIMEOUT;
  ecMapUBS2UDisk[ucloud::ubs2::EC_UBS_RESOURCE_NOT_ENOUGTH] =
      ucloud::udisk::EC_UDISK_CAP_ERROR;
  ecMapUBS2UDisk[ucloud::ubs2::EC_UBS_EXCEED_LIMIT] =
      ucloud::udisk::EC_UDISK_EXCEED_LIMIT;
  ecMapUBS2UDisk[ucloud::ubs2::EC_UBS_DOING_SNAPSHOT] =
      ucloud::udisk::EC_UDISK_DOING_SNAPSHOT;
  ecMapUBS2UDisk[ucloud::ubs2::EC_UBS_MAKING_CLONE] =
      ucloud::udisk::EC_UDISK_MAKING_CLONE;
  ecMapUBS2UDisk[ucloud::ubs2::EC_UBS_UTM_MODIFY_INTERVAL_LIMIT] =
      ucloud::udisk::EC_UDISK_ARK_MODIFY_INTERVAL_LIMIT;
  ecMapUBS2UDisk[ucloud::ubs2::EC_UBS_RESTORE_IN_HANDLING] =
      ucloud::udisk::EC_UDISK_RESTORING;
  ecMapUDiskUBS2[ucloud::ubs2::EC_UBS_CREATE_FAIL_NOT_RETRY] =
      ucloud::udisk::EC_UDISK_CREATE_FAIL_NOT_RETRY;
}

void ConstructLogicalChunkFromUDiskToUBS2(
    ucloud::ubs2::LogicalChunk* ubslc, const ucloud::udisk::LCInfoPb& udisklc) {
  ubslc->Clear();

  if (udisklc.has_extern_id()) {
    ubslc->set_extern_id(udisklc.extern_id());
    ubslc->set_id(udisklc.extern_id());
  }
  if (udisklc.has_name()) {
    ubslc->set_lc_name(udisklc.name());
  }

  ubslc->set_size(udisklc.size());

  if (udisklc.has_create_time()) {
    ubslc->set_create_time((uint32_t)udisklc.create_time());
  }
  if (udisklc.has_throw_time()) {
    ubslc->set_thrown_time((uint32_t)udisklc.throw_time());
  }
  if (udisklc.has_status()) {
    ubslc->set_status(StatusUDiskToUBS2(udisklc.status()));
  }
  if (udisklc.has_mount_status()) {
    ubslc->set_mount_status(MountStatusUDiskToUBS2(udisklc.mount_status()));
  }
  if (udisklc.has_mount_vm_id()) {
    ubslc->set_mount_vm_id(udisklc.mount_vm_id());
  }
  if (udisklc.has_mount_device_name()) {
    ubslc->set_mount_device_name(udisklc.mount_device_name());
  }
  if (udisklc.has_top_oid()) {
    ubslc->set_company_id(udisklc.top_oid());
  }
  if (udisklc.has_oid()) {
    ubslc->set_account_id(udisklc.oid());
  }
  if (udisklc.has_disk_type()) {
    ubslc->set_disk_type(TypeUDiskToUBS2(udisklc.disk_type()));
  }
  if (udisklc.has_snapshot_limit()) {
    ubslc->set_snapshot_limit(udisklc.snapshot_limit());
  }
  if (udisklc.has_utm_status()) {
    ubslc->set_utm_status(UtmStatusUDiskToUBS2(udisklc.utm_status()));
  }
  if (udisklc.has_utm_mode()) {
    ubslc->set_utm_mode(UtmModeUDiskToUBS2(udisklc.utm_mode()));
  }
  if (udisklc.has_utm_modify_time()) {
    ubslc->set_utm_modify_time((uint32_t)udisklc.utm_modify_time());
  }
  if (udisklc.has_clone_rate()) {
    ubslc->set_clone_rate(udisklc.clone_rate());
  }
  if (udisklc.has_in_used()) {
    ubslc->set_in_used(udisklc.in_used());
  }
  if (udisklc.has_snapshot_count()) {
    ubslc->set_snapshot_count(udisklc.snapshot_count());
  } else {
    ubslc->set_snapshot_count(0);
  }
  if (udisklc.has_cmk_id()) {
    ubslc->set_cmk_id(udisklc.cmk_id());
  }
  if (udisklc.has_data_key()) {
    ubslc->set_data_key(udisklc.data_key());
  }
  //(0:老版本 1:1.05版本 2:1.06版本 3:udisk新架构1.0.0)
  ubslc->set_version(3);
}

void ConstructLogicalChunkFromUBS2ToUDisk(
    ucloud::udisk::LCInfoPb* udisklc, const ucloud::ubs2::LogicalChunk& ubslc) {
  udisklc->Clear();

  if (ubslc.has_extern_id()) {
    udisklc->set_extern_id(ubslc.extern_id());
  }
  if (ubslc.has_lc_name()) {
    udisklc->set_name(ubslc.lc_name());
  }
  udisklc->set_size(ubslc.size());
  if (ubslc.has_create_time()) {
    udisklc->set_create_time(ubslc.create_time());
  }
  if (ubslc.has_thrown_time()) {
    udisklc->set_throw_time(ubslc.thrown_time());
  }
  if (ubslc.has_status()) {
    udisklc->set_status(
        ucloud::udisk::UDISK_STATUS(StatusUBS2ToUDisk(ubslc.status())));
  }
  if (ubslc.has_mount_status()) {
    udisklc->set_mount_status(ucloud::udisk::UDISK_MOUNT_STATUS(
        MountStatusUBS2ToUDisk(ubslc.mount_status())));
  }
  if (ubslc.has_mount_vm_id()) {
    udisklc->set_mount_vm_id(ubslc.mount_vm_id());
  }
  if (ubslc.has_mount_device_name()) {
    udisklc->set_mount_device_name(ubslc.mount_device_name());
  }
  if (ubslc.has_company_id()) {
    udisklc->set_top_oid(ubslc.company_id());
  }
  if (ubslc.has_account_id()) {
    udisklc->set_oid(ubslc.account_id());
  }
  if (ubslc.has_disk_type()) {
    udisklc->set_disk_type(
        ucloud::udisk::DISK_TYPE(TypeUBS2ToUDisk(ubslc.disk_type())));
  }
  if (ubslc.has_utm_status()) {
    udisklc->set_utm_status(
        ucloud::udisk::UTM_STATUS(UtmStatusUBS2ToUDisk(ubslc.utm_status())));
  }
  if (ubslc.has_utm_mode()) {
    udisklc->set_utm_mode(
        ucloud::udisk::UTM_MODE(UtmModeUBS2ToUDisk(ubslc.utm_mode())));
  }
  if (ubslc.has_utm_modify_time()) {
    udisklc->set_utm_modify_time(ubslc.utm_modify_time());
  }
  if (ubslc.has_clone_rate()) {
    udisklc->set_clone_rate(ubslc.clone_rate());
  }
  if (ubslc.has_in_used()) {
    udisklc->set_in_used(ubslc.in_used());
  }
  if (ubslc.has_cmk_id()) {
    udisklc->set_cmk_id(ubslc.cmk_id());
  }
  if (ubslc.has_data_key()) {
    udisklc->set_data_key(ubslc.data_key());
  }
}

void ConstructSnapshotFromUDiskToUBS2(
    ucloud::ubs2::Snapshot* ubsSnapshot,
    const ucloud::udisk::Snapshot& udiskSnapshot) {
  ubsSnapshot->Clear();
  ubsSnapshot->set_id(udiskSnapshot.snapshot_id());
  ubsSnapshot->set_extern_id(udiskSnapshot.snapshot_id());
  ubsSnapshot->set_lc_id(udiskSnapshot.extern_id());
  ubsSnapshot->set_index_id("");
  ubsSnapshot->set_create_time(udiskSnapshot.create_time());
  ubsSnapshot->set_modify_time(udiskSnapshot.modify_time());
  ubsSnapshot->set_status(udiskSnapshot.status());
  ubsSnapshot->set_size(udiskSnapshot.size());
  if (udiskSnapshot.has_create_status()) {
    ubsSnapshot->set_create_status(udiskSnapshot.create_status());
  }
  if (udiskSnapshot.has_snapshot_name()) {
    ubsSnapshot->set_snapshot_name(udiskSnapshot.snapshot_name());
  }
  if (udiskSnapshot.has_comment()) {
    ubsSnapshot->set_comment(udiskSnapshot.comment());
  }
  if (udiskSnapshot.has_oid()) {
    ubsSnapshot->set_account_id(udiskSnapshot.oid());
  }
  if (udiskSnapshot.has_top_oid()) {
    ubsSnapshot->set_company_id(udiskSnapshot.top_oid());
  }
  if (udiskSnapshot.has_in_used()) {
    ubsSnapshot->set_in_used(udiskSnapshot.in_used());
  }
  if (udiskSnapshot.has_version()) {
    ubsSnapshot->set_version(udiskSnapshot.version());
  }
  if (udiskSnapshot.has_disk_type()) {
    ucloud::ubs2::DISK_TYPE type =
        ucloud::ubs2::DISK_TYPE(TypeUDiskToUBS2(udiskSnapshot.disk_type()));
    ubsSnapshot->set_disk_type(type);
  }
  if (udiskSnapshot.has_uhost_id()) {
    ubsSnapshot->set_uhost_id(udiskSnapshot.uhost_id());
  }
  if (udiskSnapshot.has_cmk_id()) {
    ubsSnapshot->set_cmk_id(udiskSnapshot.cmk_id());
  }
  if (udiskSnapshot.has_data_key()) {
    ubsSnapshot->set_data_key(udiskSnapshot.data_key());
  }
}

std::string Uint32ToString(::google::protobuf::uint32 in) {
  std::stringstream ss;
  ss << in;
  return ss.str();
}

int ConstructErrorCodeFromUDiskToUBS2(int udiskec) {
  std::map<int, int>::iterator it;
  it = ecMapUDiskUBS2.find(abs(udiskec));
  if (it == ecMapUDiskUBS2.end()) {
    return -1;
  } else {
    return it->second;
  }
}

int ConstructErrorCodeFromUBS2ToUDisk(int ubsec) {
  std::map<int, int>::iterator it;
  it = ecMapUBS2UDisk.find(abs(ubsec));
  if (it == ecMapUBS2UDisk.end()) {
    return -1;
  } else {
    return it->second;
  }
}

int TypeUDiskToUBS2(int type) {
  switch (type) {
    case ucloud::udisk::DISK_TYPE_DATA:
      return ucloud::ubs2::DATA_DISK;
    case ucloud::udisk::DISK_TYPE_SYSTEM:
      return ucloud::ubs2::SYSTEM_DISK;
    case ucloud::udisk::DISK_TYPE_SSD_DATA:
      return ucloud::ubs2::SSD_DATA_DISK;
    case ucloud::udisk::DISK_TYPE_SSD_SYSTEM:
      return ucloud::ubs2::SYSTEM_SSD_DISK;
    case ucloud::udisk::DISK_TYPE_RSSD_DATA:
      return ucloud::ubs2::RSSD_DATA_DISK;
    default:
      return -1;
  }
}

int TypeUBS2ToUDisk(int type) {
  switch (type) {
    case ucloud::ubs2::DATA_DISK:
      return ucloud::udisk::DISK_TYPE_DATA;
    case ucloud::ubs2::SYSTEM_DISK:
      return ucloud::udisk::DISK_TYPE_SYSTEM;
    case ucloud::ubs2::SSD_DATA_DISK:
      return ucloud::udisk::DISK_TYPE_SSD_DATA;
    case ucloud::ubs2::SYSTEM_SSD_DISK:
      return ucloud::udisk::DISK_TYPE_SSD_SYSTEM;
    case ucloud::ubs2::RSSD_DATA_DISK:
      return ucloud::udisk::DISK_TYPE_RSSD_DATA;
    default:
      return -1;
  }
}

int UtmModeUBS2ToUDisk(int utm_mode) {
  switch (utm_mode) {
    case 0:
      return ucloud::udisk::UTM_MODE_CLOSE;
    case 1:
      return ucloud::udisk::UTM_MODE_OPEN;
    default:
      return -1;
  }
}

int UtmModeUDiskToUBS2(int utm_mode) {
  switch (utm_mode) {
    case ucloud::udisk::UTM_MODE_CLOSE:
    case ucloud::udisk::UTM_MODE_UNSUPPORT:
      return 0;
    case ucloud::udisk::UTM_MODE_OPEN:
      return 1;
    default:
      return -1;
  }
}

int StatusUDiskToUBS2(int status) {
  switch (status) {
    case ucloud::udisk::UDISK_STATUS_NORMAL:
      return 0;
    case ucloud::udisk::UDISK_STATUS_MARK_DELETED:
      return 1;
    case ucloud::udisk::UDISK_STATUS_RECYCLED:
    case ucloud::udisk::UDISK_STATUS_RECYCLING:
      return 2;
    case ucloud::udisk::UDISK_STATUS_RECYCLE_BIN:
      return 3;
    default:
      return -1;
  }
}

int StatusUBS2ToUDisk(int status) {
  switch (status) {
    case 0:
      return ucloud::udisk::UDISK_STATUS_NORMAL;
    case 1:
      return ucloud::udisk::UDISK_STATUS_MARK_DELETED;
    case 2:
      return ucloud::udisk::UDISK_STATUS_RECYCLED;
    case 3:
      return ucloud::udisk::UDISK_STATUS_RECYCLE_BIN;
    default:
      return -1;
  }
}

int MountStatusUDiskToUBS2(int mount_status) {
  switch (mount_status) {
    case ucloud::udisk::UDISK_MOUNT_STATUS_AVAILABLE:
      return ucloud::ubs2::AVAILABLE;
    case ucloud::udisk::UDISK_MOUNT_STATUS_ATTACHING:
      return ucloud::ubs2::ATTACHING;
    case ucloud::udisk::UDISK_MOUNT_STATUS_ATTACHED:
      return ucloud::ubs2::ATTACHED;
    case ucloud::udisk::UDISK_MOUNT_STATUS_DETACHING:
      return ucloud::ubs2::DETACHING;
    case ucloud::udisk::UDISK_MOUNT_STATUS_NOT_AVAILABLE:
      return ucloud::ubs2::NOT_AVAILABLE;
    case ucloud::udisk::UDISK_MOUNT_STATUS_FAILED:
      return ucloud::ubs2::FAILED;
    case ucloud::udisk::UDISK_MOUNT_STATUS_CLONING:
      return ucloud::ubs2::CLONING;
    case ucloud::udisk::UDISK_MOUNT_STATUS_RESTORING:
      return ucloud::ubs2::RESTORING;
    case ucloud::udisk::UDISK_MOUNT_STATUS_RESTORE_FAILED:
      return ucloud::ubs2::RESTORE_FAILED;
    default:
      return -1;
  }
}

int MountStatusUBS2ToUDisk(int mount_status) {
  switch (mount_status) {
    case ucloud::ubs2::AVAILABLE:
      return ucloud::udisk::UDISK_MOUNT_STATUS_AVAILABLE;
    case ucloud::ubs2::ATTACHING:
      return ucloud::udisk::UDISK_MOUNT_STATUS_ATTACHING;
    case ucloud::ubs2::ATTACHED:
      return ucloud::udisk::UDISK_MOUNT_STATUS_ATTACHED;
    case ucloud::ubs2::DETACHING:
      return ucloud::udisk::UDISK_MOUNT_STATUS_DETACHING;
    case ucloud::ubs2::NOT_AVAILABLE:
      return ucloud::udisk::UDISK_MOUNT_STATUS_NOT_AVAILABLE;
    case ucloud::ubs2::FAILED:
      return ucloud::udisk::UDISK_MOUNT_STATUS_FAILED;
    case ucloud::ubs2::CLONING:
      return ucloud::udisk::UDISK_MOUNT_STATUS_CLONING;
    case ucloud::ubs2::RESTORING:
      return ucloud::udisk::UDISK_MOUNT_STATUS_RESTORING;
    case ucloud::ubs2::RESTORE_FAILED:
      return ucloud::udisk::UDISK_MOUNT_STATUS_RESTORE_FAILED;
    default:
      return -1;
  }
}

int UtmStatusUDiskToUBS2(int utm_status) {
  switch (utm_status) {
    case ucloud::udisk::UTM_STATUS_NORMAL:
      return ucloud::ubs2::UTM_NORMAL;
    case ucloud::udisk::UTM_STATUS_UNSUPPORT:
      return ucloud::ubs2::UTM_UNSUPPORT;
    case ucloud::udisk::UTM_STATUS_NEED_REBASE:
      return ucloud::ubs2::UTM_NEED_REBASE;
    case ucloud::udisk::UTM_STATUS_REBASING:
      return ucloud::ubs2::UTM_REBASING;
    case ucloud::udisk::UTM_STATUS_RUNNING:
      return ucloud::ubs2::UTM_RUNNING;
    default:
      return utm_status;
  }
}

int UtmStatusUBS2ToUDisk(int utm_status) {
  switch (utm_status) {
    case ucloud::ubs2::UTM_NORMAL:
      return ucloud::udisk::UTM_STATUS_NORMAL;
    case ucloud::ubs2::UTM_UNSUPPORT:
      return ucloud::udisk::UTM_STATUS_UNSUPPORT;
    case ucloud::ubs2::UTM_NEED_REBASE:
      return ucloud::udisk::UTM_STATUS_NEED_REBASE;
    case ucloud::ubs2::UTM_REBASING:
      return ucloud::udisk::UTM_STATUS_REBASING;
    case ucloud::ubs2::UTM_RUNNING:
      return ucloud::udisk::UTM_STATUS_RUNNING;
    default:
      return utm_status;
  }
}
