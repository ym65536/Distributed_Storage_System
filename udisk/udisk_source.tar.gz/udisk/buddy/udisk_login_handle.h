#ifndef UDISK_BUDDY_UDISK_LOGIN_HANDLE_H
#define UDISK_BUDDY_UDISK_LOGIN_HANDLE_H

#include <string>
#include "pb_request_handle.h"
#include "message_util.h"
#include "udisk_message.h"

namespace uevent {
  class UeventLoop;
  class ConnectionUevent;
};

namespace udisk {
namespace buddy {

class UDiskLoginHandle: public uevent::PbRequestHandle {
public:
  UDiskLoginHandle(uevent::UeventLoop* loop) {}
  virtual ~UDiskLoginHandle() {}

  MYSELF_CREATE(UDiskLoginHandle);

  std::shared_ptr<UDiskLoginHandle> This() {
    return std::dynamic_pointer_cast<UDiskLoginHandle>(shared_from_this());
  }

  void TimeOut();
  void SendResponse(uint32_t retcode, const char* message);
  
  virtual void EntryInit(const uevent::ConnectionUeventPtr &conn, ucloud::UMessage* um);
  void EntryMetaResponse(ucloud::UMessage *msg);
  
private:
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage response_;
  std::string session_no_;
};

}; // end of ns metaserver
}; // end of ns udisk

#endif
