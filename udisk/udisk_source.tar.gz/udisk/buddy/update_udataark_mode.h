#ifndef UDISK_BUDDY_UPDATE_UDATAARK_MODE_H
#define UDISK_BUDDY_UPDATE_UDATAARK_MODE_H

#include "message_util.h"
#include "pb_request_handle.h"
#include "ubs2_message.h"

namespace uevent {
class UeventLoop;
class ConnectionUevent;
};  // namespace uevent

namespace udisk {
namespace buddy {

class UpdateUDataarkModeHandle : public uevent::PbRequestHandle {
 public:
  UpdateUDataarkModeHandle(uevent::UeventLoop *loop) {}
  virtual ~UpdateUDataarkModeHandle() {}

  MYSELF_CREATE(UpdateUDataarkModeHandle);

  std::shared_ptr<UpdateUDataarkModeHandle> This() {
    return std::dynamic_pointer_cast<UpdateUDataarkModeHandle>(
        shared_from_this());
  }

  void TimeOut();
  void SendResponse(uint32_t retcode, const std::string &message);

  void ProtocolTranslate(const ucloud::UMessage &src, ucloud::UMessage *dst);
  void EntryMetaResponse(ucloud::UMessage *msg);
  virtual void EntryInit(const uevent::ConnectionUeventPtr &conn,
                         ucloud::UMessage *um);

 private:
  uevent::ConnectionUeventPtr conn_;

  ucloud::UMessage response_;
  std::string session_no_;
};

};  // namespace buddy
};  // namespace udisk

#endif
