#include "update_snapshot_info.h"
#include "buddy_context.h"
#include "logging.h"
#include "message_util.h"
#include "protocol_conversion.h"
#include "umessage_common.h"

namespace udisk {
namespace buddy {

void UpdateSnapshotInfoHandle::TimeOut() {
  LOG_ERROR << "UpdateSnapshotInfoHandle " << session_no_ << "time out";
  SendResponse(-ucloud::ubs2::EC_UBS_TIMEOUT,
               "UpdateSnapshotInfoHandle time out");
}

void UpdateSnapshotInfoHandle::SendResponse(uint32_t retcode,
                                            const std::string &message) {
  ucloud::ubs2::UpdateSnapshotInfoResponse *res =
      response_.mutable_body()->MutableExtension(
          ucloud::ubs2::update_snapshot_info_response);
  res->mutable_rc()->set_retcode(retcode);
  if (retcode) {
    res->mutable_rc()->set_error_message(message);
  }
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void UpdateSnapshotInfoHandle::ProtocolTranslate(const ucloud::UMessage &src,
                                                 ucloud::UMessage *dst) {
  uint32_t objid = uevent::MessageUtil::ObjId();
  NewMessage_v2(dst, src.head().flow_no(), session_no_,
                ucloud::udisk::UPDATE_SNAPSHOT_INFO_REQUEST,
                src.head().worker_index(), src.head().tint_flag(), objid, 0,
                src.head().call_purpose().c_str(),
                src.head().access_token().c_str(), NULL);

  const ucloud::ubs2::UpdateSnapshotInfoRequest &srcReq =
      src.body().GetExtension(ucloud::ubs2::update_snapshot_info_request);
  ucloud::udisk::UpdateSnapshotInfoRequest *dstReq =
      dst->mutable_body()->MutableExtension(
          ucloud::udisk::update_snapshot_info_request);
  dstReq->set_snapshot_id(srcReq.snapshot_id());
  if (srcReq.has_snapshot_name()) {
    dstReq->set_snapshot_name(srcReq.snapshot_name());
  }
  if (srcReq.has_comment()) {
    dstReq->set_comment(srcReq.comment());
  }
  if (srcReq.has_create_status()) {
    dstReq->set_create_status(
        ucloud::udisk::SNAPSHOT_CREATE_STATUS(srcReq.create_status()));
  }
}

void UpdateSnapshotInfoHandle::EntryInit(
    const uevent::ConnectionUeventPtr &conn, ucloud::UMessage *um) {
  conn_ = conn;
  session_no_ = um->head().session_no();
  MakeResponse(um, ucloud::ubs2::UPDATE_SNAPSHOT_INFO_RESPONSE, &response_);

  ucloud::UMessage dstReqMsg;
  ProtocolTranslate(*um, &dstReqMsg);

  if (!g_context->SendMsgToMeta(
           dstReqMsg, std::bind(&UpdateSnapshotInfoHandle::EntryMetaResponse,
                                This(), std::placeholders::_1),
           std::bind(&UpdateSnapshotInfoHandle::TimeOut, This()),
           g_context->config().metaserver_timeout())) {
    LOG_ERROR << "UpdateSnapshotInfoHandle " << session_no_
              << " forward msg failed";
    SendResponse(-ucloud::ubs2::EC_UBS_NOT_READY, "forward msg failed");
    return;
  }
}

void UpdateSnapshotInfoHandle::EntryMetaResponse(ucloud::UMessage *msg) {
  const ucloud::udisk::UpdateSnapshotInfoResponse &res =
      msg->body().GetExtension(ucloud::udisk::update_snapshot_info_response);
  if (res.rc().retcode()) {
    LOG_ERROR << "UpdateSnapshotInfoHandle " << session_no_
              << " error: " << res.rc().error_message();
    SendResponse(ConstructErrorCodeFromUDiskToUBS2(res.rc().retcode()),
                 res.rc().error_message());
    return;
  }
  SendResponse(0, "");
}

};  // namespace buddy
};  // namespace udisk
