#ifndef UDISK_BUDDY_GET_AVALON_H
#define UDISK_BUDDY_GET_AVALON_H

#include "message_util.h"
#include "pb_request_handle.h"
#include "ubs2_message.h"

namespace uevent {
class UeventLoop;
class ConnectionUevent;
};  // namespace uevent

namespace udisk {
namespace buddy {

class GetAvalonHandle : public uevent::PbRequestHandle {
 public:
  GetAvalonHandle(uevent::UeventLoop *loop) {}
  virtual ~GetAvalonHandle() {}

  MYSELF_CREATE(GetAvalonHandle);

  std::shared_ptr<GetAvalonHandle> This() {
    return std::dynamic_pointer_cast<GetAvalonHandle>(shared_from_this());
  }

  void TimeOut();
  void SendResponse(uint32_t retcode, const std::string &messagee);

  void ProtocolTranslate(const ucloud::UMessage &src, ucloud::UMessage *dst);
  void EntryMetaResponse(ucloud::UMessage *msg);
  virtual void EntryInit(const uevent::ConnectionUeventPtr &conn,
                         ucloud::UMessage *um);

 private:
  uevent::ConnectionUeventPtr conn_;

  ucloud::UMessage response_;
  std::string session_no_;
};

};  // namespace buddy
};  // namespace udisk

#endif
