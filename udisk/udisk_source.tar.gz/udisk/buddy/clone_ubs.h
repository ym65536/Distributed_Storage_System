#ifndef UDISK_BUDDY_CLONE_UBS_H
#define UDISK_BUDDY_CLONE_UBS_H

#include "message_util.h"
#include "pb_request_handle.h"
#include "ubs2_message.h"

namespace uevent {
class UeventLoop;
class ConnectionUevent;
};  // namespace uevent

namespace udisk {
namespace buddy {

class CloneUBSHandle : public uevent::PbRequestHandle {
 public:
  CloneUBSHandle(uevent::UeventLoop *loop) {}
  virtual ~CloneUBSHandle() {}

  MYSELF_CREATE(CloneUBSHandle);

  std::shared_ptr<CloneUBSHandle> This() {
    return std::dynamic_pointer_cast<CloneUBSHandle>(shared_from_this());
  }

  void TimeOut();
  void SendResponse(uint32_t retcode, const std::string &message);

  void ProtocolTranslate(const ucloud::UMessage &src, ucloud::UMessage *dst);
  void EntryMetaResponse(ucloud::UMessage *msg);
  virtual void EntryInit(const uevent::ConnectionUeventPtr &conn,
                         ucloud::UMessage *um);

  void EntryGetSrcInfoLocalRegion(ucloud::UMessage *msg);
  void GetSrcInfoLocalRegion();
  void EntryGetSrcInfoOverRegion(ucloud::UMessage *msg);
  void GetSrcInfoOverRegion();
  void ForwardRequest();

 private:
  uevent::ConnectionUeventPtr conn_;

  ucloud::UMessage request_;
  ucloud::UMessage response_;
  std::string session_no_;
  std::string extern_id_;
};

};  // namespace buddy
};  // namespace udisk

#endif
