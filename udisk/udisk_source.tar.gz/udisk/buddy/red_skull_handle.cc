#include "red_skull_handle.h"

#include <sstream>
#include "buddy_context.h"
#include "eventloop_libevent.h"
#include "get_udisk_info_cross_region.h"
#include "listener_libevent.h"
#include "message_util.h"

using namespace uevent;

namespace udisk {
namespace buddy {

void RedSkullHandle::ConnectionSuccessCb(
    const uevent::ConnectionUeventPtr &conn) {
  LOG_INFO << "connect to " << conn->GetPeerAddress().ToString() << " success";
}

void RedSkullHandle::ConnectionCloseCb(
    const uevent::ConnectionUeventPtr &conn) {
  LOG_INFO << "connect to " << conn->GetPeerAddress().ToString() << " closed";
  listener_->RemoveConnection(conn);
}

void RedSkullHandle::Start() {
  loop_ = thread_.StartLoop();
  loop_->RunInLoop(std::bind(&RedSkullHandle::StartInLoop, this));
}

void RedSkullHandle::StartInLoop() {
  loop_->AssertInLoopThread();
  RegisterProtoHandle();
  ListenerInit();
}

void RedSkullHandle::RegisterProtoHandle() {
  REGISTE_PROTO_HANDLER(loop_, ucloud::udisk::META_GET_UDISK_INFO_REQUEST,
                        GetUDiskInfoCrossRegionHandle);
}

void RedSkullHandle::ListenerInit() {
  uevent::UsockAddress listen_addr(g_context->config().listenip(),
                                   g_context->config().fake_red_skull_port(),
                                   false);
  listener_ = new ListenerLibevent(loop_, listen_addr, "FakeRedSkullListener");
  listener_->SetConnectionSuccessCb(std::bind(
      &RedSkullHandle::ConnectionSuccessCb, this, std::placeholders::_1));
  listener_->SetConnectionClosedCb(std::bind(&RedSkullHandle::ConnectionCloseCb,
                                             this, std::placeholders::_1));
  listener_->SetMessageReadCb(std::bind(
      &uevent::MessageUtil::ProtobufReadCallBack, std::placeholders::_1));
  listener_->Start();
}

void RedSkullHandle::ConnectorConnSuccessCb(
    const uevent::ConnectionUeventPtr &conn) {
  LOG_INFO << "connect to " << conn->GetPeerAddress().ToString() << " success";
}

void RedSkullHandle::ConnectorConnClosedCb(
    const uevent::ConnectionUeventPtr &conn) {
  LOG_INFO << "connect to " << conn->GetPeerAddress().ToString() << " closed";
}

ConnectionUeventPtr RedSkullHandle::GetConnection(const std::string &ip,
                                                  int port) {
  ConnectorKey key = std::make_pair(ip, port);
  auto found = connectors_.find(key);
  if (found != connectors_.end()) {
    if (found->second->HasAvailableConnection() == false) {
      LOG_ERROR << "no available connection to "
                << "ip: " << ip << "port: " << port;
      return ConnectionUeventPtr();
    } else {
      return found->second->GetConnection();
    }
  }

  std::stringstream ss;
  uevent::UsockAddress addr(ip, port, false);
  ss << "connector-" << ip << ":" << port;
  ConnectorLibevent *connector =
      new uevent::ConnectorLibevent(loop_, addr, ss.str());
  connector->SetConnectionSuccessCb(std::bind(
      &RedSkullHandle::ConnectorConnSuccessCb, this, std::placeholders::_1));
  connector->SetConnectionClosedCb(std::bind(
      &RedSkullHandle::ConnectorConnClosedCb, this, std::placeholders::_1));
  connector->SetMessageReadCb(
      std::bind(&MessageUtil::ProtobufReadCallBack, std::placeholders::_1));
  connector->Connect();
  connectors_.insert(std::make_pair(key, connector));
  if (connector->HasAvailableConnection() == false) {
    LOG_ERROR << "no available connection to "
              << "ip: " << ip << "port: " << port;
    return ConnectionUeventPtr();
  } else {
    return connector->GetConnection();
  }
}

};  // namespace buddy
};  // namespace udisk
