#ifndef UDISK_BUDDY_LIST_SNAPSHOT_TOTAL_COUNT_H
#define UDISK_BUDDY_LIST_SNAPSHOT_TOTAL_COUNT_H

#include "message_util.h"
#include "pb_request_handle.h"
#include "ubs2_message.h"

namespace uevent {
class UeventLoop;
class ConnectionUevent;
};  // namespace uevent

namespace udisk {
namespace buddy {

class ListSnapshotTotalCountHandle : public uevent::PbRequestHandle {
 public:
  ListSnapshotTotalCountHandle(uevent::UeventLoop *loop) {}
  virtual ~ListSnapshotTotalCountHandle() {}

  MYSELF_CREATE(ListSnapshotTotalCountHandle);

  std::shared_ptr<ListSnapshotTotalCountHandle> This() {
    return std::dynamic_pointer_cast<ListSnapshotTotalCountHandle>(
        shared_from_this());
  }

  void TimeOut();
  void SendResponse(uint32_t retcode, const std::string &message);

  void ProtocolTranslate(const ucloud::UMessage &src, ucloud::UMessage *dst);
  void EntryMetaResponse(ucloud::UMessage *msg);
  virtual void EntryInit(const uevent::ConnectionUeventPtr &conn,
                         ucloud::UMessage *um);

 private:
  uevent::ConnectionUeventPtr conn_;

  ucloud::UMessage response_;
  std::string session_no_;
};

};  // namespace buddy
};  // namespace udisk

#endif
