#include "list_ubs_total_count_handle.h"
#include "logging.h"
#include "umessage_common.h"
#include "udisk_message.h"
#include "protocol_conversion.h"
#include "buddy_context.h"
#include "message_util.h"

#include <time.h>
#include <sstream>

namespace udisk {
namespace buddy {

void ListUBSTotalCountHandle::TimeOut() {
  LOG_ERROR << "ListUBSTotalCountHandle " << session_no_ << "time out";
  SendResponse(-ucloud::ubs2::EC_UBS_TIMEOUT, "ListUBSTotalCountHandle time out");
}

void ListUBSTotalCountHandle::SendResponse(uint32_t retcode, const char* message) {
  ucloud::ubs2::ListUBSTotalCountResponse* res = 
    response_.mutable_body()->MutableExtension(ucloud::ubs2::list_ubs_total_count_response);
  res->mutable_rc()->set_retcode(retcode);
  if (retcode) {
    res->mutable_rc()->set_error_message(message);
  }
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void ListUBSTotalCountHandle::ProtocolTranslate(const ucloud::UMessage &src, ucloud::UMessage *dst) {
  uint32_t objid = uevent::MessageUtil::ObjId();
  NewMessage_v2(dst, src.head().flow_no(), session_no_,
                ucloud::udisk::LIST_UDISK_REQUEST, src.head().worker_index(),
                src.head().tint_flag(), objid, 0,
                src.head().call_purpose().c_str(),
                src.head().access_token().c_str(), NULL);

  const ucloud::ubs2::ListUBSTotalCountRequest &srcReq =
    src.body().GetExtension(ucloud::ubs2::list_ubs_total_count_request);
  ucloud::udisk::ListUDiskRequest *dstReq =
    dst->mutable_body()->MutableExtension(ucloud::udisk::list_udisk_request);

  dstReq->set_oid(srcReq.account_id());

  if (srcReq.has_state()) {
    dstReq->set_status((ucloud::udisk::UDISK_STATUS)StatusUBS2ToUDisk(srcReq.state()));
  }
}

void ListUBSTotalCountHandle::EntryInit(const uevent::ConnectionUeventPtr &conn, ucloud::UMessage* um) {
  conn_ = conn;
  session_no_ = um->head().session_no();
  MakeResponse(um, ucloud::ubs2::LIST_UBS_TOTAL_COUNT_RESPONSE, &response_);

  ucloud::UMessage dstReqMsg;
  ProtocolTranslate(*um, &dstReqMsg);

  if (!g_context->SendMsgToMeta(dstReqMsg,
      std::bind(&ListUBSTotalCountHandle::EntryMetaResponse, This(), std::placeholders::_1),
      std::bind(&ListUBSTotalCountHandle::TimeOut, This()),
      g_context->config().metaserver_timeout())) {
    const char *msg = "forward msg failed";
    LOG_ERROR << "ListUBSHanlde " << session_no_ << " failed: " << msg;
    SendResponse(-ucloud::ubs2::EC_UBS_NOT_READY, msg);
    return;
  }
}

void ListUBSTotalCountHandle::EntryMetaResponse(ucloud::UMessage *msg) {
  const ucloud::udisk::ListUDiskResponse &res =
    msg->body().GetExtension(ucloud::udisk::list_udisk_response);
  ucloud::ubs2::ListUBSTotalCountResponse *dstRes =
    response_.mutable_body()->MutableExtension(ucloud::ubs2::list_ubs_total_count_response);
  if (res.rc().retcode() < 0) {
    LOG_ERROR << "ListUBSTotalCountHandle " << session_no_ << " error: "
              << res.rc().error_message();
    dstRes->set_total_count(0);
    SendResponse(ConstructErrorCodeFromUDiskToUBS2(res.rc().retcode()),
        res.rc().error_message().c_str());
    return;
  }

  dstRes->set_total_count(res.lcs_size());

  SendResponse(0, "");
}

}; // end of ns buddy
}; // end of ns udisk
