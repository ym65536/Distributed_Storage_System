#include "buddy_loop_handle.h"
#include "buddy_context.h"

namespace udisk {
namespace buddy {

BuddyLoopHandle::BuddyLoopHandle(uevent::UeventLoop *loop) : loop_(loop) {
}

BuddyLoopHandle::~BuddyLoopHandle() {
}

void BuddyLoopHandle::ConnectionSuccessHandle(const uevent::ConnectionUeventPtr &conn) {
}

void BuddyLoopHandle::ConnectionClosedHandle(const uevent::ConnectionUeventPtr &conn) {
  if (g_context->listener()) {
    g_context->listener()->RemoveConnection(conn);
  }
}

}; // end of ns buddy
}; // end of ns udisk
