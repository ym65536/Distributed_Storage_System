#ifndef UDISK_BUDDY_GET_LOGIN_GATE_HANDLE_H
#define UDISK_BUDDY_GET_LOGIN_GATE_HANDLE_H

#include <string>
#include "message_util.h"
#include "pb_request_handle.h"
#include "udisk_message.h"

namespace uevent {
class UeventLoop;
class ConnectionUevent;
};  // namespace uevent

namespace udisk {
namespace buddy {

class GetLoginGateHandle : public uevent::PbRequestHandle {
 public:
  GetLoginGateHandle(uevent::UeventLoop* loop) {}
  virtual ~GetLoginGateHandle() {}

  MYSELF_CREATE(GetLoginGateHandle);

  std::shared_ptr<GetLoginGateHandle> This() {
    return std::dynamic_pointer_cast<GetLoginGateHandle>(shared_from_this());
  }

  void Timeout();
  void SendResponse(uint32_t retcode, const char* message);

  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         ucloud::UMessage* um);
  void EntryMetaResponse(ucloud::UMessage* msg);

 private:
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage response_;
  std::string session_no_;
};

};  // namespace buddy
};  // namespace udisk

#endif
