#include "resize_ubs_handle.h"
#include "logging.h"
#include "udisk_message.h"
#include "umessage_common.h"
#include "protocol_conversion.h"
#include "buddy_context.h"
#include "message_util.h"

#include <time.h>
#include <sstream>

namespace udisk {
namespace buddy {

void ResizeUBSHandle::TimeOut() {
  LOG_ERROR << "ResizeUBSHandle " << session_no_ << "time out";
  SendResponse(-ucloud::ubs2::EC_UBS_TIMEOUT, "ResizeUBSHandle time out");
}

void ResizeUBSHandle::SendResponse(uint32_t retcode, const char* message) {
  ucloud::ubs2::ResizeUBSResponse* res = 
    response_.mutable_body()->MutableExtension(ucloud::ubs2::resize_ubs_response);
  res->mutable_rc()->set_retcode(retcode);
  if (retcode) {
    res->mutable_rc()->set_error_message(message);
  }
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void ResizeUBSHandle::ProtocolTranslate(const ucloud::UMessage &src, ucloud::UMessage *dst) {
  uint32_t objid = uevent::MessageUtil::ObjId();
  NewMessage_v2(dst, src.head().flow_no(), session_no_,
                ucloud::udisk::RESIZE_UDISK_REQUEST, src.head().worker_index(),
                src.head().tint_flag(), objid, 0,
                src.head().call_purpose().c_str(),
                src.head().access_token().c_str(), NULL);
  const ucloud::ubs2::ResizeUBSRequest &srcReq =
    src.body().GetExtension(ucloud::ubs2::resize_ubs_request);
  ucloud::udisk::ResizeUDiskRequest *dstReq =
    dst->mutable_body()->MutableExtension(ucloud::udisk::resize_udisk_request);
  dstReq->set_extern_id(srcReq.ubs_id());
  dstReq->set_new_size(srcReq.new_size());
}

void ResizeUBSHandle::EntryInit(const uevent::ConnectionUeventPtr &conn, ucloud::UMessage* um) {
  conn_ = conn;
  session_no_ = um->head().session_no();
  MakeResponse(um, ucloud::ubs2::RESIZE_UBS_RESPONSE, &response_);

  ucloud::UMessage dstReqMsg;
  ProtocolTranslate(*um, &dstReqMsg);

  if (!g_context->SendMsgToMeta(dstReqMsg,
      std::bind(&ResizeUBSHandle::EntryMetaResponse, This(), std::placeholders::_1),
      std::bind(&ResizeUBSHandle::TimeOut, This()),
      g_context->config().metaserver_timeout())) {
    const char *msg = "forward msg failed";
    LOG_ERROR << "ResizeUBSHandle " << session_no_ << " failed: " << msg;
    SendResponse(-ucloud::ubs2::EC_UBS_NOT_READY, msg);
    return;
  }
}

void ResizeUBSHandle::EntryMetaResponse(ucloud::UMessage *msg) {
  const ucloud::udisk::ResizeUDiskResponse &res =
    msg->body().GetExtension(ucloud::udisk::resize_udisk_response);
  if (res.rc().retcode()) {
    LOG_ERROR << "ResizeUBSHandle " << session_no_ << " error: "
              << res.rc().error_message();
    SendResponse(ConstructErrorCodeFromUDiskToUBS2(res.rc().retcode()),
        res.rc().error_message().c_str());
    return;
  }
  SendResponse(0, "");
}

}; // end of ns buddy
}; // end of ns udisk
