#include "list_snapshot_total_count.h"
#include "buddy_context.h"
#include "logging.h"
#include "message_util.h"
#include "protocol_conversion.h"
#include "umessage_common.h"

namespace udisk {
namespace buddy {

void ListSnapshotTotalCountHandle::TimeOut() {
  LOG_ERROR << "ListSnapshotTotalCountHandle " << session_no_ << "time out";
  SendResponse(-ucloud::ubs2::EC_UBS_TIMEOUT,
               "ListSnapshotTotalCountHandle time out");
}

void ListSnapshotTotalCountHandle::SendResponse(uint32_t retcode,
                                                const std::string &message) {
  ucloud::ubs2::ListSnapshotTotalCountResponse *res =
      response_.mutable_body()->MutableExtension(
          ucloud::ubs2::list_snapshot_total_count_response);
  res->mutable_rc()->set_retcode(retcode);
  if (retcode) {
    res->mutable_rc()->set_error_message(message);
  }
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void ListSnapshotTotalCountHandle::ProtocolTranslate(
    const ucloud::UMessage &src, ucloud::UMessage *dst) {
  uint32_t objid = uevent::MessageUtil::ObjId();
  NewMessage_v2(dst, src.head().flow_no(), session_no_,
                ucloud::udisk::LIST_SNAPSHOT_REQUEST, src.head().worker_index(),
                src.head().tint_flag(), objid, 0,
                src.head().call_purpose().c_str(),
                src.head().access_token().c_str(), NULL);

  const ucloud::ubs2::ListSnapshotTotalCountRequest &srcReq =
      src.body().GetExtension(ucloud::ubs2::list_snapshot_total_count_request);
  ucloud::udisk::ListSnapshotRequest *dstReq =
      dst->mutable_body()->MutableExtension(
          ucloud::udisk::list_snapshot_request);
  dstReq->set_oid(srcReq.account_id());
  if (srcReq.has_ubs_id()) {
    dstReq->set_extern_id(srcReq.ubs_id());
  }
}

void ListSnapshotTotalCountHandle::EntryInit(
    const uevent::ConnectionUeventPtr &conn, ucloud::UMessage *um) {
  conn_ = conn;
  session_no_ = um->head().session_no();
  MakeResponse(um, ucloud::ubs2::LIST_SNAPSHOT_TOTAL_COUNT_RESPONSE,
               &response_);

  ucloud::UMessage dstReqMsg;
  ProtocolTranslate(*um, &dstReqMsg);

  if (!g_context->SendMsgToMeta(
           dstReqMsg,
           std::bind(&ListSnapshotTotalCountHandle::EntryMetaResponse, This(),
                     std::placeholders::_1),
           std::bind(&ListSnapshotTotalCountHandle::TimeOut, This()),
           g_context->config().metaserver_timeout())) {
    LOG_ERROR << "ListSnapshotTotalCountHandle " << session_no_
              << " forward msg failed";
    SendResponse(-ucloud::ubs2::EC_UBS_NOT_READY, "forward msg failed");
    return;
  }
}

void ListSnapshotTotalCountHandle::EntryMetaResponse(ucloud::UMessage *msg) {
  const ucloud::udisk::ListSnapshotResponse &res =
      msg->body().GetExtension(ucloud::udisk::list_snapshot_response);
  if (res.rc().retcode()) {
    LOG_ERROR << "ListSnapshotTotalCountHandle " << session_no_
              << " error: " << res.rc().error_message();
    SendResponse(ConstructErrorCodeFromUDiskToUBS2(res.rc().retcode()),
                 res.rc().error_message());
    return;
  }
  ucloud::ubs2::ListSnapshotTotalCountResponse *dstRes =
      response_.mutable_body()->MutableExtension(
          ucloud::ubs2::list_snapshot_total_count_response);
  dstRes->set_total_count(res.snapshots_size());
  SendResponse(0, "");
}

};  // namespace buddy
};  // namespace udisk
