#ifndef UDISK_BUDDY_CONTEXT_H_
#define UDISK_BUDDY_CONTEXT_H_

#include "hydra_handle.h"
#include "red_skull_handle.h"
#include "uevent.h"
#include "zk_name_container.h"

#include <cassert>
#include <memory>
#include <string>

namespace udisk {
namespace buddy {

class BuddyConfig {
 public:
  const std::string &config_file() const { return config_file_; }

  std::tuple<int, std::string> Init();

  std::string ToString() const;

  const std::string &my_id() const {
    assert(loaded_);
    return my_id_;
  }

  const std::string &my_name() const {
    assert(loaded_);
    return my_name_;
  }

  const std::string &my_set() const {
    assert(loaded_);
    return my_set_;
  }

  const std::string &fake_hydra() const {
    assert(loaded_);
    return fake_hydra_;
  }

  const std::string &fake_red_skull() const {
    assert(loaded_);
    return fake_red_skull_;
  }

  const std::string &listenip() const {
    assert(loaded_);
    return listenip_;
  }

  int listenport() const {
    assert(loaded_);
    return listenport_;
  }

  int fake_hydra_port() const {
    assert(loaded_);
    return fake_hydra_port_;
  }

  int fake_red_skull_port() const {
    assert(loaded_);
    return fake_red_skull_port_;
  }

  const std::string &zk_server() const {
    assert(loaded_);
    return zk_server_;
  }

  int zk_timeout() const {
    assert(loaded_);
    return zk_timeout_;
  }

  const std::string zk_log() const {
    assert(loaded_);
    return zk_log_;
  }

  const std::string &metaserver_path() const {
    assert(loaded_);
    return metaserver_path_;
  }

  const std::string &logpath() const {
    assert(loaded_);
    return log_path_;
  }
  const std::string &loglevel() const {
    assert(loaded_);
    return log_level_;
  }

  int metaserver_timeout() const {
    assert(loaded_);
    return metaserver_timeout_;
  }

  const std::multimap<std::string, int> &red_skulls() const {
    assert(loaded_);
    return red_skulls_;
  }

  const std::string &hydra_path() const {
    assert(loaded_);
    return hydra_path_;
  }

 private:
  BuddyConfig(const std::string &file) : config_file_(file), loaded_(false) {}
  BuddyConfig(const BuddyConfig &) = delete;
  BuddyConfig &operator=(const BuddyConfig &) = delete;

  std::tuple<int, std::string> load();

  friend class BuddyContext;

  std::string config_file_;
  bool loaded_;

  std::string my_id_;
  std::string my_set_;
  std::string my_name_;
  std::string fake_hydra_;
  std::string fake_red_skull_;

  std::string log_path_;
  std::string log_level_;
  std::string listenip_;
  int listenport_;
  int fake_hydra_port_;
  int fake_red_skull_port_;

  std::string zk_server_;
  int zk_timeout_;  // zk 客户端session超时时间
  std::string zk_log_;

  std::string metaserver_path_;

  int metaserver_timeout_;  // 访问metaserver超时时间
  std::multimap<std::string, int> red_skulls_;
  std::string hydra_path_;
};

class BuddyContext {
 public:
  explicit BuddyContext(const std::string &conf_file);
  BuddyContext(const BuddyContext &) = delete;
  BuddyContext &operator=(const BuddyContext &) = delete;

  std::tuple<int, std::string> Init();

  const BuddyConfig &config() const { return config_; }

  void set_local_nc(common::NameContainer *nc) { local_nc_ = nc; }

  common::NameContainer *local_nc() { return local_nc_; }

  void set_loop(uevent::UeventLoop *lp) { loop_ = lp; }

  void set_listener(uevent::ListenerUevent *lu) { listener_ = lu; }

  uevent::UeventLoop *loop() { return loop_; }

  uevent::ListenerUevent *listener() { return listener_; }

  bool is_leader() { return leader_; }

  void set_leader(bool arg) { leader_ = arg; }

  void set_hydra_handle(HydraHandle *hydra_handle) {
    hydra_handle_ = hydra_handle;
  }

  HydraHandle *hydra_handle() { return hydra_handle_; }

  void set_red_skull_handle(RedSkullHandle *red_skull_handle) {
    red_skull_handle_ = red_skull_handle;
  }

  RedSkullHandle *red_skull_handle() { return red_skull_handle_; }

  bool SendMsgToMeta(ucloud::UMessage &msg,
                     std::function<void(ucloud::UMessage *)> res,
                     std::function<void()> timeout_fun, int timeout);

  uevent::ConnectionUeventPtr GetMetaConnection();

  bool GetMetaAddress(std::string *ip, int *port);

  bool SendMsgToHydra(ucloud::UMessage &msg,
                      std::function<void(ucloud::UMessage *)> res,
                      std::function<void()> timeout_fun, int timeout);

  uevent::ConnectionUeventPtr GetHydraConnection();

  bool GetHydraAddress(std::string *ip, int *port);

  bool GetRedSkullAddress(std::string *ip, int *port);

  uevent::ConnectionUeventPtr GetConnection(const std::string &ip, int port);

  bool SendMsg(const std::string &ip, int port, ucloud::UMessage &msg,
               std::function<void(ucloud::UMessage *)> res,
               std::function<void()> timeout_fun, int timeout);

  typedef std::pair<std::string, int> OutConnectorKey;
  typedef std::map<OutConnectorKey, uevent::ConnectorUevent *> OutConnectorMap;

  void OutConnectorConnClosedCb(const uevent::ConnectionUeventPtr &conn,
                                OutConnectorKey key);

 private:
  BuddyConfig config_;

  common::NameContainer *local_nc_;

  uevent::UeventLoop *loop_;
  uevent::ListenerUevent *listener_;

  OutConnectorMap out_connectors_;

  bool leader_;

  HydraHandle *hydra_handle_;
  RedSkullHandle *red_skull_handle_;
};

};  // namespace buddy
};  // namespace udisk

extern udisk::buddy::BuddyContext *g_context;

#endif
