#include "list_ubs_handle.h"
#include "logging.h"
#include "umessage_common.h"
#include "udisk_message.h"
#include "protocol_conversion.h"
#include "buddy_context.h"
#include "message_util.h"

#include <time.h>
#include <sstream>

namespace udisk {
namespace buddy {

void ListUBSHandle::TimeOut() {
  LOG_ERROR << "ListUBSHandle " << session_no_ << "time out";
  SendResponse(-ucloud::ubs2::EC_UBS_TIMEOUT, "ListUBSHandle time out");
}

void ListUBSHandle::SendResponse(uint32_t retcode, const char* message) {
  ucloud::ubs2::ListUBSResponse* res = 
    response_.mutable_body()->MutableExtension(ucloud::ubs2::list_ubs_response);
  res->mutable_rc()->set_retcode(retcode);
  if (retcode) {
    res->mutable_rc()->set_error_message(message);
  }
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void ListUBSHandle::ProtocolTranslate(const ucloud::UMessage &src, ucloud::UMessage *dst) {
  uint32_t objid = uevent::MessageUtil::ObjId();
  NewMessage_v2(dst, src.head().flow_no(), session_no_,
                ucloud::udisk::LIST_UDISK_REQUEST, src.head().worker_index(),
                src.head().tint_flag(), objid, 0,
                src.head().call_purpose().c_str(),
                src.head().access_token().c_str(), NULL);

  const ucloud::ubs2::ListUBSRequest &srcReq =
    src.body().GetExtension(ucloud::ubs2::list_ubs_request);
  ucloud::udisk::ListUDiskRequest *dstReq =
    dst->mutable_body()->MutableExtension(ucloud::udisk::list_udisk_request);
  if (srcReq.has_company_id()) {
    dstReq->set_top_oid(srcReq.company_id());
  }

  if (srcReq.has_account_id()) {
    dstReq->set_oid(srcReq.account_id());
  }

  if (srcReq.has_offset()) {
    dstReq->set_offset(srcReq.offset());
  }

  if (srcReq.has_max_count()) {
    dstReq->set_limit(srcReq.max_count());
  }

  if (srcReq.has_ubs_id()) {
    dstReq->add_extern_ids(srcReq.ubs_id());
  }

  for (int i = 0; i < srcReq.ubs_ids_size(); i++) {
    dstReq->add_extern_ids(srcReq.ubs_ids(i));
  }

  dstReq->set_status(ucloud::udisk::UDISK_STATUS_NORMAL);

  if (srcReq.has_disk_type()) {
    int disk_type = TypeUBS2ToUDisk(srcReq.disk_type());
    if (disk_type != -1) {
      dstReq->set_disk_type(ucloud::udisk::DISK_TYPE(disk_type));
    }
  }
}

void ListUBSHandle::EntryInit(const uevent::ConnectionUeventPtr& conn, ucloud::UMessage* um) {
  conn_ = conn;
  session_no_ = um->head().session_no();
  MakeResponse(um, ucloud::ubs2::LIST_UBS_RESPONSE, &response_);

  ucloud::UMessage dstReqMsg;
  ProtocolTranslate(*um, &dstReqMsg);

  if (!g_context->SendMsgToMeta(dstReqMsg,
      std::bind(&ListUBSHandle::EntryMetaResponse, This(), std::placeholders::_1),
      std::bind(&ListUBSHandle::TimeOut, This()),
      g_context->config().metaserver_timeout())) {
    const char *msg = "forward msg failed";
    LOG_ERROR << "ListUBSHanlde " << session_no_ << " failed: " << msg;
    SendResponse(-ucloud::ubs2::EC_UBS_NOT_READY, msg);
    return;
  }
}

void ListUBSHandle::EntryMetaResponse(ucloud::UMessage *msg) {
  const ucloud::udisk::ListUDiskResponse &res =
    msg->body().GetExtension(ucloud::udisk::list_udisk_response);
  if (res.rc().retcode()) {
    LOG_ERROR << "ListUBSHandle " << session_no_ << " error: "
              << res.rc().error_message();
    SendResponse(ConstructErrorCodeFromUDiskToUBS2(res.rc().retcode()),
        res.rc().error_message().c_str());
    return;
  }
  ucloud::ubs2::ListUBSResponse *dstRes =
    response_.mutable_body()->MutableExtension(ucloud::ubs2::list_ubs_response);

  for (int i = 0; i < res.lcs_size(); ++i) {
    if (res.lcs(i).status() != ucloud::udisk::UDISK_STATUS_NORMAL) {
      continue;
    }
    ucloud::ubs2::LogicalChunk *dstLC = dstRes->add_lc_infos();
    ConstructLogicalChunkFromUDiskToUBS2(dstLC, res.lcs(i));
  }
  SendResponse(0, "");
}

}; // end of ns buddy
}; // end of ns udisk
