#include "get_attach_param.h"

#include "logging.h"
#include "umessage_common.h"
#include "buddy_context.h"
#include "ubs2_message.h"
#include "message_util.h"

namespace udisk {
namespace buddy {

void GetAttachParamHandle::TimeOut() {
  LOG_ERROR << "GetAttachParamHandle time out";
  SendResponse(-2, "GetAttachParamHandle time out");
}

void GetAttachParamHandle::SendResponse(uint32_t retcode, const char* message) {
  ucloud::udisk::GetAttachParamResponse* res = 
    response_.mutable_body()->MutableExtension(ucloud::udisk::get_attach_param_response);
  res->mutable_rc()->set_retcode(retcode);
  res->mutable_rc()->set_error_message(message);
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void GetAttachParamHandle::EntryInit(const uevent::ConnectionUeventPtr &conn, ucloud::UMessage* um) {
  conn_ = conn;
  session_no_ = um->head().session_no();
  MakeResponse(um, ucloud::udisk::GET_ATTACH_PARAM_RESPONSE, &response_);

  ucloud::UMessage dstReqMsg;

  uint32_t objid = uevent::MessageUtil::ObjId();
  NewMessage_v2(&dstReqMsg, um->head().flow_no(), session_no_,
                ucloud::udisk::GET_ATTACH_PARAM_REQUEST,
                um->head().worker_index(),
                um->head().tint_flag(), objid, 0,
                um->head().call_purpose().c_str(),
                um->head().access_token().c_str(), NULL);
 
  dstReqMsg.mutable_body()->MutableExtension(ucloud::udisk::get_attach_param_request)->CopyFrom(
      um->body().GetExtension(ucloud::udisk::get_attach_param_request));

  if (!g_context->SendMsgToMeta(dstReqMsg,
      std::bind(&GetAttachParamHandle::EntryMetaResponse, This(), std::placeholders::_1),
      std::bind(&GetAttachParamHandle::TimeOut, This()),
      g_context->config().metaserver_timeout())) {
    const char *msg = "forward msg failed";
    LOG_ERROR << "GetAttachParamHandle " << session_no_ << " failed: " << msg;
    SendResponse(-ucloud::ubs2::EC_UBS_NOT_READY, msg);
    return;
  }
}

void GetAttachParamHandle::EntryMetaResponse(ucloud::UMessage *msg) {
  const ucloud::udisk::GetAttachParamResponse &res = 
    msg->body().GetExtension(ucloud::udisk::get_attach_param_response);
  ucloud::udisk::GetAttachParamResponse *dstRes =
    response_.mutable_body()->MutableExtension(ucloud::udisk::get_attach_param_response);
  *dstRes = res;
  SendResponse(res.rc().retcode(), res.rc().error_message().c_str());
}

}; // end of ns buddy
}; // end of ns udisk
