#ifndef UDISK_BUDDY_RED_SKULL_HANDLE_
#define UDISK_BUDDY_RED_SKULL_HANDLE_

#include "connector_libevent.h"
#include "uevent.h"
#include "ueventloop_thread.h"

namespace udisk {
namespace buddy {

class RedSkullHandle {
 public:
  RedSkullHandle() {}
  void ConnectionSuccessCb(const uevent::ConnectionUeventPtr &conn);
  void ConnectionCloseCb(const uevent::ConnectionUeventPtr &conn);

  uevent::ConnectionUeventPtr GetConnection(const std::string &ip, int port);

  inline uevent::UeventLoop *loop() { return loop_; }

  void Start();
  void StartInLoop();
  void ListenerInit();
  void RegisterProtoHandle();

 private:
  typedef std::pair<std::string, int> ConnectorKey;
  void ConnectorConnSuccessCb(const uevent::ConnectionUeventPtr &conn);
  void ConnectorConnClosedCb(const uevent::ConnectionUeventPtr &conn);
  struct ConnectorKeyHash {
    std::size_t operator()(ConnectorKey const &item) const {
      std::size_t h1 = std::hash<std::string>()(item.first);
      std::size_t h2 = std::hash<int>()(item.second);
      return h1 ^ (h2 << 1);
    }
  };
  std::unordered_map<ConnectorKey, uevent::ConnectorUevent *, ConnectorKeyHash>
      connectors_;

  uevent::UeventLoopThread thread_;
  uevent::ListenerUevent *listener_;
  uevent::UeventLoop *loop_;
};

};  // namespace buddy
};  // namespace udisk

#endif
