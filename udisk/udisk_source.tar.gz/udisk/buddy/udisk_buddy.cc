#include "add_host_blacklist.h"
#include "alloca_ubs_handle.h"
#include "async_logging.h"
#include "buddy_context.h"
#include "buddy_loop_handle.h"
#include "check_allowance_handle.h"
#include "clone_ubs.h"
#include "delete_snapshot.h"
#include "delete_ubs_handle.h"
#include "destroy_ubs_handle.h"
#include "eventloop_libevent.h"
#include "finish_migrate_udisk_task.h"
#include "get_attach_param.h"
#include "get_avalon.h"
#include "get_blkiotune.h"
#include "get_freyr.h"
#include "get_login_gate.h"
#include "get_snapshot_info.h"
#include "get_ubs_detail_info_handle.h"
#include "hydra_handle.h"
#include "list_snapshot.h"
#include "list_snapshot_total_count.h"
#include "list_thrown_ubs_handle.h"
#include "list_ubs_by_host_handle.h"
#include "list_ubs_handle.h"
#include "list_ubs_total_count_handle.h"
#include "list_udisk_handle.h"
#include "listener_libevent.h"
#include "message_util.h"
#include "protocol_conversion.h"
#include "red_skull_handle.h"
#include "remove_host_blacklist.h"
#include "resize_ubs_handle.h"
#include "restore_ubs.h"
#include "snapshot.h"
#include "take_back_ubs.h"
#include "ubs2_message.h"
#include "udisk_login_handle.h"
#include "udisk_message.h"
#include "uns_message.h"
#include "update_snapshot_info.h"
#include "update_ubs_info_handle.h"
#include "update_ubs_mount_info_handle.h"
#include "update_ubs_name_handle.h"
#include "update_udataark_mode.h"
#include "get_set_capacity.h"
#include "get_user_lc_statistic_info.h"

#include <getopt.h>
#include <signal.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <iostream>
#include <sstream>

using namespace udisk;
using namespace buddy;

#define str(a) (#a)
#define xstr(a) (str(a))

#ifdef VERSION_TAG
//用于标识版本号，可以用nm -C 查看
const char *version_tag = xstr(VERSION_TAG);  //两次转换将宏的值转成字符串
#else
const char *version_tag = "unknown";
#endif

static struct option long_options[] = {
    {"help", 0, nullptr, 'h'},
    {"version", 0, nullptr, 'v'},
    {"conf", 1, nullptr, 'c'},
    {"foregroud", 0, nullptr, 'f'},
};

static void print_help(const char *name) {
  std::cout << name << " Usage: \n"
            << "-h | --help, print this\n"
            << "-c | --conf config file, conf file\n"
            << "-v | --version, get the version\n"
            << "-f | --foregroud, run this on front end\n";
}

static const char *short_options = "hvfc:";

static void print_version(const char *name) {
  printf("version tag: %s\n", version_tag);
}

static void context_init(const std::string &conf_file) {
  BuddyContext *context = new BuddyContext(conf_file);
  std::tuple<int, std::string> result = context->Init();
  if (std::get<0>(result)) {
    std::cerr << "Init Failed," << std::get<1>(result) << std::endl;
    std::exit(-1);
  }
  //初始化成功
  g_context = context;
}

static void init_daemon() {
  pid_t pid;

  pid = fork();
  if (pid < 0) exit(EXIT_FAILURE);
  if (pid > 0) exit(EXIT_SUCCESS);
  if (setsid() < 0) exit(EXIT_FAILURE);

  signal(SIGCHLD, SIG_IGN);
  signal(SIGHUP, SIG_IGN);

  pid = fork();
  if (pid < 0) exit(EXIT_FAILURE);
  if (pid > 0) exit(EXIT_SUCCESS);

  umask(0);
  chdir("/");

  close(STDOUT_FILENO);
  close(STDIN_FILENO);
}

static base::AsyncLogging *logger = nullptr;
static void logger_putfn(const char *msg, int len) {
  if (logger) {
    logger->append(msg, len);
  }
}

static common::WatchLeaderCallback watch_cb = [](bool is_leader,
                                                 const void *ctx) {
  LOG_INFO << "watch callback, this is leader: " << is_leader;
  g_context->set_leader(is_leader);
};

static std::string construct_zk_data() {
  std::string nncstr;
  ucloud::uns::NameNodeContent nnc;
  nnc.set_ip(g_context->config().listenip());
  nnc.set_port(g_context->config().listenport());
  nnc.SerializeToString(&nncstr);
  return nncstr;
}

static std::string construct_hydra_data() {
  std::string nncstr;
  ucloud::uns::NameNodeContent nnc;
  nnc.set_ip(g_context->config().listenip());
  nnc.set_port(g_context->config().fake_hydra_port());
  nnc.SerializeToString(&nncstr);
  return nncstr;
}

static std::string construct_red_skull_data() {
  std::string nncstr;
  ucloud::uns::NameNodeContent nnc;
  nnc.set_ip(g_context->config().listenip());
  nnc.set_port(g_context->config().fake_red_skull_port());
  nnc.SerializeToString(&nncstr);
  return nncstr;
}

void register_or_watch_leader() {
  std::string nncstr = construct_zk_data();
  int rc = g_context->local_nc()->RegisterLeader(g_context->config().my_name(),
                                                 nncstr, &watch_cb, nullptr);
  if (rc == ZOK) {
    g_context->set_leader(true);
  } else if (rc == ZNODEEXISTS) {
    g_context->set_leader(false);
  } else {
    LOG_SYSFATAL << "rc: " << rc << "register leader error";
  }
}

static void register_myself() {
  std::string nncstr = construct_zk_data();
  int rc = g_context->local_nc()->RegisterInstance(
      g_context->config().my_name(), g_context->config().my_id(), nncstr);
  if (rc != ZOK) {
    LOG_SYSFATAL << "register my name error: " << rc;
  }

  nncstr = construct_hydra_data();
  rc = g_context->local_nc()->RegisterInstance(
      g_context->config().fake_hydra(), g_context->config().my_id(), nncstr);
  if (rc != ZOK) {
    LOG_SYSFATAL << "register my name error: " << rc;
  }

  nncstr = construct_red_skull_data();
  rc = g_context->local_nc()->RegisterInstance(
      g_context->config().fake_red_skull(), g_context->config().my_id(),
      nncstr);
  if (rc != ZOK) {
    LOG_SYSFATAL << "register my name error: " << rc;
  }
}

static void session_expire_cb() {
  if (g_context->local_nc() != nullptr) {
    register_myself();
    register_or_watch_leader();
  }
}

static void init_zkclient() {
  common::NameContainer *local_nc = new common::NameContainer(
      g_context->config().zk_server(), session_expire_cb,
      g_context->config().zk_timeout(), g_context->config().zk_log());
  if (local_nc->Init() == -1) {
    LOG_SYSFATAL << "can't connect to zookeeper";
  }
  common::ZkNameOfSetPtr local_set_ptr(
      new common::ZkNameOfSet(g_context->config().my_set()));
  LOG_INFO << g_context->config().metaserver_path();
  LOG_INFO << g_context->config().hydra_path();
  local_set_ptr->AddNamePath("metaserver",
                             g_context->config().metaserver_path());
  local_set_ptr->AddNamePath("hydra", g_context->config().hydra_path());
  local_nc->AddZkNameOfSet(local_set_ptr);

  g_context->set_local_nc(local_nc);
  LOG_INFO << "zkclient init finished";
}

static void init_logging(bool foreground) {
  if (g_context->config().loglevel() == "Info") {
    base::Logger::setLogLevel(base::Logger::INFO);
  } else if (g_context->config().loglevel() == "Debug") {
    base::Logger::setLogLevel(base::Logger::DEBUG);
  } else if (g_context->config().loglevel() == "Error") {
    base::Logger::setLogLevel(base::Logger::ERROR);
  } else if (g_context->config().loglevel() == "Trace") {
    base::Logger::setLogLevel(base::Logger::TRACE);
  } else if (g_context->config().loglevel() == "Warn") {
    base::Logger::setLogLevel(base::Logger::WARN);
  } else {
    base::Logger::setLogLevel(base::Logger::INFO);
  }
  if (!foreground) {
    logger = new base::AsyncLogging(g_context->config().logpath(), 50 << 20);
    logger->start();
    base::Logger::setOutput(logger_putfn);
  }
}

static void service_register(uevent::UeventLoop *loop) {
  REGISTE_PROTO_HANDLER(loop, ucloud::ubs2::ALLOCATE_UBS_REQUEST,
                        AllocaUBSHandle);
  REGISTE_PROTO_HANDLER(loop, ucloud::ubs2::LIST_UBS_REQUEST, ListUBSHandle);
  REGISTE_PROTO_HANDLER(loop, ucloud::ubs2::RESIZE_UBS_REQUEST,
                        ResizeUBSHandle);
  REGISTE_PROTO_HANDLER(loop, ucloud::ubs2::UPDATE_UBS_NAME_REQUEST,
                        UpdateUBSNameHandle);
  REGISTE_PROTO_HANDLER(loop, ucloud::ubs2::UPDATE_MOUNT_INFO_REQUEST,
                        UpdateUBSMountInfoHandle);
  REGISTE_PROTO_HANDLER(loop, ucloud::ubs2::DELETE_UBS_REQUEST,
                        DeleteUBSHandle);
  REGISTE_PROTO_HANDLER(loop, ucloud::ubs2::DESTROY_UBS_REQUEST,
                        DestroyUBSHandle);
  REGISTE_PROTO_HANDLER(loop, ucloud::udisk::GET_BLKIOTUNE_REQUEST,
                        GetBlkIOTuneHandle);
  REGISTE_PROTO_HANDLER(loop, ucloud::ubs2::LIST_UBS_TOTAL_COUNT_REQUEST,
                        ListUBSTotalCountHandle);
  REGISTE_PROTO_HANDLER(loop, ucloud::ubs2::CHECK_ALLOWANCE_REQUEST,
                        CheckAllowanceHandle);
  REGISTE_PROTO_HANDLER(loop, ucloud::ubs2::GET_UBS_DETAIL_INFO_REQUEST,
                        GetUBSDetailInfoHandle);
  REGISTE_PROTO_HANDLER(loop, ucloud::udisk::LIST_UDISK_REQUEST,
                        ListUDiskHandle);
  REGISTE_PROTO_HANDLER(loop, ucloud::udisk::UDISK_LOGIN_REQUEST,
                        UDiskLoginHandle);
  REGISTE_PROTO_HANDLER(loop, ucloud::udisk::GET_ATTACH_PARAM_REQUEST,
                        GetAttachParamHandle);
  REGISTE_PROTO_HANDLER(loop, ucloud::ubs2::SNAPSHOT_REQUEST, SnapshotHandle);
  REGISTE_PROTO_HANDLER(loop, ucloud::ubs2::DELETE_SNAPSHOT_REQUEST,
                        DeleteSnapshotHandle);
  REGISTE_PROTO_HANDLER(loop, ucloud::ubs2::LIST_SNAPSHOT_REQUEST,
                        ListSnapshotHandle);
  REGISTE_PROTO_HANDLER(loop, ucloud::ubs2::LIST_SNAPSHOT_TOTAL_COUNT_REQUEST,
                        ListSnapshotTotalCountHandle);
  REGISTE_PROTO_HANDLER(loop, ucloud::ubs2::GET_SNAPSHOT_DETAIL_INFO_REQUEST,
                        GetSnapshotInfoHandle);
  REGISTE_PROTO_HANDLER(loop, ucloud::ubs2::UPDATE_SNAPSHOT_INFO_REQUEST,
                        UpdateSnapshotInfoHandle);
  REGISTE_PROTO_HANDLER(loop, ucloud::ubs2::RESTORE_UBS_REQUEST,
                        RestoreUBSHandle);
  REGISTE_PROTO_HANDLER(loop, ucloud::ubs2::CLONE_UBS_REQUEST, CloneUBSHandle);
  REGISTE_PROTO_HANDLER(loop, ucloud::ubs2::UPDATE_UDATAARK_MODE_REQUEST,
                        UpdateUDataarkModeHandle);
  REGISTE_PROTO_HANDLER(loop, ucloud::ubs2::GET_UBS_AVALON_REQUEST,
                        GetAvalonHandle);
  REGISTE_PROTO_HANDLER(loop, ucloud::udisk::GET_UDISK_FREYR_REQUEST,
                        GetFreyrHandle);
  REGISTE_PROTO_HANDLER(loop, ucloud::ubs2::TAKE_BACK_UBS_REQUEST,
                        TakeBackUBSHandle);
  REGISTE_PROTO_HANDLER(loop, ucloud::udisk::FINISH_MIGRATE_UDISK_TASK_REQUEST,
                        FinishMigrateUDiskTaskHandle);
  REGISTE_PROTO_HANDLER(loop, ucloud::udisk::GET_LOGIN_GATE_REQUEST,
                        GetLoginGateHandle);
  REGISTE_PROTO_HANDLER(loop, ucloud::ubs2::TAKE_BACK_UBS_REQUEST,
                        TakeBackUBSHandle);
  REGISTE_PROTO_HANDLER(loop, ucloud::ubs2::LIST_THROWN_UBS_REQUEST,
                        ListThrownUBSHandle);
  REGISTE_PROTO_HANDLER(loop, ucloud::ubs2::UPDATE_UBS_INFO_REQUEST,
                        UpdateUBSInfoHandle);
  REGISTE_PROTO_HANDLER(loop, ucloud::ubs2::LIST_UBS_BY_HOST_REQUEST,
                        ListUBSByHostHandle);
  REGISTE_PROTO_HANDLER(loop, ucloud::udisk::ADD_HOST_BLACKLIST_REQUEST,
                        AddHostBlacklistHandle);
  REGISTE_PROTO_HANDLER(loop, ucloud::udisk::REMOVE_HOST_BLACKLIST_REQUEST,
                        RemoveHostBlacklistHandle);
  REGISTE_PROTO_HANDLER(loop, ucloud::udisk::META_GET_SET_CAPACITY_REQUEST,
                        GetSetCapacityHandle);
  REGISTE_PROTO_HANDLER(loop, ucloud::udisk::META_GET_USER_LC_STATISTIC_INFO_REQUEST,
                        GetUserLcStatisticInfoHandle);
}

static void start_manager_module() {
  uevent::UeventLoop *loop = new uevent::EventLoopLibevent(
      "main_thread", BuddyLoopHandle::CreateMyself);

  uevent::UsockAddress addr(g_context->config().listenip(),
                            g_context->config().listenport());
  uevent::ListenerUevent *listener = new uevent::ListenerLibevent(
      loop, addr, "MainListener", uevent::Option());
  service_register(loop);

  listener->SetConnectionSuccessCb(std::bind(
      &BuddyLoopHandle::ConnectionSuccessHandle, std::placeholders::_1));
  listener->SetConnectionClosedCb(std::bind(
      &BuddyLoopHandle::ConnectionClosedHandle, std::placeholders::_1));
  listener->SetMessageReadCb(std::bind(
      &uevent::MessageUtil::ProtobufReadCallBack, std::placeholders::_1));

  g_context->set_loop(loop);
  g_context->set_listener(listener);

  LOG_INFO << "start listener";
  listener->Start();
}

int main(int argc, char **argv) {
  std::string conf_file;
  bool foreground(false);
  // 解析命令行输入
  while (true) {
    int c = -1;
    int index = -1;
    c = getopt_long(argc, argv, short_options, long_options, &index);
    if (c == -1) {
      break;
    }
    switch (c) {
      case 'v':
        print_version(argv[0]);
        std::exit(0);
      case 'c':
        conf_file = std::string(optarg);
        break;
      case 'h':
        print_help(argv[0]);
        std::exit(0);
      case 'f':
        foreground = true;
        break;
      default:
        print_help(argv[0]);
        std::exit(-1);
    }
  }
  if (conf_file.empty()) {
    conf_file = "/etc/udisk/buddy.conf";
  }
  context_init(conf_file);

  if (!foreground) {
    init_daemon();
  }

  // 初始化日志模块
  init_logging(foreground);

  LOG_INFO << "config: " << g_context->config().ToString();

  // zkclient启动
  init_zkclient();

  // 初始化错误码转换表
  initEcMap();

  // 注册自身到zk
  register_myself();

  // 抢占leader否则watch leader
  register_or_watch_leader();

  // hydra转发模块启动
  HydraHandle hydra_handle;
  hydra_handle.Start();
  g_context->set_hydra_handle(&hydra_handle);

  // red skull转发模块启动
  RedSkullHandle red_skull_handle;
  red_skull_handle.Start();
  g_context->set_red_skull_handle(&red_skull_handle);

  // 管理网络模块启动
  start_manager_module();

  return 0;
}
