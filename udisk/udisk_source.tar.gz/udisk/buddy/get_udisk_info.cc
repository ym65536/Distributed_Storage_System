#include "get_udisk_info.h"
#include "buddy_context.h"
#include "logging.h"
#include "protocol_conversion.h"
#include "umessage_common.h"

namespace udisk {
namespace buddy {

void GetUDiskInfoHandle::TimeOut() {
  LOG_ERROR << "GetUDiskInfoHandle " << session_no_ << "time out";
  SendResponse(-ucloud::udisk::EC_UDISK_OPT_TIMEOUT,
               "GetUDiskInfoHandle time out");
}

void GetUDiskInfoHandle::SendResponse(uint32_t retcode,
                                      const std::string &message) {
  ucloud::udisk::MetaGetUDiskInfoResponse *res =
      response_.mutable_body()->MutableExtension(
          ucloud::udisk::meta_get_udisk_info_response);
  res->mutable_rc()->set_retcode(retcode);
  res->mutable_rc()->set_error_message(message);
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void GetUDiskInfoHandle::EntryInit(const uevent::ConnectionUeventPtr &conn,
                                   ucloud::UMessage *um) {
  conn_ = conn;
  session_no_ = um->head().session_no();
  MakeResponse(um, ucloud::udisk::META_GET_UDISK_INFO_RESPONSE, &response_);

  ProtocolTranslate(*um, &forward_req_);

  if (!ForwardHydra()) {
    LOG_ERROR << "can not get connection of hydra " << session_no_;
    SendResponse(-ucloud::udisk::EC_UDISK_META_NOT_READY,
                 "can not get connection of hydra");
    return;
  }
}

bool GetUDiskInfoHandle::ForwardHydra() {
  std::string ip;
  int port;
  if (!g_context->GetHydraAddress(&ip, &port)) {
    LOG_ERROR << "can not get hydra ip, port";
    return false;
  }
  uevent::ConnectionUeventPtr conn =
      g_context->hydra_handle()->GetConnection(ip, port);
  if (!conn) {
    return false;
  }
  uevent::MessageUtil::SendPbRequest(
      conn, forward_req_, std::bind(&GetUDiskInfoHandle::EntryForwardHydra,
                                    This(), std::placeholders::_1),
      std::bind(&GetUDiskInfoHandle::TimeOut, This()), 10.0);
  return true;
}

void GetUDiskInfoHandle::ProtocolTranslate(const ucloud::UMessage &src,
                                           ucloud::UMessage *dst) {
  uint32_t objid = uevent::MessageUtil::ObjId();
  NewMessage_v2(dst, src.head().flow_no(), session_no_,
                ucloud::ubs2::GET_UBS_DETAIL_INFO_REQUEST,
                src.head().worker_index(), src.head().tint_flag(), objid, 0,
                src.head().call_purpose().c_str(),
                src.head().access_token().c_str(), NULL);

  const ucloud::udisk::MetaGetUDiskInfoRequest &srcReq =
      src.body().GetExtension(ucloud::udisk::meta_get_udisk_info_request);
  ucloud::ubs2::GetUBSDetailInfoRequest *dstReq =
      dst->mutable_body()->MutableExtension(
          ucloud::ubs2::get_ubs_detail_info_request);
  dstReq->set_ubs_id(srcReq.extern_id());
}

void GetUDiskInfoHandle::EntryForwardHydra(ucloud::UMessage *msg) {
  const ucloud::ubs2::GetUBSDetailInfoResponse &res =
      msg->body().GetExtension(ucloud::ubs2::get_ubs_detail_info_response);
  if (res.rc().retcode()) {
    LOG_ERROR << "GetUDiskInfoHandle " << session_no_
              << " error: " << res.rc().error_message();
    SendResponse(ConstructErrorCodeFromUBS2ToUDisk(res.rc().retcode()),
                 res.rc().error_message());
    return;
  }
  if (res.has_lc()) {
    ucloud::udisk::MetaGetUDiskInfoResponse *resp =
        response_.mutable_body()->MutableExtension(
            ucloud::udisk::meta_get_udisk_info_response);
    ucloud::udisk::LCInfoPb *udisk_lc = resp->mutable_lc();
    ConstructLogicalChunkFromUBS2ToUDisk(udisk_lc, res.lc());
  }
  SendResponse(0, "");
}

};  // namespace buddy
};  // namespace udisk
