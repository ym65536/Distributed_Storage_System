#include "update_ubs_mount_info_handle.h"
#include "logging.h"
#include "umessage_common.h"
#include "protocol_conversion.h"
#include "buddy_context.h"
#include "udisk_message.h"
#include "message_util.h"

#include <time.h>
#include <sstream>

namespace udisk {
namespace buddy {

void UpdateUBSMountInfoHandle::TimeOut() {
  LOG_ERROR << "UpdateUBSMountInfoHandle " << session_no_ << "time out";
  SendResponse(-ucloud::ubs2::EC_UBS_TIMEOUT, "UpdateUBSNameHandle time out");
}

void UpdateUBSMountInfoHandle::SendResponse(uint32_t retcode, const char* message) {
  ucloud::ubs2::UpdateMountInfoResponse* res = 
    response_.mutable_body()->MutableExtension(ucloud::ubs2::update_mount_info_response);

  res->mutable_rc()->set_retcode(retcode);
  if (retcode) {
    res->mutable_rc()->set_error_message(message);
  }
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

std::string UpdateUBSMountInfoHandle::ProtocolTranslate(const ucloud::UMessage &src,
    ucloud::UMessage *dst) {
  uint32_t objid = uevent::MessageUtil::ObjId();
  NewMessage_v2(dst, src.head().flow_no(), session_no_,
                ucloud::udisk::META_UPDATE_UDISK_REQUEST,
                src.head().worker_index(),
                src.head().tint_flag(), objid, 0,
                src.head().call_purpose().c_str(),
                src.head().access_token().c_str(), NULL);

  const ucloud::ubs2::UpdateMountInfoRequest &srcReq =
    src.body().GetExtension(ucloud::ubs2::update_mount_info_request);
  ucloud::udisk::MetaUpdateUDiskRequest *dstReq =
    dst->mutable_body()->MutableExtension(ucloud::udisk::meta_update_udisk_request);

  if (srcReq.has_multi_attach()) {
    dstReq->set_multi_attach(srcReq.multi_attach());
  }
  ucloud::udisk::LCInfoPb *lcp = dstReq->mutable_lc();
  lcp->set_extern_id(srcReq.ubs_id());
  if (srcReq.has_mount_status()) {
    int status = MountStatusUBS2ToUDisk(srcReq.mount_status());
    if (status < 0) {
      return "invalid mount status";
    }
    lcp->set_mount_status(ucloud::udisk::UDISK_MOUNT_STATUS(status));
  }
  if (srcReq.has_mount_vm_id()) {
    lcp->set_mount_vm_id(srcReq.mount_vm_id());
  }
  if (srcReq.has_mount_device_name()) {
    lcp->set_mount_device_name(srcReq.mount_device_name());
  }
  if (srcReq.has_utm_status()) {
    lcp->set_utm_status(ucloud::udisk::UTM_STATUS(srcReq.utm_status()));
  }
  return std::string();
}

void UpdateUBSMountInfoHandle::EntryInit(const uevent::ConnectionUeventPtr& conn, ucloud::UMessage* um) {
  LOG_DEBUG << um->DebugString();
  conn_ = conn;
  session_no_ = um->head().session_no();
  MakeResponse(um, ucloud::ubs2::UPDATE_MOUNT_INFO_RESPONSE, &response_);

  ucloud::UMessage dstReqMsg;
  std::string rc = ProtocolTranslate(*um, &dstReqMsg);
  if (!rc.empty()) {
    LOG_ERROR << "UpdateUBSMountInfoHandle " << session_no_ << " failed: " << rc;
    SendResponse(-ucloud::ubs2::EC_UBS_INVALID_PARAMS, rc.c_str());
    return;
  }

  if (!g_context->SendMsgToMeta(dstReqMsg,
      std::bind(&UpdateUBSMountInfoHandle::EntryMetaResponse, This(), std::placeholders::_1),
      std::bind(&UpdateUBSMountInfoHandle::TimeOut, This()),
      g_context->config().metaserver_timeout())) {
    const char *msg = "forward msg failed";
    LOG_ERROR << "UpdateUBSMountInfoHandle " << session_no_ << " failed: " << msg;
    SendResponse(-ucloud::ubs2::EC_UBS_NOT_READY, msg);
    return;
  }
}

void UpdateUBSMountInfoHandle::EntryMetaResponse(ucloud::UMessage *msg) {
  const ucloud::udisk::MetaUpdateUDiskResponse &res =
    msg->body().GetExtension(ucloud::udisk::meta_update_udisk_response);
  if (res.rc().retcode()) {
    LOG_ERROR << "UpdateUBSMountInfoHandle " << session_no_ << " error: "
              << res.rc().error_message();
    SendResponse(ConstructErrorCodeFromUDiskToUBS2(res.rc().retcode()),
        res.rc().error_message().c_str());
    return;
  }
  SendResponse(0, "");
}

}; // end of ns buddy
}; // end of ns udisk
