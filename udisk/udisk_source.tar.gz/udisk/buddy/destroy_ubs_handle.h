#ifndef UDISK_BUDDY_DESTROY_UBS_H
#define UDISK_BUDDY_DESTROY_UBS_H

#include <string>
#include "pb_request_handle.h"
#include "message_util.h"
#include "ubs2_message.h"

namespace uevent {
  class UeventLoop;
  class ConnectionUevent;
};

namespace udisk {
namespace buddy {

class DestroyUBSHandle: public uevent::PbRequestHandle {
public:
  DestroyUBSHandle(uevent::UeventLoop* loop) {}
  virtual ~DestroyUBSHandle() {}

  MYSELF_CREATE(DestroyUBSHandle);

  std::shared_ptr<DestroyUBSHandle> This() {
    return std::dynamic_pointer_cast<DestroyUBSHandle>(shared_from_this());
  }

  void TimeOut();
  void SendResponse(uint32_t retcode, const char* message);
  
  void ProtocolTranslate(const ucloud::UMessage &src, ucloud::UMessage *dst);
  void EntryMetaResponse(ucloud::UMessage *msg);
  virtual void EntryInit(const uevent::ConnectionUeventPtr &conn, ucloud::UMessage* um);
  
private:
  uevent::ConnectionUeventPtr conn_;

  ucloud::UMessage response_;
  std::string session_no_;
};

}; // end of ns buddy
}; // end of ns udisk

#endif
