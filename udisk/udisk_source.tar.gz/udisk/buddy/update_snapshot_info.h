#ifndef UDISK_BUDDY_UPDATE_SNAPSHOT_INFO_H
#define UDISK_BUDDY_UPDATE_SNAPSHOT_INFO_H

#include "message_util.h"
#include "pb_request_handle.h"
#include "ubs2_message.h"

namespace uevent {
class UeventLoop;
class ConnectionUevent;
};  // namespace uevent

namespace udisk {
namespace buddy {

class UpdateSnapshotInfoHandle : public uevent::PbRequestHandle {
 public:
  UpdateSnapshotInfoHandle(uevent::UeventLoop *loop) {}
  virtual ~UpdateSnapshotInfoHandle() {}

  MYSELF_CREATE(UpdateSnapshotInfoHandle);

  std::shared_ptr<UpdateSnapshotInfoHandle> This() {
    return std::dynamic_pointer_cast<UpdateSnapshotInfoHandle>(
        shared_from_this());
  }

  void TimeOut();
  void SendResponse(uint32_t retcode, const std::string &message);

  void ProtocolTranslate(const ucloud::UMessage &src, ucloud::UMessage *dst);
  void EntryMetaResponse(ucloud::UMessage *msg);
  virtual void EntryInit(const uevent::ConnectionUeventPtr &conn,
                         ucloud::UMessage *um);

 private:
  uevent::ConnectionUeventPtr conn_;

  ucloud::UMessage response_;
  std::string session_no_;
};

};  // namespace buddy
};  // namespace udisk

#endif
