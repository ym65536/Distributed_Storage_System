#ifndef UDISK_BUDDY_UPDATE_UBS_INFO_H
#define UDISK_BUDDY_UPDATE_UBS_INFO_H

#include <string>
#include "message_util.h"
#include "pb_request_handle.h"
#include "ubs2_message.h"

namespace uevent {
class UeventLoop;
class ConnectionUevent;
};  // namespace uevent

namespace udisk {
namespace buddy {

class UpdateUBSInfoHandle : public uevent::PbRequestHandle {
 public:
  UpdateUBSInfoHandle(uevent::UeventLoop *loop) {}
  virtual ~UpdateUBSInfoHandle() {}

  MYSELF_CREATE(UpdateUBSInfoHandle);

  std::shared_ptr<UpdateUBSInfoHandle> This() {
    return std::dynamic_pointer_cast<UpdateUBSInfoHandle>(shared_from_this());
  }

  void TimeOut();
  void SendResponse(uint32_t retcode, const char *message);

  std::string ProtocolTranslate(const ucloud::UMessage &src,
                                ucloud::UMessage *dst);

  void EntryMetaResponse(ucloud::UMessage *msg);
  virtual void EntryInit(const uevent::ConnectionUeventPtr &conn,
                         ucloud::UMessage *um);

 private:
  uevent::ConnectionUeventPtr conn_;

  ucloud::UMessage response_;
  std::string session_no_;
};

};  // namespace buddy
};  // namespace udisk

#endif
