#ifndef UDISK_BUDDY_GET_UDISK_INFO_CROSS_REGION_H
#define UDISK_BUDDY_GET_UDISK_INFO_CROSS_REGION_H

#include "message_util.h"
#include "pb_request_handle.h"
#include "umessage_common.h"

namespace uevent {
class UeventLoop;
class ConnectionUevent;
};  // namespace uevent

namespace udisk {
namespace buddy {

class GetUDiskInfoCrossRegionHandle : public uevent::PbRequestHandle {
 public:
  GetUDiskInfoCrossRegionHandle(uevent::UeventLoop *loop) {}
  virtual ~GetUDiskInfoCrossRegionHandle() {}

  MYSELF_CREATE(GetUDiskInfoCrossRegionHandle);

  std::shared_ptr<GetUDiskInfoCrossRegionHandle> This() {
    return std::dynamic_pointer_cast<GetUDiskInfoCrossRegionHandle>(
        shared_from_this());
  }

  void TimeOut();
  void SendResponse(uint32_t retcode, const std::string &message);
  virtual void EntryInit(const uevent::ConnectionUeventPtr &conn,
                         ucloud::UMessage *um);
  bool ForwardRedSkull();
  void ProtocolTranslate(const ucloud::UMessage &src, ucloud::UMessage *dst);
  void EntryForwardRedSkull(ucloud::UMessage *msg);

 private:
  uevent::ConnectionUeventPtr conn_;

  ucloud::UMessage forward_req_;
  ucloud::UMessage response_;
  std::string session_no_;
};

};  // namespace buddy
};  // namespace udisk

#endif
