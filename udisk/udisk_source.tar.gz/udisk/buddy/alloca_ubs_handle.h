#ifndef UDISK_BUDDY_ALLOCA_UBS_H
#define UDISK_BUDDY_ALLOCA_UBS_H

#include <string>
#include "pb_request_handle.h"
#include "message_util.h"
#include "ubs2_message.h"

namespace uevent {
  class UeventLoop;
  class ConnectionUevent;
};

namespace udisk {
namespace buddy {

class AllocaUBSHandle: public uevent::PbRequestHandle {
public:
  AllocaUBSHandle(uevent::UeventLoop* loop) {}
  virtual ~AllocaUBSHandle() {}

  MYSELF_CREATE(AllocaUBSHandle);

  std::shared_ptr<AllocaUBSHandle> This() {
    return std::dynamic_pointer_cast<AllocaUBSHandle>(shared_from_this());
  }

  void TimeOut();
  void SendResponse(uint32_t retcode, const char* message);

  void ProtocolTranslate(const ucloud::UMessage &src, ucloud::UMessage *dst);

  void EntryMetaResponse(ucloud::UMessage *msg);
  
  virtual void EntryInit(const uevent::ConnectionUeventPtr &conn, ucloud::UMessage* um);
  
private:
  uevent::ConnectionUeventPtr conn_;

  ucloud::UMessage response_;
  std::string session_no_;

  // 这里保存下来，因为
  // ubs协议中要求将extern_id带回去
  std::string extern_id_;
};

}; // end of ns buddy
}; // end of ns udisk

#endif
