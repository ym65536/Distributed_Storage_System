#include "get_blkiotune.h"

#include "logging.h"
#include "umessage_common.h"
#include "buddy_context.h"
#include "ubs2_message.h"
#include "message_util.h"

namespace udisk {
namespace buddy {

void GetBlkIOTuneHandle::TimeOut() {
  LOG_ERROR << "GetBlkIOTuneHandle time out";
  SendResponse(-2, "GetBlkIOTuneHandle time out");
}

void GetBlkIOTuneHandle::SendResponse(uint32_t retcode, const char* message) {
  ucloud::udisk::GetBlkiotuneResponse* res = 
    response_.mutable_body()->MutableExtension(ucloud::udisk::get_blkiotune_response);
  res->mutable_rc()->set_retcode(retcode);
  res->mutable_rc()->set_error_message(message);
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void GetBlkIOTuneHandle::EntryInit(const uevent::ConnectionUeventPtr &conn, ucloud::UMessage* um) {
  conn_ = conn;
  session_no_ = um->head().session_no();
  MakeResponse(um, ucloud::udisk::GET_BLKIOTUNE_RESPONSE, &response_);

  ucloud::UMessage dstReqMsg;

  uint32_t objid = uevent::MessageUtil::ObjId();
  NewMessage_v2(&dstReqMsg, um->head().flow_no(), session_no_,
                ucloud::udisk::GET_BLKIOTUNE_REQUEST,
                um->head().worker_index(),
                um->head().tint_flag(), objid, 0,
                um->head().call_purpose().c_str(),
                um->head().access_token().c_str(), NULL);
  dstReqMsg.mutable_body()->MutableExtension(ucloud::udisk::get_blkiotune_request)->set_udisk_id(
      um->body().GetExtension(ucloud::udisk::get_blkiotune_request).udisk_id());

  if (!g_context->SendMsgToMeta(dstReqMsg,
      std::bind(&GetBlkIOTuneHandle::EntryMetaResponse, This(), std::placeholders::_1),
      std::bind(&GetBlkIOTuneHandle::TimeOut, This()),
      g_context->config().metaserver_timeout())) {
    const char *msg = "forward msg failed";
    LOG_ERROR << "GetBlkIOTuneHandle " << session_no_ << " failed: " << msg;
    SendResponse(-ucloud::ubs2::EC_UBS_NOT_READY, msg);
    return;
  }
}

void GetBlkIOTuneHandle::EntryMetaResponse(ucloud::UMessage *msg) {
  const ucloud::udisk::GetBlkiotuneResponse &res = 
    msg->body().GetExtension(ucloud::udisk::get_blkiotune_response);
  ucloud::udisk::GetBlkiotuneResponse *dstRes =
    response_.mutable_body()->MutableExtension(ucloud::udisk::get_blkiotune_response);
  *dstRes = res;
  SendResponse(res.rc().retcode(), res.rc().error_message().c_str());
}

}; // end of ns buddy
}; // end of ns udisk
