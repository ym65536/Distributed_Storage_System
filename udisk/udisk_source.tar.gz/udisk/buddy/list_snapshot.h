#ifndef UDISK_BUDDY_LIST_SNAPSHOT_H
#define UDISK_BUDDY_LIST_SNAPSHOT_H

#include "message_util.h"
#include "pb_request_handle.h"
#include "ubs2_message.h"

namespace uevent {
class UeventLoop;
class ConnectionUevent;
};  // namespace uevent

namespace udisk {
namespace buddy {

class ListSnapshotHandle : public uevent::PbRequestHandle {
 public:
  ListSnapshotHandle(uevent::UeventLoop *loop) {}
  virtual ~ListSnapshotHandle() {}

  MYSELF_CREATE(ListSnapshotHandle);

  std::shared_ptr<ListSnapshotHandle> This() {
    return std::dynamic_pointer_cast<ListSnapshotHandle>(shared_from_this());
  }

  void TimeOut();
  void SendResponse(uint32_t retcode, const std::string &message);

  void ProtocolTranslate(const ucloud::UMessage &src, ucloud::UMessage *dst);
  void EntryMetaResponse(ucloud::UMessage *msg);
  virtual void EntryInit(const uevent::ConnectionUeventPtr &conn,
                         ucloud::UMessage *um);

 private:
  uevent::ConnectionUeventPtr conn_;

  ucloud::UMessage response_;
  std::string session_no_;
};

};  // namespace buddy
};  // namespace udisk

#endif
