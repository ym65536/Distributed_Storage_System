#include "buddy_context.h"
#include <cstring>
#include <sstream>
#include "connector_libevent.h"
#include "ini_config.h"
#include "message_util.h"
#include "uns_message.h"

namespace udisk {
namespace buddy {

std::tuple<int, std::string> BuddyConfig::Init() {
  assert(!config_file_.empty());

  std::tuple<int, std::string> ret = load();
  if (std::get<0>(ret)) {
    std::string msg =
        "load conf " + config_file_ + " failed for " + std::get<1>(ret);
    return std::make_tuple(std::get<0>(ret), msg);
  }
  loaded_ = true;
  return std::make_tuple(0, "");
}

std::string BuddyConfig::ToString() const {
  std::stringstream ss;
  ss << "my_id: " << my_id_ << " my_name: " << my_name_
     << " listenip: " << listenip_ << " listenport: " << listenport_
     << " metaserver_path: " << metaserver_path_
     << " hydra_path: " << hydra_path_ << " zk_server: " << zk_server_
     << " red_skulls: ";
  std::multimap<std::string, int>::const_iterator it = red_skulls_.begin();
  while (it != red_skulls_.end()) {
    ss << it->first << ":" << it->second << ";";
    it++;
  }
  return ss.str();
}

std::tuple<int, std::string> BuddyConfig::load() {
  int ret = 0;
  std::string msg("");

  base::IniConfig parser;

  if (parser.LoadFromFile(config_file_.c_str())) {
    ret = errno;
    msg = std::strerror(errno);
    return std::make_tuple(ret, msg);
  }
  std::string my_id = parser.GetValue("common", "my_id");
  if (my_id.empty()) {
    ret = -1;
    msg = "not common/my_id";
    return std::make_tuple(ret, msg);
  }
  my_id_ = my_id;

  std::string my_set = parser.GetValue("common", "my_set");
  if (my_set.empty()) {
    my_set = "my_set";
  }
  my_set_ = my_set;

  std::string my_name = parser.GetValue("common", "my_name");
  if (my_name.empty()) {
    ret = -1;
    msg = "not common/my_name";
    return std::make_tuple(ret, msg);
  }
  my_name_ = my_name;

  std::string fake_hydra = parser.GetValue("common", "fake_hydra");
  if (fake_hydra.empty()) {
    ret = -1;
    msg = "not common/fake_hydra";
    return std::make_tuple(ret, msg);
  }
  fake_hydra_ = fake_hydra;

  std::string fake_red_skull = parser.GetValue("common", "fake_red_skull");
  if (fake_red_skull.empty()) {
    ret = -1;
    msg = "not common/fake_red_skull";
    return std::make_tuple(ret, msg);
  }
  fake_red_skull_ = fake_red_skull;

  std::string log_level = parser.GetValue("log", "log_level");
  if (log_level.empty()) {
    log_level = "info";
  }
  log_level_ = log_level;

  std::string log_path = parser.GetValue("log", "log_path");
  if (log_path.empty()) {
    log_path = "/var/log/udisk/loki";
  }
  log_path_ = log_path;

  std::string listen_ip = parser.GetValue("network", "listen_ip");
  if (listen_ip.empty()) {
    ret = -1;
    msg = "not common/listen_ip";
    return std::make_tuple(ret, msg);
  }
  listenip_ = listen_ip;

  int listen_port = parser.IntValue("network", "listen_port");
  if (listen_port == 0) {
    ret = -1;
    msg = "not common/listen_port";
    return std::make_tuple(ret, msg);
  }
  listenport_ = listen_port;

  int fake_hydra_port = parser.IntValue("network", "fake_hydra_port");
  if (fake_hydra_port == 0) {
    ret = -1;
    msg = "not common/fake_hydra_port";
    return std::make_tuple(ret, msg);
  }
  fake_hydra_port_ = fake_hydra_port;

  int fake_red_skull_port = parser.IntValue("network", "fake_red_skull_port");
  if (fake_red_skull_port == 0) {
    ret = -1;
    msg = "not common/fake_red_skull_port";
    return std::make_tuple(ret, msg);
  }
  fake_red_skull_port_ = fake_red_skull_port;

  std::string zk_server = parser.GetValue("zookeeper", "server");
  if (zk_server.empty()) {
    ret = -1;
    msg = "not zookeeper/server";
    return std::make_tuple(ret, msg);
  }
  zk_server_ = zk_server;

  std::string zk_log = parser.GetValue("zookeeper", "log");
  if (zk_log.empty()) {
    zk_log = "/dev/null";
  }
  zk_log_ = zk_log;

  std::string zk_timeout = parser.GetValue("zookeeper", "timeout");
  if (zk_timeout.empty()) {
    ret = -1;
    msg = "not zookeeper/timeout";
    return std::make_tuple(ret, msg);
  }
  zk_timeout_ = std::atoi(zk_timeout.c_str());
  if (zk_timeout_ == 0) {
    zk_timeout_ = 20;
  }

  std::string metaserver_path = parser.GetValue("name", "metaserver");
  if (metaserver_path.empty()) {
    ret = -1;
    msg = "not name/metaserver";
    return std::make_tuple(ret, msg);
  }
  metaserver_path_ = metaserver_path;

  std::string hydra_path = parser.GetValue("name", "hydra");
  if (hydra_path.empty()) {
    ret = -1;
    msg = "not name/hydra";
    return std::make_tuple(ret, msg);
  }
  hydra_path_ = hydra_path;

  int red_skull_count = parser.IntValue("name", "red_skull_count");
  for (int i = 0; i < red_skull_count; i++) {
    std::string red_skull_ip =
        parser.GetValue("name", "red_skull_ip" + std::to_string(i));
    int red_skull_port =
        parser.IntValue("name", "red_skull_port" + std::to_string(i));
    if (!red_skull_ip.empty() && red_skull_port != 0) {
      red_skulls_.insert(std::make_pair(red_skull_ip, red_skull_port));
    }
  }

  std::string metaserver_timeout =
      parser.GetValue("common", "metaserver_timeout");
  if (metaserver_timeout.empty()) {
    ret = -1;
    msg = "not common/metaserver_timeout";
    return std::make_tuple(ret, msg);
  }
  metaserver_timeout_ = std::atoi(metaserver_timeout.c_str());
  if (metaserver_timeout_ == 0) {
    metaserver_timeout_ = 10;
  }

  loaded_ = true;
  return std::make_tuple(ret, msg);
}

BuddyContext::BuddyContext(const std::string &conf_file) : config_(conf_file) {}

std::tuple<int, std::string> BuddyContext::Init() { return config_.Init(); }

void BuddyContext::OutConnectorConnClosedCb(
    const uevent::ConnectionUeventPtr &conn, OutConnectorKey key) {
  out_connectors_[key]->DestroyConnection();
  delete out_connectors_[key];
  out_connectors_.erase(key);
}

uevent::ConnectionUeventPtr BuddyContext::GetConnection(const std::string &ip,
                                                        int port) {
  OutConnectorKey key = std::make_pair(ip, port);
  auto found = out_connectors_.find(key);
  if (found != out_connectors_.end()) {
    if (found->second) {
      return found->second->GetConnection();
    }
  } else {
    std::stringstream ss;
    uevent::UsockAddress addr(ip, port, false);
    ss << "connector-" << ip << ":" << port;
    uevent::ConnectorUevent *connector =
        new uevent::ConnectorLibevent(loop_, addr, ss.str());
    connector->SetConnectionClosedCb(
        std::bind(&BuddyContext::OutConnectorConnClosedCb, this,
                  std::placeholders::_1, key));
    connector->SetMessageReadCb(&uevent::MessageUtil::ProtobufReadCallBack);
    connector->Connect();

    out_connectors_.insert(std::make_pair(key, connector));
    return connector->GetConnection();
  }
  return nullptr;
}

bool BuddyContext::SendMsgToMeta(ucloud::UMessage &msg,
                                 std::function<void(ucloud::UMessage *)> res,
                                 std::function<void()> timeout_fun,
                                 int timeout) {
  uevent::ConnectionUeventPtr conn = GetMetaConnection();
  if (!conn) {
    return false;
  }
  LOG_INFO << msg.DebugString();
  uevent::MessageUtil::SendPbRequest(conn, msg, res, timeout_fun, timeout);
  return true;
}

uevent::ConnectionUeventPtr BuddyContext::GetMetaConnection() {
  std::string ip;
  int port;
  if (!GetMetaAddress(&ip, &port)) {
    return nullptr;
  }
  return GetConnection(ip, port);
}

bool BuddyContext::GetMetaAddress(std::string *ip, int *port) {
  if (local_nc_) {
    ucloud::uns::NameNodeContent namenode;
    if (!local_nc_->GetNNCForName(g_context->config().my_set(), "metaserver",
                                  namenode, true)) {
      *ip = namenode.ip();
      *port = namenode.port();
      return true;
    }
  }
  return false;
}

bool BuddyContext::SendMsgToHydra(ucloud::UMessage &msg,
                                  std::function<void(ucloud::UMessage *)> res,
                                  std::function<void()> timeout_fun,
                                  int timeout) {
  uevent::ConnectionUeventPtr conn = GetHydraConnection();
  if (!conn) {
    return false;
  }
  uevent::MessageUtil::SendPbRequest(conn, msg, res, timeout_fun, timeout);
  return true;
}

uevent::ConnectionUeventPtr BuddyContext::GetHydraConnection() {
  std::string ip;
  int port;
  if (!GetHydraAddress(&ip, &port)) {
    return nullptr;
  }
  return GetConnection(ip, port);
}

bool BuddyContext::GetHydraAddress(std::string *ip, int *port) {
  if (local_nc_) {
    ucloud::uns::NameNodeContent namenode;
    if (!local_nc_->GetNNCForName(g_context->config().my_set(), "hydra",
                                  namenode, false)) {
      *ip = namenode.ip();
      *port = namenode.port();
      return true;
    }
  }
  return false;
}

bool BuddyContext::GetRedSkullAddress(std::string *ip, int *port) {
  std::multimap<std::string, int>::const_iterator it =
      config_.red_skulls().begin();
  if (it == config_.red_skulls().end()) {
    LOG_ERROR << "not configure red skull";
    return false;
  }
  std::advance(it, random() % g_context->config().red_skulls().size());
  *ip = it->first;
  *port = it->second;
  return true;
}

bool BuddyContext::SendMsg(const std::string &ip, int port,
                           ucloud::UMessage &msg,
                           std::function<void(ucloud::UMessage *)> res,
                           std::function<void()> timeout_fun, int timeout) {
  uevent::ConnectionUeventPtr conn = GetConnection(ip, port);
  if (!conn) {
    return false;
  }
  uevent::MessageUtil::SendPbRequest(conn, msg, res, timeout_fun, timeout);
  return true;
}

};  // namespace buddy
};  // namespace udisk

udisk::buddy::BuddyContext *g_context = nullptr;
