#include "delete_snapshot.h"
#include "buddy_context.h"
#include "logging.h"
#include "message_util.h"
#include "protocol_conversion.h"
#include "umessage_common.h"

namespace udisk {
namespace buddy {

void DeleteSnapshotHandle::TimeOut() {
  LOG_ERROR << "DeleteSnapshotHandle " << session_no_ << "time out";
  SendResponse(-ucloud::ubs2::EC_UBS_TIMEOUT, "DeleteSnapshotHandle time out");
}

void DeleteSnapshotHandle::SendResponse(uint32_t retcode,
                                        const std::string &message) {
  ucloud::ubs2::DeleteSnapshotResponse *res =
      response_.mutable_body()->MutableExtension(
          ucloud::ubs2::delete_snapshot_response);
  res->mutable_rc()->set_retcode(retcode);
  if (retcode) {
    res->mutable_rc()->set_error_message(message);
  }
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void DeleteSnapshotHandle::ProtocolTranslate(const ucloud::UMessage &src,
                                             ucloud::UMessage *dst) {
  uint32_t objid = uevent::MessageUtil::ObjId();
  NewMessage_v2(dst, src.head().flow_no(), session_no_,
                ucloud::udisk::DELETE_SNAPSHOT_REQUEST,
                src.head().worker_index(), src.head().tint_flag(), objid, 0,
                src.head().call_purpose().c_str(),
                src.head().access_token().c_str(), NULL);

  const ucloud::ubs2::DeleteSnapshotRequest &srcReq =
      src.body().GetExtension(ucloud::ubs2::delete_snapshot_request);
  ucloud::udisk::DeleteSnapshotRequest *dstReq =
      dst->mutable_body()->MutableExtension(
          ucloud::udisk::delete_snapshot_request);
  if (srcReq.has_ubs_id()) {
    dstReq->set_extern_id(srcReq.ubs_id());
  }
  if (srcReq.has_snapshot_id()) {
    dstReq->set_snapshot_id(srcReq.snapshot_id());
  }
}

void DeleteSnapshotHandle::EntryInit(const uevent::ConnectionUeventPtr &conn,
                                     ucloud::UMessage *um) {
  conn_ = conn;
  session_no_ = um->head().session_no();
  MakeResponse(um, ucloud::ubs2::DELETE_SNAPSHOT_RESPONSE, &response_);

  ucloud::UMessage dstReqMsg;
  ProtocolTranslate(*um, &dstReqMsg);

  if (!g_context->SendMsgToMeta(
           dstReqMsg, std::bind(&DeleteSnapshotHandle::EntryMetaResponse,
                                This(), std::placeholders::_1),
           std::bind(&DeleteSnapshotHandle::TimeOut, This()),
           g_context->config().metaserver_timeout())) {
    LOG_ERROR << "DeleteSnapshotHandle " << session_no_
              << " forward msg failed";
    SendResponse(-ucloud::ubs2::EC_UBS_NOT_READY, "forward msg failed");
    return;
  }
}

void DeleteSnapshotHandle::EntryMetaResponse(ucloud::UMessage *msg) {
  const ucloud::udisk::DeleteSnapshotResponse &res =
      msg->body().GetExtension(ucloud::udisk::delete_snapshot_response);
  if (res.rc().retcode()) {
    LOG_ERROR << "DeleteSnapshotHandle " << session_no_
              << " error: " << res.rc().error_message();
    SendResponse(ConstructErrorCodeFromUDiskToUBS2(res.rc().retcode()),
                 res.rc().error_message());
    return;
  }
  SendResponse(0, "");
}

};  // namespace buddy
};  // namespace udisk
