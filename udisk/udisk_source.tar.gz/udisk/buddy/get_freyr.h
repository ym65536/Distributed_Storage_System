#ifndef UDISK_BUDDY_GET_FREYR_H
#define UDISK_BUDDY_GET_FREYR_H

#include "message_util.h"
#include "pb_request_handle.h"

namespace uevent {
class UeventLoop;
class ConnectionUevent;
};  // namespace uevent

namespace udisk {
namespace buddy {

class GetFreyrHandle : public uevent::PbRequestHandle {
 public:
  GetFreyrHandle(uevent::UeventLoop *loop) {}
  virtual ~GetFreyrHandle() {}

  MYSELF_CREATE(GetFreyrHandle);

  std::shared_ptr<GetFreyrHandle> This() {
    return std::dynamic_pointer_cast<GetFreyrHandle>(shared_from_this());
  }

  void TimeOut();
  void SendResponse(uint32_t retcode, const std::string &message);

  void EntryMetaResponse(ucloud::UMessage *msg);
  virtual void EntryInit(const uevent::ConnectionUeventPtr &conn,
                         ucloud::UMessage *um);

 private:
  uevent::ConnectionUeventPtr conn_;

  ucloud::UMessage response_;
  std::string session_no_;
};

};  // namespace buddy
};  // namespace udisk

#endif
