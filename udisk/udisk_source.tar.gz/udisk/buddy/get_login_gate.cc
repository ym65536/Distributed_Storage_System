#include "get_login_gate.h"

#include "buddy_context.h"
#include "logging.h"
#include "message_util.h"
#include "ubs2_message.h"
#include "umessage_common.h"

using namespace udisk::buddy;
using namespace ucloud::udisk;

void GetLoginGateHandle::Timeout() {
  LOG_ERROR << "GetLoginGateHandle time out";
  SendResponse(-2, "GetLoginGateHandle time out");
}

void GetLoginGateHandle::SendResponse(uint32_t retcode, const char *message) {
  ucloud::udisk::GetLoginGateResponse *res =
      response_.mutable_body()->MutableExtension(get_login_gate_response);
  res->mutable_rc()->set_retcode(retcode);
  res->mutable_rc()->set_error_message(message);
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void GetLoginGateHandle::EntryInit(const uevent::ConnectionUeventPtr &conn,
                                   ucloud::UMessage *um) {
  conn_ = conn;
  session_no_ = um->head().session_no();
  MakeResponse(um, ucloud::udisk::GET_LOGIN_GATE_RESPONSE, &response_);

  ucloud::UMessage dstReqMsg;
  dstReqMsg.CopyFrom(*um);
  if (!g_context->SendMsgToMeta(
           dstReqMsg, std::bind(&GetLoginGateHandle::EntryMetaResponse, This(),
                                std::placeholders::_1),
           std::bind(&GetLoginGateHandle::Timeout, This()),
           g_context->config().metaserver_timeout())) {
    const char *msg = "forward msg failed";
    LOG_ERROR << "GetLoginGateHandle " << session_no_ << " failed: " << msg;
    SendResponse(-ucloud::ubs2::EC_UBS_NOT_READY, msg);
    return;
  }
}

void GetLoginGateHandle::EntryMetaResponse(ucloud::UMessage *msg) {
  LOG_INFO << msg->DebugString();
  const ucloud::udisk::GetLoginGateResponse &res =
      msg->body().GetExtension(ucloud::udisk::get_login_gate_response);
  GetLoginGateResponse *dstRes =
      response_.mutable_body()->MutableExtension(get_login_gate_response);
  *dstRes = res;
  SendResponse(res.rc().retcode(), res.rc().error_message().c_str());
}
