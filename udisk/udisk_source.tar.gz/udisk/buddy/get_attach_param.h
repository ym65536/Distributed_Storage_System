#ifndef UDISK_BUDDY_GET_ATTACH_PARAM_H
#define UDISK_BUDDY_GET_ATTACH_PARAM_H

#include <string>
#include "pb_request_handle.h"
#include "message_util.h"
#include "udisk_message.h"

namespace uevent {
  class UeventLoop;
  class ConnectionUevent;
};

namespace udisk {
namespace buddy {

class GetAttachParamHandle: public uevent::PbRequestHandle {
public:
  GetAttachParamHandle(uevent::UeventLoop* loop) {}
  virtual ~GetAttachParamHandle() {}

  MYSELF_CREATE(GetAttachParamHandle);

  std::shared_ptr<GetAttachParamHandle> This() {
    return std::dynamic_pointer_cast<GetAttachParamHandle>(shared_from_this());
  }

  void TimeOut();
  void SendResponse(uint32_t retcode, const char* message);
  
  virtual void EntryInit(const uevent::ConnectionUeventPtr &conn, ucloud::UMessage* um);
  void EntryMetaResponse(ucloud::UMessage *msg);
  
private:
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage response_;
  std::string session_no_;
};

}; // end of ns metaserver
}; // end of ns udisk

#endif
