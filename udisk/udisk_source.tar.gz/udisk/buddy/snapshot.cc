#include "snapshot.h"
#include "buddy_context.h"
#include "logging.h"
#include "message_util.h"
#include "protocol_conversion.h"
#include "umessage_common.h"

namespace udisk {
namespace buddy {

void SnapshotHandle::TimeOut() {
  LOG_ERROR << "SnapshotHandle " << session_no_ << "time out";
  SendResponse(-ucloud::ubs2::EC_UBS_TIMEOUT, "SnapshotHandle time out");
}

void SnapshotHandle::SendResponse(uint32_t retcode,
                                  const std::string &message) {
  ucloud::ubs2::SnapshotResponse *res =
      response_.mutable_body()->MutableExtension(
          ucloud::ubs2::snapshot_response);
  res->mutable_rc()->set_retcode(retcode);
  if (retcode) {
    res->mutable_rc()->set_error_message(message);
  }
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void SnapshotHandle::ProtocolTranslate(const ucloud::UMessage &src,
                                       ucloud::UMessage *dst) {
  uint32_t objid = uevent::MessageUtil::ObjId();
  NewMessage_v2(dst, src.head().flow_no(), session_no_,
                ucloud::udisk::CREATE_SNAPSHOT_REQUEST,
                src.head().worker_index(), src.head().tint_flag(), objid, 0,
                src.head().call_purpose().c_str(),
                src.head().access_token().c_str(), NULL);

  const ucloud::ubs2::SnapshotRequest &srcReq =
      src.body().GetExtension(ucloud::ubs2::snapshot_request);
  ucloud::udisk::CreateSnapshotRequest *dstReq =
      dst->mutable_body()->MutableExtension(
          ucloud::udisk::create_snapshot_request);
  dstReq->set_extern_id(srcReq.ubs_id());
  dstReq->set_snapshot_name(srcReq.snapshot_name());
  if (srcReq.has_custom_id()) {
    dstReq->set_snapshot_id(srcReq.custom_id());
  }
  if (srcReq.has_company_id()) {
    dstReq->set_top_oid(srcReq.company_id());
  }
  if (srcReq.has_account_id()) {
    dstReq->set_oid(srcReq.account_id());
  }
  if (srcReq.has_comment()) {
    dstReq->set_comment(srcReq.comment());
  }
  if (srcReq.has_cmk_id()) {
    dstReq->set_cmk_id(srcReq.cmk_id());
  }
  if (srcReq.has_data_key()) {
    dstReq->set_data_key(srcReq.data_key());
  }
}

void SnapshotHandle::EntryInit(const uevent::ConnectionUeventPtr &conn,
                               ucloud::UMessage *um) {
  conn_ = conn;
  session_no_ = um->head().session_no();
  MakeResponse(um, ucloud::ubs2::SNAPSHOT_RESPONSE, &response_);

  ucloud::UMessage dstReqMsg;
  ProtocolTranslate(*um, &dstReqMsg);

  if (!g_context->SendMsgToMeta(dstReqMsg,
                                std::bind(&SnapshotHandle::EntryMetaResponse,
                                          This(), std::placeholders::_1),
                                std::bind(&SnapshotHandle::TimeOut, This()),
                                g_context->config().metaserver_timeout())) {
    LOG_ERROR << "SnapshotHandle " << session_no_ << " forward msg failed";
    SendResponse(-ucloud::ubs2::EC_UBS_NOT_READY, "forward msg failed");
    return;
  }
}

void SnapshotHandle::EntryMetaResponse(ucloud::UMessage *msg) {
  const ucloud::udisk::CreateSnapshotResponse &res =
      msg->body().GetExtension(ucloud::udisk::create_snapshot_response);
  if (res.rc().retcode()) {
    LOG_ERROR << "SnapshotHandle " << session_no_
              << " error: " << res.rc().error_message();
    SendResponse(ConstructErrorCodeFromUDiskToUBS2(res.rc().retcode()),
                 res.rc().error_message());
    return;
  }
  ucloud::ubs2::SnapshotResponse *resp =
      response_.mutable_body()->MutableExtension(
          ucloud::ubs2::snapshot_response);
  resp->set_snapshot_id(res.snapshot_id());
  SendResponse(0, "");
}

};  // namespace buddy
};  // namespace udisk
