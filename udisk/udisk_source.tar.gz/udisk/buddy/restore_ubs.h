#ifndef UDISK_BUDDY_RESTORE_UBS_H
#define UDISK_BUDDY_RESTORE_UBS_H

#include "message_util.h"
#include "pb_request_handle.h"
#include "ubs2_message.h"

namespace uevent {
class UeventLoop;
class ConnectionUevent;
};  // namespace uevent

namespace udisk {
namespace buddy {

class RestoreUBSHandle : public uevent::PbRequestHandle {
 public:
  RestoreUBSHandle(uevent::UeventLoop *loop) {}
  virtual ~RestoreUBSHandle() {}

  MYSELF_CREATE(RestoreUBSHandle);

  std::shared_ptr<RestoreUBSHandle> This() {
    return std::dynamic_pointer_cast<RestoreUBSHandle>(shared_from_this());
  }

  void TimeOut();
  void SendResponse(uint32_t retcode, const std::string &message);

  void ProtocolTranslate(const ucloud::UMessage &src, ucloud::UMessage *dst);
  void EntryMetaResponse(ucloud::UMessage *msg);
  virtual void EntryInit(const uevent::ConnectionUeventPtr &conn,
                         ucloud::UMessage *um);

 private:
  uevent::ConnectionUeventPtr conn_;

  ucloud::UMessage response_;
  std::string session_no_;
};

};  // namespace buddy
};  // namespace udisk

#endif
