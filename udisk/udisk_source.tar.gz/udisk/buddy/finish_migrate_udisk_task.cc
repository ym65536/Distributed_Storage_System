#include "finish_migrate_udisk_task.h"

#include "logging.h"
#include "umessage_common.h"
#include "buddy_context.h"
#include "ubs2_message.h"
#include "message_util.h"

using namespace udisk::buddy;

void FinishMigrateUDiskTaskHandle::Timeout() {
  LOG_ERROR << "FinishMigrateUDiskTaskHandle time out";
  SendResponse(-2, "FinishMigrateUDiskTaskHandle time out");
}

void FinishMigrateUDiskTaskHandle::SendResponse(uint32_t retcode,
                                                const char *message) {
  ucloud::udisk::FinishMigrateUDiskTaskResponse *res =
      response_.mutable_body()->MutableExtension(
          ucloud::udisk::finish_migrate_udisk_task_response);
  res->mutable_rc()->set_retcode(retcode);
  res->mutable_rc()->set_error_message(message);
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void FinishMigrateUDiskTaskHandle::EntryInit(
    const uevent::ConnectionUeventPtr &conn, ucloud::UMessage *um) {
  conn_ = conn;
  session_no_ = um->head().session_no();
  MakeResponse(um, ucloud::udisk::FINISH_MIGRATE_UDISK_TASK_RESPONSE,
               &response_);

  ucloud::UMessage dstReqMsg;
  dstReqMsg.CopyFrom(*um);
  if (!g_context->SendMsgToMeta(
           dstReqMsg,
           std::bind(&FinishMigrateUDiskTaskHandle::EntryMetaResponse, This(),
                     std::placeholders::_1),
           std::bind(&FinishMigrateUDiskTaskHandle::Timeout, This()),
           g_context->config().metaserver_timeout())) {
    const char *msg = "forward msg failed";
    LOG_ERROR << "FinishMigrateUDiskTaskHandle " << session_no_
              << " failed: " << msg;
    SendResponse(-ucloud::ubs2::EC_UBS_NOT_READY, msg);
    return;
  }
}

void FinishMigrateUDiskTaskHandle::EntryMetaResponse(ucloud::UMessage *msg) {
  LOG_INFO << msg->DebugString();
  const ucloud::udisk::FinishMigrateUDiskTaskResponse &res =
      msg->body().GetExtension(
          ucloud::udisk::finish_migrate_udisk_task_response);
  ucloud::udisk::FinishMigrateUDiskTaskResponse *dstRes =
      response_.mutable_body()->MutableExtension(
          ucloud::udisk::finish_migrate_udisk_task_response);
  *dstRes = res;
  SendResponse(res.rc().retcode(), res.rc().error_message().c_str());
}
