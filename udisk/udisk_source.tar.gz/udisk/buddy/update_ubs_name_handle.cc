#include "update_ubs_name_handle.h"
#include "logging.h"
#include "umessage_common.h"
#include "protocol_conversion.h"
#include "buddy_context.h"
#include "udisk_message.h"
#include "message_util.h"
#include <time.h>
#include <sstream>

namespace udisk {
namespace buddy {

void UpdateUBSNameHandle::TimeOut() {
  LOG_ERROR << "UpdateUBSNameHandle " << session_no_ << "time out";
  SendResponse(-ucloud::ubs2::EC_UBS_TIMEOUT, "UpdateUBSNameHandle time out");
}

void UpdateUBSNameHandle::SendResponse(uint32_t retcode, const char* message) {
  ucloud::ubs2::UpdateUBSNameResponse* res = 
    response_.mutable_body()->MutableExtension(ucloud::ubs2::update_ubs_name_response);
  res->mutable_rc()->set_retcode(retcode);
  if (retcode) {
    res->mutable_rc()->set_error_message(message);
  }
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void UpdateUBSNameHandle::ProtocolTranslate(const ucloud::UMessage &src, ucloud::UMessage *dst) {
  uint32_t objid = uevent::MessageUtil::ObjId();
  NewMessage_v2(dst, src.head().flow_no(), session_no_,
                ucloud::udisk::META_UPDATE_UDISK_REQUEST,
                src.head().worker_index(),
                src.head().tint_flag(), objid, 0,
                src.head().call_purpose().c_str(),
                src.head().access_token().c_str(), NULL);

  const ucloud::ubs2::UpdateUBSNameRequest &srcReq =
    src.body().GetExtension(ucloud::ubs2::update_ubs_name_request);
  ucloud::udisk::MetaUpdateUDiskRequest *dstReq =
    dst->mutable_body()->MutableExtension(ucloud::udisk::meta_update_udisk_request);

  ucloud::udisk::LCInfoPb *lcp = dstReq->mutable_lc();
  lcp->set_extern_id(srcReq.ubs_id());

  lcp->set_extern_id(srcReq.ubs_id());
  lcp->set_name(srcReq.new_lc_name());
}

void UpdateUBSNameHandle::EntryInit(const uevent::ConnectionUeventPtr &conn, ucloud::UMessage* um) {
  conn_ = conn;
  session_no_ = um->head().session_no();
  MakeResponse(um, ucloud::ubs2::UPDATE_UBS_NAME_RESPONSE, &response_);

  ucloud::UMessage dstReqMsg;
  ProtocolTranslate(*um, &dstReqMsg);

  if (!g_context->SendMsgToMeta(dstReqMsg,
      std::bind(&UpdateUBSNameHandle::EntryMetaResponse, This(), std::placeholders::_1),
      std::bind(&UpdateUBSNameHandle::TimeOut, This()),
      g_context->config().metaserver_timeout())) {
    const char *msg = "forward msg failed";
    LOG_ERROR << "UpdateUBSNameHandle " << session_no_ << " failed: " << msg;
    SendResponse(-ucloud::ubs2::EC_UBS_NOT_READY, msg);
    return;
  }
}

void UpdateUBSNameHandle::EntryMetaResponse(ucloud::UMessage *msg) {
  const ucloud::udisk::MetaUpdateUDiskResponse &res =
    msg->body().GetExtension(ucloud::udisk::meta_update_udisk_response);
  if (res.rc().retcode()) {
    LOG_ERROR << "UpdateUBSNameHandle " << session_no_ << " error: "
              << res.rc().error_message();
    SendResponse(ConstructErrorCodeFromUDiskToUBS2(res.rc().retcode()),
        res.rc().error_message().c_str());
    return;
  }
  SendResponse(0, "");
}

}; // end of ns buddy
}; // end of ns udisk
