#include "list_ubs_by_host_handle.h"

#include <time.h>
#include <sstream>

#include "logging.h"
#include "umessage_common.h"
#include "udisk_message.h"
#include "protocol_conversion.h"
#include "buddy_context.h"
#include "message_util.h"

using namespace udisk::buddy;
using namespace ucloud::ubs2;
using namespace ucloud::udisk;
using namespace std::placeholders;

void ListUBSByHostHandle::TimeOut() {
  LOG_ERROR << "ListUBSByHostHandle " << session_no_ << "time out";
  SendResponse(-ucloud::ubs2::EC_UBS_TIMEOUT, "ListUBSByHostHandle time out");
}

void ListUBSByHostHandle::SendResponse(uint32_t retcode, const char *message) {
  ListUBSByHostResponse *res =
      response_.mutable_body()->MutableExtension(list_ubs_by_host_response);
  res->mutable_rc()->set_retcode(retcode);
  if (retcode) {
    res->mutable_rc()->set_error_message(message);
  }
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void ListUBSByHostHandle::ProtocolTranslate(const ucloud::UMessage &src,
                                            ucloud::UMessage *dst) {
  uint32_t objid = uevent::MessageUtil::ObjId();
  NewMessage_v2(dst, src.head().flow_no(), session_no_, LIST_UDISK_REQUEST,
                src.head().worker_index(), src.head().tint_flag(), objid, 0,
                src.head().call_purpose().c_str(),
                src.head().access_token().c_str(), NULL);

  const ListUBSByHostRequest &srcReq =
      src.body().GetExtension(list_ubs_by_host_request);
  ListUDiskRequest *dstReq =
      dst->mutable_body()->MutableExtension(list_udisk_request);
  dstReq->set_uhost_id(srcReq.uhost_id());
}

void ListUBSByHostHandle::EntryInit(const uevent::ConnectionUeventPtr &conn,
                                    ucloud::UMessage *um) {
  conn_ = conn;
  session_no_ = um->head().session_no();
  MakeResponse(um, LIST_UBS_BY_HOST_RESPONSE, &response_);

  ucloud::UMessage dstReqMsg;
  ProtocolTranslate(*um, &dstReqMsg);

  if (!g_context->SendMsgToMeta(
           dstReqMsg,
           std::bind(&ListUBSByHostHandle::EntryMetaResponse, This(), _1),
           std::bind(&ListUBSByHostHandle::TimeOut, This()),
           g_context->config().metaserver_timeout())) {
    const char *msg = "forward msg failed";
    LOG_ERROR << "ListUBSByHostHanlde " << session_no_ << " failed: " << msg;
    SendResponse(-EC_UBS_NOT_READY, msg);
    return;
  }
}

void ListUBSByHostHandle::EntryMetaResponse(ucloud::UMessage *msg) {
  LOG_INFO << msg->DebugString();
  const ucloud::udisk::ListUDiskResponse &res =
      msg->body().GetExtension(ucloud::udisk::list_udisk_response);
  if (res.rc().retcode()) {
    LOG_ERROR << "ListUBSByHostHandle " << session_no_
              << " error: " << res.rc().error_message();
    if (res.rc().retcode() > 0) {  // 大于0表示拉取为空，默认success
      SendResponse(0, "success");
    } else {
      SendResponse(ConstructErrorCodeFromUDiskToUBS2(res.rc().retcode()),
                   res.rc().error_message().c_str());
    }
    return;
  }
  ucloud::ubs2::ListUBSByHostResponse *dstRes =
      response_.mutable_body()->MutableExtension(list_ubs_by_host_response);
  for (int i = 0; i < res.lcs_size(); ++i) {
    LogicalChunk *dstLC = dstRes->add_lc_infos();
    ConstructLogicalChunkFromUDiskToUBS2(dstLC, res.lcs(i));
  }
  SendResponse(0, "");
}
