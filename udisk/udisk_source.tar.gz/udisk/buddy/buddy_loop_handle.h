#ifndef UDISK_BUDDY_LOOP_HANDLE_H_
#define UDISK_BUDDY_LOOP_HANDLE_H_

#include "uevent.h"
#include "loop_handle.h"

namespace udisk {
namespace buddy {

class BuddyLoopHandle : public uevent::LoopHandle {
 public:
  BuddyLoopHandle(uevent::UeventLoop *loop);
  virtual ~BuddyLoopHandle();

  static uevent::LoopHandle* CreateMyself(uevent::UeventLoop *loop) {
    return new BuddyLoopHandle(loop);
  }

  static void ConnectionSuccessHandle(const uevent::ConnectionUeventPtr &conn);

  static void ConnectionClosedHandle(const uevent::ConnectionUeventPtr &conn);

 private:
  uevent::UeventLoop *loop_;
};

}; // end of ns loki
}; // end of ns udisk

#endif
