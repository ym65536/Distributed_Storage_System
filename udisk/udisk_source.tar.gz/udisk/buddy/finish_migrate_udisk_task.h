#ifndef UDISK_BUDDY_MIGRATE_UDISK_TASK_HANDLE_H
#define UDISK_BUDDY_MIGRATE_UDISK_TASK_HANDLE_H

#include <string>
#include "pb_request_handle.h"
#include "message_util.h"
#include "udisk_message.h"

namespace uevent {
class UeventLoop;
class ConnectionUevent;
};

namespace udisk {
namespace buddy {

class FinishMigrateUDiskTaskHandle : public uevent::PbRequestHandle {
 public:
  FinishMigrateUDiskTaskHandle(uevent::UeventLoop* loop) {}
  virtual ~FinishMigrateUDiskTaskHandle() {}

  MYSELF_CREATE(FinishMigrateUDiskTaskHandle);

  std::shared_ptr<FinishMigrateUDiskTaskHandle> This() {
    return std::dynamic_pointer_cast<FinishMigrateUDiskTaskHandle>(
        shared_from_this());
  }

  void Timeout();
  void SendResponse(uint32_t retcode, const char* message);

  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         ucloud::UMessage* um);
  void EntryMetaResponse(ucloud::UMessage* msg);

 private:
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage response_;
  std::string session_no_;
};

};  // end of ns metaserver
};  // end of ns udisk

#endif
