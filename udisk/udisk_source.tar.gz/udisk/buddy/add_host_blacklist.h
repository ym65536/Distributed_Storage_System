#ifndef UDISK_BUDDY_ADD_HOST_BLACKLIST_H
#define UDISK_BUDDY_ADD_HOST_BLACKLIST_H

#include <string>
#include "message_util.h"
#include "pb_request_handle.h"
#include "udisk_message.h"

namespace uevent {
class UeventLoop;
class ConnectionUevent;
};  // namespace uevent

namespace udisk {
namespace buddy {

class AddHostBlacklistHandle : public uevent::PbRequestHandle {
 public:
  AddHostBlacklistHandle(uevent::UeventLoop* loop) {}
  virtual ~AddHostBlacklistHandle() {}

  MYSELF_CREATE(AddHostBlacklistHandle);

  std::shared_ptr<AddHostBlacklistHandle> This() {
    return std::dynamic_pointer_cast<AddHostBlacklistHandle>(
        shared_from_this());
  }

  void TimeOut();
  void SendResponse(uint32_t retcode, const std::string& message);

  virtual void EntryInit(const uevent::ConnectionUeventPtr& conn,
                         ucloud::UMessage* um);
  void EntryMetaResponse(ucloud::UMessage* msg);

 private:
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage response_;
};

};  // namespace buddy
};  // namespace udisk

#endif
