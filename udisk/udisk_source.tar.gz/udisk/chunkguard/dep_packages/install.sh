#!/bin/bash

install_check() {
  version=$(python --version 2>&1 | awk '{print $2}')
  ret=$(echo $version | grep "2.6")
  if [[ ! -z $ret ]]; then
    echo "2.6"
  else
    echo "2.7"
  fi
}

install_zkpython() {
  python -c "import zookeeper" > /dev/null 2>&1
  if [ ! $? -eq 0 ];then
    version=$(install_check)
    if [[ "$version" == "2.7" ]]; then
      tar -zxmvf zkpython-0.4.2-py2.7-linux-x86_64.egg.tar.gz -C /usr/lib64/python2.7/site-packages
      mv /usr/lib64/python2.7/site-packages/zkpython-0.4.2-py2.7-linux-x86_64.egg/zkpython.pth /usr/lib64/python2.7/site-packages
    else # 2.6
      tar -zxmvf zkpython-0.4.2-py2.6-linux-x86_64.egg.tar.gz -C /usr/lib64/python2.6/site-packages
      mv /usr/lib64/python2.6/site-packages/zkpython-0.4.2-py2.6-linux-x86_64.egg/zkpython.pth /usr/lib64/python2.6/site-packages
    fi
  fi
}

install_protobuf() {
  python -c "import google.protobuf" > /dev/null 2>&1
  if [ ! $? -eq 0 ];then
    tar -zxmvf protobuf-3.0.0-py2.7.egg.tar.gz -C /usr/lib64/python2.7/site-packages
    mv /usr/lib64/python2.7/site-packages/protobuf-3.0.0-py2.7.egg/protobuf.pth /usr/lib64/python2.7/site-packages
  fi
}

install_zkpython

#install_protobuf
