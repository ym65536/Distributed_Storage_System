#!/bin/sh

if [ ! $# -eq 1 ];then
  echo "Usage: $0 <devel | release>"
  exit 1
fi

PROTOC=/usr/bin/protoc

message_build() {
  if [ -e message ];then
    echo "message dir exists ! rm -rf message"
    rm -rf message
  fi
  mkdir message
  
  $PROTOC --proto_path=${HOME}/message/proto --python_out=message ${HOME}/message/proto/ucloud.proto
  
  $PROTOC --proto_path=${HOME}/message/proto --python_out=message ${HOME}/message/proto/uns.55000.56000.proto
  mv message/uns/55000/56000_pb2.py message/uns_pb2.py
  rm -rf message/uns
  
  ${PROTOC} --proto_path=${HOME}/message/proto --python_out=message ${HOME}/message/proto/udisk.320000.322000.proto
  mv message/udisk/320000/322000_pb2.py message/udisk_pb2.py
  rm -rf message/udisk
}

devel_build() {
  message_build
}

release_build() {
  message_build
  rm -rf build
  mkdir -p build/chunkguard
  cp -r message build/chunkguard
  cp chunkguard.py build/chunkguard
  cp wiwo_python.py build/chunkguard
  cp -r dep_packages build/chunkguard
  cp chunkguard build/chunkguard
  cd build
  tar -zcvf chunk_guard.tar.gz chunkguard
  cd -
  rm -rf message
  #rm -rf build
}

if [ $1 == "devel" ];then
  devel_build
else
  release_build
fi
