#!/usr/bin/env python2
# coding=utf8

import sys, os
# add the proto path
sys.path.append(os.path.abspath(os.path.join(__file__, '../message')))

import socket
import struct
import uuid
import random
import SocketServer

import ucloud_pb2 as ucloud

'''
@summary: convert a string into hex
@param data: the string to be converted 
'''
def str2hex(data):
    xbytes = ""
    for c in data:
        xbytes += "\\x%02x" % ord(c) 
    return xbytes
    
'''
@summary: The message used to communicate in WIWO
'''
class WIWOMessage:
    '''
    @summary: make up the head and body of UMessage
    '''
    def build(self, version, magic_flag, random_num,
                flow_no, session_no, message_type, worker_index,
                tint_flag, source_entity, dest_entity, call_purpose, 
                access_token, reserved, descriptor, internal_message):
        # build a UMessage
        self.umsg = ucloud.UMessage()
        # set the Head of UMessage
        self.umsg.head.version = version
        self.umsg.head.magic_flag = magic_flag;
        self.umsg.head.random_num = random_num
        self.umsg.head.flow_no = flow_no
        self.umsg.head.session_no = session_no
        self.umsg.head.message_type = message_type
        self.umsg.head.worker_index = worker_index
        self.umsg.head.tint_flag = tint_flag
        self.umsg.head.source_entity = source_entity
        self.umsg.head.dest_entity = dest_entity
        self.umsg.head.call_purpose = call_purpose
        self.umsg.head.access_token = access_token
        self.umsg.head.reserved = reserved

        # add the request into body
        self.umsg.body.Extensions[descriptor].CopyFrom(internal_message)
        
      
    '''
    @summary: encode the object to a string
    '''
    def encode(self):
        format = "I%ds" % self.umsg.ByteSize()
        return struct.pack(format, socket.htonl(self.umsg.ByteSize()), self.umsg.SerializeToString())
    
    '''
    @param buf: decode the buffer to a object
    '''
    def decode(self, buf):
        msg_size = socket.ntohl(struct.unpack("I", buf[0:4])[0])
        format = "%ds" % msg_size
        msg = struct.unpack(format, buf[4:])[0]
        self.umsg = ucloud.UMessage()
        self.umsg.ParseFromString(msg)
    
    '''
    @summary: get internal message
    @param desc: the descriptor
    '''
    def get_internal_message(self, desc):
        return self.umsg.body.Extensions[desc]


class MockService:
    '''
    @summary: construct a MockService
    @param req_type: the message type of request
    @param req_desc: the descriptor of request 
    @param res_type: the message type of response
    @param res_desc: the descriptor of response 
    @param res: the response object sent back 
    '''
    def __init__(self, req_type, req_desc, 
                 res_type = None, res_desc = None):
        assert req_type is not None
        assert req_desc is not None
        
        self.req_type = req_type
        self.req_desc = req_desc
        
        '''If res_type is None, it means the service doesn't has response'''
        self.res_type = res_type
        self.res_desc = res_desc
        
    def callback(self, req):
        '''You can override it.'''
        return None

'''XXX: use a global variable to save services'''
services = {}
    
'''
@summary: 
'''
class RequestHandler(SocketServer.StreamRequestHandler):
    buf_size = 65535
    
    def handle(self):
        data = self.request.recv(self.buf_size)
        #print "data:%s" % str2hex(data)
        # decode the length of message
        try:
            msg_len = socket.ntohl(struct.unpack("I", data[0:4])[0])
        except:
            print "Invalid request, data:%s" % str2hex(data)
            return -1
        
        rest_len = msg_len - len(data)
        if rest_len > 0:           
            # receive the remaining message
            while True:                                    
                s = self.request.recv(self.buf_size)             
                data += s 
                if not s: break         
                # calculate the remaining length
                rest_len -= len(s)
                if rest_len <= 0:
                    break; # nothing to be received 
                                                             
        msg_in = WIWOMessage()
        msg_in.decode(data)
        print msg_in.umsg
                 
        # find the request in services
        serv = services.get(msg_in.umsg.head.message_type)
                
        # if got it in dictionary
        if serv is not None:
            # if need response
            if serv.res_type is not None:
                req = msg_in.get_internal_message(serv.req_desc)
                res = serv.callback(req)
                if res is None:
                    # no need response
                    return 0
                
                # create the wiwo message for response
                msg_out = WIWOMessage()
                msg_out.build(msg_in.umsg.head.version,
                              msg_in.umsg.head.magic_flag,
                              msg_in.umsg.head.random_num,
                              msg_in.umsg.head.flow_no,
                              msg_in.umsg.head.session_no,
                              serv.res_type, 
                              msg_in.umsg.head.worker_index, 
                              msg_in.umsg.head.tint_flag,
                              msg_in.umsg.head.source_entity,
                              msg_in.umsg.head.dest_entity,
                              msg_in.umsg.head.call_purpose,
                              msg_in.umsg.head.access_token,
                              msg_in.umsg.head.reserved,
                              serv.res_desc, res)
                # send out
                data = msg_out.encode()
                self.request.sendall(data)
                # end 
        else :
            print "unknown service:%d" % msg_in.umsg.head.message_type
        
'''
@summary: A simple MockServer for WIWO, but implemented crudely
          Update it later...
'''
class MockServer:
    
    def __init__(self, port):
        self.port = int(port)
        # set bind_and_activate False, so that the socket can be set REUSEADDR
        self.server = SocketServer.ThreadingTCPServer(('localhost', self.port), 
                                                      RequestHandler,
                                                      False)
        self.server.allow_reuse_address = True
        self.server.timeout = 60
        self.server.server_bind()
        self.server.server_activate()
        
    def register_service(self, service):
        assert isinstance(service, MockService)
        '''Use the req_type to be key'''
        services[service.req_type] = service       
        
    def run(self):   
        assert len(services) > 0
            
        self.server.serve_forever()

        
    def stop(self):
        self.socket.close()
        return
    
'''
@summary: A simple client for WIWO 
'''
class Client:
    def __init__(self, ip, port):
        self.ip = str(ip)
        self.port = int(port)
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        
    def connect(self):
        self.socket.connect((self.ip, self.port))
        return 
    
    def close(self):
        self.socket.close()
    
    '''
    @summary: send out a request
    @param req: the request object.
    @param req_type: the message type of request.
    @param req_desc: the descriptor of request.
    @param res_desc: the descriptor of response, 
                     if it's None, don't wait for response
    '''
    def request(self, req, req_type, req_desc, res_desc):
        # create the wiwo message
        msg_out = WIWOMessage()
        msg_out.build(1, 0x12340987, random.randint(0, 100000),
                      1, str(uuid.uuid4()), req_type, 99999, 
                      False, 0, 0, "wiwo_test", "", "",
                      req_desc, req)
        # send out
        data = msg_out.encode()
        self.socket.sendall(data)
        
        # if not wait for response
        if res_desc is None:
            return
        
        # sync to receive the response
        size = 65535   # the size of socket buffer
        data = self.socket.recv(size)
        # decode the length of message
        try:
            msg_len = socket.ntohl(struct.unpack("I", data[0:4])[0])
        except:
            #print "Invalid response, data:%s" % str2hex(data)
            return -1
        
        rest_len = msg_len - len(data)
        if rest_len > 0:           
            # receive the remaining message
            while True:                                    
                s = self.socket.recv(size)             
                data += s 
                if not s: break         
                # calculate the remaining length
                rest_len -= len(s)
                if rest_len <= 0:
                    break; # nothing to be received
        
        msg_in = WIWOMessage()
        msg_in.decode(data)
        
        # return the response
        return msg_in.get_internal_message(res_desc)


