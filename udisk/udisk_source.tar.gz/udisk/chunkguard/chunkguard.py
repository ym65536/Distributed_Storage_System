#!/usr/bin/python
# -*- coding: utf-8 -*-
# ts=2, sw=2

import os, sys, commands
import ConfigParser, getopt
import logging, time
sys.path.append(os.path.abspath(os.path.join(__file__, '../message')))
import udisk_pb2, uns_pb2, wiwo_python
import zookeeper
import re
import subprocess
from logging.handlers import TimedRotatingFileHandler
from logging.handlers import RotatingFileHandler

VERSION_TAG = "1.01" # 版本变动需要改这里
TOP_COUNT = 2 # 通过top命令获取pids_stat的次数

def daemon():
  pid = os.fork()
  if pid > 0:
    sys.exit(0)

  os.chdir("/")
  os.setsid()
  os.umask(0)

  pid = os.fork()
  if pid > 0:
    sys.exit(0)
  os.close(0)
  os.close(1)
  os.close(2)

class ChunkGuard:
  def __init__(self, config, logger):
    self._config = config
    self._logger = logger

  def chunks_stat(self):
    chunks = self.running_chunk()
    self._logger.info("running_chunk: %s" % (str(chunks)))

    ret = []

    all_pids = self.pids_stat()
    all_disks = self.disks_stat(self._config.iostat_interval(),\
                                self._config.iostat_count())

    for i in chunks:
      threads = self.chunk_threads(i["pid"])
      self._logger.info("threads: %s" % (str(threads)))

      threads_stat = []
      for th in threads:
        stat = self.pid_stat(all_pids, th)
        if not stat:
          self._logger.error("can not find thread %s in all_pids: %s" % (th, all_pids))
          continue
        comm = self.command_pid(th)
        if comm.find("IOMainListener") >= 0 or comm.find("worker-") >= 0:
          ## fix command
          stat["command"] = comm
          threads_stat.append(stat)

      if len(threads_stat) == 0:
        self._logger.error("can not get threads stat from all_pids %s" % (all_pids))
        continue

      block = self.dir_block(i["storage_type"], i["data_dir"], i["chunk_id"])
      if block == None:
        disk_stat = None
      else:
        disk_stat = self.disk_stat(all_disks, block)
      ret.append({"chunk" : i, "stat" : threads_stat, "disk_stat" : disk_stat})
    return ret

  def command_pid(self, pid):
    comm = os.path.join("/proc", pid, "comm")
    fd = open(comm)
    comm = fd.readline()
    comm = comm.strip()
    return comm

  def pid_stat(self, all_pids, pid):
    count = 0
    for i in all_pids:
      if not i.startswith(pid):
        continue
      fields = i.split()
      if fields[0] != pid:
        continue
      count = count + 1
      # 只取最后一次
      if count < TOP_COUNT:
        continue
      stat = {"pid" : fields[0], "user" : fields[1],\
              "priority" : fields[2], "nice" : fields[3],\
              "virt" : fields[4], "res" : fields[5],\
              "state" : fields[7], "cpu" : fields[8],\
              "mem" : fields[9], "command" : fields[11]}
      return stat
    return None

  def disk_stat(self, all_disks, device):
    for i in all_disks:
      fields = i.split()
      dev_name = fields[0]
      if device.find(dev_name) < 0:
        continue
      stat = {"dev" : dev_name, "rrqm" : fields[1], "wrqm" : fields[2],\
              "r" : fields[3], "w" : fields[4],\
              "rkb" : fields[5], "wkb" : fields[6],\
              "avgrq-sz" : fields[7], "avgqu-sz" : fields[8],\
              "await" : fields[9], "svctm" : fields[10],\
              "util" : fields[13]}
      return stat
    return None

  """
    获取chunk_id是否在设备dev上(裸盘)
  """
  def is_chunk_dev(self, dev, chunk_id):
    cmd = ("/root/udisk/chunk/tools/raw_chunk_storage_tool dumpSuperBlock /dev/%s | grep chunk_id:"
           % dev)
    pipe = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    output = pipe.communicate()
    output = output[0]
    status = pipe.returncode
    if status != 0:
      self._logger.error("Failed to exec raw_chunk_storage_tool, chunk_id:%s, status:%s, output:%s" % (chunk_id, status, output))
      return False

    chunk_id_info = output.strip().split(':')
    if chunk_id_info[0].strip() != "chunk_id":
      self._logger.error("Failed to get chunk_id, chunk_id_info:%s" % str(chunk_id_info))
      return False
    if int(chunk_id_info[1].strip()) == int(chunk_id):
      return True
    return False

  """
    获取chunk chunk_id的块设备(裸盘)
  """
  def dir_block_raw(self, chunk_id):
    cmd = "lsblk | grep disk | grep -v sda | awk '{print $1}'"
    pipe = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    output = pipe.communicate()
    output = output[0]
    status = pipe.returncode
    if status != 0:
      self._logger.error("failed to block by file. status:%d, output:%s" % (status, output))
      return None
    devs = output.strip().split("\n")
    for dev in devs:
      dev = dev.strip()
      if self.is_chunk_dev(dev, chunk_id):
        return "dev/" + dev
    self._logger.error("Failed to get dev name of chunk:%s, chunk_id:%s" % (str(devs), chunk_id))
    return None

  """
    获取chunk data_dir的块设备(文件系统)
  """
  def dir_block_file(self, data_dir):
    if data_dir == None:
      self._logger.error("failed to block by file. data_dir is none")
      return None
    cmd = "df -h " + data_dir + " | tail -n 1"
    status, output = commands.getstatusoutput(cmd)
    if status != 0:
      self._logger.error("failed to block by file. status:%d" % status)
      return None
    return output.split()[0]

  """
    获取chunk的块设备
  """
  def dir_block(self, storage_type, data_dir, chunk_id):
    if storage_type == None:
      storage_type = "file"
    if storage_type == "raw":
      return self.dir_block_raw(chunk_id)
    elif storage_type == "file":
      return self.dir_block_file(data_dir)

    self._logger.error("failed to get dir block. storage_type(%s) invalid" % storage_type)
    return None

  """
    @brief 获取正在运行的chunk服务进程
    通过扫描chunk的所有的配置文件来定位
    正在运行的chunk服务
  """
  def running_chunk(self):
    ret = []
    for i in os.listdir(self._config.chunk_config_dir()):
      cmd = "ps -ef | grep " + i + " | grep chunk | grep -v grep"
      status, output = commands.getstatusoutput(cmd)
      if status != 0:
        continue
      pid = output.split()[1]
      config_file = os.path.join(self._config.chunk_config_dir(), i)
      ip, port, data_dir, chunk_id, storage_type = self.chunk_address_from_file(config_file)
      ret.append({"pid" : pid, "ip" : ip, "port" : port, "data_dir" : data_dir, "chunk_id" : chunk_id, "storage_type" : storage_type})
    return ret

  def chunk_address_from_file(self, config_file):
    config = ConfigParser.RawConfigParser()
    config.read(config_file)
    listen_ip = config.get("network", "listen_ip")
    man_port = config.get("network", "listen_port")
    chunk_id = config.get("common", "my_id")
    try:
      data_dir = config.get("common", "chunk_dir")
    except Exception as e:
      data_dir = None

    try:
      storage_type = config.get("common", "storage_type")
    except Exception as e:
      storage_type = None
    return (listen_ip, man_port, data_dir, chunk_id, storage_type)

  """
    @brief 获取指定的chunk服务进程的所有线程
  """
  def chunk_threads(self, pid):
    task_dir = os.path.join("/proc", pid, "task")
    if not os.path.exists(task_dir) or not os.path.isdir(task_dir):
      return None
    return os.listdir(task_dir)

  def odin_address(self):
    odin_path = self._config.odin_path()
    zk_server = self._config.zk_server()
    try:
      zookeeper.set_log_stream(open("/dev/null"))
      zkclient = zookeeper.init(zk_server)
    except Exception as e:
      self._logger.error("connect zookeeper server %s faied" % (zk_server))
      return None, None

    try:
      data = zookeeper.get(zkclient, odin_path)
    except Exception as e:
      zookeeper.close(zkclient)
      self._logger.error("odin path %s is not found" % (odin_path))
      return None, None
    zookeeper.close(zkclient)

    if not data or len(data) == 0:
      return None, None
    nc = uns_pb2.NameNodeContent()
    nc.ParseFromString(data[0])

    #if not nc.has_reserved():
    #  return None, None
    port_pair = udisk_pb2.OdinPortPair()
    port_pair.ParseFromString(nc.reserved)
    return nc.ip, port_pair.chunk_port

  def start(self):
    while True:
      last_time = time.time()
      time.sleep(self._config.loop_interval())
      odin_ip, odin_port = self.odin_address()
      if not odin_ip or not odin_port:
        self._logger.error("can not get the address of odin server from path %s" % (self._config.odin_path()))
        continue
      else:
        self._logger.info("current active odin server %s:%s" % (odin_ip, str(odin_port)))

      odin_client = wiwo_python.Client(odin_ip, odin_port)
      try:
        odin_client.connect()
      except Exception as e:
        self._logger.error("connect odin server failed %s" % (str(e)))
        continue

      try:
        stat = self.chunks_stat()
        if 0 == len(stat):
          self._logger.warning("not found running chunk")
          continue
        request = udisk_pb2.ReportChunkGuardOdinRequest()
        self.report_request_build(stat, request, last_time)
        self._logger.info("Request: %s" % str(request))
      except Exception as e:
        self._logger.error("get chunk stat failed: %s" % (str(e)))
        continue

      try:
        response = odin_client.request(request, udisk_pb2.REPORT_CHUNK_GUARD_ODIN_REQUEST,\
                            udisk_pb2.report_chunk_guard_odin_request,\
                            udisk_pb2.report_chunk_guard_odin_response)
        self._logger.info("odin response: \n%s" % (str(response)));
      except Exception as e:
        self._logger.error("send request to %s:%s failed" % (odin_ip, str(odin_port)))
        continue

  def report_request_build(self, stat, req, last):
    now = time.time()
    for i in stat:
      chunk_state = req.states.add()
      chunk_state.ip = i["chunk"]["ip"]
      chunk_state.port = int(i["chunk"]["port"])
      chunk_state.stats_time = int(now)
      chunk_state.stats_period = int(now - last)

      for j in i["stat"]:
        thread_state = chunk_state.thread_state.add()
        thread_state.name = j["command"]
        thread_state.cpu_util = float(j["cpu"])

      chunk_state.disk_state.dev_name = i["disk_stat"]["dev"]
      chunk_state.disk_state.r_iops = int(float(i["disk_stat"]["r"]))
      chunk_state.disk_state.r_bw = int(float(i["disk_stat"]["rkb"]))
      chunk_state.disk_state.w_iops = int(float(i["disk_stat"]["w"]))
      chunk_state.disk_state.w_bw = int(float(i["disk_stat"]["wkb"]))
      chunk_state.disk_state.latency = int(float(i["disk_stat"]["await"]) * 1000)
      chunk_state.disk_state.util = float(i["disk_stat"]["util"])

  def pids_stat(self):
    cmd_count = "-n %d" % TOP_COUNT
    process = subprocess.Popen(["top", "-b", "-H", cmd_count], stdout=subprocess.PIPE)
    output = process.communicate()
    output = output[0]
    pids = output.split("\n")[7:]
    ret = []
    for i in pids:
        ret.append(i.strip())
    return ret

  def disks_stat(self, interval = 1, count = 4):
    cmd = "iostat -d -k -x " + str(interval) + " " + str(count)
    cmd = cmd + " | grep Device -A 65535"
    status, output = commands.getstatusoutput(cmd)
    if status != 0:
      return None
    data = output.split("\n")
    data.reverse()
    ret = []
    for i in data:
      i = i.strip()
      if not i:
        continue
      if i.find("Device") < 0:
        ret.append(i.strip())
      else:
        break
    return ret

class UDiskLogger():
  def __init__(self, logname, loglevel, logger='', split='H'):
    self.logger = logging.getLogger(logger)
    self.logger.setLevel(loglevel)

    #日志打印格式
    log_fmt = '[%(asctime)s][%(process)d][%(levelname)s][line:%(lineno)s]: %(message)s'
    formatter = logging.Formatter(log_fmt)
    #创建TimedRotatingFileHandler对象
    handler = TimedRotatingFileHandler(filename=logname, when=split, interval=1, backupCount=30)
    handler.suffix = "%Y-%m-%d_%H-%M-%S.log"
    handler.extMatch = re.compile(r"^\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}.log$")
    handler.setFormatter(formatter)
    self.logger.addHandler(handler)

  def getHandler(self):
    return self.logger;

class Config:
  def __init__(self, f):
    self._file = f

  def load(self):
    config = ConfigParser.RawConfigParser()
    config.read(self._file)

    self._log_file = config.get("logging", "log_file")
    self._log_level = config.get("logging", "log_level")
    self._chunk_config_dir = config.get("common", "chunk_config_dir")
    self._odin_path = config.get("names", "odin")
    self._zk_server = config.get("zookeeper", "server")
    try:
      self._loop_interval = int(config.get("common", "loop_interval"))
      if self._loop_interval <= 0:
        self._loop_interval = 2
    except:
      self._loop_interval = 2
    try:
      self._iostat_interval = int(config.get("common", "iostat_interval"))
      if self._iostat_interval <= 0:
        self._iostat_interval = 1
    except:
      self._iostat_interval = 1
    try:
      self._iostat_count = int(config.get("common", "iostat_count"))
      if self._iostat_count <= 1:
        self._iostat_count = 2
    except:
      self._iostat_count = 2

  def log_file(self):
    return self._log_file

  def log_level(self):
    return self._log_level

  def chunk_config_dir(self):
    return self._chunk_config_dir

  def odin_path(self):
    return self._odin_path

  def zk_server(self):
    return self._zk_server

  def iostat_interval(self):
    return self._iostat_interval

  def iostat_count(self):
    return self._iostat_count

  def loop_interval(self):
    return self._loop_interval

def help():
  print sys.argv[0] + " Usage: [-h] [-f foreground run] <-c config file>"

def main():
  try:
    options, args = getopt.getopt(sys.argv[1:], "hfvc:", [])
  except getopt.GetoptError as e:
    print str(e)
    help()
    sys.exit(1)

  config_file = None
  foreground = False
  for option, value in options:
    if option == "-h":
      help()
      sys.exit(0)
    elif option == "-f":
      foreground = True
    elif option == "-v":
      print "version tag: %s" % VERSION_TAG
      sys.exit(0)
    elif option == "-c":
      config_file = value
    else:
      help()
      sys.exit(1)

  if not config_file:
    print "-c option is required"
    help()
    sys.exit(1)

  if not os.path.exists(config_file) or not os.path.isfile(config_file):
    print "file " + config_file + " is not found"
    sys.exit(1)

  config = Config(config_file)
  config.load()

  log_level = config.log_level()
  log_level = log_level.lower()

  if "debug" == log_level:
    log_level = logging.DEBUG
  else:
    log_level = logging.INFO

  if not foreground:
    daemon()
    log_file = config.log_file()
    logger = UDiskLogger(log_file, log_level, split='midnight').getHandler()
  else:
    logging.basicConfig(level = log_level,\
                        stream = sys.stderr,\
                        format='%(asctime)s - %(levelname)s: %(message)s')
    logger = logging.getLogger()

  chunk_guard = ChunkGuard(config, logger)
  chunk_guard.start()

if __name__ == "__main__":
  main()
