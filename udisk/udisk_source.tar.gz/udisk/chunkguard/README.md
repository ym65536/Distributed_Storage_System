# 研发环境构建
研发环境仅仅需要构建message,其中message的构建
依赖当前用户目录下的message目录
./build.sh devel

# 发布的包的构建

./build.sh release


# 包的安装

* 1)  将构建好的包copy到要发布的机器上，然后解压
* 2)  安装依赖包，cd dep_packages && ./install.sh
