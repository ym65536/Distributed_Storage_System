#ifndef UDISK_NEW_UNIX_SOCK_HANDLE_H
#define UDISK_NEW_UNIX_SOCK_HANDLE_H

#include <string>

namespace uevent {
class UeventLoop;
};

namespace udisk {
namespace block_gate_proxy {

class FdDispatcher;

class NewUnixSockHandle {
 public:
  NewUnixSockHandle(const std::string& unix_sock);
  ~NewUnixSockHandle();

  void Start();

 private:
  uevent::UeventLoop* loop_;
  std::string unix_sock_;
  FdDispatcher* fd_dispatcher_;
};

};  // end of ns block_gate_proxy
};  // end of ns udisk

#endif
