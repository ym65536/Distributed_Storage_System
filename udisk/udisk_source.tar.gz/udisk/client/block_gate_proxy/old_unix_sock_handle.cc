#include "old_unix_sock_handle.h"

#include "fd_dispatcher.h"
#include "eventloop_libevent.h"

namespace udisk {
namespace block_gate_proxy {

OldUnixSockHandle::OldUnixSockHandle(const std::string &unix_sock)
    : unix_sock_(unix_sock), fd_dispatcher_(nullptr) {}

OldUnixSockHandle::~OldUnixSockHandle() {
  if (fd_dispatcher_) {
    delete fd_dispatcher_;
  }
}

void OldUnixSockHandle::Start() {
  loop_ = thread_.StartLoop();
  loop_->RunInLoop(std::bind(&OldUnixSockHandle::StartInLoop, this));
}

void OldUnixSockHandle::StartInLoop() {
  fd_dispatcher_ = new FdDispatcher(loop_, unix_sock_);
  fd_dispatcher_->Init();
  fd_dispatcher_->Start();
}

};  // end of ns block_gate_proxy
};  // end of ns udisk
