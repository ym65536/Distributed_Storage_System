#ifndef UDISK_BLOCK_GATE_PROXY_H_
#define UDISK_BLOCK_GATE_PROXY_H_

#include <memory>

namespace udisk {

namespace common {
class NameContainer;
}

namespace block_gate_proxy {

class MyConfigParser;

extern std::unique_ptr<common::NameContainer> g_name_container;
extern std::shared_ptr<MyConfigParser> g_config_parser;

}  // namespace block_gate_proxy
}  // namespace udisk

#endif
