#include "fd_dispatcher.h"
#include <functional>
#include <unistd.h>
#include <arpa/inet.h>
#include "usock_address.h"
#include "logging.h"
#include "message_util.h"
#include "uevent.h"
#include "listener_libevent.h"
#include "connector_libevent.h"
#include "block_gate_proxy.h"
#include "qemu_io_proto.h"
#include "my_config_parser.h"
#include "login_gate_strategy.h"

namespace udisk {
namespace block_gate_proxy {

using namespace uevent;
using namespace base;
using namespace common;

FdDispatcher::FdDispatcher(UeventLoop* loop,
                           const std::string &unix_sock)
    : loop_(loop),
      unix_sock_(unix_sock),
      gate_ctor_id_(0) {
}

void FdDispatcher::Init() {
  unlink(unix_sock_.c_str());
  UsockAddress listen_addr(unix_sock_);
  listener_.reset(reinterpret_cast<ListenerUevent*>(new ListenerLibevent(
      loop_, listen_addr, unix_sock_ + "_listener")));
  listener_->SetConnectionSuccessCb(std::bind(&FdDispatcher::QemuConnSuccessCb,
      this, std::placeholders::_1));
  listener_->SetConnectionClosedCb(std::bind(&FdDispatcher::QemuConnClosedCb,
      this, std::placeholders::_1));
  listener_->SetMessageReadCb(std::bind(&FdDispatcher::QemuConnReadCb,
      this, std::placeholders::_1));
  login_strategy_.reset(new LoginGateStrategy(loop_, this));
}

void FdDispatcher::Start() {
    listener_->Start();
}

void FdDispatcher::QemuConnSuccessCb(const ConnectionUeventPtr& conn) {
  LOG_INFO << "new connection from qemu, connection name: "
           << conn->GetName() << "connection id: " << conn->GetId(); 
}

void FdDispatcher::QemuConnClosedCb(const ConnectionUeventPtr& conn) {
  LOG_INFO << "disconnect from qemu, connection name: "
           << conn->GetName() << "connection id: "<< conn->GetId();
  //由listener中统一的入口对accept的连接进行删除和析构
  listener_->RemoveConnection(conn);
  DelLoginInfoEntryByConn(conn);
}

void FdDispatcher::QemuConnReadCb(const ConnectionUeventPtr& conn) {
  size_t readable = conn->ReadableLength();
  uint32_t size;
  while (readable >= sizeof(QemuIOHead)) {  // 数据不够不能清除
    conn->ReceiveData(&size, sizeof(size));
    if (readable >= size) {  // data len enough
      QemuIOHead head;
      conn->RemoveData(&head, sizeof(QemuIOHead));
      readable -= size;
      switch (head.cmd) {
        case QEMU_CMD_LOGIN:
          // qemu 里忘记设置这个命令的MAGIC_NUMBER了
          LOG_DEBUG << "login request from qemu:" << DumpQemuIOHead(head);
          LoginRequestHandle(head, conn);
          break;
        case QEMU_CMD_RESIZE:
          LOG_INFO << "resize request from qemu:" << DumpQemuIOHead(head);
          DispatchResizeFd(head, conn);
          break;
        default: // 不应该处理其他的命令
          LOG_ERROR << "cmd: " << head.cmd << "not login";
          listener_->RemoveConnection(conn);
          break;
      }
    } else {  // 数据不够， 退出
      break;
    }
  }
}

ConnectorUeventPtr FdDispatcher::CreateGateConnector(const std::string& gate_name) {
  std::string gate_addr = g_config_parser->get_gate_addr(gate_name);
  if (gate_addr == std::string("")) {
    LOG_ERROR << "can't find the specified gate: " << gate_name;
    return ConnectorUeventPtr();
  }
  std::string ctor_name = gate_name + std::to_string(gate_ctor_id_);
  gate_ctor_id_++;
  ConnectorUeventPtr ctor = std::make_shared<ConnectorLibevent>(
      loop_, gate_addr, ctor_name);
  gate_connectors_[ctor_name] = ctor;
  ctor->SetConnectionSuccessCb(std::bind(&FdDispatcher::GateConnSuccessCb,
        this, std::placeholders::_1));
  ctor->SetConnectionClosedCb(std::bind(&FdDispatcher::GateConnClosedCb,
        this, std::placeholders::_1));
  ctor->SetMessageReadCb(std::bind(&FdDispatcher::GateConnReadCb,
        this, std::placeholders::_1));
  return ctor;
}


void FdDispatcher::GateConnSuccessCb(const ConnectionUeventPtr& conn) {
  LOG_INFO << "connect to gate success, connection name: "
           << conn->GetName() << "connection id: " << conn->GetId(); 
}

//框架产生的connection的name和其所属的connector name相同
//gate 接收到fd后会主动关闭连接，这时释放ctor
void FdDispatcher::GateConnClosedCb(const ConnectionUeventPtr& conn) {
  std::string conn_name = conn->GetName(); // 和ctor name相同
  LOG_INFO << "disconnect from gate, connection name: "
           << conn_name << "connection id: "<< conn->GetId();
  DelGateConnector(conn_name);
}

// 防止主动析构ctor, 重复释放ctor, 导致core
void FdDispatcher::DelGateConnector(std::string& name) {
  auto it = gate_connectors_.find(name);
  if (it != gate_connectors_.end()) {
    gate_connectors_.erase(it);
  } else {
    LOG_ERROR << "gate connector has been deleted, gate connector name: "
              << name;
  }

}

void FdDispatcher::GateConnReadCb(const ConnectionUeventPtr& conn) {
}

void FdDispatcher::DelLoginInfoEntryByConn(const ConnectionUeventPtr& conn) {
  auto it = flowno_to_login_entry_.begin();
  while (it != flowno_to_login_entry_.end()) {
    if (it->second->conn->GetId() == conn->GetId()) {
      LOG_INFO << "delete login info entry, conn_id:" << conn->GetId()
               << " extern_id: " << it->second->login_info.udisk_id
               << " flowno: " << it->second->flowno;
      flowno_to_login_entry_.erase(it++);
    } else {
      it++;
    }
  }
}

void FdDispatcher::DelLoginInfoEntryByFlowno(uint32_t flowno) {
  auto it = flowno_to_login_entry_.find(flowno);
  if (it == flowno_to_login_entry_.end()) {
      LOG_ERROR << "login info entry has deleted, flowno:" << flowno;
      return;
  }
  LOG_INFO << "delete login info entry, conn_id:" << it->second->conn->GetId()
           << " extern_id: " << it->second->login_info.udisk_id
           << " flowno: " << it->second->flowno;
  flowno_to_login_entry_.erase(it);
}

std::shared_ptr<LoginInfoEntry>
    FdDispatcher::GetLoginInfoEntry(uint32_t flowno) {
  auto it = flowno_to_login_entry_.find(flowno);
  if (it == flowno_to_login_entry_.end()) {
    LOG_ERROR << "login info entry has deleted, flowno: " << flowno;
    return std::shared_ptr<LoginInfoEntry>();
  }
  return it->second;
}

void FdDispatcher::LoginRequestHandle(const QemuIOHead &head,
                                      const ConnectionUeventPtr& conn) {
  std::shared_ptr<LoginInfoEntry> entry(new LoginInfoEntry());
  conn->RemoveData(&entry->login_info, sizeof(QemuLoginInfo));
  entry->conn = conn;
  entry->flowno = MessageUtil::Flowno();
  entry->login_head = head;
  flowno_to_login_entry_.insert(std::make_pair(entry->flowno, entry));
  LOG_INFO << "udisk login extern id: " 
           << std::string(entry->login_info.udisk_id);
  login_strategy_->GetGateRequest(entry);
}

int FdDispatcher::Dispatch(std::shared_ptr<LoginInfoEntry> entry,
                           const std::string &gate_name, 
                           const std::string &trans_ip, 
                           uint32_t trans_port) {
  const ConnectorUeventPtr &gate_ctor = CreateGateConnector(gate_name);
  if (!gate_ctor) { // 没有这个gate_key对应的gate
    listener_->RemoveConnection(entry->conn);
    return -1;
  }
  std::string ctor_name = gate_ctor->GetName();
  if (gate_ctor->HasAvailableConnection() == false) {
    LOG_ERROR << "connection to gate not available, delete gate connector:"
              << ctor_name;
    DelGateConnector(ctor_name); // 释放connector
    listener_->RemoveConnection(entry->conn);
    return -1;
  }
  const ConnectionUeventPtr &gate_conn = gate_ctor->GetConnection();
  auto it = flowno_to_login_entry_.find(entry->flowno);
  if (it == flowno_to_login_entry_.end()) {
    LOG_ERROR << "qemu connection closed when get gate from access, extern_id: "
              << std::string(entry->login_info.udisk_id) << " flowno: "
              << entry->flowno;
    DelGateConnector(ctor_name); // 释放connector
    return -1;
  }
  LOG_INFO << "login info entry -- flowno: " << entry->flowno
           << " udisk id: " << entry->login_info.udisk_id
           << " udisk ip: " << entry->login_info.udisk_ip
           << " udisk port " << entry->login_info.udisk_port;
  // 对于trans_gate需要将trans_ip和trans_port附加在login请求后转发出去
  int login_data_len = 0;
  struct in_addr trans_ip_data;
  if (!trans_ip.empty()) {
    ::inet_pton(AF_INET, trans_ip.c_str(), &trans_ip_data);
    login_data_len = sizeof(QemuIOHead) + sizeof(QemuLoginInfo)
                          + sizeof(trans_ip_data) + sizeof(trans_port);
  }
  else {
    login_data_len = sizeof(QemuIOHead) + sizeof(union QemuCommandBody);
  }
  LOG_INFO << "login data len: " << login_data_len;
  char* login_data = reinterpret_cast<char*>(malloc(login_data_len));
  char* ptr = login_data;
  memset(ptr, 0, login_data_len);
  memcpy(ptr, &entry->login_head, sizeof(QemuIOHead));
  ptr += sizeof(QemuIOHead);
  memcpy(ptr, &entry->login_info, sizeof(QemuLoginInfo));
  if (!trans_ip.empty()) {
    ptr += sizeof(QemuLoginInfo);
    memcpy(ptr, &trans_ip_data, sizeof(trans_ip_data));
    ptr += sizeof(trans_ip_data);
    memcpy(ptr, &trans_port, sizeof(trans_port));
  }
  int ret = SendFd(gate_conn->GetFd(), login_data, login_data_len,
      entry->conn->GetFd());
  free(login_data);
  //发送后关闭来自qemu连接
  listener_->RemoveConnection(entry->conn);
  return ret;
}

// 失败返回 -1
int FdDispatcher::SendFd(int fd, void* ptr, int nbytes, int sendfd) {
  LOG_INFO << "fd to send: " << sendfd << " by fd: " << fd;
  int control_len = CMSG_LEN(sizeof(int));
  struct msghdr msg;
  struct iovec iov[1];
  struct cmsghdr* cmptr = NULL;

  msg.msg_name = NULL;
  msg.msg_namelen = 0;

  iov[0].iov_base = ptr;
  iov[0].iov_len = nbytes;
  msg.msg_iov = iov;
  msg.msg_iovlen = 1;
  cmptr = reinterpret_cast<cmsghdr*>(malloc(control_len));
  cmptr->cmsg_len = control_len;
  cmptr->cmsg_level = SOL_SOCKET;
  cmptr->cmsg_type = SCM_RIGHTS;
  msg.msg_control = cmptr;
  msg.msg_controllen = control_len; 
  *((int *)CMSG_DATA(cmptr)) = sendfd;
  int ret = sendmsg(fd, &msg, 0);
  if (ret != nbytes) {
    LOG_SYSERR << "sendmsg error, ret: " << ret;
    ret =  -1;
  }
  free(cmptr);
  return ret;
}

void FdDispatcher::RemoveConn(uevent::ConnectionUeventPtr &conn) {
   listener_->RemoveConnection(conn);
}

void FdDispatcher::DispatchResizeFd(const QemuIOHead &head,
                                    const ConnectionUeventPtr& conn) {
  QemuResizeInfo resize_info;
  conn->RemoveData(&resize_info, sizeof(QemuResizeInfo));
  LOG_INFO << "udisk resize extern id: "
           << std::string(resize_info.udisk_id);
  const ConnectorUeventPtr &gate_ctor = CreateGateConnector("block_gate");
  if (!gate_ctor) {
    LOG_ERROR << "get connection failed";
    listener_->RemoveConnection(conn);
    return;
  }
  std::string ctor_name = gate_ctor->GetName();
  if (gate_ctor->HasAvailableConnection() == false) {
    LOG_ERROR << "connection to gate not available, delete gate connector:"
              << ctor_name;
    DelGateConnector(ctor_name); // 释放connector
    listener_->RemoveConnection(conn);
    return;
  }
  const ConnectionUeventPtr &gate_conn = gate_ctor->GetConnection();
  // 对于trans_gate需要将trans_ip和trans_port附加在login请求后转发出去
  int resize_data_len = sizeof(QemuIOHead) + sizeof(union QemuCommandBody);
  LOG_INFO << "resize data len: " << resize_data_len;
  char* resize_data = reinterpret_cast<char*>(malloc(resize_data_len));
  char* ptr = resize_data;
  memset(ptr, 0, resize_data_len);
  memcpy(ptr, &head, sizeof(QemuIOHead));
  ptr += sizeof(QemuIOHead);
  memcpy(ptr, &resize_info, sizeof(QemuResizeInfo));
  int ret = SendFd(gate_conn->GetFd(), resize_data, resize_data_len, conn->GetFd());
  if (ret < 0) {
    LOG_ERROR << "resize send fd failed, " << ret;
  }
  free(resize_data);
  //发送后关闭来自qemu连接
  listener_->RemoveConnection(conn);
  return;
}

} // namespace block_gate_proxy
} // udisk
