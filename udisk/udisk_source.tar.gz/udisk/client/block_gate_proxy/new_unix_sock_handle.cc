#include "new_unix_sock_handle.h"

#include "fd_dispatcher.h"
#include "eventloop_libevent.h"

namespace udisk {
namespace block_gate_proxy {

NewUnixSockHandle::NewUnixSockHandle(const std::string &unix_sock)
    : unix_sock_(unix_sock) {
  loop_ = new uevent::EventLoopLibevent("main loop");
  fd_dispatcher_ = new FdDispatcher(loop_, unix_sock_);
}

NewUnixSockHandle::~NewUnixSockHandle() {
  delete fd_dispatcher_;
  delete loop_;
}

void NewUnixSockHandle::Start() {
  fd_dispatcher_->Init();
  fd_dispatcher_->Start();
}

};  // end of ns block_gate_proxy
};  // end of ns udisk
