#include "my_config_parser.h"
#include "logging.h"

#include <stdlib.h>
#include <time.h>

namespace udisk {
namespace block_gate_proxy {

const std::string MyConfigParser::kOldGateCount = std::string("old_gate_count");
const std::string MyConfigParser::kOldGateName = std::string("old_gate");
const std::string MyConfigParser::kBlockGateName = std::string("block_gate");
const std::string MyConfigParser::kTransGateName = std::string("trans_gate");
const std::string MyConfigParser::kListenOldUnixSock = std::string("listen_old_unix_sock");
const std::string MyConfigParser::kGlobalOdinName = std::string("global_odin");
using namespace base;

MyConfigParser::MyConfigParser(const std::string& file)
    : ConfigParser(file) {
}

void MyConfigParser::Init() {
  ConfigParser::Init(); 
  //必要部分为填无法启动
  if (listen_ip().empty()) {
    // 目前用于告警时标识自己
    LOG_FATAL << "listen_ip is empty";
  }
  if (zk_server().empty()) {
    LOG_FATAL << "listen_ip is empty";
  }
  if (listen_unix_addr().empty()) {
    LOG_FATAL << "listen unix addr is empty";
  }
  if (access_zk_path().empty()) {
    LOG_FATAL << "access_zk_path is empty";
  }
  int32_t old_gate_count = parser_.IntValue(kSectionName, kOldGateCount);
  if (old_gate_count == 0) {
    LOG_FATAL << "old gate count is empty in config file";
  } 
  else {
    for(int i = 0; i < old_gate_count; i++) {
      std::string old_gate_item = kOldGateName + std::to_string(i);
      std::string old_gate_addr = parser_.GetValue(kSectionName, old_gate_item);
      if (old_gate_addr.empty()) {
        LOG_FATAL << old_gate_item << " is empty in config file";
      } 
      else {
        LOG_INFO << old_gate_item << " : " << old_gate_addr;
        old_gate_addrs_.push_back(old_gate_addr);
      }
    }
  }
  block_gate_addr_ = parser_.GetValue(kSectionName, kBlockGateName);
  if (block_gate_addr_.empty()) {
    LOG_FATAL << kBlockGateName << " is empty in config file";
  } 
  LOG_INFO << kBlockGateName << " : " << block_gate_addr_;

  trans_gate_addr_ = parser_.GetValue(kSectionName, kTransGateName);
  if (trans_gate_addr_.empty()) {
    LOG_FATAL << kTransGateName << " is empty in config file";
  } 
  LOG_INFO << kTransGateName << " : " << trans_gate_addr_;

  listen_old_unix_sock_ = parser_.GetValue(kSectionNetworks, kListenOldUnixSock);
  if (listen_old_unix_sock_.empty()) {
    LOG_FATAL << kListenOldUnixSock << " is empty in config file";
  } 
  LOG_INFO << kListenOldUnixSock << " : " << listen_old_unix_sock_;

  global_odin_zk_path_ = parser_.GetValue(kSectionName, kGlobalOdinName);
  if (global_odin_zk_path_.empty()) {
    LOG_FATAL << "global odin is empty in config file";
  }
  LOG_INFO << "global odin path: " << global_odin_zk_path_;
}

std::string MyConfigParser::get_gate_addr(const std::string &gate_name) {
  if (gate_name == std::string("block_gate")) {
    return block_gate_addr_; 
  }
  else if (gate_name == std::string("trans_gate")) {
    return trans_gate_addr_;
  }
  else if (gate_name == std::string("old_gate")) {
    srand((int)time(0));
    int i = rand() % old_gate_addrs_.size();
    return old_gate_addrs_.at(i);
  }
  else {
    std::string gate_addr = parser_.GetValue(kSectionNetworks, gate_name.c_str());
    if (gate_addr.empty()) {
      LOG_ERROR << gate_name << " is empty in config file";
      return std::string("");
    }
    else {
      return gate_addr;  
    }
  }
}

} // ns trans_gate_proxy
} // ns udisk
