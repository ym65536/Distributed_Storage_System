#ifndef UDISK_BLOCK_GATE_PROXY_LOGIN_GATE_STRATEGY_H_
#define UDISK_BLOCK_GATE_PROXY_LOGIN_GATE_STRATEGY_H_

#include <memory>
#include <umessage.h>
#include "callbacks.h"

namespace uevent {
class UeventLoop;
class ConnectionUevent;
class ConnectorUevent;
}

namespace udisk {

namespace block_gate_proxy {

class FdDispatcher;
struct LoginInfoEntry;

class LoginGateStrategy {
 public:
  LoginGateStrategy(uevent::UeventLoop* loop,
                    FdDispatcher* dispatcher);

  uevent::ConnectorUeventPtr CreateAccessConnector();
  int Dispatch(uint32_t flowno, const std::string& gate_name, 
               const std::string &trans_ip, uint32_t trans_port);
  void AccessConnSuccessCb(const uevent::ConnectionUeventPtr& conn);
  void AccessConnClosedCb(const uevent::ConnectionUeventPtr& conn);
  void GetGateRequest(std::shared_ptr<LoginInfoEntry> entry);
  void GetGateResponseCb(ucloud::UMessage* um, 
                         const uevent::ConnectorUeventPtr& ctor, 
                         const std::shared_ptr<LoginInfoEntry> &entry);
  void AccessTimeoutCb(const uevent::ConnectorUeventPtr& ctor, 
                      const std::shared_ptr<LoginInfoEntry> &entry);
  void OdinConnSuccessCb(const uevent::ConnectionUeventPtr& conn);
  void OdinConnClosedCb(const uevent::ConnectionUeventPtr& conn);
  uevent::ConnectorUeventPtr CreateOdinConnector();
  void WarningToOdin(const std::shared_ptr<LoginInfoEntry> &entry);
  void OdinWarningResponseCb(ucloud::UMessage* um,
                             const uevent::ConnectorUeventPtr& ctor);
  void OdinWarningTimeout(const uevent::ConnectorUeventPtr& ctor);

 private:
  uevent::UeventLoop* loop_;
  FdDispatcher* dispatcher_;
};

} // namespace block_gate_proxy
} // namespace udisk

#endif
