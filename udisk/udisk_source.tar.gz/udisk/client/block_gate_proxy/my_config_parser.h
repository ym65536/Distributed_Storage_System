#ifndef UDISK_BLOCK_GATE_PROXY_CONFIG_PARSER_H_
#define UDISK_BLOCK_GATE_PROXY_CONFIG_PARSER_H_

#include "config_parser.h"
#include <string>
#include <vector>

namespace udisk {
namespace block_gate_proxy {

class MyConfigParser : public common::ConfigParser {
 public :
  explicit MyConfigParser(const std::string& file);
  void Init();
  std::string get_gate_addr(const std::string &gate_name);
  const std::string &listen_old_unix_sock() const{
    return listen_old_unix_sock_;
  }
  const std::string &global_odin_zk_path() const { 
    return global_odin_zk_path_; 
  }
  const static std::string kOldGateCount;
  const static std::string kOldGateName;
  const static std::string kBlockGateName;
  const static std::string kTransGateName;
  const static std::string kListenOldUnixSock;
  const static std::string kGlobalOdinName;
 private :
  std::vector<std::string> old_gate_addrs_;
  std::string block_gate_addr_;
  std::string trans_gate_addr_;
  std::string listen_old_unix_sock_;
  std::string global_odin_zk_path_;
};

} // ns block_gate_proxy
} // ns udisk

#endif
