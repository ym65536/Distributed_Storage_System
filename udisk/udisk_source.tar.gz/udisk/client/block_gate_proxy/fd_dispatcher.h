#ifndef UDISK_BLOCK_GATE_PROXY_FD_DISPATCHER_H_
#define UDISK_BLOCK_GATE_PROXY_FD_DISPATCHER_H_

#include <map>
#include <memory>
#include "login_gate_strategy.h"
#include "qemu_io_proto.h"
#include "usock_address.h"

namespace uevent {
class UeventLoop;
class ConnectionUevent;
class ConnectorUevent;
class ListenerUevent;
}  // namespace uevent

namespace udisk {
namespace block_gate_proxy {

class LoginGateStrategy;

struct LoginInfoEntry {
  uint32_t flowno;
  common::QemuIOHead login_head;
  common::QemuLoginInfo login_info;
  uevent::ConnectionUeventPtr conn;
};

class FdDispatcher {
 public:
  FdDispatcher(uevent::UeventLoop* loop, const std::string& unix_sock);
  void Init();
  void Start();
  void LoginRequestHandle(const common::QemuIOHead& head,
                          const uevent::ConnectionUeventPtr& conn);
  std::shared_ptr<LoginInfoEntry> GetLoginInfoEntry(uint32_t flowno);
  int Dispatch(std::shared_ptr<LoginInfoEntry> entry,
               const std::string& gate_name, const std::string& trans_ip,
               uint32_t trans_port);
  void RemoveConn(uevent::ConnectionUeventPtr& conn);

 private:
  void QemuConnSuccessCb(const uevent::ConnectionUeventPtr& conn);
  void QemuConnClosedCb(const uevent::ConnectionUeventPtr& conn);
  void QemuConnReadCb(const uevent::ConnectionUeventPtr& conn);
  uevent::ConnectorUeventPtr CreateGateConnector(const std::string& gate_name);
  void GateConnSuccessCb(const uevent::ConnectionUeventPtr& conn);
  void GateConnClosedCb(const uevent::ConnectionUeventPtr& conn);
  void DelGateConnector(std::string& name);
  void GateConnReadCb(const uevent::ConnectionUeventPtr& conn);
  int SendFd(int fd, void* ptr, int nbytes, int sendfd);
  void DelLoginInfoEntryByConn(const uevent::ConnectionUeventPtr& conn);
  void DelLoginInfoEntryByFlowno(uint32_t flowno);
  void DispatchResizeFd(const common::QemuIOHead& head,
                        const uevent::ConnectionUeventPtr& conn);

  uevent::UeventLoop* loop_;
  std::string unix_sock_;
  std::unique_ptr<uevent::ListenerUevent> listener_;
  std::unique_ptr<LoginGateStrategy> login_strategy_;
  int64_t gate_ctor_id_;  //标识不同的ctor, 帮助短连接析构
  std::map<std::string, uevent::ConnectorUeventPtr> gate_connectors_;
  common::QemuLoginInfo* login_info_;
  std::map<uint32_t, std::shared_ptr<LoginInfoEntry> > flowno_to_login_entry_;
};

}  // namespace block_gate_proxy
}  // namespace udisk

#endif
