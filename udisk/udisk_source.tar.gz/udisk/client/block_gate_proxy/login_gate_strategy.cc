#include "login_gate_strategy.h"

#include "logging.h"
#include "my_uuid.h"
#include "uevent.h"
#include "connector_libevent.h"
#include "message_util.h"
#include "umessage.h"
#include "usock_address.h"
#include "zk_name_container.h"
#include "block_gate_proxy.h"
#include "fd_dispatcher.h"
#include "my_config_parser.h"

namespace udisk {
namespace block_gate_proxy {

using namespace uevent;
using namespace common;
  
LoginGateStrategy::LoginGateStrategy(UeventLoop* loop,
            FdDispatcher* dispatcher)
    : loop_(loop),
      dispatcher_(dispatcher) {
}

ConnectorUeventPtr LoginGateStrategy::CreateAccessConnector() {
  ucloud::uns::NameNodeContent nnc;
  if (g_name_container->GetNNCForName(common::ConfigParser::kGlobalSetName,
    common::ConfigParser::kAccessName, nnc) == -1) {
    LOG_ERROR << "get nnc for access error";
    return ConnectorUeventPtr();
  }
  std::string access_ip = nnc.ip();
  uint32_t access_port = nnc.port();
  UsockAddress access_addr(access_ip, access_port);
  ConnectorUeventPtr access_ctor = std::make_shared<ConnectorLibevent>(
      loop_, access_addr, "AccessConnector");
  access_ctor->SetConnectionSuccessCb(std::bind(
      &LoginGateStrategy::AccessConnSuccessCb,
      this, std::placeholders::_1));
  access_ctor->SetConnectionClosedCb(std::bind(
      &LoginGateStrategy::AccessConnClosedCb,
      this, std::placeholders::_1));
  access_ctor->SetMessageReadCb(std::bind(
      MessageUtil::ProtobufReadCallBack, std::placeholders::_1));
  return access_ctor;
}

void LoginGateStrategy::AccessConnSuccessCb(const ConnectionUeventPtr& conn) {
  LOG_INFO << "connect to access success, peer address: "
           << conn->GetPeerAddress().ToString();
}

// 因为access使用平铺部署方式,使用的是短连接，每次都会析构上次的
// connector,创建一个新的connector。这里断开连接时不用DestroyConnection
// 不用担心connector中的无效connection 会被使用
void LoginGateStrategy::AccessConnClosedCb(const ConnectionUeventPtr& conn) {
  LOG_INFO << "disconnect from access, peer address: "
           << conn->GetPeerAddress().ToString();
}

void LoginGateStrategy::GetGateRequest(std::shared_ptr<LoginInfoEntry> entry) {
  ucloud::UMessage um;
  NewMessage_v2(&um, entry->flowno, base::MyUuid::NewUuid(),
                ucloud::udisk::GET_LOGIN_GATE_REQUEST, 0, false, 
                MessageUtil::ObjId(), 0, "GetLoginGate", NULL, NULL);
  ucloud::udisk::GetLoginGateRequest* req_body =
      um.mutable_body()->MutableExtension(
              ucloud::udisk::get_login_gate_request);
  req_body->set_extern_id(std::string(entry->login_info.udisk_id));

  const ConnectorUeventPtr &access_ctor = CreateAccessConnector();
  if (!access_ctor || access_ctor->HasAvailableConnection() == false) {
    LOG_ERROR << "connect to access error";
    dispatcher_->RemoveConn(entry->conn);
    // 这个函数返回后access_ctor引用为0, 自动析构
    // 由于login 失败无法获取set，发给机房的全局odin
    WarningToOdin(entry);
    return; // 这里返回access_ctor 会被自动析构
  }
  const ConnectionUeventPtr &access_conn = access_ctor->GetConnection();
  LOG_INFO << um.DebugString();
  MessageUtil::SendPbRequest(access_conn, um, 
      std::bind(&LoginGateStrategy::GetGateResponseCb,
      this, std::placeholders::_1, access_ctor, entry),
      std::bind(&LoginGateStrategy::AccessTimeoutCb, this, access_ctor, entry),
      2.0);
}

void LoginGateStrategy::GetGateResponseCb(ucloud::UMessage* um,
                                          const ConnectorUeventPtr& ctor, 
                                          const std::shared_ptr<LoginInfoEntry> &entry) {
  LOG_INFO << um->DebugString();
  assert(um->head().message_type() ==
          ucloud::udisk::GET_LOGIN_GATE_RESPONSE);
  assert(um->has_body());
  assert(um->body().HasExtension(ucloud::udisk::get_login_gate_response));
  uint32_t flowno = um->head().flow_no();
  const ucloud::udisk::GetLoginGateResponse& rsp =
      um->body().GetExtension(ucloud::udisk::get_login_gate_response);
  std::string gate_name;
  std::string trans_ip;
  uint32_t trans_port = 0;
  if (rsp.rc().retcode() != 0) {
    // 为了兼容老版本
    if (rsp.rc().retcode() == ucloud::udisk::EC_UDISK_NO_GRAY_GATE) {
      gate_name = std::string("block_gate");
      Dispatch(flowno, gate_name, trans_ip, trans_port);
    }
    else {
      LOG_ERROR << "get login gate response error. "
                << rsp.rc().error_message();
      dispatcher_->RemoveConn(entry->conn);
      // 由于login 失败无法获取set，发给机房的全局odin
      WarningToOdin(entry);
    }
    return;
  }

  if (rsp.version() == ucloud::udisk::VER_UBS2) {
    if (rsp.has_migrate_udisk()) {
      if (rsp.migrate_udisk().status() == ucloud::udisk::MIGRATE_INEXISTENCE) {
        gate_name = std::string("old_gate");
      }
      else if (rsp.migrate_udisk().status() == ucloud::udisk::MIGRATE_INPROCESS ||
          rsp.migrate_udisk().status() == ucloud::udisk::MIGRATE_SUSPENDED) {
        gate_name = std::string("trans_gate");
        trans_ip = rsp.migrate_udisk().trans_ip();
        trans_port = rsp.migrate_udisk().trans_port();
      }
      else if (rsp.migrate_udisk().status() == ucloud::udisk::MIGRATE_COMPLETE) {
        gate_name = std::string("block_gate");
      }
      else {
        LOG_ERROR << "migrate task status is error. ";
        dispatcher_->RemoveConn(entry->conn);
        // 由于login 失败无法获取set，发给机房的全局odin
        WarningToOdin(entry);
        return;
      }
    }
    else {
      LOG_ERROR << "migrate task is null";
      dispatcher_->RemoveConn(entry->conn);
      // 由于login 失败无法获取set，发给机房的全局odin
      WarningToOdin(entry);
      return;
    }
  }
  else if (rsp.version() == ucloud::udisk::VER_UDISK_V4) {
    if (rsp.has_migrate_udisk()) {
      if (rsp.migrate_udisk().status() == ucloud::udisk::MIGRATE_INEXISTENCE || 
          rsp.migrate_udisk().status() == ucloud::udisk::MIGRATE_COMPLETE) {
        if (rsp.has_gate_key()) {
          gate_name = rsp.gate_key();
        }
        else {
          gate_name = std::string("block_gate");
        }
      }
      else if (rsp.migrate_udisk().status() == ucloud::udisk::MIGRATE_INPROCESS ||
          rsp.migrate_udisk().status() == ucloud::udisk::MIGRATE_SUSPENDED) {
        gate_name = std::string("trans_gate");
        trans_ip = rsp.migrate_udisk().trans_ip();
        trans_port = rsp.migrate_udisk().trans_port();
      }
      else {
        LOG_ERROR << "migrate task status is error. ";
        dispatcher_->RemoveConn(entry->conn);
        // 由于login 失败无法获取set，发给机房的全局odin
        WarningToOdin(entry);
        return;
      }
    }
    else {
      LOG_ERROR << "migrate task is null";
      dispatcher_->RemoveConn(entry->conn);
      // 由于login 失败无法获取set，发给机房的全局odin
      WarningToOdin(entry);
      return;
    }
  }
  else {
    LOG_ERROR << "get login gate verison error";
    dispatcher_->RemoveConn(entry->conn);
    // 由于login 失败无法获取set，发给机房的全局odin
    WarningToOdin(entry);
    return;
  }

  Dispatch(flowno, gate_name, trans_ip, trans_port);
  // 这个函数返回后access_ctor引用为0, 自动析构
}

int LoginGateStrategy::Dispatch(uint32_t flowno, const std::string &gate_name, 
                                const std::string &trans_ip, uint32_t trans_port) {
  std::shared_ptr<LoginInfoEntry> entry =
      dispatcher_->GetLoginInfoEntry(flowno);
  if (!entry) {
    LOG_ERROR << "can't find login info entry when get gate response";
    return -1; // qemu的连接断开了,不属于login 失败，不用告警
  }
  // 分发fd失败需要告警
  if (dispatcher_->Dispatch(entry, gate_name, trans_ip, trans_port) == -1) {
    // 由于login 失败无法获取set，发给机房的全局odin
    WarningToOdin(entry);
  }
  return 0;
}

void LoginGateStrategy::AccessTimeoutCb(const ConnectorUeventPtr& ctor, 
                                       const std::shared_ptr<LoginInfoEntry> &entry) {
  LOG_ERROR << "get login gate timeout";
  dispatcher_->RemoveConn(entry->conn);
  // 这个函数返回后access_ctor引用为0, 自动析构
  // 由于login 失败无法获取set，发给机房的全局odin
  WarningToOdin(entry);
}

void LoginGateStrategy::OdinConnSuccessCb(const ConnectionUeventPtr& conn) {
  LOG_INFO << "connect to Odin success, peer address: "
           << conn->GetPeerAddress().ToString(); 
}
void LoginGateStrategy::OdinConnClosedCb(const ConnectionUeventPtr& conn) {
  LOG_INFO << "disconnect from odin, peer address: "
           << conn->GetPeerAddress().ToString(); 
}
// gate proxy 与odin 采用短连接
ConnectorUeventPtr LoginGateStrategy::CreateOdinConnector() {
  ucloud::uns::NameNodeContent nnc;
  // 获取odin 的leader 节点
  if (g_name_container->GetNNCForName(
      ConfigParser::kGlobalSetName, MyConfigParser::kGlobalOdinName, nnc, true) == -1) {
    LOG_ERROR << "get nnc for odin error";
    return ConnectorUeventPtr();
  }
  ucloud::udisk::OdinPortPair extend_info;
  if (!extend_info.ParseFromString(nnc.reserved())) {
    LOG_ERROR << "parse odin pair fail.";
    return ConnectorUeventPtr();
  }
  std::string odin_ip = nnc.ip();
  uint32_t odin_port = extend_info.gate_port();
  UsockAddress odin_addr(odin_ip, odin_port);
  ConnectorUeventPtr odin_ctor(new ConnectorLibevent(
      loop_, odin_addr, "OdinConnector"));
  odin_ctor->SetConnectionSuccessCb(std::bind(
      &LoginGateStrategy::OdinConnSuccessCb, this, std::placeholders::_1));
  odin_ctor->SetConnectionClosedCb(std::bind(
      &LoginGateStrategy::OdinConnClosedCb, this, std::placeholders::_1));
  odin_ctor->SetMessageReadCb(std::bind(
      MessageUtil::ProtobufReadCallBack, std::placeholders::_1));
  return odin_ctor;
}

void LoginGateStrategy::WarningToOdin(const std::shared_ptr<LoginInfoEntry> &entry) {
  ucloud::udisk::OdinWarningRequest warn_request;
  // ip:extern_id 拼成uuid, 唯一标识这个告警
  std::string uuid = g_config_parser->listen_ip() + ":" +
      std::string(entry->login_info.udisk_id);
  warn_request.set_uuid(uuid);
  warn_request.set_item_id(ConfigParser::kLoginFailedItemId);
  warn_request.set_info("login failed in block_gate_proxy");
  warn_request.set_time(base::Timestamp::now().secondsSinceEpoch());
  // 由于login 失败无法获取set，发给机房的全局odin
  LOG_WARN << "report waring to odin";
  ConnectorUeventPtr odin_ctor = CreateOdinConnector();
  if (!odin_ctor || odin_ctor->HasAvailableConnection() == false) {
    LOG_ERROR << "connect to odin error";
    return;
  }
  ucloud::UMessage um;
  uint32_t obj_id = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&um, flowno, base::MyUuid::NewUuid(),
      ucloud::udisk::ODIN_WARNING_REQUEST, 0, false,
      obj_id, 0, "OdinWarningRequest", NULL, NULL);
  ucloud::udisk::OdinWarningRequest* req = um.mutable_body()->
      MutableExtension(ucloud::udisk::odin_warning_request);
  req->Swap(&warn_request);
  LOG_INFO << um.DebugString();
  ConnectionUeventPtr odin_conn = odin_ctor->GetConnection();
  MessageUtil::SendPbRequest(odin_conn, um, 
      std::bind(&LoginGateStrategy::OdinWarningResponseCb,
          this, std::placeholders::_1, odin_ctor),
      std::bind(&LoginGateStrategy::OdinWarningTimeout, this, odin_ctor),
      2.0);
}
void LoginGateStrategy::OdinWarningResponseCb(ucloud::UMessage* um,
                                    const ConnectorUeventPtr& ctor) {
  const ucloud::udisk::OdinWarningResponse &res = 
    um->body().GetExtension(ucloud::udisk::odin_warning_response); 
  if (res.rc().retcode() != 0) {
    LOG_ERROR << "odin warning response error";
  }
}
void LoginGateStrategy::OdinWarningTimeout(const ConnectorUeventPtr& ctor) {
  LOG_ERROR << "report to odin timeout";
  // 这个函数返回后odin_ctor引用为0, 自动析构
}

}  //namespace block_gate_proxy
} // namespace udisk
