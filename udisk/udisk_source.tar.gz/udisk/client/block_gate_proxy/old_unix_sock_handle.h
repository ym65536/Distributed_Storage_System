#ifndef UDISK_OLD_UNIX_SOCK_HANDLE_H
#define UDISK_OLD_UNIX_SOCK_HANDLE_H

#include <string>
#include "ueventloop_thread.h"

namespace uevent {
class UeventLoop;
class UeventLoopThread;
};

namespace udisk {
namespace block_gate_proxy {

class FdDispatcher;

class OldUnixSockHandle {
 public:
  OldUnixSockHandle(const std::string& unix_sock);
  ~OldUnixSockHandle();

  void Start();
  void StartInLoop();

 private:
  uevent::UeventLoopThread thread_;
  uevent::UeventLoop* loop_;
  std::string unix_sock_;
  FdDispatcher* fd_dispatcher_;
};

};  // end of ns block_gate_proxy
};  // end of ns udisk

#endif
