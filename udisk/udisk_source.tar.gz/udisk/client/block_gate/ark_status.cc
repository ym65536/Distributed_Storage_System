#include "ark_status.h"
#include "gate.h"
#include "manager_thread.h"

namespace udisk {
namespace gate {

using std::placeholders::_1;
using std::placeholders::_2;
using namespace uevent;
using namespace common;

ArkStatus::ArkStatus(ucloud::udisk::UTM_MODE ark_mode, /*{{{*/
                     ucloud::udisk::UTM_STATUS ark_status,
                     ucloud::udisk::UDISK_MOUNT_STATUS mount_status,
                     UDiskHandle* udisk_handle)
    : ark_mode_(ark_mode),
      ark_status_(ark_status),
      mount_status_(mount_status),
      udisk_handle_(udisk_handle),
      op_(ARK_NOP) {} /*}}}*/

ArkStatus::~ArkStatus() {/*{{{*/
} /*}}}*/

// Ark同步状态控制
bool ArkStatus::StatTransOn(ArkTransOp op, /*{{{*/
                            ucloud::udisk::UTM_STATUS target_status) {
  //对于NeedRebase抢占式，直接打断当前状态同步
  if (op_ != ARK_NOP &&
      target_status != ucloud::udisk::UTM_STATUS_NEED_REBASE) {
    ULOG_ERROR << "someone is syncing ark status to:" << target_status_
               << ", ark_op:" << op_;
    return false;
  }

  op_ = op;
  target_status_ = target_status;
  return true;
} /*}}}*/

void ArkStatus::StatTransOff() {/*{{{*/
  op_ = ARK_NOP;
} /*}}}*/

bool ArkStatus::IsTransingStatus() {/*{{{*/
  if (op_ != ARK_NOP) {
    return true;
  } else {
    return false;
  }
} /*}}}*/

// Ark发起状态变化
void ArkStatus::Ark2Normal(ArkTransOp op) {/*{{{*/
  ULOG_INFO << "start ArkOp:" << op;
  if (StatTransOn(op, ucloud::udisk::UTM_STATUS_NORMAL) == true) {
    ManagerThread::Instance()->SetArkStatus(udisk_handle_, target_status_,
                                            ark_status_);
  }
} /*}}}*/

void ArkStatus::Ark2Standby(ArkTransOp op) {/*{{{*/
  ULOG_INFO << "start ArkOp:" << op;
  if (StatTransOn(op, ucloud::udisk::UTM_STATUS_STANDBY) == true) {
    ManagerThread::Instance()->SetArkStatus(udisk_handle_, target_status_,
                                            ark_status_);
  }
} /*}}}*/

void ArkStatus::Ark2Running(ArkTransOp op) {/*{{{*/
  ULOG_INFO << "start ArkOp:" << op;
  if (StatTransOn(op, ucloud::udisk::UTM_STATUS_RUNNING) == true) {
    ManagerThread::Instance()->SetArkStatus(udisk_handle_, target_status_,
                                            ark_status_);
  }
} /*}}}*/

void ArkStatus::Ark2Rebasing(ArkTransOp op) {/*{{{*/
  ULOG_INFO << "start ArkOp:" << op;
  if (StatTransOn(op, ucloud::udisk::UTM_STATUS_REBASING) == true) {
    ManagerThread::Instance()->SetArkStatus(udisk_handle_, target_status_,
                                            ark_status_);
  }
} /*}}}*/

//先停止Ark,再去同步，直到成功
void ArkStatus::Ark2NeedRebase(ArkTransOp op) {/*{{{*/
  ULOG_INFO << "start ArkOp:" << op;
  if (StatTransOn(op, ucloud::udisk::UTM_STATUS_NEED_REBASE) == true) {
    ManagerThread::Instance()->SetArkStatus(udisk_handle_, target_status_,
                                            ark_status_);
  }
} /*}}}*/

// NeedRebase重试
void ArkStatus::Ark2NeedRebase() {/*{{{*/
  ULOG_INFO << "retry ark need rebase,  ArkOp:" << op_;
  if (StatTransOn(op_, ucloud::udisk::UTM_STATUS_NEED_REBASE) == true) {
    ManagerThread::Instance()->SetArkStatus(udisk_handle_, target_status_,
                                            ark_status_);
  }
} /*}}}*/

//远端数据库设置成功后，再设置本地ark状态
void ArkStatus::Ark2NormalSuccess() {/*{{{*/
  SetArkStatus(ucloud::udisk::UTM_STATUS_NORMAL);
  StatTransOff();
} /*}}}*/

void ArkStatus::Ark2StandbySuccess() {/*{{{*/
  SetArkStatus(ucloud::udisk::UTM_STATUS_STANDBY);
  StatTransOff();
} /*}}}*/

void ArkStatus::Ark2RunningSuccess() {/*{{{*/
  SetArkStatus(ucloud::udisk::UTM_STATUS_RUNNING);
  StatTransOff();
} /*}}}*/

void ArkStatus::Ark2RebasingSuccess() {/*{{{*/
  SetArkStatus(ucloud::udisk::UTM_STATUS_REBASING);
  StatTransOff();
} /*}}}*/

void ArkStatus::Ark2NeedRebaseSuccess() {/*{{{*/
  SetArkStatus(ucloud::udisk::UTM_STATUS_NEED_REBASE);
  StatTransOff();
} /*}}}*/

//远端数据库设置成功后，再设置本地ark状态
void ArkStatus::Ark2NormalFailed() {/*{{{*/
  StatTransOff();
} /*}}}*/

void ArkStatus::Ark2StandbyFailed() {/*{{{*/
  StatTransOff();
} /*}}}*/

void ArkStatus::Ark2RunningFailed() {/*{{{*/
  StatTransOff();
} /*}}}*/

void ArkStatus::Ark2RebasingFailed() {/*{{{*/
  StatTransOff();
} /*}}}*/

void ArkStatus::Ark2NeedRebaseFailed() {/*{{{*/
                                        // NeedRebase状态需要一直重试到成功，故不能关闭Trans状态，防止新的状态介入
} /*}}}*/

//数据库设置同步超时
void ArkStatus::Ark2NormalTimeout() {/*{{{*/
  StatTransOff();
} /*}}}*/

void ArkStatus::Ark2StandbyTimeout() {/*{{{*/
  StatTransOff();
} /*}}}*/

void ArkStatus::Ark2RunningTimeout() {/*{{{*/
  StatTransOff();
} /*}}}*/

void ArkStatus::Ark2RebasingTimeout() {/*{{{*/
  StatTransOff();
} /*}}}*/

void ArkStatus::Ark2NeedRebaseTimeout() {/*{{{*/
                                         // NeedRebase状态需要一直重试到成功，故不能关闭Trans状态，防止新的状态介入
} /*}}}*/

}  // namespace gate
}  // namespace udisk
