#ifndef UDISK_GATE_GET_LC_LAST_RW_TICK_H_
#define UDISK_GATE_GET_LC_LAST_RW_TICK_H_

#include <ustevent/base/logging.h>
#include <ustevent/eventloop.h>
#include <ustevent/pb_request_handle.h>
#include "udisk_message.h"

using namespace uevent;

namespace udisk {
namespace gate {

class GetLcRwTick : public PbRequestHandle {
 public:
  explicit GetLcRwTick(uevent::EventLoop* loop) : loop_(loop) {}
  virtual ~GetLcRwTick() {}
  virtual void EntryInit(const ConnectionUeventPtr& conn,
                         const UMessagePtr& um);

  void GetRwTickInfos(const ucloud::udisk::GetLcLastRwTickRequest& req);
  void GetRwTickInfosCb(bool has_valid_lc,
                        const ucloud::udisk::LcLastRwTickInfo& info);
  void GetRwTickInfosCbInLoop(bool has_valid_lc,
                              const ucloud::udisk::LcLastRwTickInfo& info);
  void TimeoutCb();
  void SendResponse(int retcode, const std::string& message);
  MYSELF_CREATE(GetLcRwTick);

  void DestroyMyself();

 private:
  static int type_;
  uevent::EventLoop* loop_;
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage response_;
  ucloud::udisk::GetLcLastRwTickResponse* resp_body_;
  int loop_count_;
  uevent::TimerId timer_id_;
  // 保证每次返回的盘顺序一致，方便查看
  std::map<std::string, ucloud::udisk::LcLastRwTickInfo> infos_;
};
}
}
#endif
