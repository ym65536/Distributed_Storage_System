#include "get_lc_last_rw_tick.h"
#include <ustevent/message_util.h>
#include "umessage_common.h"
#include "gate.h"
#include "gate_listener.h"
#include "udisk_handle.h"

namespace udisk {
namespace gate {

using namespace uevent;

int GetLcRwTick::type_ = ucloud::udisk::GET_LC_LAST_RW_TICK_REQUEST;

void GetLcRwTick::EntryInit(const ConnectionUeventPtr& conn,
                            const UMessagePtr& um) {
  ULOG_INFO << um->DebugString();
  conn_ = conn;
  assert(um->head().message_type() == type_);
  assert(um->body().HasExtension(ucloud::udisk::get_lc_last_rw_tick_request));
  ucloud::udisk::GetLcLastRwTickRequest req_body =
      um->body().GetExtension(ucloud::udisk::get_lc_last_rw_tick_request);
  MakeResponse(um.get(), ucloud::udisk::GET_LC_LAST_RW_TICK_RESPONSE,
               &response_);
  resp_body_ = response_.mutable_body()->MutableExtension(
      ucloud::udisk::get_lc_last_rw_tick_response);
  GetRwTickInfos(req_body);
}

void GetLcRwTick::GetRwTickInfos(
    const ucloud::udisk::GetLcLastRwTickRequest& req) {
  std::shared_ptr<GetLcRwTick> ptr =
      std::dynamic_pointer_cast<GetLcRwTick>(shared_from_this());
  std::vector<EventLoop*> all_loops = g_listener->GetAllLoops();
  loop_count_ = all_loops.size();
  for (auto l : all_loops) {
    UDiskHandle* udisk_handle =
        reinterpret_cast<UDiskHandle*>(l->GetLoopHandle());
    l->RunInLoop(std::bind(&UDiskHandle::GetRwTickInfo, udisk_handle, ptr));
  }
  timer_id_ = loop_->RunAfter(2, std::bind(&GetLcRwTick::TimeoutCb, ptr));
}

void GetLcRwTick::GetRwTickInfosCb(
    bool has_valid_lc, const ucloud::udisk::LcLastRwTickInfo& info) {
  std::shared_ptr<GetLcRwTick> ptr =
      std::dynamic_pointer_cast<GetLcRwTick>(shared_from_this());
  loop_->RunInLoop(
      std::bind(&GetLcRwTick::GetRwTickInfosCbInLoop, ptr, has_valid_lc, info));
}

void GetLcRwTick::GetRwTickInfosCbInLoop(
    bool has_valid_lc, const ucloud::udisk::LcLastRwTickInfo& info) {
  --loop_count_;
  if (has_valid_lc) {
    infos_[info.extern_id()] = info;
  }
  if (loop_count_ == 0) { // 所有的loop都执行结束
    for (auto it = infos_.begin(); it != infos_.end(); ++it) {
      ucloud::udisk::LcLastRwTickInfo* tick_info = resp_body_->add_infos();
      tick_info->CopyFrom(it->second);
    }
    loop_->CancelTimer(timer_id_);
    SendResponse(0, "sucess");
  }
}

void GetLcRwTick::TimeoutCb() {
  ULOG_ERROR << "get rw tick info timeout, remain loop_cout:" << loop_count_;
  SendResponse(-1, "get rw tick info in io loop timeout");
}

void GetLcRwTick::SendResponse(int retcode, const std::string& message) {
  resp_body_->mutable_rc()->set_retcode(retcode);
  resp_body_->mutable_rc()->set_error_message(message);
  ULOG_INFO << response_.DebugString();
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

}  // namespace gate
}  // namespace udisk
