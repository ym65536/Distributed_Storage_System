#ifndef UDISK_GATE_ARK_IO_REQUEST_H_
#define UDISK_GATE_ARK_IO_REQUEST_H_

#include <stdint.h>

namespace udisk {
namespace gate {

class UDiskHandle;
class IORequest;
class ArkHandle;

class ArkIORequest {
 public:
  ArkIORequest(ArkHandle* ark_handle, IORequest* io);
  ~ArkIORequest();
  uint64_t io_size() { return io_size_; }
  uint64_t io_secnum() { return io_secnum_; }
  uint64_t begin_sector() { return begin_sector_; }
  char* io_data() { return io_data_; }
  uint64_t seq_no() { return seq_no_; }
  void AssignSeqNo(uint64_t seq_no) { seq_no_ = seq_no; }

 private:
  ArkHandle* ark_handle_;
  IORequest* io_req_;
  char* io_data_;
  uint64_t io_secnum_;
  uint64_t io_size_;
  uint64_t begin_sector_;
  uint64_t seq_no_;
};

}  // namespace gate
}  // namespace udisk

#endif
