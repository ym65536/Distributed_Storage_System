#ifndef UDISK_GATE_ARK_IO_BATCH_H_
#define UDISK_GATE_ARK_IO_BATCH_H_

#include <stdint.h>
#include <list>
#include "ark_io_request.h"

namespace udisk {
namespace gate {

class UDiskHandle;
class IORequest;
class ArkHandle;

class ArkIOBatch {
 public:
  explicit ArkIOBatch(ArkHandle* ark_handle);
  ~ArkIOBatch();
  void Insert(ArkIORequest* ark_io);
  uint32_t length() { return batch_.size(); }
  uint64_t batch_no() { return batch_no_; }
  uint64_t batch_size() { return batch_size_; }
  void AssignBatchNo(uint64_t batch_no) { batch_no_ = batch_no; }
  void Send();

 private:
  ArkHandle* ark_handle_;
  uint64_t batch_no_;
  uint64_t batch_size_;
  std::list<ArkIORequest*> batch_;
};

}  // namespace gate
}  // namespace udisk

#endif
