#ifndef UDISK_GATE_ABORT_H_
#define UDISK_GATE_ABORT_H_

#include <ustevent/base/logging.h>
#include <ustevent/eventloop.h>
#include <ustevent/pb_request_handle.h>
#include "udisk_message.h"

using namespace uevent;

namespace udisk {
namespace gate {

class BlockGateAbort : public PbRequestHandle {
 public:
  explicit BlockGateAbort(uevent::EventLoop* loop) : loop_(loop) {}
  virtual ~BlockGateAbort() {}
  virtual void EntryInit(const ConnectionUeventPtr& conn, const UMessagePtr& um); 

  void Abort(const ucloud::udisk::BlockGateTerminateRequest& req);
  void SendResponse(int retcode, const std::string& message);
  MYSELF_CREATE(BlockGateAbort);

  void DestroyMyself();

 private:
  static int type_;
  uevent::EventLoop* loop_;
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage response_;
  ucloud::udisk::BlockGateTerminateResponse* resp_body_;
};
}
}
#endif
