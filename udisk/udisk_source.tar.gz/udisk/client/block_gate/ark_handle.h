#ifndef UDISK_GATE_ARK_HANDLE_H_
#define UDISK_GATE_ARK_HANDLE_H_

#include <vector>
#include <ustevent/base/logging.h>
#include <ustevent/eventloop.h>
#include "io_request.h"
#include "udisk_message.h"
#include "ark_io_batch.h"
#include "ark_io_request.h"
#include "ark_status.h"

namespace uevent {
class EventLoop;
}

namespace udisk {
namespace gate {

class UDiskHandle;

using uevent::ConnectionUeventPtr;
using uevent::TimerId;
using uevent::EventLoop;

typedef std::function<void(int retcode, const std::string& message)>
    ArkResponseCb;
const int MAX_ARK_SIZE_MB = 4096;
const int MAX_ARK_PENDING_SIZE_MB = 1024;
const int MAX_ARK_INFLIGHT_SIZE_MB = 1024;
const int MAX_ARK_INFLIGHT_DEPTH = 128;
const int MAX_ARK_BATCH_SIZE = 524288;  // 521k
const int MAX_ARK_BATCH_LENGTH = 512;

enum ArkChannelStatus {
  ON = 0,
  OFF = 1,
  DOWN = 2
};

class TimeWheel {
 public:
  TimeWheel(int cycle, EventLoop* loop) : tick_(0), cycle_(cycle), loop_(loop) {
    for (auto i = 0; i < cycle; i++) {
      time_wheel_.push_back(std::list<std::weak_ptr<ArkIOBatch>>());
    }
  }

  ~TimeWheel() { StopTimeWheel(); }

  void StartTimeWheel() {
    tw_timer_id_ = loop_->RunEvery(1, std::bind(&TimeWheel::Tick, this));
  }

  void StopTimeWheel() { loop_->CancelTimer(tw_timer_id_); }

  void AddBatch(const std::shared_ptr<ArkIOBatch>& batch) {
    ULOG_DEBUG << "###add batch_no:" << batch->batch_no() << " into time wheel";
    std::weak_ptr<ArkIOBatch> wp_batch = batch;
    std::list<std::weak_ptr<ArkIOBatch>>& timeout_batchs = time_wheel_[tick_];
    timeout_batchs.push_back(wp_batch);
  }

  void Tick() {
    tick_++;
    tick_ = tick_ % cycle_;
    std::list<std::weak_ptr<ArkIOBatch>>& timeout_batchs = time_wheel_[tick_];
    ULOG_DEBUG << "###tick:" << tick_
               << " timeout_batch_io begin size:" << timeout_batchs.size();
    for (auto iter = timeout_batchs.begin(); iter != timeout_batchs.end();) {
      auto ark_batch_ptr = iter->lock();
      if (ark_batch_ptr) {
        ULOG_TRACE << "###timeout_batch_no:" << ark_batch_ptr->batch_no()
                   << ", batch_size:" << ark_batch_ptr->batch_size()
                   << ", length:" << ark_batch_ptr->length();
        ark_batch_ptr->Send();
        iter++;
      } else {
        iter = timeout_batchs.erase(iter);
      }
    }
    ULOG_DEBUG << "###tick:" << tick_
               << " timeout_batch_io after size:" << timeout_batchs.size();
  }

 private:
  int tick_;
  int cycle_;
  std::vector<std::list<std::weak_ptr<ArkIOBatch>>> time_wheel_;
  TimerId tw_timer_id_;
  EventLoop* loop_;
};

class ArkHandle {
 public:
  ArkHandle(UDiskHandle* handle, ucloud::udisk::UTM_MODE utm_mode,
            ucloud::udisk::UTM_STATUS utm_status,
            ucloud::udisk::UDISK_MOUNT_STATUS mount_status);
  ~ArkHandle();
  void LoginArk(const uevent::UsockAddress& addr);
  void InsertArkIO(IORequest* io_req);
  void SendPendingArkIO();
  const ConnectionUeventPtr GetConnection();
  void RebaseLogin(ArkResponseCb cb);
  void RebaseLogout(ArkResponseCb cb);
  void ArkOn(ArkResponseCb cb);
  void ArkOff(ArkResponseCb cb);
  void ArkKill();
  void ArkFinalCheck();
  void ArkStatTransSuccess();
  void ArkStatTransFailed();
  void ArkStatTransTimeout();

  inline EventLoop* GetLoop() { return loop_; }
  inline void set_max_pending_size(uint64_t size) { max_pending_size_ = size; }
  inline void set_max_inflight_size(uint64_t size) {
    max_inflight_size_ = size;
  }
  inline uint32_t cur_pending_size() { return cur_pending_size_; }
  inline uint32_t cur_inflight_size() { return cur_inflight_size_; }
  inline std::string extern_id() const { return extern_id_; }
  inline void set_extern_id(const std::string& extern_id) {
    extern_id_ = extern_id;
  }
  inline ucloud::udisk::UTM_STATUS GetTargetStatus() {
    return ark_status_->GetTargetStatus();
  }
  inline ucloud::udisk::UTM_STATUS GetArkStatus() {
    return ark_status_->GetArkStatus();
  }
  inline UDiskHandle* udisk_handle() { return udisk_handle_; }

  void TryTurnOffChannel() {
    if (channel_status_ == ON) {
      TurnOffChannel();
    } else {
      ULOG_INFO << "extern_id:" << extern_id_ << " ArkChannel Not Open";
    }
  }

  void ReLoginArk();

 private:
  static void ArkConnSuccessCb(const ConnectionUeventPtr& conn);
  static void ArkConnClosedCb(const ConnectionUeventPtr& conn);
  static void ArkConnReadCb(const ConnectionUeventPtr& conn);
  void ArkIOResponseHandle(const ConnectionUeventPtr& conn);
  void ArkLoginResponseHandle(const ConnectionUeventPtr& conn);
  void ArkHeartbeatResponseHandle(const ConnectionUeventPtr& conn);
  void SetArkConnector(const uevent::UsockAddress& addr);
  void LoginArk();
  void UpdateRouteAndReLoginArk();
  void DoLoginArk(ConnectionUeventPtr conn);
  void LoginTimeoutCb(uint64_t request_id);
  void RegisterTimeIdMap(uint64_t request_id, TimerId& timer_id);
  bool UnRegisterTimeIdMap(uint64_t request_id);
  void ArkErrorHandle(int32_t retcode);
  void ArkIODone(uint64_t batch_no);
  void StartGateArkHeartbeat();
  void GateArkHeartbeat();
  void GateArkHeartbeatTimeoutCb(uint64_t request_id);
  void ClearPendingList();
  void ClearInFlightList();
  void StopArk();
  void InitArk();
  void ResetArk();
  void ArkStatTransCb(bool success, ArkTransOp op,
                      ucloud::udisk::UTM_STATUS target_status);
  void Ark2NeedRebaseWrapper(ArkTransOp op);

  uint64_t GetNextSeqNo() { return seq_no_counter_++; }
  uint64_t GetNextBatchNo() { return batch_no_counter_++; }
  uint64_t GetNextRequestId() { return request_id_++; }

  void TurnOnChannel() {
    ULOG_INFO << "extern_id:" << extern_id_ << " Turn On ArkChannel";
    channel_status_ = ON;
  }
  void TurnOffChannel() {
    ULOG_INFO << "extern_id:" << extern_id_ << " Turn Off ArkChannel";
    channel_status_ = OFF;
  }
  void ShutDownChannel() {
    ULOG_INFO << "extern_id:" << extern_id_ << " Turn Down ArkChannel";
    channel_status_ = DOWN;
  }

  void EnableHeartbeat() { enable_heartbeat_ = true; }

  void DisableHeartbeat() { enable_heartbeat_ = false; }

  const static int kArkLoginTimeOut = 3;       // 3s
  const static int kArkHeartbeatTimeOut = 10;  // 10s
  const static int kArkIOSendTimeOut = 3;      // 3s
  UDiskHandle* udisk_handle_;
  std::string extern_id_;
  EventLoop* loop_;
  ArkChannelStatus channel_status_;
  uint64_t max_pending_size_;   // memory size byte
  uint64_t cur_pending_size_;   // memory size byte
  uint64_t max_inflight_size_;  // memory size byte
  uint64_t cur_inflight_size_;  // memory size byte
  TimeWheel tw_;
  uint64_t seq_no_counter_;
  uint64_t batch_no_counter_;
  uint64_t request_id_;
  int heartbeat_retry_;
  int login_retry_;
  TimerId heartbeat_timer_id_;
  bool enable_heartbeat_;
  uevent::ConnectorUeventPtr ctor_;
  std::list<ArkIORequest*> ark_pending_list_;
  std::list<std::shared_ptr<ArkIOBatch>> ark_inflight_list_;
  std::map<uint64_t, TimerId> timer_id_map_;
  ArkResponseCb ark_resp_cb_;
  ArkStatus* ark_status_;
};

}  // namespace gate
}  // namespace udisk

#endif
