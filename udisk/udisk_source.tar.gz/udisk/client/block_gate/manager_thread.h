#ifndef UDISK_GATE_MANAGER_THREAD_H_
#define UDISK_GATE_MANAGER_THREAD_H_

#include <set>
#include <map>
#include <unordered_map>
#include <memory>
#include <ustevent/worker_thread.h>
#include <ustevent/libevent/listener_libevent.h>
#include <tuple>
#include "umessage.h"
#include "ark_handle.h"
#include "cluster_hash_ring.h"

namespace uevent {
class EventLoop;
class ListenerUevent;
class ConnectionUevent;
class ConnectorUevent;
}

namespace udisk {
namespace gate {

class MyConfigParser;
class UDiskHandle;
class GateChunkIOStatsHandle;

typedef std::map<std::string, std::tuple<std::string, uint32_t, std::string, std::string, uint32_t>> 
                        LCTimeoutMap;
typedef std::function<void(bool, int64_t)> ResizeResponseCb;
class ManagerThread {
 public:
  // handle_id,UDiskHandle* 组合才能唯一标识一个handle
  typedef std::pair<int64_t, UDiskHandle*> HandleEntry;
  typedef std::map<std::string, uevent::ConnectorUeventPtr>
      SetNameToConnectorMap;
  struct QosInfo {
    int limit_bw_percent;
    int limit_iops_percent;
    int limit_read_bw_percent;
    int limit_write_bw_percent;
    uint64_t max_bw;
    uint64_t max_iops;
  };

  static ManagerThread* Instance();
  inline uevent::EventLoop* GetLoop() { return loop_; }
  uevent::ConnectorUeventPtr CreateAccessConnector();
  uevent::ConnectionUeventPtr GetMetaServerConnection(
      const std::string& set_name, const std::string& zk_server);
  uevent::ConnectionUeventPtr GetOdinConnection(const std::string& set_name,
                                                const std::string& zk_server);
  uevent::ConnectionUeventPtr GetArkAccessConnection(
      const std::string& set_name, const std::string& global_zk_server);

  UDiskHandle* GetUDiskHandleByExternId(const std::string& extern_id);

  // thread safe
  void Start();
  void StartInLoop();

  void LoginAccess(UDiskHandle* handle);
  void GetMetaData(UDiskHandle* handle);
  void Heartbeat(UDiskHandle* handle);
  void DelLoginAccessPtr(UDiskHandle* handle, int64_t handle_id);
  void ReportOdinTimer();
  void WarningToOdin(ucloud::udisk::OdinWarningRequest& warn_request,
                     const std::string& set_name, const std::string& zk_server);

  // ark
  void GetArkRouter(UDiskHandle* handle);
  void ArkResponse(ArkResponseCb cb, int retcode, std::string msg);
  void SetArkStatus(UDiskHandle* handle);
  void SetArkStatus(UDiskHandle* handle,
                    ucloud::udisk::UTM_STATUS target_utm_status,
                    ucloud::udisk::UTM_STATUS current_utm_status);
  void ArkExit();
  void ReportIOTimeout(const std::string& extern_id,
                       uint32_t retry_times,
                       const std::string& set_name, 
                       const std::string& zk_server,
                       const std::string& chunk_ip,
                       uint32_t chunk_id);
  void SetUDiskQosInfo(UDiskHandle* handle, const QosInfo& info);
  void DeleteUDiskQosInfo(UDiskHandle* handle);
  int GetChunkIOStatistics(const std::string& extern_id,
                           const std::shared_ptr<GateChunkIOStatsHandle>& ptr);
  void GetChunkIOStatisticsResponse(
      std::vector<ucloud::udisk::GateChunkIOStats> stats,
      std::unordered_map<uint32_t, ucloud::udisk::GatePCIOStats> pc_stats,
      std::shared_ptr<GateChunkIOStatsHandle> ptr);

  void ReportInitHashRingResult(bool result, UDiskHandle* handle,
                                const cluster::ClusterHashRing::VirtualNodeMap* node_map);
  void InitClusterNodes(UDiskHandle* handle);
  void Resize(UDiskHandle* handle, uint32_t size, ResizeResponseCb cb);

 private:
  typedef std::pair<std::string, int> ConnectorKey;
  struct ConnectorKeyHash {
    std::size_t operator()(ConnectorKey const& item) const {
      std::size_t h1 = std::hash<std::string>()(item.first);
      std::size_t h2 = std::hash<int>()(item.second);
      return h1 ^ (h2 << 1);
    }
  };
  typedef std::vector<ucloud::udisk::LCStats> SegmentIOInfo;
  typedef std::map<HandleEntry, QosInfo> UDiskQosInfoMap;
  typedef std::map<HandleEntry, std::vector<ucloud::udisk::LCIOStats>>
      UDiskStatMap;
  typedef std::map<HandleEntry, std::vector<SegmentIOInfo>> UDiskSegmentIOStatMap;

  enum QosOpType {
    kQosReadBw = 0,
    kQosWriteBw,
    kQosTotal,
    kQosTypeNum,
  };
  static const uint32_t kIOSize8KRange = 3;
  static const uint32_t kIOSize16KRange = 5;
  static const uint32_t kIOSize64KRange = 17;
  static const uint32_t kIOSize256KRange = 65;

  ManagerThread();
  ~ManagerThread();
  void ListenerInit();
  void ManConnSuccessCb(const uevent::ConnectionUeventPtr& conn);
  void ManConnClosedCb(const uevent::ConnectionUeventPtr& conn);
  void ConnectorConnSuccessCb(const uevent::ConnectionUeventPtr& conn);
  void ConnectorConnClosedCb(const uevent::ConnectionUeventPtr& conn);
  void LoginAccessInLoop(HandleEntry entry);
  void GetMetaDataInLoop(HandleEntry entry);
  void HeartbeatInLoop(HandleEntry& entry,
                       ucloud::udisk::LCIOStats& iostat,
                       SegmentIOInfo& segment_iostat);
  void StatsInfoHandle(HandleEntry& entry,
                      ucloud::udisk::LCIOStats& iostat,
                      SegmentIOInfo& segment_iostat);
  void WarningToOdinInLoop(ucloud::udisk::OdinWarningRequest& warn_request,
                           const std::string& set_name,
                           const std::string& zk_server);
  void LoginResponseCb(const uevent::UMessagePtr& um, HandleEntry entry,
                       const uevent::ConnectorUeventPtr& ctor);
  void LoginTimeoutCb(HandleEntry entry,
                      const uevent::ConnectorUeventPtr& ctor);
  void LoginAccessFinish(int32_t ret_code, HandleEntry entry);
  void GetMetaDataResponseCb(const UMessagePtr& um, HandleEntry entry);
  void GetMetaDataTimeoutCb(HandleEntry entry);
  void HeartbeatResponseCb(const uevent::UMessagePtr& um, HandleEntry entry);
  void HeartbeatTimeoutCb(HandleEntry entry);
  void ReportIOStatResponseCb(const uevent::UMessagePtr& um);
  void ReportIOStatTimeout();
  void OdinWarningResponseCb(const uevent::UMessagePtr& um);
  void OdinWarningTimeout();
  // ark
  void GetArkRouterInLoop(HandleEntry entry);
  void GetArkRouterResponseCb(const uevent::UMessagePtr& um, HandleEntry entry);
  void GetArkRouterTimeoutCb(HandleEntry entry);
  void ArkWoodpeckerTimer();
  void ArkAccessConnSuccessCb(const ConnectionUeventPtr& conn);
  void ArkAccessConnClosedCb(const ConnectionUeventPtr& conn);
  void SetArkStatusInLoop(HandleEntry entry,
                          ucloud::udisk::UTM_STATUS target_utm_status,
                          ucloud::udisk::UTM_STATUS current_utm_status,
                          std::string extern_id, std::string set_name);
  void SetArkStatusTimeoutCb(HandleEntry entry);
  void SetArkStatusResponseCb(const uevent::UMessagePtr& um, HandleEntry entry);
  void ArkResponseInLoop(ArkResponseCb cb, int retcode, std::string& msg);
  void ArkFinalSendTimeUp();
  void ReportIOTimeoutInLoop(const std::string& extern_id,
                             uint32_t retry_times,
                             const std::string& set_name, 
                             const std::string& zk_server,
                             const std::string& chunk_ip,
                             uint32_t chunk_id);
  void ReportOdinIOTimeout();
  void SetUDiskQosInfoInLoop(const HandleEntry& entry, const QosInfo& info);
  void DeleteUDiskQosInfoInLoop(const HandleEntry& entry);
  void QosThrottle();
  void QosThrottleHandle(QosOpType type, double total_bw,
                         std::multimap<double, HandleEntry> lcs_rate);
  int GetQosPercentByType(QosOpType type, const HandleEntry& entry);
  string GetLimitBWTypeString(QosOpType type);
  void SetLimitBWPercent(QosOpType type, UDiskHandle* handle,
                         int limit_bw_percent);
  void ReportOverload(const std::string& info, bool recover);
  void ResizeInLoop(HandleEntry entry, uint32_t size, ResizeResponseCb cb);
  void ResizeResponse(const uevent::UMessagePtr& um, HandleEntry entry,
                      ResizeResponseCb cb);
  void ResizeTimeout(HandleEntry entry, ResizeResponseCb cb);

  uevent::WorkerThread work_thread_;
  uevent::EventLoop* loop_;
  uevent::ConnectionUeventPtr GetConnection(const std::string &ip, uint32_t port);
  void ReportIOStat();
  void ReportSegmentIOStat();
  void ReportSegmentIOStatResponseCb(const uevent::UMessagePtr& um);
  void ReportSegmentIOStatTimeout();
  std::string ValidClusterUuid(const UDiskHandle* handle, uint32_t uuid);
  void InitClusterNodesInLoop(HandleEntry entry);
  void InitHashRingFailureInLoop(HandleEntry entry, uint32_t uuid);
  void InitHashRingSuccessInLoop(HandleEntry entry, uint32_t uuid,
                                 const cluster::ClusterHashRing::VirtualNodeMap& node_map);
  void AssignSegmentIOInfo(const ucloud::udisk::LCStats& src_lcstat,
                           ucloud::udisk::LCStats* dst_lcstat, 
                           uint32_t item_count);
  void SumSegmentIOInfo(const ucloud::udisk::LCStats& src_lcstat, 
                        ucloud::udisk::LCStats* dst_lcstat);
  void CeilSegmentIOInfo(ucloud::udisk::LCStats* lcstat, uint32_t item_count);

  // 管理线程的listener，接收PB请求
  std::shared_ptr<uevent::ListenerUevent> listener_;
  ucloud::udisk::UDiskLoginResponse login_rsp_;
  SetNameToConnectorMap ark_access_connector_map_;
  static ManagerThread* instance_;
  UDiskStatMap udisk_stats_;
  UDiskSegmentIOStatMap udisk_segment_stats_;

  std::unordered_map<ConnectorKey, uevent::ConnectorUevent*, ConnectorKeyHash>
      connectors_;
  LCTimeoutMap lc_timeout_;
  UDiskQosInfoMap qos_info_;
  uint32_t throttle_broaden_time_; 

  std::unordered_map<std::string, cluster::ClusterHashRing::VirtualNodeMap> cluster_node_map_cache_;
  std::unordered_multimap<std::string, HandleEntry> wait_init_hash_handle_;
};

}  // namespace gate
}  // namespace udisk

#endif

