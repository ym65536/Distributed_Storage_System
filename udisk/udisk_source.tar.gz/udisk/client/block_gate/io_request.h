#ifndef UDISK_GATE_IO_REQUEST_H_
#define UDISK_GATE_IO_REQUEST_H_

#include <vector>
#include <bitset>
#include <ustevent/base/timestamp.h>
#include <ustevent/callbacks.h>
#include "qemu_io_proto.h"

namespace udisk {
namespace gate {

// IO 按1MB 切片
//#define SECTOR_PER_SLICE 2048
static const int kSectorPerSlice = 2048;

class UDiskHandle;
class FragIORequest;

class IORequest {
 public:
  IORequest(UDiskHandle* handle, common::QemuIOHead* head);
  ~IORequest();
  void Init(const uevent::ConnectionUeventPtr& conn);
  int Send();
  void Response();
  void DecTimerCount();
  void DecPendingTimerCount();
  inline uint64_t GetFlowno() const { return qemu_head_->flowno; }
  inline uint64_t GetBeginSector() const { return qemu_head_->sector; }
  inline uint64_t GetEndSector() const { return end_sector_; }
  inline FragIORequest* GetFragIORequest(uint32_t fragno) {
    return frag_req_vec_[fragno];
  }
  inline std::vector<FragIORequest*>* GetFragReqVec() { return &frag_req_vec_; }

  //最多只能有1024个分片
  inline bool MarkFragReceived(uint32_t fragno) {
    frag_bit_set_[fragno] = 0;
    return frag_bit_set_.none();  // 全为0 表示收到了所有的分片
  }

  inline void MarkFragUnReceived(uint32_t fragno) { frag_bit_set_[fragno] = 1; }

  inline char* GetDataAddress() { return data_; }

  inline uint64_t GetSectorNumber() { return qemu_head_->secnum; }

  // 0表示读，1表示写
  inline int GetIOCmd() {
    return qemu_head_->cmd;
  }

 private:
  bool CheckOverlap();
  UDiskHandle* udisk_handle_;
  common::QemuIOHead* qemu_head_;
  uint64_t end_sector_;
  char* data_;
  std::vector<FragIORequest*> frag_req_vec_;
  std::bitset<1024> frag_bit_set_;
  base::Timestamp start_time_;
  int pending_timer_count_;
};

}  // namespace gate
}  // namespace udisk

#endif
