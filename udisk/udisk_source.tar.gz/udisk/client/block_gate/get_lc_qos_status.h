#ifndef UDISK_GATE_GET_LC_QOS_STATUS_H_
#define UDISK_GATE_GET_LC_QOS_STATUS_H_

#include <ustevent/base/logging.h>
#include <ustevent/eventloop.h>
#include <ustevent/pb_request_handle.h>
#include "udisk_message.h"

using namespace uevent;

namespace udisk {
namespace gate {

class GetLcQosStatus : public PbRequestHandle {
 public:
  GetLcQosStatus(uevent::EventLoop* loop) : loop_(loop) {}
  virtual ~GetLcQosStatus() {}
  virtual void EntryInit(const ConnectionUeventPtr& conn,
                         const UMessagePtr& um);

  void GetQosStatusInfos(const ucloud::udisk::GetLcQosStatusRequest& req);
  void GetQosStatusInfosCb(bool has_valid_lc,
                           const ucloud::udisk::LcQosStatusInfo& info);
  void GetQosStatusInfosCbInLoop(bool has_valid_lc,
                                 const ucloud::udisk::LcQosStatusInfo& info);
  void TimeoutCb();
  void SendResponse(int retcode, const std::string& message);
  MYSELF_CREATE(GetLcQosStatus);

  void DestroyMyself();

 private:
  static int type_;
  uevent::EventLoop* loop_;
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage response_;
  ucloud::udisk::GetLcQosStatusResponse* resp_body_;
  int loop_count_;
  uevent::TimerId timer_id_;
};
}
}
#endif
