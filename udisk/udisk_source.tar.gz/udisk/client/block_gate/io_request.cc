#include "io_request.h"
#include <ustevent/base/logging.h>
#include <ustevent/libevent/connection_libevent.h>
#include "udisk_types.h"
#include "udisk_handle.h"
#include "frag_io_request.h"
#include "gate.h"

namespace udisk {

namespace gate {

using namespace uevent;
using namespace base;
using namespace common;

IORequest::IORequest(UDiskHandle* handle, QemuIOHead* head)
    : udisk_handle_(handle),
      qemu_head_(head),
      end_sector_(head->sector + head->secnum),  //结束位置，便于计算
      start_time_(Timestamp::now()), //io开始时间,用于延时统计
      pending_timer_count_(100 * g_config_parser->max_pending_time()) {
  data_ = reinterpret_cast<char*>(malloc(head->secnum * SECTOR_SIZE));
}

IORequest::~IORequest() {
  delete qemu_head_;
  free(data_);
  for (auto it = frag_req_vec_.begin(); it != frag_req_vec_.end(); it++) {
    delete *it;  //析构包含的分片请求
  }
}

void IORequest::Init(const ConnectionUeventPtr& conn) {
  if (qemu_head_->cmd == QEMU_CMD_WRITE) {
    conn->RemoveData(data_, qemu_head_->size - sizeof(QemuIOHead));
    // 将应答的size填好，发送应答时会直接用这个头
    qemu_head_->size = sizeof(QemuIOHead);
  } else {
    qemu_head_->size = sizeof(QemuIOHead) + qemu_head_->secnum * SECTOR_SIZE;
  }
  FragIORequest* frag_io_req = NULL;
  for (uint64_t b = qemu_head_->sector,
           e = b - b % kSectorPerSlice + kSectorPerSlice;
           b < end_sector_; e += kSectorPerSlice) {
    frag_io_req = new FragIORequest(udisk_handle_);
    if (e <= end_sector_) {
      frag_io_req->begin_sector = b;
      // 分片的数据对应的起始地址
      frag_io_req->data = data_ + (b - qemu_head_->sector) * SECTOR_SIZE;
      frag_io_req->secnum = e - b;
      frag_bit_set_[frag_req_vec_.size()] = 1;
      frag_req_vec_.push_back(frag_io_req);
      b = e;
    } else {
      frag_io_req->begin_sector = b;
      // 分片的数据对应的起始地址
      frag_io_req->data = data_ + (b - qemu_head_->sector) * SECTOR_SIZE;
      frag_io_req->secnum = end_sector_ - b;
      frag_bit_set_[frag_req_vec_.size()] = 1;
      frag_req_vec_.push_back(frag_io_req);
      break;
    }
  }
  ULOG_TRACE << "frag size: " << frag_req_vec_.size();
  if (frag_req_vec_.size() > 1024) {
    ULOG_FATAL << "io frag size is too large";
  }
}

int IORequest::Send() {
  if (udisk_handle_->RouteIsReady() == false) {
    ULOG_DEBUG << "udisk route is not ready";
    return -1;
  }
  if (CheckOverlap() == true) {
    ULOG_TRACE << "the io has overlap, need pending";
    return -1;
  }
  //遍历所有分片，依次发送
  for (uint32_t i = 0; i < frag_req_vec_.size(); i++) {
    frag_req_vec_[i]->gate_req_head.flowno = qemu_head_->flowno;
    frag_req_vec_[i]->gate_req_head.magic = QEMU_MAGIC;
    frag_req_vec_[i]->gate_req_head.fragno = i;
    frag_req_vec_[i]->gate_req_head.cmd = qemu_head_->cmd;
    //没有检查返回值，只要执行了就放入inflight队列,如果失败，依赖超时重发
    frag_req_vec_[i]->SendFragIO();
  }
  return 0;
}

// 为了实现IO的保序，
// 有重叠的的区域必须等待之前IO应答，即与pending_list
// 中位于本IO之前所有的IO都不重叠才能发送，不要考虑之后的IO
bool IORequest::CheckOverlap() {
  for (auto it = udisk_handle_->GetInflightList().begin();
       it != udisk_handle_->GetInflightList().end(); it++) {
    if (end_sector_ <= (*it)->GetBeginSector() ||
        qemu_head_->sector >= (*it)->GetEndSector()) {
      continue;  //无重叠继续下一个
    }
    ULOG_TRACE << "has overlap with inflight io";
    return true;  // 有重叠， 不发送直接返回
  }
  for (auto it = udisk_handle_->GetPendingList().begin();
       it != udisk_handle_->GetPendingList().end() &&
           (*it)->GetFlowno() != qemu_head_->flowno;
       it++) {
    if (end_sector_ <= (*it)->GetBeginSector() ||
        qemu_head_->sector >= (*it)->GetEndSector()) {
      continue;  //无重叠继续下一个
    }
    ULOG_TRACE << "has overlap with pending io";
    return true;  // 有重叠， 不发送直接返回
  }
  return false;
}

void IORequest::Response() {
  ULOG_TRACE << "io response to qemu:\n" << DumpQemuIOHead(*qemu_head_);
  Timestamp end_time(Timestamp::now());
  const ConnectionUeventPtr& qemu_conn = udisk_handle_->GetQemuConn();
  // qemu_conn已经被reset或者已经关闭
  if (!qemu_conn || qemu_conn->IsClosed() == true) {
    ULOG_ERROR << "qemu connection closed when response";
    return;
  }
  qemu_conn->SendData(qemu_head_, sizeof(QemuIOHead));
  const int64_t io_size = qemu_head_->secnum * SECTOR_SIZE;
  // 根据IO大小分别统计各IO的iops、时延等
  if (qemu_head_->cmd == QEMU_CMD_READ) { // 读请求需要带上数据
    qemu_conn->SendData(data_, io_size);
    udisk_handle_->IncReadIOCount(io_size); // 记录IO的统计信息
    udisk_handle_->IncReadBytesCount(io_size);
    udisk_handle_->AddReadLatency(base::timeDifferenceUs(end_time, start_time_),
                                  io_size);
    udisk_handle_->set_last_read_tick(end_time);
  } else { // qemu_head_->cmd == WRITE
    udisk_handle_->IncWriteIOCount(io_size);  // 记录IO的统计信息
    udisk_handle_->IncWriteBytesCount(io_size);
    udisk_handle_->AddWriteLatency(base::timeDifferenceUs(end_time, start_time_),
                                  io_size);
    udisk_handle_->set_last_write_tick(end_time);
  }
}

void IORequest::DecTimerCount() {
  for (uint32_t i = 0; i < frag_req_vec_.size(); i++) {
    if (frag_bit_set_[i] == 1) {  //没有收到回复才需要减计数
      frag_req_vec_[i]->DecTimerCount();
    }
  }
}

void IORequest::DecPendingTimerCount() {
  if (--pending_timer_count_ == 0) {
    LOG_ERROR << "io request has been pending over max pending time, "
              << DumpQemuIOHead(*qemu_head_);
    udisk_handle_->ReportPendingIOTimeout();
  }
}

} // namespace gate
} // namespace udisk
