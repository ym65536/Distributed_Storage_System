#include "ark_on.h"
#include <ustevent/message_util.h>
#include "gate.h"
#include "gate_listener.h"
#include "udisk_handle.h"
#include "manager_thread.h"
#include "umessage_common.h"

namespace udisk {
namespace gate {

using namespace uevent;

int ArkOnHandle::type_ = ucloud::udisk::ARK_ON_REQUEST;

void ArkOnHandle::EntryInit(const ConnectionUeventPtr& conn,
                            const UMessagePtr& um) {
  ULOG_INFO << um->DebugString();
  conn_ = conn;
  assert(um->head().message_type() == type_);
  assert(um->body().HasExtension(ucloud::udisk::ark_on_request));
  req_body_ = um->body().GetExtension(ucloud::udisk::ark_on_request);
  MakeResponse(um.get(), ucloud::udisk::ARK_ON_RESPONSE, &response_);
  resp_body_ = response_.mutable_body()->MutableExtension(
      ucloud::udisk::ark_on_response);
  ArkOnProcess();
}

void ArkOnHandle::ArkOnProcess() {
  UDiskHandle* udisk_handle =
      ManagerThread::Instance()->GetUDiskHandleByExternId(
          req_body_.extern_id());
  if (udisk_handle == nullptr) {
    ULOG_ERROR << "get null udisk_handle with extern_id:"
               << req_body_.extern_id();
    SendResponse(ucloud::udisk::EC_UDISK_QEMU_NOT_LOGIN,
                 "extern_id:" + req_body_.extern_id() + " is not exist");
    return;
  }
  std::shared_ptr<ArkOnHandle> this_ptr =
      std::dynamic_pointer_cast<ArkOnHandle>(shared_from_this());
  udisk_handle->ArkOn(std::bind(&ArkOnHandle::SendResponse, this_ptr,
                                std::placeholders::_1, std::placeholders::_2),
                      udisk_handle->handle_id());
}

void ArkOnHandle::SendResponse(int retcode, const std::string& message) {
  resp_body_->mutable_rc()->set_retcode(retcode);
  resp_body_->mutable_rc()->set_error_message(message);
  ULOG_INFO << response_.DebugString();
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

}  // namespace gate
}  // namespace udisk
