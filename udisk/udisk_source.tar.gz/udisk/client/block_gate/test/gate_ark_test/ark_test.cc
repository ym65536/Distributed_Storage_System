#include <malloc.h>
#include <pthread.h>
#include <stdlib.h>
#include <sys/syscall.h>
#include <unistd.h>
#include <iostream>
#include "ark_handle.h"
#include "async_logging.h"
#include "logging.h"
#include "manager_thread.h"
#include "udisk_handle.h"
#include "udisk_types.h"

using namespace std;
using namespace udisk::gate;
using namespace uevent;

std::unique_ptr<base::AsyncLogging> g_asyncLog;
TimerId simu_id;

void GenData(int size, char* addr) {
  for (int i = 0; i < size; i++) {
    *(addr + i) = (i % 10) + 48;
  }
}

IORequest* IORequestGenerator(UDiskHandle* handle, int sector_num) {
  QemuIOHead* fake_head = new QemuIOHead();
  fake_head->secnum = sector_num;

  IORequest* io_req = new IORequest(handle, fake_head);
  GenData(fake_head->secnum * SECTOR_SIZE, io_req->GetDataAddress());

  return io_req;
}

int mo_count = 0;

// clear mem
void MemTrim() {
  cout << "clear memory" << endl;
  malloc_trim(0);
}

void IOSimulation(UDiskHandle* udisk_handle) {
  if (udisk_handle->GetArkHandle()->GetArkStatus() ==
      ucloud::udisk::UTM_STATUS_NEED_REBASE) {
    cout << "need rebase stop simulation, count:" << mo_count << endl;
    udisk_handle->GetLoop()->CancelTimer(simu_id);

    udisk_handle->GetLoop()->RunAfter(60, std::bind(&MemTrim));

    return;
  }

  int rand_secnum = rand() % 1000;
  cout << "gen a fake io===>sector_num:" << rand_secnum << endl;
  IORequest* io_req = IORequestGenerator(udisk_handle, rand_secnum);
  udisk_handle->GetArkHandle()->InsertArkIO(io_req);
  mo_count++;
}

void AsyncOutput(const char* msg, int len) { g_asyncLog->append(msg, len); }

int main(int argc, char** argv) {
  base::Logger::setLogLevel("debug");  //设置日志级别
  g_asyncLog.reset(
      new base::AsyncLogging("/home/sean.shuai/log/ark_test.log", 1000000000));
  g_asyncLog->start();  //会等待日志线程初始化好
  base::Logger::setOutput(AsyncOutput);

  EventLoopLibevent loop("ark_test_thread", UDiskHandle::CreateMyself);
  UDiskHandle* udisk_handle =
      reinterpret_cast<UDiskHandle*>(loop.GetLoopHandle());
  udisk_handle->SetLcSize(10240);
  udisk_handle->SetLcId(1);
  udisk_handle->ArkInit(0, ucloud::udisk::UTM_MODE_OPEN,
                        ucloud::udisk::UTM_STATUS_NORMAL,
                        ucloud::udisk::UDISK_MOUNT_STATUS_AVAILABLE);
  ArkHandle* ark_handle = udisk_handle->GetArkHandle();
  ark_handle->set_extern_id("test_vdisk_000_data");
  UsockAddress addr("192.168.152.110", 50001);

  double t = atoi(argv[1]);
  simu_id = udisk_handle->GetLoop()->RunEvery(
      1 / t, std::bind(&IOSimulation, udisk_handle));

  ark_handle->LoginArk(addr);
  loop.Start();

  return 0;
}
