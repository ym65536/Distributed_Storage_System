#include "udisk_test_handle.h"
#include "connector_libevent.h"
#include "eventloop_libevent.h"
#include <unistd.h>

#include "logging.h"
#include "qemu_io_proto.h"
#include "gate_fio.h"

using std::placeholders::_1;
using std::placeholders::_2;
using namespace uevent;
using namespace base;
using namespace udisk::common;

LoopHandle* UDiskTestHandle::CreateMyself(UeventLoop* loop) {
  return new UDiskTestHandle(loop);
}

UDiskTestHandle::UDiskTestHandle(UeventLoop* loop)
    : loop_(loop),
      last_flowno_(1),
      last_sector_(0),
      iops_(0),
      lat_(0),
      bw_(0) {
}

void UDiskTestHandle::Start(LCTestInfo& info) {
  loop_->RunInLoop(std::bind(
      &UDiskTestHandle::StartRunInLoop, this, info));
  
}
void UDiskTestHandle::StartRunInLoop(LCTestInfo& info) {
  LOG_INFO << "lc stats info: " << info.extern_id 
           << " size: " << info.lc_size << " rw: " << info.rw
           << " io_size: " << info.io_size << " io_depth: " << info.io_depth
           << " begin_pos: " << info.begin_pos << " end_pos: " << info.end_pos;
  begin_sector_ = info.begin_pos >> 9;
  end_sector_ = info.end_pos >> 9;
<<<<<<< HEAD
=======
  magic_num_  = (int8_t)info.magic;
>>>>>>> journal_gate_consistent
  last_sector_ = begin_sector_; 
  test_info_ = info;
  UsockAddress gate_addr(g_config_parser->gate_unix_addr());
  ctor_.reset(new ConnectorLibevent(loop_, gate_addr, ""));
  ctor_->SetConnectionSuccessCb(
      std::bind(&UDiskTestHandle::ConnSuccessCb, this, _1));
  ctor_->SetConnectionClosedCb(
      std::bind(&UDiskTestHandle::ConnClosedCb, this, _1));
  ctor_->SetMessageReadCb(
      std::bind(&UDiskTestHandle::MessageReadCb, this, _1));
  ctor_->Connect();
  DoLoginRequest();
}

void UDiskTestHandle::ConnSuccessCb(const ConnectionUeventPtr& conn) {
  LOG_INFO << "connect to " << conn->GetPeerAddress().ToString()
           << " success";
}

void UDiskTestHandle::ConnClosedCb(const ConnectionUeventPtr& conn) {
  LOG_INFO << "connect to " << conn->GetPeerAddress().ToString()
           << " closed";
}

void UDiskTestHandle::MessageReadCb(const ConnectionUeventPtr& conn) {
  size_t readable = conn->ReadableLength();
  uint32_t size;
  while (readable >= sizeof(QemuIOHead)) {  // 数据不够不能清除
    conn->ReceiveData(&size, sizeof(size));
    if (readable >= size) {  // data len enough
      QemuIOHead* head = new QemuIOHead();
      conn->RemoveData(head, sizeof(QemuIOHead));
      readable -= size;
      switch (head->cmd) {
        case QEMU_CMD_READ:
        case QEMU_CMD_WRITE:
          LOG_DEBUG << "io response from gate: " << DumpQemuIOHead(*head);
          assert(head->magic == QEMU_MAGIC);
          // 读写的扇区不能超过盘的末尾
          RwResponseHandle(conn, head);
          break;
        case QEMU_CMD_LOGIN:
          LOG_INFO << "login response from gate";
          LoginResponseHandle(conn, head);
          break;
        case QEMU_CMD_FLUSH:
          LOG_ERROR << "flush cmd not expected";
        default:
          LOG_ERROR << "unknown cmd: " << head->cmd;
          ctor_->DestroyConnection(); // 断开连接
          break;
      }
    } else {  // 数据不够， 退出
      break;
    }
  }
}

void UDiskTestHandle::DoLoginRequest() {
  QemuIOHead login_head;
  memset(&login_head, 0, sizeof(QemuIOHead));
  login_head.size = sizeof(QemuIOHead) + sizeof(QemuLoginInfo);
  login_head.cmd = QEMU_CMD_LOGIN;
  login_head.magic = QEMU_MAGIC;
  QemuLoginInfo login_info;
  memset(&login_info, 0, sizeof(QemuLoginInfo));
  memcpy(&login_info.udisk_id,
      test_info_.extern_id.data(), test_info_.extern_id.size());
  if (ctor_->HasAvailableConnection() == false) {
    LOG_FATAL << "connection with gate not available";
  }
  ConnectionUeventPtr conn = ctor_->GetConnection();
  conn->SendData(&login_head, sizeof(QemuIOHead));
  conn->SendData(&login_info, sizeof(QemuLoginInfo));
}

void UDiskTestHandle::RwResponseHandle(const ConnectionUeventPtr& conn, QemuIOHead* head) {
  auto it = inflight_list_.find(head->flowno);
  if (it == inflight_list_.end()) {
    LOG_FATAL << "can't find the response: " << DumpQemuIOHead(*head);
    return;
  }
  uint32_t data_size = head->size - sizeof(QemuIOHead);
  if (data_size > 0) {
    assert(head->cmd == QEMU_CMD_READ);
    assert(data_size == it->second->data_len);
    conn->RemoveData(it->second->data, data_size);
    VerifyData((char*)it->second->data, data_size);
<<<<<<< HEAD
=======
    LOG_DEBUG << "Check Data Finish:" << head->flowno;
>>>>>>> journal_gate_consistent
  }
  iops_++;
  lat_ += timeDifferenceUs(Timestamp::now(), it->second->start_time);
  bw_ += it->second->data_len;
<<<<<<< HEAD
  delete head;
  delete it->second;
  inflight_list_.erase(it);
=======
  LOG_DEBUG << "response:" << DumpQemuIOHead(*head);
  delete head;
  delete it->second;
  LOG_DEBUG << "############left:" << inflight_list_.size();
  inflight_list_.erase(it);
  LOG_DEBUG << "############left:" << inflight_list_.size();
>>>>>>> journal_gate_consistent
  DoIORequest(conn);
}

void UDiskTestHandle::DoIORequest(const ConnectionUeventPtr& conn) {
<<<<<<< HEAD
  while (inflight_list_.size() < test_info_.io_depth) {
    IORequest* io_req =  BuildIORequest();
    LOG_DEBUG << "io request to gate: " << DumpQemuIOHead(io_req->head);
    conn->SendData(&io_req->head, sizeof(QemuIOHead));
    if (io_req->head.cmd == QEMU_CMD_WRITE) {
      conn->SendData(io_req->data, io_req->data_len);
    }
    uint64_t flowno = io_req->head.flowno;
    inflight_list_.insert(std::make_pair(flowno, io_req));
=======
  if (inflight_list_.size() < test_info_.io_depth) {
    IORequest* io_req =  BuildIORequest();
    if (io_req != nullptr) {
      LOG_DEBUG << "io request to gate: " << DumpQemuIOHead(io_req->head);
      conn->SendData(&io_req->head, sizeof(QemuIOHead));
      if (io_req->head.cmd == QEMU_CMD_WRITE) {
        conn->SendData(io_req->data, io_req->data_len);
      }
      uint64_t flowno = io_req->head.flowno;
      inflight_list_.insert(std::make_pair(flowno, io_req));
    }
>>>>>>> journal_gate_consistent
  }
}


void UDiskTestHandle::LoginResponseHandle(const ConnectionUeventPtr& conn, 
                                          QemuIOHead* head) {
  if (head->retcode != 0) {
    LOG_ERROR << "login error, extern_id: "  << test_info_.extern_id;
    return;
  }
  LOG_ERROR << "login sueccess, extern_id: "  << test_info_.extern_id;
  delete head;
  loop_->RunEvery(1.0, std::bind(&UDiskTestHandle::IOStatsCb, this));
  DoIORequest(conn);
}

void UDiskTestHandle::IOStatsCb() {
  uint64_t avg_lat = 0;
  if (iops_ == 0) {
    LOG_ERROR << "iops is 0 for extern_id: " << test_info_.extern_id;
  } else {
    avg_lat = lat_/iops_;
  }
  LOG_INFO << "lc stats info: " << test_info_.extern_id << " => iops: " << iops_ 
           << "  lat: " << avg_lat  << "us  bw: " << bw_  << "Byte/s";
  iops_ = 0;
  bw_ = 0;
  lat_ = 0;
}

void UDiskTestHandle::VerifyData(char* data, int size) {
  for(auto i = 0; i < size; i++) {
    LOG_TRACE << "date check "
        << i << " >>> expect:" 
        << magic_num_ << " get:" << int8_t(*(data + i))
        << " sector:" << last_sector_;
    if (int8_t(*(data + i)) != magic_num_) {
      LOG_ERROR << "consistent found~!! expect:" 
          << magic_num_ << " get:" << int8_t(*(data + i))
          << " sector:" << last_sector_;
      exit(-1);
    }
  }
}


IORequest* UDiskTestHandle::BuildIORequest() {
  uint64_t sector = 0;
<<<<<<< HEAD
  uint64_t sector_num = test_info_.io_size >> 9;
  IORequest* io_req = new IORequest();
  io_req->data = malloc(test_info_.io_size);
  memset(io_req->data, MAGIC_PAD, test_info_.io_size);
  io_req->data_len = test_info_.io_size;
=======
  //uint64_t sector_num = test_info_.io_size >> 9;
  //IORequest* io_req = new IORequest();
  //io_req->data = malloc(test_info_.io_size);
  //memset(io_req->data, magic_num_, test_info_.io_size);
  //io_req->data_len = test_info_.io_size;
  size_t rand_sector = (magic_num_ % 256) + 1;
  uint64_t sector_num = rand_sector;
  IORequest* io_req = new IORequest();
  io_req->data = malloc(rand_sector << 9);
  memset(io_req->data, magic_num_, rand_sector << 9);
  io_req->data_len = rand_sector << 9;
>>>>>>> journal_gate_consistent
  switch (test_info_.rw) {
    case 0: 
    case 1: {
      sector = last_sector_;
      last_sector_ += sector_num;
      LOG_TRACE << ">>>last_sector:" << last_sector_
          << " end_sector:" << end_sector_;
      if (last_sector_ > end_sector_) {
<<<<<<< HEAD
        if (test_info_.rw == 1) {
          //开始check
          test_info_.rw = 0;
          last_sector_ = 0;
          sector = 0;
          LOG_INFO << "===================Start Check=================";
          sleep(1);
        } else {
          //开始写
          test_info_.rw = 1;
          last_sector_ = 0;
          sector = 0;
          LOG_INFO << "===================Start Write=================";
          sleep(1);
=======
        if (inflight_list_.empty()) {
          if (test_info_.rw == 1) {
            //开始check
            test_info_.rw = 0;
            last_sector_ = 0;
            sector = 0;
            LOG_INFO << "===================Start Check=================";
            sleep(1);
          } else {
            magic_num_++;
            //开始写
            test_info_.rw = 1;
            last_sector_ = 0;
            sector = 0;
            LOG_INFO << "===================Start Write=================";
            sleep(1);
          }
        } else {
          LOG_DEBUG << ">>>>>>>> left:" << inflight_list_.size();
          delete io_req;
          return nullptr;
>>>>>>> journal_gate_consistent
        }
      }
      if (test_info_.rw == 0) {
        io_req->head.cmd = QEMU_CMD_READ;
        io_req->head.size = sizeof(QemuIOHead);
      } else {
        io_req->head.cmd = QEMU_CMD_WRITE;
        io_req->head.size = sizeof(QemuIOHead) + io_req->data_len;
      }
      break;
    }
    case 2:
    case 3: {
      uint64_t sector_span = end_sector_ - begin_sector_;
      uint64_t random_offset = 0;
      // 构造一个不超过范围的随机IO
      do {
        random_offset = random() % sector_span;
        sector = begin_sector_ + random_offset;
      } while(sector + sector_num > end_sector_);
      if (test_info_.rw == 2) {
        io_req->head.cmd = QEMU_CMD_READ;
        io_req->head.size = sizeof(QemuIOHead);
      } else {
        io_req->head.cmd = QEMU_CMD_WRITE;
        io_req->head.size = sizeof(QemuIOHead) + io_req->data_len;
      }
      break;
    }
    default: 
      LOG_FATAL << "unknow rw mode: " << test_info_.rw;
      break;
  }
  io_req->head.sector = sector;
  io_req->head.secnum = sector_num;
  io_req->head.flowno = last_flowno_++;
  io_req->head.magic = QEMU_MAGIC;
  io_req->start_time = Timestamp::now();
  return io_req;
}

