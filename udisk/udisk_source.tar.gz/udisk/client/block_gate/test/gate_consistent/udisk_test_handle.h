#ifndef UDISK_UDISK_TEST_HANDLE_H_
#define UDISK_UDISK_TEST_HANDLE_H_ 

#include <unordered_map>
#include "uevent.h"
#include "timestamp.h"
#include "qemu_io_proto.h"
#include "my_config_parser.h"

struct IORequest {
  IORequest() {
    memset(&head, 0, sizeof(udisk::common::QemuIOHead));
  }
  ~IORequest() {
    free(data);
  }
  udisk::common::QemuIOHead head;
  void* data;
  uint32_t data_len;
  base::Timestamp start_time;
};


class UDiskTestHandle : public uevent::LoopHandle {
 public:
  static uevent::LoopHandle* CreateMyself(uevent::UeventLoop* loop);
  UDiskTestHandle(uevent::UeventLoop* loop);
  void Start(LCTestInfo& info);
  void StartRunInLoop(LCTestInfo& info);
  void ConnSuccessCb(const uevent::ConnectionUeventPtr& conn);
  void ConnClosedCb(const uevent::ConnectionUeventPtr& conn);
  void MessageReadCb(const uevent::ConnectionUeventPtr& conn);
  void DoLoginRequest();
  void RwResponseHandle(const uevent::ConnectionUeventPtr& conn, 
                        udisk::common::QemuIOHead* head);
  void DoIORequest(const uevent::ConnectionUeventPtr& conn);
  void LoginResponseHandle(const uevent::ConnectionUeventPtr& conn,
                           udisk::common::QemuIOHead* head);
  void IOStatsCb();
  IORequest* BuildIORequest();
 
 private:
  void VerifyData(char* data, int size);
  uevent::UeventLoop* loop_;
  uevent::ConnectorUeventPtr ctor_;
  LCTestInfo test_info_;
  uint64_t last_flowno_;
  uint64_t last_sector_; 
  uint64_t iops_;
  uint64_t lat_;
  uint64_t bw_;
  uint64_t begin_sector_;
  uint64_t end_sector_;
  std::unordered_map<uint64_t, IORequest*> inflight_list_;
<<<<<<< HEAD
=======
  int8_t magic_num_ = 0;
>>>>>>> journal_gate_consistent
};

#endif
