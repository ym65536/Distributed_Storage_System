#ifndef UDISK_GATE_UDISK_HANDLE_H_
#define UDISK_GATE_UDISK_HANDLE_H_

#include <string>
#include <memory>
#include <deque>
#include <list>
#include "loop_handle.h"
#include "usock_address.h"
#include "qemu_io_proto.h"
#include "callbacks.h"
#include "logging.h"

namespace uevent {
class UeventLoop;
}

namespace udisk {
namespace gate {

using uevent::LoopHandle;
using uevent::ConnectionUeventPtr;
using uevent::UeventLoop;

class UDiskHandle : public LoopHandle {
 public:
  static LoopHandle* CreateMyself(UeventLoop* loop);
  UDiskHandle(UeventLoop* loop);
  ~UDiskHandle() {}
  void Reset();
  void RwRequestHandle(const ConnectionUeventPtr& conn,
                       common::QemuIOHead* head);
  void LoginHandle(const ConnectionUeventPtr& conn, common::QemuIOHead* head);
  void FlushHandle(common::QemuIOHead* head);
  static void QemuConnSuccessCb(const ConnectionUeventPtr& conn);
  static void QemuConnClosedCb(const ConnectionUeventPtr& conn);
  static void QemuConnReadCb(const ConnectionUeventPtr& conn);

 private:
  
  UeventLoop* loop_;
  ConnectionUeventPtr qemu_conn_;
  std::string extern_id_;
  bool has_flush_;
};

} //namespace gate
} //namespace udisk

#endif
