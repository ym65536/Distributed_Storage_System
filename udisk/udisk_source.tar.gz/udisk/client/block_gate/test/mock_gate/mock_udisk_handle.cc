#include "mock_udisk_handle.h"
#include "logging.h"
#include "loop_handle.h"
#include "uevent.h"
#include "listener_libevent.h"
#include "gate_io_proto.h"
#include "mock_gate.h"
#include "udisk_types.h"



namespace udisk {
namespace gate {


using std::placeholders::_1;
using std::placeholders::_2;
using namespace uevent;
using namespace base;
using namespace common;

LoopHandle* UDiskHandle::CreateMyself(UeventLoop* loop) {
  return reinterpret_cast<LoopHandle*>(new UDiskHandle(loop));
}

UDiskHandle::UDiskHandle(UeventLoop* loop)
    : loop_(loop),
      has_flush_(false) {
}

void UDiskHandle::Reset() {
  // 标识该UDisk Handle 负责其他的盘 
  //由listener中统一的入口对accept的连接进行删除和析构
  LOG_INFO << "mock udisk handle do reset, extern_id:" << extern_id_;
  g_listener->RemoveConnection(qemu_conn_);
  qemu_conn_.reset();
  has_flush_ = false;
  DecRefs();
  assert(GetRefs() == 0);
}

void UDiskHandle::QemuConnSuccessCb(const ConnectionUeventPtr& conn) {
  LoopHandle* loop_handle = conn->GetLoop()->GetLoopHandle();
  loop_handle->IncRefs();
  UDiskHandle* instance = reinterpret_cast<UDiskHandle*>(loop_handle);
  LOG_INFO << "new connection from qemu, connection name:"
           << conn->GetName() << " connection id: " << conn->GetId(); 
  if (instance->qemu_conn_) {
    LOG_FATAL << "the before qemu connection still exist, conn_id:"
              << instance->qemu_conn_->GetId();
  }
  instance->qemu_conn_ = conn;
}

void UDiskHandle::QemuConnClosedCb(const ConnectionUeventPtr& conn) {
  LoopHandle* loop_handle = conn->GetLoop()->GetLoopHandle();
  UDiskHandle* instance = reinterpret_cast<UDiskHandle*>(loop_handle);
  LOG_INFO << "disconnect from qemu, connection name: "
           << conn->GetName() << "connection id: "<< conn->GetId();
  //延时reset防止虚机宕机时chunk刚好重启或者某个IO超时，降低副本不一致的
  //概率，除非宿主机宕机，或者gate重试了几次任然没有成功. 最彻底的解决
  //方法是上一致性协议(TODO yeheng)
  //断开连接之前，如果有flush, 说明只是超时，不是虚机挂掉，不用延时reset
  //如果有flush任然延时的话，会发生两个线程同时写，可能会乱序
  LOG_INFO << "udisk will reset after "
           << g_config_parser->udisk_handle_delay_reset_time() << "s"
           << " has_flush:" << (uint32_t)instance->has_flush_;
  if (g_config_parser->udisk_handle_delay_reset_time() == 0 ||
      instance->has_flush_ == true) {
    instance->Reset(); // 立即reset
  } else {
    instance->loop_->RunAfter(g_config_parser->udisk_handle_delay_reset_time(),
        std::bind(&UDiskHandle::Reset, instance));
  }
}

void UDiskHandle::QemuConnReadCb(const ConnectionUeventPtr& conn) {
  LoopHandle* loop_handle = conn->GetLoop()->GetLoopHandle();
  UDiskHandle* instance = reinterpret_cast<UDiskHandle*>(loop_handle);
  size_t readable = conn->ReadableLength();
  uint32_t size;
  while (readable >= sizeof(QemuIOHead)) {  // 数据不够不能清除
    conn->ReceiveData(&size, sizeof(size));
    if (readable >= size) {  // data len enough
      QemuIOHead* head = new QemuIOHead();
      conn->RemoveData(head, sizeof(QemuIOHead));
      readable -= size;
      switch (head->cmd) {
        case QEMU_CMD_READ:
        case QEMU_CMD_WRITE:
          LOG_TRACE << "io request from qemu: " << DumpQemuIOHead(*head);
          assert(head->magic == QEMU_MAGIC);
          // 读写的扇区不能超过盘的末尾
          instance->RwRequestHandle(conn, head);
          break;
        case QEMU_CMD_FLUSH:
          // qemu 里忘记设置这个命令的MAGIC_NUMBER了
          instance->FlushHandle(head);
          break;
        case QEMU_CMD_LOGIN:
          instance->LoginHandle(conn, head);
          break;
        default:
          LOG_ERROR << "unknown cmd";
          g_listener->RemoveConnection(conn); // 断开连接
          break;
      }
    } else {  // 数据不够， 退出
      break;
    }
  }
}

void UDiskHandle::LoginHandle(const ConnectionUeventPtr& conn, QemuIOHead* login_head) {
  common::QemuLoginInfo login_info;
  conn->RemoveData(&login_info, sizeof(common::QemuLoginInfo));
  extern_id_ = std::string(login_info.udisk_id);
  LOG_INFO << "udisk login, extern id: " << extern_id_;
  uint64_t size = 100;
  login_head->secnum = size << 21; // 通过secnum返回盘的大小
  login_head->retcode = 0;
  login_head->size = sizeof(QemuIOHead);
  qemu_conn_->SendData(login_head, sizeof(QemuIOHead));
  delete login_head;
}

void UDiskHandle::FlushHandle(QemuIOHead* head) {
    QemuIOHead* flush_head = head;
    flush_head->size = sizeof(QemuIOHead);
    flush_head->retcode = 0;
    LOG_INFO << "flush response head:" << DumpQemuIOHead(*flush_head);
    qemu_conn_->SendData(flush_head, sizeof(QemuIOHead));
    delete flush_head;
    has_flush_ = true;
}

void UDiskHandle::RwRequestHandle(const ConnectionUeventPtr& conn,
                                  QemuIOHead* head) {
  char* data = reinterpret_cast<char*>(malloc(head->secnum * SECTOR_SIZE));
  if (head->cmd == QEMU_CMD_WRITE) {
    conn->RemoveData(data, head->size - sizeof(QemuIOHead));
    // 将应答的size填好，发送应答时会直接用这个头
    head->size = sizeof(QemuIOHead);  
  } else {
    head->size = sizeof(QemuIOHead) + head->secnum * SECTOR_SIZE;
  }
  qemu_conn_->SendData(head, sizeof(QemuIOHead));
  if (head->cmd == QEMU_CMD_READ) { // 读请求需要带上数据
    qemu_conn_->SendData(data, head->secnum * SECTOR_SIZE);
  } else { // qemu_head_->cmd == WRITE
  }
  free(data);
  delete head;
}



} // namespace gate
} // namespace udisk
