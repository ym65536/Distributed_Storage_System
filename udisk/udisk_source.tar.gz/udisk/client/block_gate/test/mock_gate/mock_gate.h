#ifndef UDISK_GATE_H_
#define UDISK_GATE_H_

#include <memory>
#include "my_config_parser.h"

namespace uevent {
class ListenerLibevent;
}

namespace udisk {

namespace common {
class NameContainer;
}

namespace gate {

extern std::unique_ptr<uevent::ListenerLibevent> g_listener;
extern std::unique_ptr<MyConfigParser> g_config_parser;


} // namespace gate
} // namespace udisk

#endif
