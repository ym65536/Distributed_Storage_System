#include "my_config_parser.h"
#include "logging.h"

namespace udisk {
namespace gate {

const std::string MyConfigParser::kThreadNum = std::string("thread_num");
const std::string MyConfigParser::kUDiskHandleDelayResetTime =
                                        std::string("udisk_handle_delay_reset_time");

using namespace base;

MyConfigParser::MyConfigParser(const std::string& file)
    : ConfigParser(file) {
}

void MyConfigParser::Init() {
  ConfigParser::Init(); 
  if (listen_unix_addr().empty()) {
    LOG_FATAL << "listen unix addr is empty";
  }
  thread_num_ = parser_.IntValue(kSectionUDisk, kThreadNum);
  if (thread_num_ == 0) {
    LOG_INFO << "thread_num is empty or 0 in config file";
  }
  udisk_handle_delay_reset_time_ = parser_.IntValue(kSectionUDisk, kUDiskHandleDelayResetTime);
  if (udisk_handle_delay_reset_time_ == 0) {
    LOG_INFO << "udisk_handle_delay_reset_time is empty or 0 in config file";
  }
  LOG_INFO << "udisk_handle_delay_reset_time:" << udisk_handle_delay_reset_time_;

}

} // namespace gate
} // namespace udisk
