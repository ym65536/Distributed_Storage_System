#ifndef UDISK_GATE_FIO_H_
#define UDISK_GATE_FIO_H_

#include <memory>
#include "my_config_parser.h"
#include "test_manager.h"


extern std::unique_ptr<MyConfigParser> g_config_parser;
extern std::unique_ptr<TestManager> g_test_manager;

#endif
