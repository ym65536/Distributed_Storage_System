#ifndef UDISK_TEST_MY_CONFIG_PARSER_H_
#define UDISK_TEST_MY_CONFIG_PARSER_H_

#include "config_parser.h"

struct LCTestInfo {
  std::string extern_id;
  uint64_t lc_size;
  uint64_t begin_pos;
  uint64_t end_pos;
  uint32_t rw;
  uint32_t io_size;
  uint32_t io_depth;
  
};

class MyConfigParser : public udisk::common::ConfigParser {
 public :
  explicit MyConfigParser(const std::string& file);
  void Init();
  inline std::string gate_unix_addr() {
    return gate_unix_addr_;
  }
  inline uint32_t udisk_count() { return udisk_count_; }
  inline std::vector<LCTestInfo> lc_test_info_vec() {
    return lc_test_info_vec_;
  }
  const static std::string kGateUnixAddr;
  const static std::string kUDiskCount;
  const static std::string kExternId;
  const static std::string kLCSize;
  const static std::string kRW;
  const static std::string kIODepth;
  const static std::string kIOSize;
  const static std::string kBeginPos;
  const static std::string kEndPos;

 private :
  std::string gate_unix_addr_;
  uint32_t udisk_count_;
  std::vector<LCTestInfo> lc_test_info_vec_;

};


#endif
