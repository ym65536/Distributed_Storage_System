#include "my_config_parser.h"
#include "logging.h"

const std::string MyConfigParser::kGateUnixAddr = std::string("gate_unix_addr");
const std::string MyConfigParser::kUDiskCount = std::string("udisk_count");
const std::string MyConfigParser::kExternId  = std::string("extern_id");
const std::string MyConfigParser::kLCSize  = std::string("lc_size");
const std::string MyConfigParser::kRW  = std::string("rw");
const std::string MyConfigParser::kIODepth  = std::string("io_depth");
const std::string MyConfigParser::kIOSize  = std::string("io_size");
const std::string MyConfigParser::kBeginPos  = std::string("begin_pos");
const std::string MyConfigParser::kEndPos  = std::string("end_pos");

using namespace base;

MyConfigParser::MyConfigParser(const std::string& file)
    : ConfigParser(file) {
}

void MyConfigParser::Init() {
  ConfigParser::Init(); 
  gate_unix_addr_ = parser_.GetValue(kSectionNetworks, kGateUnixAddr);
  if (gate_unix_addr_.empty()) {
    LOG_FATAL << "gate_unix_addr is empty in config file";
  }
  udisk_count_ = parser_.IntValue(kSectionUDisk, kUDiskCount);
  if (udisk_count_ == 0) {
    LOG_FATAL << "udisk_count is empty or 0 in config file";
  }

  for(uint32_t i = 0; i < udisk_count_; i++) {
    LCTestInfo test_info;
    std::string index = std::to_string(i);
    std::string extern_id_index = kExternId + index;
    test_info.extern_id = parser_.GetValue(kSectionUDisk, extern_id_index);
    if (test_info.extern_id.empty()) {
      LOG_FATAL << extern_id_index << "is empty in config file";
    }

    std::string lc_size_index = kLCSize + index;
    test_info.lc_size = parser_.IntValue(kSectionUDisk, lc_size_index);
    if (test_info.lc_size == 0) {
      LOG_FATAL << lc_size_index << " is empty in config file";
    }

    std::string rw_index = kRW + index;
    std::string rw = parser_.GetValue(kSectionUDisk, rw_index);
    if (rw.empty()) {
      LOG_FATAL << rw_index << "is empty in config file";
    }
    if (rw == "read") {
      test_info.rw = 0;
    } else if (rw == "write") {
      test_info.rw = 1;
    } else if (rw == "randread") {
      test_info.rw = 2;
    } else if (rw == "randwrite") {
      test_info.rw = 3;
    } else {
      LOG_FATAL << "unknow rw mode: " << rw;
    }
    std::string io_depth_index = kIODepth + index;
    test_info.io_depth = parser_.IntValue(kSectionUDisk, io_depth_index);
    if (test_info.io_depth == 0) {
      LOG_FATAL << io_depth_index << " is empty in config file";
    }

    std::string io_size_index = kIOSize + index;
    test_info.io_size = parser_.IntValue(kSectionUDisk, io_size_index);
    if (test_info.io_size == 0) {
      LOG_FATAL << io_size_index << "is empty in config file";
    }

    std::string begin_pos_index = kBeginPos + index;
    test_info.begin_pos = parser_.IntValue(kSectionUDisk, begin_pos_index);
    if (test_info.begin_pos == 0) {
      LOG_INFO << begin_pos_index << " set to default 0";
    }
    std::string end_pos_index = kEndPos + index;
    test_info.end_pos = parser_.IntValue(kSectionUDisk, end_pos_index);
    if (test_info.end_pos == 0) {
      LOG_INFO << end_pos_index << "set to default lc_size: " << test_info.lc_size;
    }
    lc_test_info_vec_.push_back(test_info);
  }
}
