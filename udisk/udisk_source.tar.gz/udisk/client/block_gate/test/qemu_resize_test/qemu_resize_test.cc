#include <utility>
#include <unistd.h>
#include <memory>
#include "uevent.h"
#include "connector_libevent.h"
#include "eventloop_libevent.h"
#include "logging.h"
#include "qemu_io_proto.h"
#include "udisk_types.h"

using std::placeholders::_1;
using namespace uevent;
using namespace base;
using namespace udisk::common;

static char buf[256];
static uint32_t buf_len;

static void ConnectionSuccessHandle(const uevent::ConnectionUeventPtr& conn) {
  LOG_INFO << "connect to " << conn->GetPeerAddress().ToString() << " success";
  conn->SendData(buf, buf_len);
}

static void ConnectionClosedHandle(const uevent::ConnectionUeventPtr& conn) {
  LOG_INFO << "connection " << conn->GetPeerAddress().ToString() << " closed";
}

static void MessageReadHandle(const uevent::ConnectionUeventPtr& conn) {
  size_t readable = conn->ReadableLength();
  LOG_INFO << "connection id: " << conn->GetId() << " receive " << readable
           << " bytes";
  if (readable < sizeof(QemuIOHead)) {
    return;
  }
  void* data = malloc(readable);
  conn->RemoveData(data, readable);
  QemuIOHead* head = (QemuIOHead*)data;
  LOG_INFO << "receive res: " << DumpQemuIOHead(*head);
  free(data);
  conn->ForceClose();
  _exit(0);
}

int main(int argc, char* argv[]) {
  if (argc > 3) {
    uint64_t size = atoi(argv[3]);
    QemuIOHead* qemu_head = (QemuIOHead*)buf;
    QemuResizeInfo* resize_info = (QemuResizeInfo*)(buf + sizeof(QemuIOHead));
    memset(qemu_head, 0, sizeof(QemuIOHead));
    memset(resize_info, 0, sizeof(QemuResizeInfo));
    qemu_head->size = sizeof(QemuIOHead) + sizeof(QemuResizeInfo);
    qemu_head->cmd = QEMU_CMD_RESIZE;
    qemu_head->sector = 0;
    qemu_head->secnum = size << (GB_SHIFT - SECTOR_SHIFT);
    qemu_head->magic = QEMU_MAGIC;
    std::string extern_id(argv[2]);
    memcpy(resize_info->udisk_id, extern_id.c_str(), extern_id.size());
    buf_len = sizeof(QemuIOHead) + sizeof(QemuResizeInfo);

    uevent::EventLoopLibevent loop("main_thread");
    uevent::UsockAddress server_addr(argv[1]);
    uevent::ConnectorLibevent connector(&loop, server_addr, "resize_connector");
    connector.SetConnectionSuccessCb(std::bind(ConnectionSuccessHandle, _1));
    connector.SetConnectionClosedCb(std::bind(ConnectionClosedHandle, _1));
    connector.SetMessageReadCb(std::bind(MessageReadHandle, _1));
    connector.Connect();
    loop.Start();
  } else {
    printf("Usage: %s unix_domain_socket extern_id size(GB)\n", argv[0]);
  }
  return 0;
}
