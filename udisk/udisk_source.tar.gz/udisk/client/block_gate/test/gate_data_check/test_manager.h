#ifndef UDISK_TEST_MANAGER_H_
#define UDISK_TEST_MANAGER_H_

#include "uevent.h"

class TestManager {
 public:
  TestManager();
  void Start();


 private:
  uevent::UeventLoop* loop_;
  uevent::UeventLoopThreadPool* thread_pool_;
  std::vector<uevent::UeventLoop*> all_loops_;
};

#endif

