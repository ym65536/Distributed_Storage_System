#include "test_manager.h"
#include "udisk_test_handle.h"
#include "data_check.h"
#include "eventloop_libevent.h"
#include "ueventloop_thread_pool.h"

using namespace uevent;

TestManager::TestManager()
    : loop_(new EventLoopLibevent("manager_thread")),
      thread_pool_(new UeventLoopThreadPool(loop_, "manager_thread_pool")) {
}

void TestManager::Start() {
  thread_pool_->set_thread_num(g_config_parser->udisk_count());
  thread_pool_->Start(UDiskTestHandle::CreateMyself);
  all_loops_ = thread_pool_->GetAllLoops();
  auto lc_test_info_vec = g_config_parser->lc_test_info_vec();
  // 启动所有盘的IO 测试
  for (uint32_t i = 0; i < lc_test_info_vec.size(); i++) {
    reinterpret_cast<UDiskTestHandle*>(all_loops_[i]->GetLoopHandle())
        ->Start(lc_test_info_vec[i]);
  }
  //启动管理线程的循环
  loop_->Start();
}

