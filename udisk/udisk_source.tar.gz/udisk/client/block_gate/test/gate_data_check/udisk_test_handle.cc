#include "udisk_test_handle.h"
#include "md5_digest.h"
#include "unistd.h"
#include "connector_libevent.h"
#include "eventloop_libevent.h"

#include "logging.h"
#include "qemu_io_proto.h"
#include "data_check.h"
#include <string>

using std::placeholders::_1;
using std::placeholders::_2;
using namespace uevent;
using namespace base;
using namespace udisk::common;

LoopHandle* UDiskTestHandle::CreateMyself(UeventLoop* loop) {
  return new UDiskTestHandle(loop);
}

UDiskTestHandle::UDiskTestHandle(UeventLoop* loop)
    : loop_(loop),
      last_flowno_(1),
      last_sector_(0),
      benchmark_data_(NULL),
      memory_size_(0),
      has_write_zero_(false),
      check_start_(false),
      check_all_io_(false),
      times_(0),
      flowno_count_(0) {
}

void UDiskTestHandle::Start(LCTestInfo& info) {
  loop_->RunInLoop(std::bind(
      &UDiskTestHandle::StartRunInLoop, this, info));
  
}
void UDiskTestHandle::StartRunInLoop(LCTestInfo& info) {
  begin_sector_ = info.begin_pos >> 9;
  end_sector_ = info.end_pos >> 9;
  last_sector_ = begin_sector_;
  memory_size_ = info.end_pos - info.begin_pos;
  if (memory_size_ > (1 << 30)) {
    LOG_FATAL << "need too many memroy";
  }
  benchmark_data_ = malloc(memory_size_);
  if (benchmark_data_ == NULL) {
    LOG_FATAL << "malloc error";
  }
//  memset(benchmark_data_, 0, memory_size_);
  zero_io_count_ = memory_size_ / 512; // 以8K写
  test_info_ = info;
  UsockAddress gate_addr(g_config_parser->gate_unix_addr());
  connector_ = reinterpret_cast<ConnectorUevent*>(
      new ConnectorLibevent(loop_, gate_addr, ""));
  connector_->SetConnectionSuccessCb(
      std::bind(&UDiskTestHandle::ConnSuccessCb, this, _1));
  connector_->SetConnectionClosedCb(
      std::bind(&UDiskTestHandle::ConnClosedCb, this, _1));
  connector_->SetMessageReadCb(
      std::bind(&UDiskTestHandle::MessageReadCb, this, _1));
  connector_->Connect();
  DoLoginRequest();
}

void UDiskTestHandle::ConnSuccessCb(const ConnectionUeventPtr& conn) {
  LOG_INFO << "connect to " << conn->GetPeerAddress().ToString()
           << " success";
}

void UDiskTestHandle::ConnClosedCb(const ConnectionUeventPtr& conn) {
  LOG_INFO << "connect to " << conn->GetPeerAddress().ToString()
           << " closed";
}

void UDiskTestHandle::MessageReadCb(const ConnectionUeventPtr& conn) {
  size_t readable = conn->ReadableLength();
  uint32_t size;
  while (readable >= sizeof(QemuIOHead)) {  // 数据不够不能清除
    conn->ReceiveData(&size, sizeof(size));
    if (readable >= size) {  // data len enough
      QemuIOHead* head = new QemuIOHead();
      conn->RemoveData(head, sizeof(QemuIOHead));
      readable -= size;
      switch (head->cmd) {
        case QEMU_CMD_READ:
        case QEMU_CMD_WRITE:
          LOG_DEBUG << "io response from gate: " << DumpQemuIOHead(*head);
          assert(head->magic == QEMU_MAGIC);
          // 读写的扇区不能超过盘的末尾
          RwResponseHandle(conn, head);
          break;
        case QEMU_CMD_LOGIN:
          LOG_INFO << "login response from gate";
          LoginResponseHandle(conn, head);
          break;
        case QEMU_CMD_FLUSH:
          LOG_ERROR << "flush cmd not expected";
        default:
          LOG_ERROR << "unknown cmd: " << head->cmd;
          connector_->DestroyConnection(); // 断开连接
          break;
      }
    } else {  // 数据不够， 退出
      break;
    }
  }
}

void UDiskTestHandle::DoLoginRequest() {
  QemuIOHead login_head;
  memset(&login_head, 0, sizeof(QemuIOHead));
  login_head.size = sizeof(QemuIOHead) + sizeof(QemuLoginInfo);
  login_head.cmd = QEMU_CMD_LOGIN;
  login_head.magic = QEMU_MAGIC;
  QemuLoginInfo login_info;
  memset(&login_info, 0, sizeof(QemuLoginInfo));
  memcpy(&login_info.udisk_id,
      test_info_.extern_id.data(), test_info_.extern_id.size());
  if (connector_->HasAvailableConnection() == false) {
    LOG_FATAL << "connection with gate not available";
  }
  ConnectionUeventPtr conn = connector_->GetConnection();
  conn->SendData(&login_head, sizeof(QemuIOHead));
  conn->SendData(&login_info, sizeof(QemuLoginInfo));
}

void UDiskTestHandle::RwResponseHandle(const ConnectionUeventPtr& conn, QemuIOHead* head) {
  auto it = inflight_list_.find(head->flowno);
  if (it == inflight_list_.end()) {
    LOG_FATAL << "can't find the response: " << DumpQemuIOHead(*head);
    return;
  }
  uint64_t data_size = head->size - sizeof(QemuIOHead);
  if (data_size > 0) {
    assert(head->cmd == QEMU_CMD_READ);
    assert(data_size == it->second->data_len);
    conn->RemoveData(it->second->data, data_size);
    uint64_t memory_offset =  (head->sector - begin_sector_) << 9;
    int ret = DoMD5Check(it->second->data, data_size, memory_offset);
    if (ret != 0) {
      LOG_ERROR << "check failed for: " << test_info_.extern_id <<
                " flowno_count: " << flowno_count_ <<  DumpQemuIOHead(*head);
    }
  }
  delete head;
  delete it->second;
  inflight_list_.erase(it);
  if (check_start_ == true) {
    DoCheckIORequest(conn);
  } else {
    DoIORequest(conn);
  }
}

void UDiskTestHandle::DoIORequest(const ConnectionUeventPtr& conn) {
  IORequest* io_req;
  while (inflight_list_.size() < test_info_.io_depth) {
    if (has_write_zero_ == false) {
      io_req =  BuildZeroIORequest();
    } else {
      io_req =  BuildIORequest();
    }
    LOG_DEBUG << "cmd: " << io_req->head.cmd  << "flowno: " << io_req->head.flowno;
    conn->SendData(&io_req->head, sizeof(QemuIOHead));
    if (io_req->head.cmd == QEMU_CMD_WRITE) {
      conn->SendData(io_req->data, io_req->data_len);
    }
    uint64_t flowno = io_req->head.flowno;
    inflight_list_.insert(std::make_pair(flowno, io_req));
  }
}

void UDiskTestHandle::DoCheckIORequest(const ConnectionUeventPtr& conn) {
  IORequest* io_req;
  while (inflight_list_.size() < test_info_.io_depth) {
    if (check_all_io_ == true) {
      times_ ++;
      LOG_INFO << "check all io finished for times: " << times_
               << "extern_id: "  << test_info_.extern_id;
      Restart(conn);
      return;
    } else {
      io_req =  BuildCheckIORequest();
    }
    conn->SendData(&io_req->head, sizeof(QemuIOHead));
    if (io_req->head.cmd == QEMU_CMD_WRITE) {
      conn->SendData(io_req->data, io_req->data_len);
    }
    uint64_t flowno = io_req->head.flowno;
    inflight_list_.insert(std::make_pair(flowno, io_req));
  }
}

void UDiskTestHandle::LoginResponseHandle(const ConnectionUeventPtr& conn, 
                                          QemuIOHead* head) {
  if (head->retcode != 0) {
    LOG_ERROR << "login error, extern_id: "  << test_info_.extern_id;
    return;
  }
  delete head;
  DoIORequest(conn);
}


IORequest* UDiskTestHandle::BuildZeroIORequest() {
  uint64_t sector = 0;
  uint64_t sector_num = 1; // 8K
  IORequest* io_req = new IORequest();
  io_req->data = malloc(sector_num << 9);
  io_req->data_len = sector_num << 9;
 // memset(io_req->data, 0, io_req->data_len);
  uint64_t random_value = last_flowno_;
  uint64_t arr_size = sector_num << 6; //需要多少个64 byte
  uint64_t* arr = BuildArray(random_value, arr_size);
  io_req->data = malloc(sector_num << 9);
  memcpy(io_req->data, arr, sector_num << 9);
  memcpy((char*)benchmark_data_ + ((last_sector_ - begin_sector_) << 9),
         io_req->data,
         sector_num << 9); // 记录在内存中
  free(arr);
 // PrintMemory((uint64_t*)io_req->data);
  io_req->head.cmd = QEMU_CMD_WRITE;
  io_req->head.size = sizeof(QemuIOHead) + io_req->data_len;
  sector = last_sector_;
  last_sector_ += sector_num;
  io_req->head.sector = sector;
  io_req->head.secnum = sector_num;
  io_req->head.flowno = last_flowno_++;
  flowno_count_++;
//  LOG_INFO << "flowno_count: " << flowno_count_ << " last_flowno: " << last_flowno_;
  io_req->head.magic = QEMU_MAGIC;
  if (flowno_count_ == zero_io_count_) {
    flowno_count_ = 0;
    has_write_zero_ = true;
    last_sector_ = begin_sector_;
    LOG_INFO << "start test io--------------------------";
  }
  return io_req;
}

IORequest* UDiskTestHandle::BuildCheckIORequest() {
  uint64_t sector = 0;
  uint64_t sector_num = 1; // 8K
  IORequest* io_req = new IORequest();
  io_req->data = malloc(sector_num << 9);
  io_req->data_len = sector_num << 9;
  io_req->head.cmd = QEMU_CMD_READ;
  io_req->head.size = sizeof(QemuIOHead);
  sector = last_sector_;
  last_sector_ += sector_num;
  io_req->head.sector = sector;
  io_req->head.secnum = sector_num;
  io_req->head.flowno = last_flowno_++;
  flowno_count_++;
// LOG_INFO << "flowno_count: " << flowno_count_ << " last_flowno: " << last_flowno_;
  io_req->head.magic = QEMU_MAGIC;
  if (flowno_count_ == zero_io_count_) {
    check_all_io_ = true;
    LOG_INFO << "check all io finish";
    sleep(10);
    flowno_count_ = 0; // 
    last_sector_ = begin_sector_;
  }
  return io_req;
}


IORequest* UDiskTestHandle::BuildIORequest() {
  uint64_t sector = 0;
  uint64_t sector_num = 0;
  IORequest* io_req = new IORequest();
  io_req->head.cmd = QEMU_CMD_WRITE;
  uint64_t sector_span = end_sector_ - begin_sector_;
  uint64_t io_size_span = (test_info_.io_high_size - test_info_.io_low_size) >> 9;
  uint64_t random_offset = 0;
  uint64_t random_secnum = 0;
  // 构造一个不超过范围的随机IO
  do {
    random_offset = random() % sector_span;
    LOG_DEBUG << "random_offset: " << random_offset;
    random_secnum = random() % io_size_span;
    LOG_DEBUG << "random_secnum: " << random_secnum;
    sector = begin_sector_ + random_offset;
    sector_num = (test_info_.io_low_size >> 9) + random_secnum;
    LOG_DEBUG << "sector_num: " << sector_num;
  } while(sector + sector_num > end_sector_);
  uint64_t random_value = last_flowno_;
  uint64_t arr_size = sector_num << 6; //需要多少个64 byte
  uint64_t* arr = BuildArray(random_value, arr_size);
  io_req->data = malloc(sector_num << 9);
  memcpy(io_req->data, arr, sector_num << 9);
  memcpy((char*)benchmark_data_ + (random_offset << 9),
         io_req->data,
         sector_num << 9); // 记录在内存中
 // LOG_INFO << "print test io";
 // PrintMemory((uint64_t*)io_req->data);
  free(arr);
  io_req->data_len = sector_num << 9;
  io_req->head.size = sizeof(QemuIOHead) + io_req->data_len;
  io_req->head.sector = sector;
  io_req->head.secnum = sector_num;
  io_req->head.flowno = last_flowno_++;
  flowno_count_ ++;
//  LOG_INFO << "flowno_count: " << flowno_count_ << " last_flowno: " << last_flowno_;
  io_req->head.magic = QEMU_MAGIC;
  if (flowno_count_ == test_info_.io_count) {
    flowno_count_ = 0;
    check_start_ = true;
    LOG_INFO << "start check--------------------------";
    sleep(3);
  }
  return io_req;
}

int UDiskTestHandle::DoMD5Check(void* data, uint64_t len, uint64_t memory_offset) {
  /*md5digest md1;
  md5digest md2;
  md5(data, len, md1);
  md5((char*)benchmark_data_ + memory_offset, len, md2);
  if (strncmp((char*)md1, (char*)md2, 16) != 0) {
    return -1;
  } */
  uint64_t* p = (uint64_t*)((char*)benchmark_data_ + memory_offset);
  if (memcmp((char*)benchmark_data_ + memory_offset, data, len) != 0) {
    PrintMemory(p);
    LOG_INFO << " ====================================================";
    PrintMemory((uint64_t*)data);
    sleep(5);
    return -1;
  }
 // LOG_INFO << "+++++++++++++++++++++++++++++++++++++++++++";
 // PrintMemory(p);
  return 0;
}
void UDiskTestHandle::PrintMemory(uint64_t* p) {
  for(int i = 0; i < 64; i++) {
    printf("%lu\t", *p);
    p++;
  }
}

uint64_t* UDiskTestHandle::BuildArray(uint64_t value, uint64_t count) {
    uint64_t* p = (uint64_t*)malloc(8*count);
    uint64_t* q = p;
    for(uint32_t i = 0; i < count; i++) {
      *q = value;
      q++;
    }
    return p;
}

void UDiskTestHandle::Restart(const ConnectionUeventPtr& conn) {
  LOG_INFO << "restart data check --------------------------";
  has_write_zero_ = false;
  check_start_ = false;
  check_all_io_ = false;
 //last_flowno_  = 0;
  flowno_count_ = 0;
  last_sector_ = begin_sector_;
  DoIORequest(conn);
}

