#ifndef UDISK_UDISK_TEST_HANDLE_H_
#define UDISK_UDISK_TEST_HANDLE_H_ 

#include <unordered_map>
#include "uevent.h"
#include "timestamp.h"
#include "qemu_io_proto.h"
#include "my_config_parser.h"


struct IORequest {
  IORequest() {
    memset(&head, 0, sizeof(udisk::common::QemuIOHead));
  }
  ~IORequest() {
    free(data);
  }
  udisk::common::QemuIOHead head;
  void* data;
  uint32_t data_len;
};


class UDiskTestHandle : public uevent::LoopHandle {
 public:
  static uevent::LoopHandle* CreateMyself(uevent::UeventLoop* loop);
  UDiskTestHandle(uevent::UeventLoop* loop);
  void Start(LCTestInfo& info);
  void StartRunInLoop(LCTestInfo& info);
  void ConnSuccessCb(const uevent::ConnectionUeventPtr& conn);
  void ConnClosedCb(const uevent::ConnectionUeventPtr& conn);
  void MessageReadCb(const uevent::ConnectionUeventPtr& conn);
  void DoLoginRequest();
  void RwResponseHandle(const uevent::ConnectionUeventPtr& conn, 
                        udisk::common::QemuIOHead* head);
  void DoIORequest(const uevent::ConnectionUeventPtr& conn);
  void DoCheckIORequest(const uevent::ConnectionUeventPtr& conn);
  void LoginResponseHandle(const uevent::ConnectionUeventPtr& conn,
                           udisk::common::QemuIOHead* head);
  IORequest* BuildIORequest();
  IORequest* BuildZeroIORequest();
  IORequest* BuildCheckIORequest();
  int DoMD5Check(void* data, uint64_t len, uint64_t memory_offset);
  void Restart(const uevent::ConnectionUeventPtr& conn);
  void PrintMemory(uint64_t* p);
  uint64_t* BuildArray(uint64_t value, uint64_t count);
 
 private:
  uevent::UeventLoop* loop_;
  uevent::ConnectorUevent* connector_;
  LCTestInfo test_info_;
  uint64_t last_flowno_;
  uint64_t last_sector_; 
  void* benchmark_data_;
  uint64_t memory_size_;
  uint64_t begin_sector_;
  uint64_t end_sector_;
  bool has_write_zero_;
  bool check_start_;
  bool check_all_io_;
  int times_;
  uint64_t zero_io_count_;
  uint64_t flowno_count_;
  std::unordered_map<uint64_t, IORequest*> inflight_list_;
};

#endif
