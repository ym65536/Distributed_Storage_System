#include "data_check.h"
#include <stdlib.h>
#include <getopt.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string>
#include "logging.h"
#include "async_logging.h"
#include "uevent.h"
#include "eventloop_libevent.h"

static struct option long_options[] = {
  {"help", 0, nullptr, 'h'},
  {"conf", 1, nullptr, 'c'},
  {"foregroud", 0, nullptr, 'f'},
};

static const char *short_options = "hfc:";

static void print_help(const char *name) {
  LOG_INFO  << name
            << " Usage: \n"
            << "-h | --help, print this\n"
            << "-c | --conf config file, conf file\n"
            << "-f | --foregroud, run this on front end\n";
}


static void init_daemon() {
 pid_t pid;
 pid = fork();
 if (pid < 0)
   exit(EXIT_FAILURE);
 if (pid > 0)
   exit(EXIT_SUCCESS);
 if (setsid() < 0)
   exit(EXIT_FAILURE);

 signal(SIGCHLD, SIG_IGN);
 signal(SIGHUP, SIG_IGN);

 pid = fork();
 if (pid < 0)
   exit(EXIT_FAILURE);
 if (pid > 0)
   exit(EXIT_SUCCESS);

 umask(0);
 chdir("/");

 close(STDOUT_FILENO);
 close(STDIN_FILENO);
}


std::unique_ptr<base::AsyncLogging> g_asyncLog;
std::unique_ptr<MyConfigParser> g_config_parser;
std::unique_ptr<TestManager> g_test_manager;

void AsyncOutput(const char* msg, int len) {
  g_asyncLog->append(msg, len);
}

void InitLogging(const char* argv0,
                 bool foreground) {
  char name[256];
  strncpy(name, argv0, 256);
  std::string name_str = g_config_parser->log_common_path()
      + std::string(::basename(name)); // 加上进程名
  base::Logger::setLogLevel(g_config_parser->log_level()); //设置日志级别
  if (!foreground) { // 如果是前台运行，日志打到标准输出
    g_asyncLog.reset(new base::AsyncLogging(name_str,
        g_config_parser->log_roll_size()));
    g_asyncLog->start(); //会等待日志线程初始化好
    base::Logger::setOutput(AsyncOutput); 
  }
}

using namespace uevent;

int main(int argc, char** argv) {
  std::string conf_file;
  bool foreground(false);
  // 解析命令行输入
  while (true) {
    int c = -1;
    int index = -1;
    c = getopt_long(argc, argv, short_options, long_options, &index);
    if (c == -1) {
      break;
    }
    switch (c) {
      case 'c':
        conf_file = std::string(optarg);
        break;
      case 'h':
        print_help(argv[0]);
        std::exit(0);
      case 'f':
        foreground = true;
        break;
      default:
        print_help(argv[0]);
        std::exit(-1);
    }
  }
  if(conf_file.empty()) { // 需要指定配置文件
    LOG_FATAL  << "need specify the config file";
  }
  g_config_parser.reset(new MyConfigParser(conf_file));
  g_config_parser->Init();
  if (!foreground) {
    init_daemon();
  }
  InitLogging(argv[0], foreground); // 初始化异步日志系统,完成后继续执行
  //启动管理线程 
  g_test_manager.reset(new TestManager());
  g_test_manager->Start(); 
  return 0;
}

