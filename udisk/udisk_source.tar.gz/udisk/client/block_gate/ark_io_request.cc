#include "ark_io_request.h"
#include <ustevent/base/logging.h>
#include "udisk_types.h"
#include "ark_handle.h"
#include "io_request.h"

namespace udisk {
namespace gate {

using namespace uevent;

ArkIORequest::ArkIORequest(ArkHandle* handle, IORequest* io)
    : ark_handle_(handle), io_req_(io), seq_no_(0) {
  io_data_ = io->GetDataAddress();
  io_secnum_ = io->GetSectorNumber();
  io_size_ = io_secnum_ * SECTOR_SIZE;
  begin_sector_ = io->GetBeginSector();
}

ArkIORequest::~ArkIORequest() { delete io_req_; }

}  // namespace gate
}  // namespace udisk
