#ifndef UDISK_GATE_SET_ARK_MAX_PENDING_INFLIGHT_SIZE_H_
#define UDISK_GATE_SET_ARK_MAX_PENDING_INFLIGHT_SIZE_H_

#include <ustevent/base/logging.h>
#include <ustevent/pb_request_handle.h>
#include "udisk_message.h"

using namespace uevent;

namespace udisk {
namespace gate {

class SetArkMaxPendingInflightSizeHandle : public PbRequestHandle {
 public:
  explicit SetArkMaxPendingInflightSizeHandle(uevent::EventLoop* loop)
      : loop_(loop) {}
  virtual ~SetArkMaxPendingInflightSizeHandle() {}
  virtual void EntryInit(const ConnectionUeventPtr& conn,
                         const UMessagePtr& um);

  void SendResponse(int retcode, const std::string& message);
  MYSELF_CREATE(SetArkMaxPendingInflightSizeHandle);
  void SetArkMaxPendingInflightSizeProcess();

 private:
  static int type_;
  uevent::EventLoop* loop_;
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage response_;
  ucloud::udisk::SetArkMaxPendingInflightSizeResponse* resp_body_;
  ucloud::udisk::SetArkMaxPendingInflightSizeRequest req_body_;
};

}  // namespace gate
}  // namespace udisk
#endif
