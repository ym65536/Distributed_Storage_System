#ifndef UDISK_GATE_ARK_STATUS_H_
#define UDISK_GATE_ARK_STATUS_H_

#include <vector>
#include <ustevent/base/logging.h>
#include "udisk_message.h"

namespace udisk {
namespace gate {

class UDiskHandle;

enum ArkTransOp {
  ARK_NOP = 0,
  QEMU_LOGIN = 1,
  REBASE_LOGIN = 2,
  REBASE_LOGOUT = 3,
  ARK_IO_ERROR = 4,
  ARK_ON = 5,
  ARK_OFF = 6,
  ARK_OUT_OF_MEM = 7,
  ARK_EXIT = 8,
  ARK_DEFAULT_ERROR = 9,
  ARK_BAD_SEQUENCE_ERROR = 10
};

class ArkStatus {
 public:
  ArkStatus(ucloud::udisk::UTM_MODE ark_mode,
            ucloud::udisk::UTM_STATUS ark_status,
            ucloud::udisk::UDISK_MOUNT_STATUS mount_status,
            UDiskHandle* udisk_handle);
  ~ArkStatus();
  bool IsTransingStatus();
  //设置数据库状态
  void Ark2Normal(ArkTransOp op);
  void Ark2Standby(ArkTransOp op);
  void Ark2Running(ArkTransOp op);
  void Ark2Rebasing(ArkTransOp op);
  void Ark2NeedRebase(ArkTransOp op);
  void Ark2NeedRebase();
  //数据库状态设置成功
  void Ark2NormalSuccess();
  void Ark2StandbySuccess();
  void Ark2RunningSuccess();
  void Ark2RebasingSuccess();
  void Ark2NeedRebaseSuccess();
  //数据库状态设置失败
  void Ark2NormalFailed();
  void Ark2StandbyFailed();
  void Ark2RunningFailed();
  void Ark2RebasingFailed();
  void Ark2NeedRebaseFailed();
  //数据库状态设置超时
  void Ark2NormalTimeout();
  void Ark2StandbyTimeout();
  void Ark2RunningTimeout();
  void Ark2RebasingTimeout();
  void Ark2NeedRebaseTimeout();

  inline void SetArkMode(ucloud::udisk::UTM_MODE ark_mode) {
    ark_mode_ = ark_mode;
  }
  inline void SetArkStatus(ucloud::udisk::UTM_STATUS ark_status) {
    ark_status_ = ark_status;
  }
  inline ucloud::udisk::UTM_MODE GetArkMode() { return ark_mode_; }
  inline ucloud::udisk::UTM_STATUS GetArkStatus() { return ark_status_; }
  inline ucloud::udisk::UTM_STATUS GetTargetStatus() { return target_status_; }
  inline ArkTransOp GetArkTransOp() { return op_; }

 private:
  bool StatTransOn(ArkTransOp op, ucloud::udisk::UTM_STATUS target_status);
  void StatTransOff();

  ucloud::udisk::UTM_MODE ark_mode_;
  ucloud::udisk::UTM_STATUS ark_status_;
  ucloud::udisk::UDISK_MOUNT_STATUS mount_status_;
  UDiskHandle* udisk_handle_;
  ArkTransOp op_;
  ucloud::udisk::UTM_STATUS target_status_;
};

}  // namespace gate
}  // namespace udisk

#endif
