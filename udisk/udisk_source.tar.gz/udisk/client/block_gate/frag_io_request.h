#ifndef UDISK_GATE_FRAG_IO_REQUEST_H_
#define UDISK_GATE_FRAG_IO_REQUEST_H_

#include <memory>
#include <ustevent/base/timestamp.h>
#include <ustevent/callbacks.h>
#include "gate_io_proto.h"

namespace udisk {

namespace gate {

class UDiskHandle;

struct FragIORequest {
  explicit FragIORequest(UDiskHandle* handle);
  inline void SetTimerCount(int count) { timer_count = count; }
  int SendFragIO();
  int DoSendFragIO(const uevent::ConnectionUeventPtr& conn);
  void DecTimerCount();
  void TimeoutCb();
  uint64_t begin_sector;
  uint64_t secnum;
  uint32_t chunk_id;
  char* data;
  common::GateIORequestHead gate_req_head;
  UDiskHandle* udisk_handle;
  int timer_count;
  int retry_times;
  base::Timestamp start_time;
  int64_t chunk_conn_id;  // 记录要发向的chunk的连接id
};

}  // namespace gate
}  // namespace udisk

#endif
