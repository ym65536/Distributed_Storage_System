#ifndef UDISK_GATE_LISTENER_LIBEVENT_H
#define UDISK_GATE_LISTENER_LIBEVENT_H

#include <map>
#include <ustevent/usock_address.h>
#include <ustevent/callbacks.h>
#include <ustevent/libevent/posix_stack.h>
#include <ustevent/listener_uevent.h>
#include "qemu_io_proto.h"

namespace uevent {

class ListenerLibevent;
class EventLoopLibevent;
}

namespace udisk {
namespace gate {

class GateListener;

class Processor {
 public:
  Processor(GateListener* listener, uevent::PosixWorker* w);
  ~Processor() {};
  void Stop();
  int Bind(const uevent::UsockAddress& listen_addr);
  void Start();
  void Accept();

 private:
  GateListener* listener_;
  uevent::PosixWorker* worker_;
  uevent::ServerSocketPtr listen_socket_;
  int accept_event_idx_ = -1;
  uevent::EventLoopLibevent* eventloop_;
  static void AcceptEventCbWrapper(int fd, short event, void* arg);
  int RecvFd(int fd, void* ptr, int nbytes, int* re_fd);
};

class GateListener : public uevent::ListenerUevent {
 public:
  GateListener(uevent::PosixWorker* w, const uevent::UsockAddress& addr,
               const std::string& name, const uevent::Option& option_)
      : uevent::ListenerUevent(addr, name, option_), worker_(w) {}

  virtual ~GateListener();
  virtual int Start() override;
  virtual int Stop() override;
  virtual void RemoveConnection(const uevent::ConnectionUeventPtr& conn)
      override;
  virtual void RemoveConnectionBySrcIp(const std::string& ip) {}
  virtual void AddSrcIpBlacklist(const std::string& ip,
                                 uint32_t refuse_seconds) {}
  virtual void RemoveSrcIpBlacklist(const std::string& ip) {}

  int Bind();
  void CreateConnection(uevent::PosixWorker* w,
                        const uevent::ConnectedSocketPtr& cli_socket,
                        const uevent::UsockAddress& addr);
  uevent::ConnectionUeventPtr CreateResizeConnection(
      uevent::PosixWorker* w, const uevent::ConnectedSocketPtr& cli_socket,
      const uevent::UsockAddress& addr);
  uevent::PosixWorker* GetEmptyLoopWorker();

  inline uevent::EventLoop* GetLoop() { return worker_->eventloop(); }
  void QemuCmdConnSuccessCb(const uevent::ConnectionUeventPtr& conn); 
  void QemuCmdConnClosedCb(const uevent::ConnectionUeventPtr& conn); 

 private:
  void HandleQemuCommand(const common::QemuIOHead& head,
                         const common::QemuResizeInfo& info,
                         const uevent::ConnectionUeventPtr& conn); 
  void ResponseQemuCommand(int retcode, common::QemuIOHead head,
                           const uevent::ConnectionUeventPtr& conn); 
  friend class Processor;
  uevent::PosixWorker* worker_;
  Processor* processor_;
};

}  // namespace gate
}  // namespace udisk

#endif
