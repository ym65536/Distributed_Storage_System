#include "set_ark_max_pending_inflight_size.h"

#include <ustevent/message_util.h>
#include "gate.h"
#include "gate_listener.h"
#include "manager_thread.h"
#include "udisk_handle.h"
#include "ark_handle.h"
#include "umessage_common.h"

namespace udisk {
namespace gate {

using namespace uevent;

int SetArkMaxPendingInflightSizeHandle::type_ =
    ucloud::udisk::SET_ARK_MAX_PENDING_INFLIGHT_SIZE_REQUEST;

void SetArkMaxPendingInflightSizeHandle::EntryInit(
    const ConnectionUeventPtr& conn, const UMessagePtr& um) {
  ULOG_INFO << um->DebugString();
  conn_ = conn;
  assert(um->head().message_type() == type_);
  assert(um->body().HasExtension(
      ucloud::udisk::set_ark_max_pending_inflight_size_request));
  req_body_ = um->body().GetExtension(
      ucloud::udisk::set_ark_max_pending_inflight_size_request);
  MakeResponse(um.get(),
               ucloud::udisk::SET_ARK_MAX_PENDING_INFLIGHT_SIZE_RESPONSE,
               &response_);
  resp_body_ = response_.mutable_body()->MutableExtension(
      ucloud::udisk::set_ark_max_pending_inflight_size_response);
  SetArkMaxPendingInflightSizeProcess();
}

void SetArkMaxPendingInflightSizeHandle::SetArkMaxPendingInflightSizeProcess() {
  uint64_t max_pending_size = req_body_.max_pending_size();
  uint64_t max_inflight_size = req_body_.max_inflight_size();

  UDiskHandle* udisk_handle =
      ManagerThread::Instance()->GetUDiskHandleByExternId(
          req_body_.extern_id());
  if (udisk_handle == nullptr) {
    ULOG_ERROR << "get null udisk_handle with extern_id:"
               << req_body_.extern_id();
    SendResponse(ucloud::udisk::EC_UDISK_QEMU_NOT_LOGIN,
                 "extern_id:" + req_body_.extern_id() + " is not exist");
    return;
  }
  ArkHandle* ark_handle = udisk_handle->GetArkHandle();
  if (ark_handle == nullptr) {
    ULOG_ERROR << "get null ark_handle with extern_id:"
               << req_body_.extern_id();
    SendResponse(ucloud::udisk::EC_UDISK_QEMU_NOT_LOGIN,
                 "extern_id:" + req_body_.extern_id() + " ark is not exist");
    return;
  }
  ark_handle->set_max_pending_size(max_pending_size);
  ark_handle->set_max_inflight_size(max_inflight_size);
  ULOG_DEBUG << "set max pending size:" << max_pending_size
             << ", max inflight size:" << max_inflight_size;
  SendResponse(0, "set max ark pending and inflight size successfully");
}

void SetArkMaxPendingInflightSizeHandle::SendResponse(
    int retcode, const std::string& message) {
  resp_body_->mutable_rc()->set_retcode(retcode);
  resp_body_->mutable_rc()->set_error_message(message);
  ULOG_INFO << response_.DebugString();
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

}  // namespace gate
}  // namespace udisk
