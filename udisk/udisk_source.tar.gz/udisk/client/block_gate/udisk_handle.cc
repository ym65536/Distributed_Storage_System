#include "udisk_handle.h"
#include <sys/time.h>
#include <ustevent/base/logging.h>
#include <ustevent/libevent/connector_libevent.h>
#include <ustevent/libevent/listener_libevent.h>
#include "msgr.h"
#include "udisk_types.h"
#include "gate_io_proto.h"
#include "gate.h"
#include "io_request.h"
#include "frag_io_request.h"
#include "gate_listener.h"
#include "manager_thread.h"
#include "route_manager.h"
#include "my_config_parser.h"
#include "likely.h"
#include "ark_handle.h"

#include <algorithm>
#include <limits.h>

namespace udisk {
namespace gate {

uint64_t UDiskHandle::kTokenPerIO = 1000;

using std::placeholders::_1;
using std::placeholders::_2;
using namespace uevent;
using namespace base;
using namespace common;

LoopHandle* UDiskHandle::CreateMyself(EventLoop* loop) {
  return reinterpret_cast<LoopHandle*>(new UDiskHandle(loop));
}

UDiskHandle::UDiskHandle(EventLoop* loop)
    : LoopHandle(loop),
      loop_(loop),
      handle_id_(0),
      conn_is_reset_(false),
      has_flush_(false),
      last_read_tick_(0),
      last_write_tick_(0),
      last_heartbeat_tick_(0),
      io_timer_count_(200),
      amount_io_retry_(0),
      need_pending_qemu_io_(false),
      ark_handle_(nullptr),
      bucket_(nullptr) {}

void UDiskHandle::Reset() {
  // 标识该UDisk Handle 负责其他的盘
  //由listener中统一的入口对accept的连接进行删除和析构
  ULOG_INFO << "udisk handle do reset, extern_id:" << extern_id_
            << " set name:" << lc_set_name_ << " lc_id:" << lc_id_;
  g_listener->RemoveConnection(qemu_conn_);
  qemu_conn_.reset();
  has_flush_ = false;
  //析构ark_handle
  if (ark_handle_ != nullptr) {
    delete ark_handle_;
    ark_handle_ = nullptr;
  }
  if (bucket_ != nullptr) {
    delete bucket_;
    bucket_ = nullptr;
  }

  // DeleteUDiskQosInfo 需要在handle_id改变之前调用
  ManagerThread::Instance()->DeleteUDiskQosInfo(this);
  ++handle_id_;
  DecRefs();
  assert(GetRefs() == 0);
  // 取消心跳
  loop_->CancelTimer(heartbeat_timer_id_);
  loop_->CancelTimer(io_timer_id_);
  loop_->CancelTimer(qos_timer_id_);
  for (auto it = qos_list_.begin(); it != qos_list_.end(); ++it) {
    delete *it;
  }
  for (auto it = pending_list_.begin(); it != pending_list_.end(); ++it) {
    delete *it;
  }
  for (auto it = inflight_list_.begin(); it != inflight_list_.end(); ++it) {
    delete *it;
  }
  qos_list_.clear();
  pending_list_.clear();
  inflight_list_.clear();
  route_manager_ptr_.reset();
  extern_id_= "has_reset";
  ClearIOStats();
  chunk_io_stats_.clear();
  before_chunk_io_stats_.clear();
  pc_io_stats_.clear();
  before_pc_io_stats_.clear();
  segmentation_io_stats_.clear();
  //必须释放连接否则之前连接Buffer中残留的数据会导致解包失败
  for (auto it = chunk_connector_map_.begin(); it != chunk_connector_map_.end();
       it++) {
    it->second->DestroyConnection();
  }
  // chunk_connector_map_.clear(); //connector可以保留
}

void UDiskHandle::QemuConnSuccessCb(const ConnectionUeventPtr& conn) {
  LoopHandle* loop_handle = conn->GetLoop()->GetLoopHandle();
  UDiskHandle* instance = reinterpret_cast<UDiskHandle*>(loop_handle);
  ULOG_INFO << "new connection from qemu, connection name:"
           << conn->GetName() << " connection id: " << conn->GetId();
  if (instance->qemu_conn_) {
    ULOG_FATAL << "the before qemu connection still exist, conn_id:"
               << instance->qemu_conn_->GetId();
  }
  if (instance->route_manager_ptr_) {
    ULOG_FATAL << "the before route_manager still exist";
  }
  instance->qemu_conn_ = conn;
}

void UDiskHandle::QemuConnClosedCb(const ConnectionUeventPtr& conn) {
  LoopHandle* loop_handle = conn->GetLoop()->GetLoopHandle();
  UDiskHandle* instance = reinterpret_cast<UDiskHandle*>(loop_handle);
  ULOG_INFO << "disconnect from qemu, connection name: " << conn->GetName()
            << "connection id: " << conn->GetId();
  //延时reset防止虚机宕机时chunk刚好重启或者某个IO超时，降低副本不一致的
  //概率，除非宿主机宕机，或者gate重试了几次任然没有成功. 最彻底的解决
  //方法是上一致性协议(TODO yeheng)
  //断开连接之前，如果有flush, 说明只是超时，不是虚机挂掉，不用延时reset
  //如果有flush任然延时的话，会发生两个线程同时写，可能会乱序
  ULOG_INFO << "udisk will reset after "
            << g_config_parser->udisk_handle_delay_reset_time() << "s"
            << " has_flush:" << (uint32_t)instance->has_flush_;
  if (g_config_parser->udisk_handle_delay_reset_time() == 0 ||
      instance->has_flush_ == true) {
    instance->Reset();  // 立即reset
  } else {
    instance->loop_->RunAfter(g_config_parser->udisk_handle_delay_reset_time(),
                              std::bind(&UDiskHandle::Reset, instance));
  }
}

void UDiskHandle::QemuConnReadCb(const ConnectionUeventPtr& conn) {
  LoopHandle* loop_handle = conn->GetLoop()->GetLoopHandle();
  UDiskHandle* instance = reinterpret_cast<UDiskHandle*>(loop_handle);
  size_t readable = conn->ReadableLength();
  uint32_t size;
  while (readable >= sizeof(QemuIOHead)) {  // 数据不够不能清除
    conn->ReceiveData(&size, sizeof(size));
    if (readable >= size) {  // data len enough
      QemuIOHead* head = new QemuIOHead();
      conn->RemoveData(head, sizeof(QemuIOHead));
      readable -= size;
      if (UNLIKELY(head->flowno == UINT_MAX)) {
        LOG_ERROR << "qemu io flowno == UINT_MAX. head info: "
                  << DumpQemuIOHead(*head);
      }
      switch (head->cmd) {
        case QEMU_CMD_READ:
        case QEMU_CMD_WRITE:
          ULOG_TRACE << "io request from qemu: " << DumpQemuIOHead(*head);
          if (UNLIKELY(head->magic != QEMU_MAGIC)) {
            ULOG_FATAL << "qemu magic is invalid:" << DumpQemuIOHead(*head);
          }
          if (instance->IsQemuIOPending() == true) {
            ULOG_INFO<< "io request from qemu is pending: " << DumpQemuIOHead(*head);
            if (head->cmd == QEMU_CMD_WRITE) {
              conn->DrainData(head->size - sizeof(QemuIOHead));
            }
          } else {
            // 读写的扇区不能超过盘的末尾
            instance->RwRequestHandle(conn, head);
          }
          break;
        case QEMU_CMD_FLUSH:
          // qemu 里忘记设置这个命令的MAGIC_NUMBER了
          instance->FlushHandle(head);
          break;
        case QEMU_CMD_LOGIN:
          ULOG_ERROR << "QEMU_CMD_LOGIN not expected";
        default:
          ULOG_ERROR << "unknown cmd";
          g_listener->RemoveConnection(conn);  // 断开连接
          break;
      }
    } else {  // 数据不够， 退出
      break;
    }
  }
}

void UDiskHandle::LoginHandle(QemuIOHead& head, QemuLoginInfo& info) {
  loop_->RunInLoop(
      std::bind(&UDiskHandle::LoginHandleInLoop, this, head, info));
}

void UDiskHandle::LoginHandleInLoop(QemuIOHead& head, QemuLoginInfo& info) {
  loop_->AssertInLoopThread();
  login_head_ = head;  //记录登录头
  extern_id_ = std::string(info.udisk_id);
  ULOG_INFO << "udisk login from gate_proxy extern id: " << extern_id_;
  // login access 完成或者超时后管理线程会处理
  ManagerThread::Instance()->LoginAccess(this);
}

void UDiskHandle::OdinWarning(const std::string& warn_info, int32_t item_id) {
  ucloud::udisk::OdinWarningRequest warn_request;
  // ip:port:extern_id 拼成uuid, 唯一标识这个告警
  std::string uuid = g_config_parser->listen_ip() + ":" +
  std::to_string(g_config_parser->listen_port()) + ":" +  extern_id_;
  warn_request.set_uuid(uuid);
  warn_request.set_item_id(item_id);
  warn_request.set_info(warn_info);
  warn_request.set_time(base::Timestamp::now().secondsSinceEpoch());
  // 由于login 失败无法获取set，发给机房的全局odin
  ManagerThread::Instance()->WarningToOdin(
             warn_request, ConfigParser::kGlobalSetName,
             g_config_parser->zk_server());

}

// 在管理线程login access成功后会调用
void UDiskHandle::SendLoginResponse(
                       int32_t ret_code,
                       int64_t handle_id,
                       ucloud::udisk::UDiskLoginResponse& rsp) {
  uint32_t error_code = abs(ret_code);
  if (error_code != 0) {
    std::string warn_msg = "login failed in block_gate, error_code: "
        + std::to_string(error_code);
    if (error_code == ucloud::udisk::EC_UDISK_LOGIN_FAILED_STATUS_ERROR) {
      OdinWarning(warn_msg, ConfigParser::kBlockGateLoginLcInvalidItemId);
    } else if (error_code == ucloud::udisk::EC_UDISK_LOGIN_IN_BLACKLIST) {
      OdinWarning(warn_msg, ConfigParser::kBlockGateLoginInBlacklistItemId);
    } else {
      OdinWarning(warn_msg, ConfigParser::kBlockGateLoginFailedItemId);
    }
  }

  loop_->RunInLoop(std::bind(
      &UDiskHandle::SendLoginResponseInLoop, this, error_code == 0, handle_id, rsp));
}

void UDiskHandle::SendLoginResponseInLoop(
    bool success, int64_t handle_id, ucloud::udisk::UDiskLoginResponse rsp) {
  // login 过程中, 与qemu的连接已经断开，这个Handle可能已经负责别的盘
  if (handle_id != handle_id_) {
    ULOG_WARN << "handle id changed, before:" << handle_id
              << " now:" << handle_id_;
    return;
  }
  login_head_.size = sizeof(QemuIOHead);
  if (success) {
    size_ = rsp.size();
    lc_id_ = rsp.lc_id();
    lc_random_id_ = rsp.lc_random_id();
    lc_set_name_ = rsp.set_name();
    if (rsp.has_pc_size()) {
      pc_size_ = rsp.pc_size(); 
    } else {
      //pc_size_ = UDISK_PC_SIZE;
      ULOG_FATAL << "pc_size is null";
    }
    if (pc_size_ == 0 || pc_size_ % MB_SIZE != 0) {
      ULOG_FATAL << "pc_size is not MB_SIZE integral multiple, pc_size: " << pc_size_;
    }
    ULOG_INFO << extern_id_ << " pc_size: " << pc_size_;
    if (rsp.has_zk_server()) {
      zk_server_ = rsp.zk_server();
    } else {
      zk_server_ = g_config_parser->zk_server();
    }
    if (rsp.has_global_zk_server()) {
      global_zk_server_ = rsp.global_zk_server();
    } else {
      global_zk_server_ = g_config_parser->global_zk_server();
    }
    InitQos(rsp.iops(), rsp.bw());
    if (rsp.has_io_timeout() && rsp.io_timeout() != 0) {
      io_timer_count_ = rsp.io_timeout() * 100;
    }
    login_head_.secnum = size_ << 21; // 通过secnum返回盘的大小
    login_head_.retcode = 0;

    //方舟盘Normal或Standby,非方舟盘Standby时需要等到ark状态和数据库同步完成后才返回Qemu
    ArkInit(rsp.utm_mode(), rsp.utm_status(), rsp.mount_status(), rsp.set_name());
    if (rsp.utm_mode() == ucloud::udisk::UTM_MODE_OPEN) {
      if ((rsp.utm_status() != ucloud::udisk::UTM_STATUS_STANDBY &&
           rsp.utm_status() != ucloud::udisk::UTM_STATUS_NORMAL)) {
        DoSendLoginResponse();
      }
    } else {
      if (rsp.utm_status() != ucloud::udisk::UTM_STATUS_STANDBY) {
        DoSendLoginResponse();
      }
    }
  } else {
    login_head_.retcode = -1;
    ULOG_ERROR << "udisk login error";
    DoSendLoginResponse();
  }
}

void UDiskHandle::DoSendLoginResponse() {
  ULOG_INFO<< "login response head:" <<  DumpQemuIOHead(login_head_);
  qemu_conn_->SendData(&login_head_, sizeof(QemuIOHead));
  // 错误的login_head 可能还没有发送到qemu，连接断开
  // qemu依然会重试，不会有影响
  if (login_head_.retcode == -1) {
    g_listener->RemoveConnection(qemu_conn_);
  } else {
    // 连接建立成功后开始获取MetaData和heartbeat
    // 这两个获取metadata的请求完成的先后顺序不重要
    ULOG_INFO << "udisk login successfully, extern_id:" << extern_id_
              << " lc_id:" << lc_id_;
    ManagerThread::Instance()->GetMetaData(this);
    // 启动心跳定时器
    heartbeat_timer_id_ = loop_->RunEvery(
      g_config_parser->heartbeat_period(),
      std::bind(&ManagerThread::Heartbeat, ManagerThread::Instance(), this));
    // 启动IO超时定时器
    io_timer_id_ =
        loop_->RunEvery(0.01, std::bind(&UDiskHandle::IOTimerCb, this));
    // 启动qos定时器
    qos_timer_id_ =
        loop_->RunEvery(0.001, std::bind(&UDiskHandle::QosTimerCb, this));
  }
}


void UDiskHandle::FlushHandle(QemuIOHead* head) {
  QemuIOHead* flush_head = head;
  flush_head->size = sizeof(QemuIOHead);
  flush_head->retcode = 0;
  ULOG_INFO << "flush response head:" << DumpQemuIOHead(*flush_head);
  qemu_conn_->SendData(flush_head, sizeof(QemuIOHead));
  delete flush_head;
  has_flush_ = true;
}

bool UDiskHandle::NeedFlowCtrl(IORequest *req) {
  // 关qos时出于保序目的，只有qos_list为空，才会真正关qos
  if (qos_list_.size() != 0) {
    return true;
  }
  // qos被关闭
  if (!g_config_parser->is_qos()) {
    return false;
  }
  uint64_t pair[kLimitMax];
  pair[kLimitIops] = kTokenPerIO;
  pair[kLimitBW] = req->GetSectorNumber() * SECTOR_SIZE;
  if (req->GetIOCmd() == 0) {
    pair[kLimitReadBW] = req->GetSectorNumber() * SECTOR_SIZE;
    pair[kLimitWriteBW] = 0;
  } else {
    pair[kLimitReadBW] = 0;
    pair[kLimitWriteBW] = req->GetSectorNumber() * SECTOR_SIZE;
  }
  if (!bucket_->grant(pair)) {
    return true;
  }
  return false;
}

// io_req->Send()只要满足发送条件（路由ready，符合保序的要求）
// 就会正确返回，将IO加入inflight list, 但这个时候io可能并没有
// 发送成功发送(发送报错),这时依赖超时重发。不满足发送条件加入pending list,
// 等chunk的IO response时,触发发送pending住的IO
void UDiskHandle::RwRequestHandle(const ConnectionUeventPtr& conn,
                                  QemuIOHead* head) {
  IORequest* io_req = new IORequest(this, head);
  io_req->Init(conn);
  if (NeedFlowCtrl(io_req)) {
    qos_list_.push_back(io_req);
    ULOG_TRACE << "qos list size:" << qos_list_.size();
    return;
  }
  if (io_req->Send() != 0) {
    pending_list_.push_back(io_req);
    ULOG_TRACE << "pending list size:" << pending_list_.size();
  } else {
    inflight_list_.push_back(io_req);
    ULOG_TRACE << "inflight list size:" << inflight_list_.size();
  }
}

void UDiskHandle::ChunkConnSuccessCb(const ConnectionUeventPtr& conn) {
  LoopHandle* loop_handle = conn->GetLoop()->GetLoopHandle();
  UDiskHandle* instance = reinterpret_cast<UDiskHandle*>(loop_handle);
  ULOG_INFO << "connect to chunkserver success, connection name:"
           << conn->GetName() << " connection id:" << conn->GetId()
           << " lc_id:" << instance->GetLcId()
           << " peer addr:" << conn->GetPeerAddress().ToString();
}

void UDiskHandle::ChunkConnClosedCb(const ConnectionUeventPtr& conn) {
  LoopHandle* loop_handle = conn->GetLoop()->GetLoopHandle();
  UDiskHandle* instance = reinterpret_cast<UDiskHandle*>(loop_handle);
  ULOG_INFO << "disconnect from chunkserver, lc_id:" << instance->GetLcId()
           << " peer addr:" << conn->GetPeerAddress().ToString();
}

void UDiskHandle::ChunkConnReadCb(const ConnectionUeventPtr& conn) {
  LoopHandle* loop_handle = conn->GetLoop()->GetLoopHandle();
  UDiskHandle* instance = reinterpret_cast<UDiskHandle*>(loop_handle);
  size_t readable = conn->ReadableLength();
  uint32_t size;
  while (readable >=
         sizeof(MessageHeader)) {  // head len enough 数据不够不能清除
    conn->ReceiveData(&size, sizeof(size));
    if (readable >= size + sizeof(MessageHeader)) {  // data len enough
      MessageHeader msg_head;
      conn->RemoveData(&msg_head, sizeof(MessageHeader));
      readable -= (size + sizeof(MessageHeader));
      if (msg_head.msg_type == MSG_GATE_IO_RES) {
        GateIOResponseHead* res_head = new GateIOResponseHead();
        conn->RemoveData(res_head, GATE_RES_HEAD_SIZE);
        switch (res_head->cmd) {
          case GATE_CMD_READ:
          case GATE_CMD_WRITE:
            instance->RwResponseHandle(conn, res_head);
            break;
          default:
            ULOG_ERROR << "unknown response cmd: " << (uint32_t)res_head->cmd
                       << DumpGateResHead(*res_head);
            break;
        }
        delete res_head;
      } else {
        ULOG_ERROR << "unknown message type: " << msg_head.msg_type
                   << ", data_len: " << msg_head.data_len
                   << ", version: " << msg_head.version
                   << ", readable: " << readable
                   << ", peer_address: " << conn->GetPeerAddress().ToString();
      }
    } else {  // 数据不够， 退出
      break;
    }
    //发生了connection_reset错误，连接已经被释放, 继续读会core
    if (instance->conn_is_reset_ == true) {
      instance->conn_is_reset_ = false;
      break;
    }
  }
}

void UDiskHandle::RwResponseHandle(const ConnectionUeventPtr& conn,
                                   GateIOResponseHead* head) {
  ULOG_TRACE << "receive response from chunksever: "
             << conn->GetPeerAddress().ToString() << DumpGateResHead(*head);
  bool find = false;
  bool io_finish = false;  //标记是否收到了所有的分片
  for (auto it = inflight_list_.begin(); it != inflight_list_.end(); it++) {
    if (head->flowno != (*it)->GetFlowno()) {
      continue;
    }

    find = true;
    FragIORequest* frag_req = (*it)->GetFragIORequest(head->fragno);
    // 如果有数据，读取出数据
    if (head->size != 0) {
      if (UNLIKELY(head->cmd != GATE_CMD_READ)) {
        ULOG_FATAL << "The size of head is not 0 and cmd is not read"
                   << DumpGateResHead(*head); 
      }
      conn->RemoveData(frag_req->data, head->size);
    }

    if (head->retcode == common::RETCODE_PC_NOT_EXISTS &&
        head->cmd == GATE_CMD_READ) {
      ULOG_DEBUG << "read not exist pc, will set 0:"
                 << DumpGateResHead(*head);
      ::memset(frag_req->data, 0, frag_req->secnum * SECTOR_SIZE);
    } else if (head->retcode != 0) {
      // 错误的分片不标记完成，稍后会重试，不立即重试
      ULOG_ERROR << "error gate response head:"
                 << DumpGateResHead(*head);
      IOErrorHandle(head->retcode, frag_req, conn);
      break;
    }

    // 收到正确的回复
    // 区分chunk统计信息, 这里统计的是分片的iops
    Timestamp end_time(Timestamp::now());
    if (head->cmd == GATE_CMD_READ) {
      IncReadIOCount(frag_req->chunk_id, frag_req->gate_req_head.pc_no); // 记录IO的统计信息
      IncReadBytesCount(frag_req->chunk_id, frag_req->gate_req_head.pc_no, 
        frag_req->gate_req_head.length);
      AddReadLatency(frag_req->chunk_id, frag_req->gate_req_head.pc_no, 
        timeDifferenceUs(end_time, frag_req->start_time));
    } else { // qemu_head_->cmd == WRITE
      IncWriteIOCount(frag_req->chunk_id, frag_req->gate_req_head.pc_no);  // 记录IO的统计信息
      IncWriteBytesCount(frag_req->chunk_id, frag_req->gate_req_head.pc_no, 
        frag_req->gate_req_head.length);
      AddWriteLatency(frag_req->chunk_id, frag_req->gate_req_head.pc_no, 
        base::timeDifferenceUs(end_time, frag_req->start_time));
    }

    if ((*it)->MarkFragReceived(head->fragno) == true) {  //收到了所有分片
      io_finish = true;
      ULOG_TRACE << "receive all fragment";
      (*it)->Response();
      if (head->cmd == GATE_CMD_WRITE) {
        //ArkFlow:若开启ark服务，则将IORequest转入Ark流程
        ArkFlow(*it);
      } else {
        delete *it;  // 释放IORequest
      }
      inflight_list_.erase(it);
    }

    break;  //找到对应的request 就可以break
  }
  //可能是chunk已经回复过一次，重复回复(gate进行了超时重试)
  if (find == false) {
    // 将数据部分从缓冲区移除，防止后续解包错误
    if (head->size != 0) {
      assert(head->cmd == GATE_CMD_READ);
      conn->DrainData(head->size);
    }
    ULOG_ERROR << "can't find this response from chunkserver: "
              << conn->GetPeerAddress().ToString()
              << DumpGateResHead(*head);
  } else if (io_finish) {  //避免收到每个分片都触发一次尝试发送
    SendPendingIO();
  }
}

// bit: 0~7 主副本retcode， 8~15 从副本retcode, 16~23 从副本retcode
// 错误处理时，低位错误处理优先
void UDiskHandle::IOErrorHandle(int32_t retcode, FragIORequest* frag_req,
                                const ConnectionUeventPtr& conn) {
  assert(retcode != 0);
  bool first_error_index = true;  // 按最低位的错误标记处理
  for (int i = 0; i < kReplicaNum; i++) {
    uint8_t one_replica_retcode = (uint8_t)(retcode >> (i * 8));
    if (one_replica_retcode != 0) {
      ULOG_ERROR << "error replica index: " << i
                 << ", retcode: " << (uint32_t)one_replica_retcode
                 << " message: " << RetcodeMsg(one_replica_retcode)
                 << " is_first_error_index: " << first_error_index;
      if (first_error_index == true) {
        first_error_index = false;
      } else {
        continue;  // 更高位的错误不需要处理, 只是打印log
      }
      switch (one_replica_retcode) {
        case RETCODE_CLUSTER_VERSION_ERR:
        case RETCODE_CHUNK_NOT_READY:
          ULOG_INFO << "retry error io after 1s";
          RetryErrorFragIO(frag_req, 100);  // 1s 后重试
          break;
        case RETCODE_RESET_CONNECTION: 
          {
            //主动断开连接后立即重试
            auto closed_conn_id = conn->GetId();
            DestroyChunkConnection(closed_conn_id);
            ULOG_INFO << "retry all io immediately at conn id: "
                     << closed_conn_id;
            RetryAllSameConnFragIO(closed_conn_id);
            conn_is_reset_ = true;
          }
          break;
        case RETCODE_AIO_ERR:
        case RETCODE_AIO_WRITE_TIMEOUT:
        case RETCODE_AIO_READ_TIMEOUT:
        case RETCODE_REPLICA_TIMEOUT:
        case RETCODE_OTHER_ERR:
          ULOG_INFO << "retry error io after 2s";
          RetryErrorFragIO(frag_req, 200);  // 2s 后重试
          break;
        default: 
          {
            //主动断开连接后立即重试
            auto closed_conn_id = conn->GetId();
            DestroyChunkConnection(closed_conn_id);
            ULOG_ERROR << "unknow error, retry all io immediately at conn id: "
                     << closed_conn_id;
            RetryAllSameConnFragIO(closed_conn_id);
          }
          break;
      }
    }
  }
}

// 这里重置超时时间，依赖定时器超时，重试IO
void UDiskHandle::RetryErrorFragIO(FragIORequest* frag_req, int timer_count) {
  // 计数设为1然后主动减一，立即出发了重试
  if (timer_count == 0) {
    frag_req->SetTimerCount(1);
    frag_req->DecTimerCount();
  } else {
    frag_req->SetTimerCount(timer_count);
  }
}

// 重试指定连接上的所有的IO
void UDiskHandle::RetryAllSameConnFragIO(int64_t conn_id) {
  for (auto it = inflight_list_.begin(); it != inflight_list_.end(); it++) {
    std::vector<FragIORequest*>* frag_req_vec = (*it)->GetFragReqVec();
    for (auto it1 = frag_req_vec->begin(); it1 != frag_req_vec->end(); it1++) {
      if ((*it1)->chunk_conn_id == conn_id) {
        RetryErrorFragIO(*it1, 0); //
      }
    }
  }
}

void UDiskHandle::IOTimerCb() {
  for (auto it = inflight_list_.begin(); it != inflight_list_.end(); ++it) {
    (*it)->DecTimerCount();
  }
  for (auto it = pending_list_.begin(); it != pending_list_.end(); ++it) {
    (*it)->DecPendingTimerCount();
  }
}

void UDiskHandle::SendPendingIO() {
  // 收到应答后要尝试发送，避免PENDING的IO得不到发送
  ULOG_TRACE << "pending list size: " << pending_list_.size();
  for (auto it = pending_list_.begin(); it != pending_list_.end();) {
    if ((*it)->Send() == 0) {
      inflight_list_.push_back(*it);
      pending_list_.erase(it++);
    } else {
      it++;
    }
  }
}

ConnectionUeventPtr UDiskHandle::GetChunkConnection(FragIORequest* frag_req) {
  frag_req->gate_req_head.lc_id = lc_id_;
  frag_req->gate_req_head.lc_random_id = lc_random_id_;  
  frag_req->gate_req_head.lc_size = size_;  
  frag_req->gate_req_head.pc_size = pc_size_;  
  frag_req->gate_req_head.cluster_uuid = route_manager_ptr_->GetClusterUuid();
  ConnectorUeventPtr chunk_ctor;
  route_manager_ptr_->GetChunkRoute(lc_id_,
                                    frag_req->gate_req_head.pc_no,
                                    lc_random_id_,
                                    &frag_req->gate_req_head.route_version,
                                    &frag_req->gate_req_head.pg_id,
                                    &frag_req->chunk_id,
                                    &chunk_ctor);
  ULOG_TRACE << "chunk id:" << frag_req->chunk_id
            << " lc_id:" << lc_id_ << " pg_id:" << frag_req->gate_req_head.pg_id
            << " pc_no:" << frag_req->gate_req_head.pc_no
            << " pc_size:" << frag_req->gate_req_head.pc_size
            << " cluster_uuid:" << frag_req->gate_req_head.cluster_uuid;
  if (chunk_ctor->HasAvailableConnection() == false) {
    ULOG_ERROR << "no available connection to chunk";
    return ConnectionUeventPtr();
  }
  return chunk_ctor->GetConnection();
}

// 主动断开与chunkserver的连接
void UDiskHandle::DestroyChunkConnection(uint64_t conn_id) {
  auto it = chunk_connector_map_.find(conn_id);
  if (it == chunk_connector_map_.end()) {
    ULOG_FATAL << "no connector in chunk_connector_map with conn_id: "
               << conn_id;
  }
  ULOG_INFO << "gate close connection with chunkserver: "
            << it->second->GetPeerAddress().ToString();
  // 销毁connector 中的连接, 会触发与chunk连接关闭回调
  it->second->DestroyConnection();
}

ConnectorUeventPtr UDiskHandle::GetChunkConnector(const UsockAddress& addr) {
  // 这个id 的构造方法与connetor中构造connection设置的id相同, 所以
  // 需要断开连接时可以通过这个id找到对应的conector
  uint64_t conn_id =
      (static_cast<uint64_t>(addr.IpNetEndian()) << 16) | addr.PortNetEndian();
  ConnectorUeventPtr ctor;
  auto it = chunk_connector_map_.find(conn_id);
  if (it == chunk_connector_map_.end()) {
    ctor.reset(reinterpret_cast<ConnectorUevent*>(new ConnectorLibevent(
        (PosixWorker*)loop_->worker(), addr, "ChunkConnector")));
    ctor->SetConnectionSuccessCb(ChunkConnSuccessCb);
    ctor->SetConnectionClosedCb(ChunkConnClosedCb);
    ctor->SetMessageReadCb(ChunkConnReadCb);
    ctor->Connect();
    chunk_connector_map_[conn_id] = ctor;

  } else {
    ctor = chunk_connector_map_[conn_id];
  }
  return ctor;
}

void UDiskHandle::UpdateRouteManager(
    const ucloud::udisk::ClusterInfoPb& cluster_info,
    const ::google::protobuf::RepeatedPtrField<::ucloud::udisk::ChunkInfoPb>&
        chunk_info,
    const ::google::protobuf::RepeatedPtrField<::ucloud::udisk::PGInfoPb>&
        pg_info,
    int64_t handle_id) {
  loop_->RunInLoop(std::bind(&UDiskHandle::UpdateRouteManagerInLoop, this,
                             cluster_info, chunk_info, pg_info, handle_id));
}

void UDiskHandle::UpdateRouteManagerInLoop(
    const ucloud::udisk::ClusterInfoPb cluster_info,
    const ::google::protobuf::RepeatedPtrField<::ucloud::udisk::ChunkInfoPb>
        chunk_info,
    const ::google::protobuf::RepeatedPtrField<::ucloud::udisk::PGInfoPb>
        pg_info, int64_t handle_id) {
  if (handle_id != handle_id_) {
    ULOG_WARN << "handle id changed";
    return;
  }

  if (!route_manager_ptr_) {
    route_manager_ptr_.reset(new RouteManager(this));
  }

  route_manager_ptr_->UpdateClusterMap(cluster_info, chunk_info, pg_info);
  if (RouteIsReady()) {
    ULOG_TRACE << "route is ready";
    return;
  }

  ManagerThread::Instance()->InitClusterNodes(this);
}

void UDiskHandle::GetIOStatistics(ucloud::udisk::LCIOStats & stats,
                                  int interval,
                                  time_t stat_time) {
  stats.set_iops_read(io_stats_.amount_io_read);
  stats.set_iops_write(io_stats_.amount_io_write);
  stats.set_byteps_read(io_stats_.amount_byte_read / interval);
  stats.set_byteps_write(io_stats_.amount_byte_write / interval);
  stats.set_byteps_ark(io_stats_.amount_byte_ark / interval);
  stats.set_io_retry(amount_io_retry_);
  //平均时延 = 总时延 / IO数，这里只统计总时延，由manager线程计算平均时延
  stats.set_read_latency(io_stats_.amount_read_latency);
  stats.set_write_latency(io_stats_.amount_write_latency);
  stats.set_stats_time(stat_time);
}

//获取按IO大小划分的统计结果
void UDiskHandle::GetSegmentIOStatistics(
                  std::vector<ucloud::udisk::LCStats>& segment_iostat,
                  int interval, time_t stat_time) {
  uint32_t vector_size = segmentation_io_stats_.size();
  segment_iostat.resize(vector_size);
  for (uint32_t i = 0; i < vector_size; i++) {
    AmountIOStats& io_stat = segmentation_io_stats_[i];
    if (io_stat.amount_io_read == 0 && io_stat.amount_io_write == 0) {
      continue;
    }
    segment_iostat[i].set_iops_read(io_stat.amount_io_read);
    segment_iostat[i].set_iops_write(io_stat.amount_io_write);
    segment_iostat[i].set_byteps_read(io_stat.amount_byte_read / interval);
    segment_iostat[i].set_byteps_write(io_stat.amount_byte_write / interval);
    segment_iostat[i].set_byteps_ark(io_stat.amount_byte_ark / interval);
    //平均时延 = 总时延 / IO数，这里只统计总时延，由manager线程计算平均时延
    segment_iostat[i].set_read_latency(io_stat.amount_read_latency);
    segment_iostat[i].set_write_latency(io_stat.amount_write_latency);

    segment_iostat[i].set_stats_time(stat_time);    
  }
}

void UDiskHandle::GetChunkIOStatistics(
      std::shared_ptr<GateChunkIOStatsHandle> ptr,
      int interval) {
  std::vector<ucloud::udisk::GateChunkIOStats> stats;
  std::unordered_map<uint32_t, ucloud::udisk::GatePCIOStats> pc_stats;
  stats.resize(before_chunk_io_stats_.size());
  for (uint32_t chunk_id = 0; chunk_id < before_chunk_io_stats_.size();
                                                               ++chunk_id) {
    AmountIOStats& io_stat = before_chunk_io_stats_[chunk_id];
    stats[chunk_id].set_chunk_id(chunk_id);
    stats[chunk_id].set_iops_read(io_stat.amount_io_read / interval);
    stats[chunk_id].set_iops_write(io_stat.amount_io_write / interval);
    stats[chunk_id].set_byteps_read(io_stat.amount_byte_read / interval);
    stats[chunk_id].set_byteps_write(io_stat.amount_byte_write / interval);

    if (io_stat.amount_io_read != 0) {  //计算读平均延时
      stats[chunk_id].set_read_latency(
          ceil(io_stat.amount_read_latency * 1.0 / io_stat.amount_io_read));
    } else {
      stats[chunk_id].set_read_latency(0);
    }
    if (io_stat.amount_io_write != 0) {  //计算写平均延时
      stats[chunk_id].set_write_latency(
          ceil(io_stat.amount_write_latency * 1.0 / io_stat.amount_io_write));
    } else {
      stats[chunk_id].set_write_latency(0);
    }
  }

  for (auto it = before_pc_io_stats_.begin();
                         it != before_pc_io_stats_.end(); it++) {
    AmountIOStats& io_stat = it->second;
    pc_stats[it->first].set_pc_no(it->first);
    pc_stats[it->first].set_iops_read(io_stat.amount_io_read / interval);
    pc_stats[it->first].set_iops_write(io_stat.amount_io_write/ interval);
    pc_stats[it->first].set_byteps_read(io_stat.amount_byte_read / interval);
    pc_stats[it->first].set_byteps_write(io_stat.amount_byte_write / interval);

    if(io_stat.amount_io_read != 0) { //计算读平均延时
      pc_stats[it->first].set_read_latency(
        ceil(io_stat.amount_read_latency * 1.0 / io_stat.amount_io_read));
    } else{
      pc_stats[it->first].set_read_latency(0);
    }
    if(io_stat.amount_io_write != 0) { //计算写平均延时
      pc_stats[it->first].set_write_latency(
        ceil(io_stat.amount_write_latency * 1.0 / io_stat.amount_io_write));
    } else{
      pc_stats[it->first].set_write_latency(0);
    }
  }
  ManagerThread::Instance()->GetLoop()->RunInLoop(
          std::bind(&ManagerThread::GetChunkIOStatisticsResponse,
                      ManagerThread::Instance(), stats, pc_stats, ptr));
}

void UDiskHandle::GetRwTickInfo(std::shared_ptr<GetLcRwTick> ptr) {
  ucloud::udisk::LcLastRwTickInfo tick_info;
  if (GetRefs() == 0) {  //该udisk handle没有被使用
    ptr->GetRwTickInfosCb(false, tick_info);
    return;
  }
  tick_info.set_extern_id(extern_id_);
  tick_info.set_lc_id(lc_id_);
  tick_info.set_last_read_tick(last_read_tick_);
  tick_info.set_last_write_tick(last_write_tick_);
  tick_info.set_last_heartbeat_tick(last_heartbeat_tick_);
  ptr->GetRwTickInfosCb(true, tick_info);
}

// Ark
void UDiskHandle::ArkFlow(IORequest* io_req) {
  assert(ark_handle_ != nullptr);
  ark_handle_->InsertArkIO(io_req);
}

void UDiskHandle::ArkInit(ucloud::udisk::UTM_MODE ark_mode,
                          ucloud::udisk::UTM_STATUS ark_status,
                          ucloud::udisk::UDISK_MOUNT_STATUS mount_status,
                          std::string set_name){
  ark_handle_ = new ArkHandle(this, ark_mode, ark_status, mount_status);
  if (atoi(set_name.c_str()) >= 3000) {
    ULOG_INFO << "extern_id:" << extern_id_
        << " lc_id:" << lc_id_
        << " ark login a SSD set, set ark max_pending_size and max_infligth_size as 2G";
    ark_handle_->set_max_pending_size(2147483648);
    ark_handle_->set_max_inflight_size(2147483648);
  } else {
    ULOG_INFO << "extern_id::" << extern_id_
        << " lc_id:" << lc_id_
        << " ark login a SATA set, use default ark max_pending_size and max_infligth_size as 1G";
  }
}

void UDiskHandle::ArkInitComplete(int retcode, const std::string& msg) {
  ULOG_INFO << msg;
  if (retcode != 0) {
    OdinWarning("ark init failed", ConfigParser::kLoginFailedItemId);
    ULOG_ERROR << "extern_id_:" << extern_id_
        << " lc_id:" << lc_id_
        << " ark init failed";
    login_head_.retcode = -1;
  }
  DoSendLoginResponse();
}

void UDiskHandle::ArkStatTransTimeout(int64_t handle_id) {
  loop_->RunInLoop(std::bind(&UDiskHandle::ArkStatTransTimeoutInLoop,
                             this,
                             handle_id));
}

void UDiskHandle::ArkStatTransTimeoutInLoop(int64_t handle_id) {
  if (handle_id != handle_id_) {
    ULOG_WARN << "handle id changed, before:" << handle_id
              << " now:" << handle_id_;
    return;
  }
  assert(ark_handle_ != nullptr);
  ark_handle_->ArkStatTransTimeout();
}

void UDiskHandle::ArkStatTransFailed(int64_t handle_id) {
  loop_->RunInLoop(std::bind(&UDiskHandle::ArkStatTransFailedInLoop,
                             this,
                             handle_id));
}

void UDiskHandle::ArkStatTransFailedInLoop(int64_t handle_id) {
  if (handle_id != handle_id_) {
    ULOG_WARN << "handle id changed, before:" << handle_id
              << " now:" << handle_id_;
    return;
  }
  assert(ark_handle_ != nullptr);
  ark_handle_->ArkStatTransFailed();
}

void UDiskHandle::ArkStatTransSuccess(int64_t handle_id) {
  loop_->RunInLoop(std::bind(&UDiskHandle::ArkStatTransSuccessInLoop,
                             this,
                             handle_id));
}

void UDiskHandle::ArkStatTransSuccessInLoop(int64_t handle_id) {
  if (handle_id != handle_id_) {
    ULOG_WARN << "handle id changed, before:" << handle_id
              << " now:" << handle_id_;
    return;
  }
  assert(ark_handle_ != nullptr);
  ark_handle_->ArkStatTransSuccess();
}

void UDiskHandle::ArkRebaseLogin(ArkResponseCb cb, int64_t handle_id) {
  loop_->RunInLoop(std::bind(&UDiskHandle::ArkRebaseLoginInLoop,
                             this,
                             cb,
                             handle_id));
}

void UDiskHandle::ArkRebaseLoginInLoop(ArkResponseCb cb,
                                       int64_t handle_id) {
  if (handle_id != handle_id_) {
    ULOG_WARN << "handle id changed, before:" << handle_id
              << " now:" << handle_id_;
    ManagerThread::Instance()->ArkResponse(cb, -1, "rebase login failed");
    return;
  }
  assert(ark_handle_ != nullptr);
  ark_handle_->RebaseLogin(cb);
  return;
}

void UDiskHandle::ArkRebaseLogout(ArkResponseCb cb,
                                  int64_t handle_id) {
  loop_->RunInLoop(std::bind(&UDiskHandle::ArkRebaseLogoutInLoop,
                             this,
                             cb,
                             handle_id));
}

void UDiskHandle::ArkRebaseLogoutInLoop(ArkResponseCb cb, int64_t handle_id) {
  if (handle_id != handle_id_) {
    ULOG_WARN << "handle id changed, before:" << handle_id
              << " now:" << handle_id_;
    ManagerThread::Instance()->ArkResponse(cb, -1, "rebase logout failed");
    return;
  }
  assert(ark_handle_ != nullptr);
  ark_handle_->RebaseLogout(cb);
}

void UDiskHandle::GetArkRouterSuccess(const uevent::UsockAddress& addr,
                           int64_t handle_id) {
  loop_->RunInLoop(std::bind(&UDiskHandle::GetArkRouterSuccessInLoop,
                             this,
                             addr,
                             handle_id));
}

void UDiskHandle::GetArkRouterSuccessInLoop(const uevent::UsockAddress addr,
                                 int64_t handle_id) {
  if (handle_id != handle_id_) {
    ULOG_WARN << "handle id changed, before:" << handle_id
              << " now:" << handle_id_;
    return;
  }
  assert(ark_handle_ != nullptr);
  ark_handle_->LoginArk(addr);
}

void UDiskHandle::GetArkRouterFailed(int ret_code,
                           int64_t handle_id) {
  loop_->RunInLoop(std::bind(&UDiskHandle::GetArkRouterFailedInLoop,
                             this,
                             ret_code,
                             handle_id));
}

void UDiskHandle::GetArkRouterFailedInLoop(int ret_code,
                                 int64_t handle_id) {
  if (handle_id != handle_id_) {
    ULOG_WARN << "handle id changed, before:" << handle_id
              << " now:" << handle_id_;
    return;
  }
  assert(ark_handle_ != nullptr);
  ULOG_ERROR << "extern_id:" << extern_id_
      << " lc_id:" << lc_id_
      << " get ark router failed, ret_code:"
      << ret_code << ", will retry";
  ManagerThread::Instance()->GetArkRouter(this);
}

void UDiskHandle::GetArkRouterTimeout(int64_t handle_id) {
  loop_->RunInLoop(std::bind(&UDiskHandle::GetArkRouterTimeoutInLoop,
                             this,
                             handle_id));
}

void UDiskHandle::GetArkRouterTimeoutInLoop(int64_t handle_id) {
  if (handle_id != handle_id_) {
    ULOG_WARN << "handle id changed, before:" << handle_id
              << " now:" << handle_id_;
    return;
  }
  assert(ark_handle_ != nullptr);
  ULOG_ERROR << "extern_id:" << extern_id_
      << " lc_id:" << lc_id_
      << " get ark router timeout, will retry";
  ManagerThread::Instance()->GetArkRouter(this);
}

void UDiskHandle::ArkOn(ArkResponseCb cb, int64_t handle_id) {
  loop_->RunInLoop(std::bind(&UDiskHandle::ArkOnInLoop, this, cb, handle_id));
}

void UDiskHandle::ArkOnInLoop(ArkResponseCb cb,
                              int64_t handle_id) {
  if (handle_id != handle_id_) {
    ULOG_WARN << "handle id changed, before:" << handle_id
              << " now:" << handle_id_;
    ManagerThread::Instance()->ArkResponse(cb, -1, "ArkOn failed");
    return;
  }
  assert(ark_handle_ != nullptr);
  ark_handle_->ArkOn(cb);
}

void UDiskHandle::ArkOff(ArkResponseCb cb,
                         int64_t handle_id) {
  //等待后续Rebase操作,Frey已经将数据库状态置为NORMAL
  loop_->RunInLoop(std::bind(&UDiskHandle::ArkOffInLoop, this, cb, handle_id));
}

void UDiskHandle::ArkOffInLoop(ArkResponseCb cb,
                               int64_t handle_id) {
  if (handle_id != handle_id_) {
    ULOG_WARN << "handle id changed, before:" << handle_id
              << " now:" << handle_id_;
    ManagerThread::Instance()->ArkResponse(cb, -1, "ArkOff failed");
    return;
  }
  assert(ark_handle_ != nullptr);
  ark_handle_->ArkOff(cb);
}

void UDiskHandle::ArkKill(int64_t handle_id) {
  loop_->RunInLoop(std::bind(&UDiskHandle::ArkKillInLoop, this, handle_id));
}

void UDiskHandle::ArkKillInLoop(int64_t handle_id) {
  if (handle_id != handle_id_) {
    ULOG_WARN << "handle id changed, before:" << handle_id
              << " now:" << handle_id_;
    return;
  }
  assert(ark_handle_ != nullptr);
  ark_handle_->ArkKill();
}

//无需判断handle_id，所有的handle都要杀，最后一遍通知发送队列，尽可能发完IO
void UDiskHandle::ArkFinalSend() {
  loop_->RunInLoop(std::bind(&UDiskHandle::ArkFinalSendInLoop, this));
}

void UDiskHandle::ArkFinalSendInLoop() {
  assert(ark_handle_ != nullptr);
  //开始PendingQemuIO,可读,不可写
  PendingQemuIO();
  ULOG_INFO << "extern_id:" << extern_id_
      << " lc_id:" << lc_id_
      << " start pending io";
  ark_handle_->SendPendingArkIO();
}

void UDiskHandle::ArkFinalCheck() {
  loop_->RunInLoop(std::bind(&UDiskHandle::ArkFinalCheckInLoop, this));
}

void UDiskHandle::ArkFinalCheckInLoop() {
  assert(ark_handle_ != nullptr);
  ark_handle_->ArkFinalCheck();
}

uint32_t UDiskHandle::ArkPendingSize() {
  if (ark_handle_ != nullptr) {
    return ark_handle_->cur_pending_size();
  }
  return 0;
}

uint32_t UDiskHandle::ArkInflightSize() {
  if (ark_handle_ != nullptr) {
    return ark_handle_->cur_inflight_size();
  }
  return 0;
}

void UDiskHandle::InitQos(uint64_t iops, uint64_t bw) {
  // 若后端不支持qos，则设置iops、bw为当前版本最大值
  if (iops == 0 || bw == 0) {
    max_iops_ = 24000;
    max_bw_ = 260 * MB_SIZE;
  } else {
    max_iops_ = iops;
    max_bw_ = bw;
  }
  // 放大单个io的令牌数以提高精度
  uint64_t capacity[kLimitMax] = {max_iops_ * kTokenPerIO, max_bw_, max_bw_, max_bw_};
  uint64_t rate[kLimitMax] = {max_iops_ * kTokenPerIO, max_bw_, max_bw_, max_bw_};
  bucket_ = new CompoundTokenBucket<uint64_t, kLimitMax>(capacity, rate);

  ReportUDiskQosInfo();
}

void UDiskHandle::SetQos(const std::string& extern_id, uint64_t iops, uint64_t bw) {
  loop_->RunInLoop(std::bind(&UDiskHandle::SetQosInLoop, this, extern_id, iops, bw));
}

void UDiskHandle::SetQosInLoop(const std::string& extern_id, uint64_t iops, uint64_t bw) {
  // 该udisk_handle未分配
  if (GetRefs() == 0) {
    return;
  }
  if (extern_id_ == extern_id) {
    ULOG_INFO << "set qos, extern_id: " << extern_id
              << ", iops:" << iops
              << ", bw: " << bw;
    uint64_t bytes_bw = bw * MB_SIZE;
    // 更新udisk_handle和manager_thread的qos值
    max_iops_ = iops;
    max_bw_ = bytes_bw;
    ReportUDiskQosInfo();
    // 更新令牌桶的容量和速率
    uint64_t capacity[kLimitMax] = {iops * kTokenPerIO, bytes_bw, bytes_bw, bytes_bw};
    uint64_t rate[kLimitMax] = {iops * kTokenPerIO, bytes_bw, bytes_bw, bytes_bw};
    bucket_->reset(capacity, rate);
  }
}

void UDiskHandle::SetLimitBWPercent(int percent) {
  loop_->RunInLoop(
      std::bind(&UDiskHandle::SetLimitBWPercentInLoop, this, percent));
}

void UDiskHandle::SetLimitBWPercentInLoop(int percent) {
  if (bucket_) {
    bucket_->set_percent(percent, kLimitBW);
    ReportUDiskQosInfo();
  }
}

void UDiskHandle::SetLimitIopsPercent(int percent) {
  loop_->RunInLoop(
      std::bind(&UDiskHandle::SetLimitIopsPercentInLoop, this, percent));
}

void UDiskHandle::SetLimitIopsPercentInLoop(int percent) {
  if (bucket_) {
    bucket_->set_percent(percent, kLimitIops);
    ReportUDiskQosInfo();
  }
}

void UDiskHandle::SetLimitReadBWPercent(int percent) {
  loop_->RunInLoop(std::bind(&UDiskHandle::SetLimitReadBWPercentInLoop,
                             this, percent));
}

void UDiskHandle::SetLimitReadBWPercentInLoop(int percent) {
  if (bucket_) {
    bucket_->set_percent(percent, kLimitReadBW);
    ReportUDiskQosInfo();
  }
}

void UDiskHandle::SetLimitWriteBWPercent(int percent) {
  loop_->RunInLoop(std::bind(&UDiskHandle::SetLimitWriteBWPercentInLoop,
                             this, percent));
}

void UDiskHandle::SetLimitWriteBWPercentInLoop(int percent) {
  if (bucket_) {
    bucket_->set_percent(percent, kLimitWriteBW);
    ReportUDiskQosInfo();
  }
}

void UDiskHandle::ReportUDiskQosInfo() {
  ManagerThread::QosInfo info;
  info.limit_bw_percent = limit_bw_percent();
  info.limit_iops_percent = limit_iops_percent();
  info.limit_read_bw_percent = limit_read_bw_percent();
  info.limit_write_bw_percent = limit_write_bw_percent();
  info.max_bw = max_bw_;
  info.max_iops = max_iops_;
  ManagerThread::Instance()->SetUDiskQosInfo(this, info);
}

void UDiskHandle::GetQosStatusInfo(std::shared_ptr<GetLcQosStatus> ptr) {
  ucloud::udisk::LcQosStatusInfo qos_info;
  if (GetRefs() == 0) {  //该udisk handle没有被使用
    ptr->GetQosStatusInfosCb(false, qos_info);
    return;
  }

  uint64_t limit_bw = max_bw_ * limit_bw_percent() / 100;
  uint64_t limit_iops = max_iops_ * limit_iops_percent() / 100;
  qos_info.set_extern_id(extern_id_);
  qos_info.set_lc_id(lc_id_);
  qos_info.set_is_qos(!qos_list_.empty());
  qos_info.set_throttle_bw(limit_bw);
  qos_info.set_throttle_iops(limit_iops);
  qos_info.set_limit_iops_percent(limit_iops_percent());
  qos_info.set_limit_bw_percent(limit_bw_percent());
  qos_info.set_limit_read_bw_percent(limit_read_bw_percent());
  qos_info.set_limit_write_bw_percent(limit_write_bw_percent());
  ptr->GetQosStatusInfosCb(true, qos_info);
}

void UDiskHandle::QosTimerCb() {
  // udisk handle已经reset
  if (GetRefs() == 0) {
    return;
  }
  // 放入定时器间隔时间内新产生的令牌
  bucket_->add();
  // 对qos_list中被限流的io进行重试
  uint64_t pair[kLimitMax];
  for (auto it = qos_list_.begin(); it != qos_list_.end();
       it = qos_list_.erase(it)) {
    pair[kLimitIops] = kTokenPerIO;
    pair[kLimitBW] = (*it)->GetSectorNumber() * SECTOR_SIZE;
    // 读IO
    if ((*it)->GetIOCmd() == 0) {
      pair[kLimitReadBW] = (*it)->GetSectorNumber() * SECTOR_SIZE;
      pair[kLimitWriteBW] = 0;
    // 写IO
    } else {
      pair[kLimitReadBW] = 0;
      pair[kLimitWriteBW] = (*it)->GetSectorNumber() * SECTOR_SIZE;
    }

    if (!bucket_->grant(pair)) {
      break;
    }
    if ((*it)->Send() != 0) {
      pending_list_.push_back(*it);
      ULOG_TRACE << "pending list size:" << pending_list_.size();
    } else {
      inflight_list_.push_back(*it);
      ULOG_TRACE << "inflight list size:" << inflight_list_.size();
    }
  }
}

void UDiskHandle::SetHashNodes(const cluster::ClusterHashRing::VirtualNodeMap& node_map, int64_t handle_id) {
  loop_->RunInLoop(std::bind(
      &UDiskHandle::SetHashNodesInLoop, this, std::cref(node_map), handle_id));
}

void UDiskHandle::SetHashNodesInLoop(const cluster::ClusterHashRing::VirtualNodeMap& node_map, int64_t handle_id) {
  if (handle_id != handle_id_) {
    ULOG_WARN << "Failed to set hash ring, handle id changed, before:"
              << handle_id << " now:" << handle_id_;
    return;
  }

  if (route_manager_ptr_) {
    route_manager_ptr_->SetHashNodes(node_map);
  }
}

void UDiskHandle::InitHashRing(int64_t handle_id) {
  loop_->RunInLoop(std::bind(&UDiskHandle::InitHashRingInLoop, this, handle_id));
}

void UDiskHandle::InitHashRingInLoop(int64_t handle_id) {
  if (handle_id != handle_id_) {
    ULOG_WARN << "Failed to init hash ring, handle id changed, before:"
              << handle_id << " now:" << handle_id_;
    ManagerThread::Instance()->ReportInitHashRingResult(false, this, nullptr);
    return;
  }

  if (route_manager_ptr_ && route_manager_ptr_->InitHashRing()) {
    ManagerThread::Instance()->ReportInitHashRingResult(true, this, &route_manager_ptr_->NodeMap());
    return;
  }

  ManagerThread::Instance()->ReportInitHashRingResult(false, this, nullptr);
}

void UDiskHandle::Resize(const std::string& extern_id, uint32_t size, ResizeCb cb) {
  if (extern_id != extern_id_) {
    ULOG_ERROR << "resize failed because extern_id is not the same, " << extern_id
               << " != " << extern_id_;
    cb(QEMU_FAILURE);
    return;
  }
  ManagerThread::Instance()->Resize(
      this, size, std::bind(&UDiskHandle::ResizeResponse, this, _1, _2, size,
                            std::move(cb)));
}

void UDiskHandle::ResizeResponse(bool success, int64_t handle_id, uint32_t size,
                                 ResizeCb cb) {
  loop_->RunInLoop(std::bind(&UDiskHandle::ResizeResponseInLoop, this, success,
                             handle_id, size, std::move(cb)));
}

void UDiskHandle::ResizeResponseInLoop(bool success, int64_t handle_id,
                                       uint32_t size, ResizeCb cb) {
  if (handle_id != handle_id_) {
    ULOG_WARN << "handle id changed, before:" << handle_id
              << " now:" << handle_id_;
    cb(QEMU_FAILURE);
    return;
  }
  if (!success) {
    ULOG_ERROR << extern_id_ << " resize to " << size << " failed";
    cb(QEMU_FAILURE);
    return;
  }
  ULOG_INFO << "resize success, update size from " << size_ << " to " << size;
  size_ = size;
  route_manager_ptr_->UpdateLcSize(size);
  cb(QEMU_SUCCESS);
}

void UDiskHandle::ReportPendingIOTimeout() {
  ucloud::udisk::OdinWarningRequest warn_request;
  // ip:port:extern_id 拼成uuid, 唯一标识这个告警
  warn_request.set_uuid(g_config_parser->listen_ip() + ":" +
      std::to_string(g_config_parser->listen_port()) + ":" +  extern_id_);
  warn_request.set_item_id(ConfigParser::kGateIOHangPendingItemId);
  warn_request.set_info("pending io hang over " +
      std::to_string(g_config_parser->max_pending_time()) + " seconds");
  warn_request.set_time(Timestamp::now().secondsSinceEpoch());
  ManagerThread::Instance()->WarningToOdin(
             warn_request, lc_set_name_, zk_server_);
}

} // namespace gate
} // namespace udisk
