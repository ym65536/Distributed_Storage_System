#ifndef UDISK_GATE_MY_CONFIG_PARSER_H_
#define UDISK_GATE_MY_CONFIG_PARSER_H_

#include "config_parser.h"

namespace udisk {
namespace gate {

class MyConfigParser : public common::ConfigParser {
 public:
  explicit MyConfigParser(const std::string& file);
  void Init();
  std::tuple<int, std::string> Reload();
  inline int32_t thread_num() const { return thread_num_; }
  inline int32_t report_odin_period() const { return report_odin_period_; }
  inline int32_t heartbeat_period() const { return heartbeat_period_; }
  inline int32_t ark_heartbeat_period() const { return ark_heartbeat_period_; }
  std::string global_odin_zk_path() const { return global_odin_zk_path_; }
  int32_t udisk_handle_delay_reset_time() const {
    return udisk_handle_delay_reset_time_;
  }
  inline int32_t ark_mem_check_period() const { return ark_mem_check_period_; }
  inline bool is_qos() const { return is_qos_; }
  inline uint64_t network_bandwidth() const { return network_bandwidth_; }
  inline uint32_t throttle_high_water_line() const {
    return throttle_high_water_line_;
  }
  inline uint32_t throttle_low_water_line() const {
    return throttle_low_water_line_;
  }
  inline uint32_t throttle_udisk_num() const { return throttle_udisk_num_; }
  inline uint32_t throttle_min_percent() const { return throttle_min_percent_; }
  inline uint32_t throttle_step_percent() const { return throttle_step_percent_; }
  inline uint32_t throttle_broaden_time() const { return throttle_broaden_time_; }
  inline int32_t terminal_dead_line() const { return terminal_dead_line_; }
  inline uint32_t max_pending_time() const { return max_pending_time_; }
  
  const static std::string kThreadNum;
  const static std::string kReportOdinPeriod;
  const static std::string kHeartbeatPeriod;
  const static std::string kArkHeartbeatPeriod;
  const static std::string kGlobalOdinName;
  const static std::string kUDiskHandleDelayResetTime;
  const static std::string kArkMemCheckPeriod;
  const static std::string kQosSwitch;
  const static std::string kNetworkBandwidth;
  const static std::string kThrottleHighWaterLine;
  const static std::string kThrottleLowWaterLine;
  const static std::string kThrottleUdiskNum;
  const static std::string kThrottleMinPercent;
  const static std::string kThrottleStepPercent;
  const static std::string kThrottleBroadenTime;
  const static std::string kTerminalDeadLine;
  const static std::string kMaxPendingTime;

 private:
  std::tuple<int, std::string> LoadMayReloadOption();

  int32_t thread_num_;
  int32_t report_odin_period_;
  int32_t heartbeat_period_;
  int32_t ark_heartbeat_period_;
  std::string global_odin_zk_path_;
  int32_t udisk_handle_delay_reset_time_;
  int32_t ark_mem_check_period_;
  uint64_t network_bandwidth_;
  uint32_t throttle_high_water_line_;
  uint32_t throttle_low_water_line_;
  bool is_qos_;
  uint32_t throttle_udisk_num_;
  uint32_t throttle_min_percent_;
  uint32_t throttle_step_percent_;
  uint32_t throttle_broaden_time_;
  int32_t terminal_dead_line_;
  uint32_t max_pending_time_;
};

}  // gate
}  // udisk

#endif
