#ifndef UDISK_GATE_H_
#define UDISK_GATE_H_

#include <memory>
#include <string>
#include <map>
#include "my_config_parser.h"

namespace uevent {
class ListenerLibevent;
}

namespace udisk {

namespace common {
class NameContainer;
}

namespace gate {

typedef std::map<std::string, std::shared_ptr<common::NameContainer>> NameContainerMap;

class GateListener;

extern std::unique_ptr<GateListener> g_listener;
extern NameContainerMap g_name_containers;
extern std::unique_ptr<MyConfigParser> g_config_parser;
void TerminateBlockGate();

}  // namespace gate
}  // namespace udisk

#endif
