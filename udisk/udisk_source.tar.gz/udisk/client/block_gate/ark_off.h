#ifndef UDISK_GATE_ARK_OFF_H_
#define UDISK_GATE_ARK_OFF_H_

#include <ustevent/base/logging.h>
#include <ustevent/pb_request_handle.h>
#include <ustevent/eventloop.h>
#include "udisk_message.h"

using namespace uevent;

namespace udisk {
namespace gate {

class ArkOffHandle : public PbRequestHandle {
 public:
  explicit ArkOffHandle(uevent::EventLoop* loop) : loop_(loop) {}
  virtual ~ArkOffHandle() {}
  virtual void EntryInit(const ConnectionUeventPtr& conn,
                         const UMessagePtr& um);

  void SendResponse(int retcode, const std::string& message);
  MYSELF_CREATE(ArkOffHandle);
  void ArkOffProcess();

 private:
  static int type_;
  uevent::EventLoop* loop_;
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage response_;
  ucloud::udisk::ArkOffResponse* resp_body_;
  ucloud::udisk::ArkOffRequest req_body_;
};

}  // namespace gate
}  // namespace udisk
#endif
