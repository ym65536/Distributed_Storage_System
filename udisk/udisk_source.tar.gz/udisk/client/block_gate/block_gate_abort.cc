#include "block_gate_abort.h"
#include "umessage_common.h"
#include <ustevent/message_util.h>
#include "gate.h"
#include "gate_listener.h"
//#include "ueventloop_thread_pool.h"
//#include "udisk_handle.h"
#include "manager_thread.h"

namespace udisk {
namespace gate {

using namespace uevent;

int BlockGateAbort::type_ = ucloud::udisk::BLOCK_GATE_TERMINATE_REQUEST;

void BlockGateAbort::EntryInit(const ConnectionUeventPtr& conn,
                               const UMessagePtr& um) {
  ULOG_INFO << um->DebugString();
  conn_ = conn;
  assert(um->head().message_type() == type_);
  assert(um->body().HasExtension(ucloud::udisk::block_gate_terminate_request));
  ucloud::udisk::BlockGateTerminateRequest req_body =
      um->body().GetExtension(ucloud::udisk::block_gate_terminate_request);
  MakeResponse(um.get(), ucloud::udisk::BLOCK_GATE_TERMINATE_RESPONSE, &response_);
  resp_body_ = response_.mutable_body()->MutableExtension(
      ucloud::udisk::block_gate_terminate_response);
  Abort(req_body);
}

void BlockGateAbort::Abort(
    const ucloud::udisk::BlockGateTerminateRequest& req) {
  ManagerThread::Instance()->ArkExit();
  SendResponse(0, "success");
}

void BlockGateAbort::SendResponse(int retcode, const std::string& message) {
  resp_body_->mutable_rc()->set_retcode(retcode);
  resp_body_->mutable_rc()->set_error_message(message);
  ULOG_INFO << response_.DebugString();
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

}  // namespace gate
}  // namespace udisk
