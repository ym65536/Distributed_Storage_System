#include "ark_handle.h"
#include <ustevent/libevent/connector_libevent.h>
#include <ustevent/libevent/connection_libevent.h>
#include "ark_front_io_proto.h"
#include "gate.h"
#include "msgr.h"
#include "udisk_handle.h"
#include "manager_thread.h"
#include "udisk_types.h"

namespace udisk {
namespace gate {

using std::placeholders::_1;
using std::placeholders::_2;
using namespace uevent;
using namespace common;

ArkHandle::ArkHandle(UDiskHandle* handle, /*{{{*/
                     ucloud::udisk::UTM_MODE ark_mode,
                     ucloud::udisk::UTM_STATUS ark_status,
                     ucloud::udisk::UDISK_MOUNT_STATUS mount_status)
    : udisk_handle_(handle),
      extern_id_(handle->extern_id()),
      loop_(handle->GetLoop()),
      max_pending_size_(((uint64_t)MAX_ARK_PENDING_SIZE_MB << 20)),
      cur_pending_size_(0),
      max_inflight_size_(((uint64_t)MAX_ARK_INFLIGHT_SIZE_MB << 20)),
      cur_inflight_size_(0),
      tw_(TimeWheel(kArkIOSendTimeOut, loop_)),
      seq_no_counter_(0),
      batch_no_counter_(0),
      request_id_(0),
      heartbeat_retry_(0),
      login_retry_(0),
      heartbeat_timer_id_(NULL, -1),
      enable_heartbeat_(false),
      ark_resp_cb_(nullptr) {
  ark_status_ = new ArkStatus(ark_mode, ark_status, mount_status, handle);
  tw_.StartTimeWheel();
  InitArk();
} /*}}}*/

ArkHandle::~ArkHandle() {/*{{{*/
  if (heartbeat_timer_id_.sequence != -1) {
    loop_->CancelTimer(heartbeat_timer_id_);
  }

  for (auto it = timer_id_map_.begin(); it != timer_id_map_.end(); it++) {
    loop_->CancelTimer(it->second);
  }

  if (ark_status_->GetArkStatus() == ucloud::udisk::UTM_STATUS_RUNNING ||
      ark_status_->GetArkStatus() == ucloud::udisk::UTM_STATUS_REBASING) {
    ArkFinalCheck();
  }

  delete ark_status_;
} /*}}}*/

void ArkHandle::ArkConnSuccessCb(const ConnectionUeventPtr& conn) {/*{{{*/
  LoopHandle* loop_handle = conn->GetLoop()->GetLoopHandle();
  UDiskHandle* instance = reinterpret_cast<UDiskHandle*>(loop_handle);
  ULOG_INFO << " connect to ark server success, connection name:"
           << conn->GetName() << " connection id:" << conn->GetId()
           << " lc_id:" << instance->GetLcId();
} /*}}}*/

void ArkHandle::ArkConnClosedCb(const ConnectionUeventPtr& conn) {/*{{{*/
  LoopHandle* loop_handle = conn->GetLoop()->GetLoopHandle();
  UDiskHandle* instance = reinterpret_cast<UDiskHandle*>(loop_handle);
  ULOG_INFO << " disconnect from ark server, lc_id:" << instance->GetLcId()
           << " peer addr:" << conn->GetPeerAddress().ToString();

  ArkHandle* ark_handle = instance->GetArkHandle();
  ark_handle->TryTurnOffChannel();
  //更新路由，重新登录
  ULOG_INFO << "lc:" << instance->GetLcId() << " try update and relogin";
  ManagerThread::Instance()->GetArkRouter(instance);
} /*}}}*/

void ArkHandle::ArkConnReadCb(const ConnectionUeventPtr& conn) {/*{{{*/
  LoopHandle* loop_handle = conn->GetLoop()->GetLoopHandle();
  UDiskHandle* instance = reinterpret_cast<UDiskHandle*>(loop_handle);
  ArkHandle* ark_handle = instance->GetArkHandle();
  size_t readable = conn->ReadableLength();
  uint32_t size;
  while (readable >=
         sizeof(MessageHeader)) {  // head len enough 数据不够不能清除
    conn->ReceiveData(&size, sizeof(size));
    if (readable >= size + sizeof(MessageHeader)) {  // data len enough
      MessageHeader msg_head;
      conn->RemoveData(&msg_head, sizeof(MessageHeader));
      readable -= (size + sizeof(MessageHeader));
      switch (msg_head.msg_type) {
        case MSG_FRONT_GATE_IO_RES:
          ark_handle->ArkIOResponseHandle(conn);
          break;
        case MSG_FRONT_GATE_LOGIN_RES:
          ark_handle->ArkLoginResponseHandle(conn);
          break;
        case MSG_FRONT_GATE_PING_RES:
          ark_handle->ArkHeartbeatResponseHandle(conn);
          break;
        default:
          ULOG_ERROR << "lc:" << instance->extern_id()
                     << ", unknown message type: "
                     << (uint32_t)msg_head.msg_type;
      }
    } else {  // 数据不够， 退出
      break;
    }
  }
} /*}}}*/

void ArkHandle::ArkIOResponseHandle(const ConnectionUeventPtr& conn) {/*{{{*/
  GateIOResponse gate_io_resp;
  memset(&gate_io_resp, 0, sizeof(GateIOResponse));
  conn->RemoveData(&gate_io_resp, sizeof(GateIOResponse));
  if (channel_status_ != DOWN) {
    if (gate_io_resp.m_ret_code_ != 0) {
      ULOG_ERROR << "lc:" << extern_id_ << ", send ark io failed, batch_no:"
                 << gate_io_resp.m_squence_number_
                 << " , errno: " << gate_io_resp.m_ret_code_;
      ArkErrorHandle(gate_io_resp.m_ret_code_);
      return;
    } else {
      ULOG_INFO << "lc:" << extern_id_ << " send ark io successfully, batch_no:"
                << gate_io_resp.m_squence_number_;
      ArkIODone(gate_io_resp.m_squence_number_);
    }
  } else {
    ULOG_ERROR << "lc:" << extern_id_ << " ark service is stop, NeedRebase!";
  }
} /*}}}*/

void ArkHandle::ArkLoginResponseHandle(const ConnectionUeventPtr& conn) {/*{{{*/
  GateLoginResponse gate_login_resp;
  memset(&gate_login_resp, 0, sizeof(GateLoginResponse));
  conn->RemoveData(&gate_login_resp, sizeof(GateLoginResponse));
  if (UnRegisterTimeIdMap(gate_login_resp.m_squence_number_) == false) {
    ULOG_ERROR << "lc:" << extern_id_ << " ark response not exist:"
              << gate_login_resp.m_squence_number_;
    return;
  }

  if (gate_login_resp.m_ret_code_ != 0) {
    ULOG_ERROR << "lc:" << extern_id_
              << ", login ark failed, errno: " << gate_login_resp.m_ret_code_;
    ArkErrorHandle(gate_login_resp.m_ret_code_);
  } else if (ark_status_->GetArkStatus() == ucloud::udisk::UTM_STATUS_RUNNING ||
             ark_status_->GetArkStatus() ==
                 ucloud::udisk::UTM_STATUS_REBASING) {
    if (channel_status_ != ON) {
      //登录成功，启动心跳，取消登录超时重试
      StartGateArkHeartbeat();
      login_retry_ = 0;
      ULOG_INFO << "lc:" << extern_id_
               << " login ark successfully, next_sequence_number:"
               << gate_login_resp.m_next_squence_number_;
      if (seq_no_counter_ < gate_login_resp.m_next_squence_number_) {
        if (seq_no_counter_ == 0) {
          seq_no_counter_ = gate_login_resp.m_next_squence_number_;
          ULOG_INFO << "lc:" << extern_id_
                   << " reinit seq_no_counter from ark, seq_no_counter:"
                   << seq_no_counter_ << ", next_sequence_number:"
                   << gate_login_resp.m_next_squence_number_;
        } else {
          ULOG_ERROR << "lc:" << extern_id_
                    << "  bad next_sequence_number, seq_no_counter:"
                    << seq_no_counter_ << ", next_sequence_number:"
                    << gate_login_resp.m_next_squence_number_;
          Ark2NeedRebaseWrapper(ARK_BAD_SEQUENCE_ERROR);
          return;
        }
      }
      TurnOnChannel();
      SendPendingArkIO();
    } else {
      ULOG_ERROR << "lc:" << extern_id_ << " , ark already login";
    }
  } else {
    ULOG_ERROR << "lc:" << extern_id_ << " login ark failed, ark_status error:"
              << ark_status_->GetArkStatus();
  }
} /*}}}*/

void ArkHandle::ArkHeartbeatResponseHandle(
    const ConnectionUeventPtr& conn) {/*{{{*/
  GatePingResponse gate_ping_resp;
  memset(&gate_ping_resp, 0, sizeof(GatePingResponse));
  conn->RemoveData(&gate_ping_resp, sizeof(GatePingResponse));
  if (gate_ping_resp.m_ret_code_ != 0) {
    if (UnRegisterTimeIdMap(gate_ping_resp.m_squence_number_) == true) {
      ULOG_ERROR << "lc:" << extern_id_
                 << ", heartbeat failed, errno: " << gate_ping_resp.m_ret_code_;
      ArkErrorHandle(gate_ping_resp.m_ret_code_);
    }
    return;
  } else {
    if (UnRegisterTimeIdMap(gate_ping_resp.m_squence_number_) == true) {
      ULOG_DEBUG << "lc:" << extern_id_
                 << " heartbeat_id:" << gate_ping_resp.m_squence_number_;
      heartbeat_retry_ = 0;
      SendPendingArkIO();
    }
  }
} /*}}}*/

void ArkHandle::SetArkConnector(const UsockAddress& addr) {/*{{{*/
  if (ctor_) {
    std::string new_addr = addr.ToIpPortString();
    std::string old_addr = ctor_->GetPeerAddress().ToIpPortString();
    ULOG_DEBUG << "reset new_addr:" << new_addr << " old_addr:" << old_addr;
    if (new_addr == old_addr) {
      return;
    }
  }
  ctor_.reset(reinterpret_cast<ConnectorUevent*>(new ConnectorLibevent(
      (PosixWorker*)loop_->worker(), addr, "ArkConnector")));

  ctor_->SetConnectionSuccessCb(ArkConnSuccessCb);
  ctor_->SetConnectionClosedCb(ArkConnClosedCb);
  ctor_->SetMessageReadCb(ArkConnReadCb);
  ctor_->Connect();
} /*}}}*/

void ArkHandle::LoginArk(const UsockAddress& addr) {/*{{{*/
  ULOG_INFO << "login new ark:" << addr.ToIpPortString();
  SetArkConnector(addr);
  if (!ctor_ || ctor_->HasAvailableConnection() == false) {
    ULOG_ERROR << "lc:" << extern_id_ << " no available connection to ark";
    Ark2NeedRebaseWrapper(ARK_IO_ERROR);
    return;
  }
  DoLoginArk(ctor_->GetConnection());
} /*}}}*/

void ArkHandle::LoginArk() {/*{{{*/
  if (!ctor_) {
    ManagerThread::Instance()->GetArkRouter(udisk_handle_);
  } else {
    if (ctor_->HasAvailableConnection() == false) {
      ULOG_INFO << "lc:" << extern_id_
               << " no available connection to ark, update router";
      ManagerThread::Instance()->GetArkRouter(udisk_handle_);
    } else {
      DoLoginArk(ctor_->GetConnection());
    }
  }
} /*}}}*/

void ArkHandle::ReLoginArk() {/*{{{*/
  if (!ctor_ || ctor_->HasAvailableConnection() == false) {
    ULOG_ERROR << "lc:" << extern_id_ << " no available connection to ark";
    Ark2NeedRebaseWrapper(ARK_IO_ERROR);
    ctor_->DestroyConnection();
    return;
  }
  DoLoginArk(ctor_->GetConnection());
} /*}}}*/

void ArkHandle::UpdateRouteAndReLoginArk() {/*{{{*/
  ULOG_INFO << "lc:" << extern_id_ << " update router and relogin";
  //关闭发送流程
  if (channel_status_ == ON) {
    TurnOffChannel();
  }
  ManagerThread::Instance()->GetArkRouter(udisk_handle_);
} /*}}}*/

void ArkHandle::DoLoginArk(ConnectionUeventPtr conn) {/*{{{*/
  //确保方舟服的务状态为RUNNING或REBASING才能登陆到方舟
  if (channel_status_ != ON) {
    if (ark_status_->GetArkStatus() == ucloud::udisk::UTM_STATUS_RUNNING ||
        ark_status_->GetArkStatus() == ucloud::udisk::UTM_STATUS_REBASING) {
      MessageHeader msg_head;
      msg_head.data_len = sizeof(GateLoginRequest);
      msg_head.msg_type = MSG_FRONT_GATE_LOGIN_REQ;
      uint64_t request_id = GetNextRequestId();

      GateLoginRequest gate_login_req;
      memset(&gate_login_req, 0, sizeof(GateLoginRequest));
      strncpy(gate_login_req.m_key_id_, extern_id_.c_str(),
              extern_id_.length());
      gate_login_req.m_vdisk_cap_ = udisk_handle_->GetLcSize();
      gate_login_req.m_sector_size_ = SECTOR_SIZE;
      gate_login_req.m_squence_number_ = request_id;

      ULOG_INFO << "lc:" << extern_id_
                << " lc_size:" << gate_login_req.m_vdisk_cap_
                << " login ark:" << conn->GetPeerAddress().ToString()
                << " request_id:" << request_id;
      conn->SendData(&msg_head, sizeof(MessageHeader));
      conn->SendData(&gate_login_req, sizeof(GateLoginRequest));

      TimerId ark_login_timeout_id = loop_->RunAfter(
          kArkLoginTimeOut,
          std::bind(&ArkHandle::LoginTimeoutCb, this, (request_id)));
      RegisterTimeIdMap(gate_login_req.m_squence_number_, ark_login_timeout_id);
    } else {
      ULOG_ERROR << "lc:" << extern_id_
                 << " , current ark status:" << ark_status_->GetArkStatus()
                 << " can't login ark";
    }
  } else {
    ULOG_ERROR << "lc:" << extern_id_ << " , ark already login";
  }
} /*}}}*/

void ArkHandle::LoginTimeoutCb(uint64_t request_id) {/*{{{*/
  if (login_retry_ > 3) {
    UnRegisterTimeIdMap(request_id);
    ULOG_ERROR << "lc:" << extern_id_
              << " retry login timeout 3 times, ark is lost";
    login_retry_ = 0;
    //更新路由，重新登录
    UpdateRouteAndReLoginArk();
  } else {
    login_retry_++;
    ULOG_ERROR << "lc:" << extern_id_ << " request_id:" << request_id
               << ", ark login timeout, retry login:" << login_retry_;
    UnRegisterTimeIdMap(request_id);
    ReLoginArk();
  }
} /*}}}*/

void ArkHandle::RegisterTimeIdMap(uint64_t request_id,
                                  TimerId& timer_id) {/*{{{*/
  auto success = timer_id_map_.insert(std::pair<uint64_t, TimerId>(
                                          request_id, timer_id)).second;
  if (success) {
    ULOG_DEBUG << "register request_id:" << request_id << " success";
  } else {
    ULOG_ERROR << "lc:" << extern_id_ << " request_id:" << request_id
              << " already exist";
  }
} /*}}}*/

bool ArkHandle::UnRegisterTimeIdMap(uint64_t request_id) {/*{{{*/
  auto it = timer_id_map_.find(request_id);
  if (it == timer_id_map_.end()) {
    ULOG_ERROR << "lc:" << extern_id_ << " request_id:" << request_id
               << " not exist";
    return false;
  } else {
    loop_->CancelTimer(it->second);
    timer_id_map_.erase(it);
    ULOG_DEBUG << "unregister request_id:" << request_id << " success";
    return true;
  }
} /*}}}*/

void ArkHandle::ArkErrorHandle(int32_t retcode) {/*{{{*/
  assert(retcode != 0);
  switch (retcode) {
    case ARK_RETCODE_RE_LOGIN:
      ULOG_ERROR << "lc:" << extern_id_ << " re_login, retcode:" << retcode
                << ", msg:" << ArkRetcodeMsg(retcode);
      //关闭发送流程
      if (channel_status_ == ON) {
        TurnOffChannel();
      }
      ReLoginArk();
      break;
    case ARK_RETCODE_REFECH_ROUTER:
      ULOG_ERROR << "lc:" << extern_id_ << " re_fetch_route, retcode:" << retcode
                << ", msg:" << ArkRetcodeMsg(retcode);
      //关闭发送流程
      if (channel_status_ == ON) {
        TurnOffChannel();
      }
      UpdateRouteAndReLoginArk();
      break;
    case ARK_RETCODE_TIME_OUT:
      ULOG_ERROR << "lc:" << extern_id_
                << " ark io timeout, inflight list will retry it"
                << ", msg:" << ArkRetcodeMsg(retcode);
      break;
    case ARK_RETCODE_TMDISK_FULL:
      ULOG_ERROR << "lc:" << extern_id_
                 << " ark is full, 2NeedRebase, retcode:" << retcode
                 << ", msg:" << ArkRetcodeMsg(retcode);
      Ark2NeedRebaseWrapper(ARK_IO_ERROR);
      break;
    default:
      ULOG_ERROR << "lc:" << extern_id_
                 << " ArkErrorHandle:default 2NeedRebase, retcode:" << retcode
                 << ", msg:" << ArkRetcodeMsg(retcode);
      Ark2NeedRebaseWrapper(ARK_IO_ERROR);
  }
} /*}}}*/

void ArkHandle::InsertArkIO(IORequest* io_req) {/*{{{*/
  if (channel_status_ != DOWN) {
    if (cur_pending_size_ < max_pending_size_) {
      ArkIORequest* ark_io = new ArkIORequest(this, io_req);
      ark_pending_list_.push_back(ark_io);
      cur_pending_size_ += ark_io->io_size();
      ULOG_DEBUG << "extern_id:" << extern_id_
                << "insert pending qemu_io_flowno:" << io_req->GetFlowno()
                << " , pending size:" << cur_pending_size_
                << ", pending length:" << ark_pending_list_.size();
      SendPendingArkIO();
    } else {
      //内存不足，进入Rebase流程
      ULOG_ERROR << "extern_id:" << extern_id_
                << " pending list is out of memory:" << cur_pending_size_;
      Ark2NeedRebaseWrapper(ARK_IO_ERROR);
      delete io_req;
    }
  } else {
    ULOG_DEBUG << "extern_id:" << extern_id_
               << " ark service is stop, NeedRebase!";
    //未启动方舟服务
    delete io_req;
  }
} /*}}}*/

void ArkHandle::SendPendingArkIO() {/*{{{*/
  if (channel_status_ == ON) {
    if (ark_inflight_list_.size() >= MAX_ARK_INFLIGHT_DEPTH) {
      ULOG_ERROR << "lc:" << extern_id_
                 << " inflight io depth is full: " << ark_inflight_list_.size();
      return;
    }
    std::shared_ptr<ArkIOBatch> ark_batch_ptr =
        std::make_shared<ArkIOBatch>(this);
    for (auto iter = ark_pending_list_.begin();
         iter != ark_pending_list_.end();) {
      if (cur_inflight_size_ < max_inflight_size_ &&
          ark_batch_ptr->length() < MAX_ARK_BATCH_LENGTH &&
          ark_batch_ptr->batch_size() < MAX_ARK_BATCH_SIZE) {
        //在发送时才分配SeqNo
        (*iter)->AssignSeqNo(GetNextSeqNo());
        ark_batch_ptr->Insert(*iter);
        cur_inflight_size_ += (*iter)->io_size();
        cur_pending_size_ -= (*iter)->io_size();
        ULOG_DEBUG << "extern_id:" << extern_id_
                  << " insert pending io_seq_no:" << (*iter)->seq_no()
                  << ", inflight length:" << ark_inflight_list_.size()
                  << " pending length:" << ark_pending_list_.size()
                  << " , inflight size:" << cur_inflight_size_
                  << " pending size:" << cur_pending_size_;
        iter = ark_pending_list_.erase(iter);
      } else {
        ULOG_ERROR << "extern_id:" << extern_id_
                  << " inflight io list full:" << cur_inflight_size_
                  << ", current pending mem:" << cur_pending_size_;
        ;
        break;
      }
    }

    if (ark_batch_ptr->length() > 0) {
      //发送时再分配BatchNo
      ark_batch_ptr->AssignBatchNo(GetNextBatchNo());
      ark_batch_ptr->Send();
      ark_inflight_list_.push_back(ark_batch_ptr);
      //添加超时重试IO
      tw_.AddBatch(ark_batch_ptr);
    } else {
      ULOG_WARN << "lc:" << extern_id_ << "ark_batch is empty"
                << ", may be pending list is empty or inflight list is full, "
                << "current pending mem:" << cur_pending_size_;
    }
  } else {
    ULOG_ERROR << "lc:" << extern_id_
               << " send pending io failed, ark send channel is not open, status:"
               << channel_status_;
  }
} /*}}}*/

//考虑到发送队列基本上遵守先发送，先回复，故直接遍历发送队列
//也能够获得不错的查找效率
void ArkHandle::ArkIODone(uint64_t batch_no) {/*{{{*/
  ULOG_DEBUG << "=====>batch_no:" << batch_no;
  auto iter = ark_inflight_list_.begin();
  for (; iter != ark_inflight_list_.end();) {
    if ((*iter)->batch_no() == batch_no) {
      cur_inflight_size_ -= (*iter)->batch_size();
      ark_inflight_list_.erase(iter);
      ULOG_DEBUG << "batch_no:" << batch_no
                 << " done, inflight length:" << ark_inflight_list_.size()
                 << " pending length:" << ark_pending_list_.size()
                 << ", inflight size:" << cur_inflight_size_
                 << " pending size:" << cur_pending_size_;
      break;
    } else {
      iter++;
    }
  }

  if (iter == ark_inflight_list_.end()) {
    ULOG_DEBUG << "not find batch_no:" << batch_no
               << " in ark_infligth_list, maybe already freed";
  }

  SendPendingArkIO();
} /*}}}*/

//心跳
void ArkHandle::StartGateArkHeartbeat() {/*{{{*/
  EnableHeartbeat();
  if (heartbeat_timer_id_.sequence == -1) {
    heartbeat_timer_id_ =
        loop_->RunEvery(g_config_parser->ark_heartbeat_period(),
                        std::bind(&ArkHandle::GateArkHeartbeat, this));
    ULOG_INFO << "lc:" << extern_id_ << " start gate ark heartbeat period:"
             << g_config_parser->ark_heartbeat_period();
  } else {
    ULOG_INFO << "lc:" << extern_id_ << " gate ark heartbeat already start:";
  }
} /*}}}*/

void ArkHandle::GateArkHeartbeat() {/*{{{*/
  if (enable_heartbeat_ == false) {
    ULOG_INFO << "gate ark heartbeat is disable, maybe ark service is stop";
    return;
  }

  MessageHeader msg_head;
  msg_head.data_len = sizeof(GatePingRequest);
  msg_head.msg_type = MSG_FRONT_GATE_PING_REQ;

  uint64_t request_id = GetNextRequestId();
  GatePingRequest gate_ping_req;
  memset(&gate_ping_req, 0, sizeof(GatePingRequest));

  gate_ping_req.m_squence_number_ = request_id;
  strncpy(gate_ping_req.m_key_id_, extern_id_.c_str(), extern_id_.length());

  const ConnectionUeventPtr conn = GetConnection();
  if (conn == nullptr) {
    ULOG_ERROR << "lc:" << extern_id_
              << " send ark heartbeat:" << gate_ping_req.m_squence_number_
              << " failed";
    return;
  }

  conn->SendData(&msg_head, sizeof(MessageHeader));
  conn->SendData(&gate_ping_req, sizeof(GatePingRequest));
  ULOG_DEBUG << "lc:" << extern_id_
             << ", heartbeat_id:" << gate_ping_req.m_squence_number_
             << " to ark:" << conn->GetPeerAddress().ToString()
             << ", request_id:" << request_id;

  TimerId heartbeat_timeout_id = loop_->RunAfter(
      kArkHeartbeatTimeOut,
      std::bind(&ArkHandle::GateArkHeartbeatTimeoutCb, this, (request_id)));
  RegisterTimeIdMap(gate_ping_req.m_squence_number_, heartbeat_timeout_id);
} /*}}}*/

void ArkHandle::GateArkHeartbeatTimeoutCb(uint64_t request_id) {/*{{{*/
  if (heartbeat_retry_ > 3) {
    UnRegisterTimeIdMap(request_id);
    ULOG_ERROR << "lc:" << extern_id_
              << " GateArkHeartbeat timeout 3 times, ark is lost";
    heartbeat_retry_ = 0;
    //更新路由，重新登录
    UpdateRouteAndReLoginArk();
  } else {
    heartbeat_retry_++;
    ULOG_ERROR << "lc:" << extern_id_
              << " GateArkHeartbeat timeout:" << heartbeat_retry_;
    UnRegisterTimeIdMap(request_id);
  }
} /*}}}*/

const ConnectionUeventPtr ArkHandle::GetConnection() {/*{{{*/
  if (!ctor_ || ctor_->HasAvailableConnection() == false) {
    ULOG_ERROR << "lc:" << extern_id_ << " no available connection to ark";
    ctor_->DestroyConnection();
    return nullptr;
  }
  return ctor_->GetConnection();
} /*}}}*/

void ArkHandle::ClearPendingList() {/*{{{*/
  for (auto iter = ark_pending_list_.begin(); iter != ark_pending_list_.end();
       iter++) {
    delete *iter;
  }
  ark_pending_list_.clear();
  cur_pending_size_ = 0;
} /*}}}*/

void ArkHandle::ClearInFlightList() {/*{{{*/
  for (auto iter = ark_inflight_list_.begin(); iter != ark_inflight_list_.end();
       iter++) {
    iter->reset();
  }
  ark_inflight_list_.clear();
  cur_inflight_size_ = 0;
} /*}}}*/

void ArkHandle::ResetArk() {/*{{{*/
  ClearPendingList();
  ClearInFlightList();
  seq_no_counter_ = 0;
  batch_no_counter_ = 0;
  request_id_ = 0;
  TurnOffChannel();

  ULOG_INFO << "lc:" << extern_id_ << " ark service has resset successfully";
} /*}}}*/

//清空发送队列,并初始化计数器
void ArkHandle::StopArk() {/*{{{*/
  if (channel_status_ != DOWN) {
    ShutDownChannel();
    DisableHeartbeat();
    ClearPendingList();
    ClearInFlightList();
    seq_no_counter_ = 0;
    batch_no_counter_ = 0;
    request_id_ = 0;
  }
  ULOG_INFO << "lc:" << extern_id_ << " ark service has stopped successfully";
} /*}}}*/

// Ark状态转换
void ArkHandle::InitArk() {/*{{{*/
  ucloud::udisk::UTM_MODE ark_mode = ark_status_->GetArkMode();
  ucloud::udisk::UTM_STATUS ark_status = ark_status_->GetArkStatus();
  if (ark_mode == ucloud::udisk::UTM_MODE_OPEN) {  //方舟盘
    //方舟盘启动置为OFF，qemu登录成功即记录request_io
    channel_status_ = OFF;
    // Normal和StandyBy需要等到Ark状态和数据库同步完成才能回复
    //其他状态为异常状态，需要NeedRebase
    switch (ark_status) {
      case ucloud::udisk::UTM_STATUS_NORMAL:
        //方舟盘启动NORMAL状态，转换为RUNNING并发送io(正常流程)
        ULOG_INFO << "lc:" << extern_id_ << " ark status is " << ark_status
                  << ", start ark to RUNNING";
        ark_status_->Ark2Running(QEMU_LOGIN);
        ark_resp_cb_ = std::bind(&UDiskHandle::ArkInitComplete, udisk_handle_,
                                 std::placeholders::_1, std::placeholders::_2);
        break;
      //方舟盘启动STANDBY状态，转换为Rebasing并发送io,未挂载时，
      //收到RebaseLogin请求(正常流程)
      case ucloud::udisk::UTM_STATUS_STANDBY:
        // To Rebasing
        ULOG_INFO << "lc:" << extern_id_ << " ark status is " << ark_status
                 << ", start ark to REBASING";
        ark_status_->Ark2Rebasing(QEMU_LOGIN);
        ark_resp_cb_ = std::bind(&UDiskHandle::ArkInitComplete, udisk_handle_,
                                 std::placeholders::_1, std::placeholders::_2);
        break;
      //方舟盘为RUNNING或REBASING状态，表明之前异常退出，
      //转换为NeedRebase状态(异常流程)
      case ucloud::udisk::UTM_STATUS_RUNNING:
      case ucloud::udisk::UTM_STATUS_REBASING:
        // To NeedRebase
        ULOG_ERROR << "lc:" << extern_id_ << " ark status is " << ark_status
                  << ", change ark status to NeedRebase";
        Ark2NeedRebaseWrapper(QEMU_LOGIN);
        break;
      //方舟盘启动时已经为NeedRebase状态，表示之前有异常,
      //等待RebaseLogin请求(异常流程)
      case ucloud::udisk::UTM_STATUS_NEED_REBASE:
        ULOG_INFO << "lc:" << extern_id_ << " ark status is " << ark_status
                 << ", wait for rebase login";
        // NeedRebase状态下无需PendingIO,等待rebase login即可
        StopArk();
        break;
      default:
        //其他都是异常流程
        ULOG_ERROR << "lc:" << extern_id_ << " ark_staus:" << ark_status
                  << " is not support";
        Ark2NeedRebaseWrapper(QEMU_LOGIN);
    }
  } else {  //非方舟盘
    //非方舟盘启动置为DOWN，qemu登录成功后，不记录request_io
    channel_status_ = DOWN;
    switch (ark_status) {
      //非方舟启动为NORMAL状态，无状态转换(正常流程)
      case ucloud::udisk::UTM_STATUS_NORMAL:
        ULOG_INFO << "lc:" << extern_id_
                 << " inital ark status is NORMAL, no ark task, stop ark";
        break;
      //非方舟启动为STANDBY状态，说明挂载之前有RebaseLogin请求，
      //需要转换到Rebasing状态(正常流程)
      case ucloud::udisk::UTM_STATUS_STANDBY:
        ULOG_ERROR << "lc:" << extern_id_ << " initial ark status is "
                  << ark_status << ", change ark status to Rebasing";
        channel_status_ = OFF;
        ark_status_->Ark2Rebasing(QEMU_LOGIN);
        ark_resp_cb_ = std::bind(&UDiskHandle::ArkInitComplete, udisk_handle_,
                                 std::placeholders::_1, std::placeholders::_2);
        break;
      //非方舟盘为Rebasing状态，说明之前异常退出,需要转换到NeedRebase状态，
      //并等待下一次NeedRebase请求(异常流程)
      case ucloud::udisk::UTM_STATUS_REBASING:
        ULOG_ERROR << "lc:" << extern_id_ << " initial ark status is "
                  << ark_status << ", change ark status to NeedRebase";
        Ark2NeedRebaseWrapper(QEMU_LOGIN);
        break;
      //非方舟盘为NeedRebase状态，说明之前已经是异常，
      //无需转换，等待下次RebaseLogin
      case ucloud::udisk::UTM_STATUS_NEED_REBASE:
        ULOG_ERROR << "lc:" << extern_id_ << " initial ark status is "
                  << ark_status << ", wait for rebase";
        break;
      default:
        //其他状态皆为异常状态，全都转换为NeedRebase状态
        ULOG_ERROR << "lc:" << extern_id_ << " initial ark staus is "
                  << ark_status << " is not support, reset as NeedRebase";
        Ark2NeedRebaseWrapper(QEMU_LOGIN);
    }
  }
} /*}}}*/

void ArkHandle::RebaseLogin(ArkResponseCb cb) {/*{{{*/
  //保证同时只有一个op能改变状态
  if (ark_status_->IsTransingStatus()) {
    ULOG_ERROR << "lc:" << extern_id_ << " someone is transing ark status to:"
              << ark_status_->GetTargetStatus();
    ManagerThread::Instance()->ArkResponse(cb, -1, "rebase login failed");
    return;
  }

  // rebase login
  //需要重新初始化ark服务状态，并设置成off状态，且状态转换成功后需要重新登录到方舟
  ResetArk();
  ark_resp_cb_ = cb;
  ucloud::udisk::UTM_MODE ark_mode = ark_status_->GetArkMode();
  ucloud::udisk::UTM_STATUS ark_status = ark_status_->GetArkStatus();
  if (ark_mode == ucloud::udisk::UTM_MODE_OPEN) {  //方舟盘
    switch (ark_status) {
      //方舟盘为Running或NeedRebase，
      // RebaseLogin请求只需将状态转换为Rebasing(正常流程)
      case ucloud::udisk::UTM_STATUS_RUNNING:
      case ucloud::udisk::UTM_STATUS_NEED_REBASE:
        ULOG_INFO << "lc:" << extern_id_
                 << " rebase login , current ark status:" << ark_status
                 << " set status as rebasing";
        ark_status_->Ark2Rebasing(REBASE_LOGIN);
        break;
      //方舟盘为Rebasing状态，仍然执行2Rebasing流程
      case ucloud::udisk::UTM_STATUS_REBASING:
        ULOG_WARN << "lc:" << extern_id_
                 << " rebase login , ark status is already rebasing";
        ark_status_->Ark2Rebasing(REBASE_LOGIN);
        break;
      default:
        //其他流程皆为异常流程，返回失败
        ULOG_ERROR << "lc:" << extern_id_
                  << " rebase login not support ark_status:" << ark_status;
        ManagerThread::Instance()->ArkResponse(
            cb, -1, "rebase login not support ark_status:" +
                        std::to_string(ark_status));
        ark_resp_cb_ = nullptr;
    }
  } else {  //非方舟盘
    switch (ark_status) {
      //非方舟盘为NeedRebase或Normal状态，
      //转换为Rebasing状态(正常流程)
      case ucloud::udisk::UTM_STATUS_NEED_REBASE:
      case ucloud::udisk::UTM_STATUS_NORMAL:
        ULOG_INFO << "lc:" << extern_id_
                 << " rebase login , current ark status:" << ark_status
                 << " set status as rebasing";
        ark_status_->Ark2Rebasing(REBASE_LOGIN);
        break;
      //非方舟盘为Rebasing状态， 仍然执行2Rebasing流程
      case ucloud::udisk::UTM_STATUS_REBASING:
        ULOG_WARN << "lc:" << extern_id_
                 << " rebase login , ark status is already rebasing";
        ark_status_->Ark2Rebasing(REBASE_LOGIN);
        break;
      //非方舟盘为Running状态(非方舟盘不可能是Running状态)，
      //转换为NeedRebase状态(异常流程)
      case ucloud::udisk::UTM_STATUS_RUNNING:
        ULOG_ERROR  << "lc:" << extern_id_
            << " rebase login , ark status is running, impossible, needreabse";
        Ark2NeedRebaseWrapper(REBASE_LOGIN);
        break;
      default:
        //其他状态皆为异常流程，返回失败
        ULOG_ERROR << "lc:" << extern_id_
                  << " rebase login not support ark_status:" << ark_status;
        ManagerThread::Instance()->ArkResponse(
            cb, -1, "rebase login not support ark_status:" +
                        std::to_string(ark_status));
        ark_resp_cb_ = nullptr;
    }
  }
} /*}}}*/

void ArkHandle::RebaseLogout(ArkResponseCb cb) {/*{{{*/
  //保证同时只有一个op能改变状态
  if (ark_status_->IsTransingStatus()) {
    ULOG_ERROR << "lc:" << extern_id_ << " someone is transing ark status to:"
              << ark_status_->GetTargetStatus();
    ManagerThread::Instance()->ArkResponse(cb, -1, "rebase logout failed");
    return;
  }
  ark_resp_cb_ = cb;
  ucloud::udisk::UTM_MODE ark_mode = ark_status_->GetArkMode();
  ucloud::udisk::UTM_STATUS ark_status = ark_status_->GetArkStatus();
  if (ark_mode == ucloud::udisk::UTM_MODE_OPEN) {
    switch (ark_status) {
      //方舟盘为Rebasing状态，转换为Running状态(正常流程)
      case ucloud::udisk::UTM_STATUS_REBASING:
        ULOG_INFO << "lc:" << extern_id_
                 << " rebase logout , current ark status:" << ark_status
                 << " set status as running";
        ark_status_->Ark2Running(REBASE_LOGOUT);
        break;
      //方舟盘为NeedRebase状态，表示出现异常，需要等到下一次RebaseLogin(异常流程)
      case ucloud::udisk::UTM_STATUS_NEED_REBASE:
        ULOG_INFO << "lc:" << extern_id_
                 << " rebase logout failed, ark status is NeedRebase";
        ManagerThread::Instance()->ArkResponse(
            cb, -1, "rebase logout failed, ark status:NeedRebase");
        ark_resp_cb_ = nullptr;
        break;
      default:
        //其他流程皆为异常流程，返回失败
        ULOG_ERROR << "lc:" << extern_id_
                  << " rebase logout not support ark_status:" << ark_status;
        ManagerThread::Instance()->ArkResponse(
            cb, -1, "rebase login not support ark_status:" +
                        std::to_string(ark_status));
        ark_resp_cb_ = nullptr;
    }
  } else {
    switch (ark_status) {
      //非方舟盘为Rebasing状态，转换为Normal状态(正常流程)
      case ucloud::udisk::UTM_STATUS_REBASING:
        ark_status_->Ark2Normal(REBASE_LOGOUT);
        break;
      //方舟盘为NeedRebase状态，表明之前的Rebase流程失败，
      //等待下一次RebaseLogin(异常流程)
      case ucloud::udisk::UTM_STATUS_NEED_REBASE:
        ULOG_INFO << "lc:" << extern_id_
                 << " rebase logout failed, ark status is NeedRebase";
        ManagerThread::Instance()->ArkResponse(
            cb, -1, "rebase logout failed, ark status:NeedRebase");
        ark_resp_cb_ = nullptr;
        break;
      default:
        //其他流程皆为异常流程，返回失败
        ULOG_ERROR << "lc:" << extern_id_
                  << " rebase logout not support ark_status:" << ark_status;
        ManagerThread::Instance()->ArkResponse(
            cb, -1, "rebase login not support ark_status:" +
                        std::to_string(ark_status));
        ark_resp_cb_ = nullptr;
    }
  }
} /*}}}*/

void ArkHandle::ArkOn(ArkResponseCb cb) {/*{{{*/
  //等待后续Rebase操作,Frey已经将数据库状态置为mode:OPEN,status:NeedRebase无需设置数据库状态
  ark_status_->SetArkMode(ucloud::udisk::UTM_MODE_OPEN);
  Ark2NeedRebaseWrapper(ARK_ON);
  ManagerThread::Instance()->ArkResponse(cb, 0, "ArkOn Success");
} /*}}}*/

void ArkHandle::ArkOff(ArkResponseCb cb) {/*{{{*/
  //等待后续Rebase操作,Frey已经将数据库状态置为OFF,status:NeedRebase无需设置数据库状态
  ark_status_->SetArkMode(ucloud::udisk::UTM_MODE_CLOSE);
  Ark2NeedRebaseWrapper(ARK_OFF);
  ManagerThread::Instance()->ArkResponse(cb, 0, "ArkOff Success");
} /*}}}*/

void ArkHandle::ArkKill() {/*{{{*/
  ULOG_INFO << "lc:" << extern_id_ << " ark kill is called";
  Ark2NeedRebaseWrapper(ARK_OUT_OF_MEM);
} /*}}}*/

void ArkHandle::ArkFinalCheck() {/*{{{*/
  //都为空，表示IO已经发完，可以转换为Normal状态，否则需要转换为NeedRebase状态
  if (ark_pending_list_.empty() && ark_inflight_list_.empty()) {
    ULOG_INFO << "lc:" << extern_id_ << " all io is send out";
    if (ark_status_->GetArkMode() == ucloud::udisk::UTM_MODE_CLOSE &&
        ark_status_->GetArkStatus() == ucloud::udisk::UTM_STATUS_REBASING) {
      ULOG_INFO << "lc:" << extern_id_ << " trans to Standby";
      ark_status_->Ark2Standby(ARK_EXIT);
    } else if (ark_status_->GetArkMode() == ucloud::udisk::UTM_MODE_OPEN &&
               ark_status_->GetArkStatus() ==
                   ucloud::udisk::UTM_STATUS_REBASING) {
      ULOG_INFO << "lc:" << extern_id_ << " trans to Standby";
      ark_status_->Ark2Standby(ARK_EXIT);
    } else if (ark_status_->GetArkMode() == ucloud::udisk::UTM_MODE_OPEN &&
               ark_status_->GetArkStatus() ==
                   ucloud::udisk::UTM_STATUS_RUNNING) {
      ULOG_INFO << "lc:" << extern_id_ << " trans to Normal";
      ark_status_->Ark2Normal(ARK_EXIT);
    } else {
      ULOG_INFO << "lc:" << extern_id_ << "io list is empty, but status "
                                          "is not right ,trans to NeedRebase";
      Ark2NeedRebaseWrapper(ARK_EXIT);
    }
  } else {
    ULOG_INFO << "lc:" << extern_id_
             << " still io left in list, trans to NeedRebase";
    Ark2NeedRebaseWrapper(ARK_EXIT);
  }
} /*}}}*/

// ArkStatTransCb
void ArkHandle::ArkStatTransSuccess() {/*{{{*/
  ULOG_INFO << "lc:" << extern_id_ << " ark status trans success";
  bool flag = true;
  ucloud::udisk::UTM_STATUS target_status = ark_status_->GetTargetStatus();
  ArkTransOp op = ark_status_->GetArkTransOp();
  switch (target_status) {
    case ucloud::udisk::UTM_STATUS_STANDBY:
      ark_status_->Ark2StandbySuccess();
      StopArk();
      break;
    case ucloud::udisk::UTM_STATUS_NORMAL:
      ark_status_->Ark2NormalSuccess();
      StopArk();
      break;
    case ucloud::udisk::UTM_STATUS_RUNNING:
      ark_status_->Ark2RunningSuccess();
      LoginArk();
      break;
    case ucloud::udisk::UTM_STATUS_REBASING:
      ark_status_->Ark2RebasingSuccess();
      UpdateRouteAndReLoginArk();
      break;
    case ucloud::udisk::UTM_STATUS_NEED_REBASE:
      ark_status_->Ark2NeedRebaseSuccess();
      break;
    default:
      flag = false;
      ULOG_ERROR << "lc:" << extern_id_ << " target_status:" << target_status
                << " is not support for success callback";
  }
  ArkStatTransCb(flag, op, target_status);
} /*}}}*/

void ArkHandle::ArkStatTransFailed() {/*{{{*/
  ULOG_ERROR << "lc:" << extern_id_ << " ark status trans failed";
  ucloud::udisk::UTM_STATUS target_status = ark_status_->GetTargetStatus();
  ArkTransOp op = ark_status_->GetArkTransOp();
  switch (target_status) {
    case ucloud::udisk::UTM_STATUS_STANDBY:
      ark_status_->Ark2StandbyFailed();
      break;
    case ucloud::udisk::UTM_STATUS_NORMAL:
      ark_status_->Ark2NormalFailed();
      break;
    case ucloud::udisk::UTM_STATUS_RUNNING:
      ark_status_->Ark2RunningFailed();
      break;
    case ucloud::udisk::UTM_STATUS_REBASING:
      ark_status_->Ark2RebasingFailed();
      break;
    case ucloud::udisk::UTM_STATUS_NEED_REBASE:
      ark_status_->Ark2NeedRebaseFailed();
      //重试NeedRebase,直到成功
      ark_status_->Ark2NeedRebase();
      break;
    default:
      ULOG_ERROR << "lc:" << extern_id_ << " target_status:" << target_status
                << " is not support for failed callback";
  }
  ArkStatTransCb(false, op, target_status);
} /*}}}*/

void ArkHandle::ArkStatTransTimeout() {/*{{{*/
  ULOG_ERROR << "lc:" << extern_id_ << " ark status trans timeout";
  ucloud::udisk::UTM_STATUS target_status = ark_status_->GetTargetStatus();
  ArkTransOp op = ark_status_->GetArkTransOp();
  switch (target_status) {
    case ucloud::udisk::UTM_STATUS_STANDBY:
      ark_status_->Ark2StandbyTimeout();
      break;
    case ucloud::udisk::UTM_STATUS_NORMAL:
      ark_status_->Ark2NormalTimeout();
      break;
    case ucloud::udisk::UTM_STATUS_RUNNING:
      ark_status_->Ark2RunningTimeout();
      break;
    case ucloud::udisk::UTM_STATUS_REBASING:
      ark_status_->Ark2RebasingTimeout();
      break;
    case ucloud::udisk::UTM_STATUS_NEED_REBASE:
      ark_status_->Ark2NeedRebaseTimeout();
      //重试NeedRebase,直到成功
      ark_status_->Ark2NeedRebase();
      break;
    default:
      ULOG_ERROR << "lc:" << extern_id_ << " target_status:" << target_status
                << " is not support for timeout callback";
  }
  ArkStatTransCb(false, op, target_status);
} /*}}}*/

void ArkHandle::ArkStatTransCb(bool success, /*{{{*/
                               ArkTransOp op,
                               ucloud::udisk::UTM_STATUS target_status) {
  if (success == true) {
    ULOG_INFO << "lc:" << extern_id_ << " ark_op:" << op
             << ", ark trans status:" << target_status << " successfully";
    if (ark_resp_cb_ != nullptr) {
      switch (op) {
        case QEMU_LOGIN:
          ark_resp_cb_(0, "ark sync status success");
          break;
        case REBASE_LOGIN:
          ark_resp_cb_(0, "ark rebase login success");
          break;
        case REBASE_LOGOUT:
          ark_resp_cb_(0, "ark rebase logout success");
          break;
        default:
          ULOG_ERROR << "lc:" << extern_id_
                    << " no match ark stat sync success callback";
      }
    }
  } else {
    if (ark_resp_cb_ != nullptr) {
      ULOG_INFO << "lc:" << extern_id_ << "ark_op:" << op
               << ", ark trans status:" << target_status << " failed";
      switch (op) {
        case QEMU_LOGIN:
          ark_resp_cb_(-1, "ark sync status failed");
          break;
        case REBASE_LOGIN:
          ark_resp_cb_(-1, "ark rebase login failed");
          break;
        case REBASE_LOGOUT:
          ark_resp_cb_(-1, "ark rebase logout failed");
          break;
        default:
          ULOG_ERROR << "lc:" << extern_id_
                     << " no match ark stat sync failed callback";
      }
    }
  }

  ark_resp_cb_ = nullptr;
} /*}}}*/

void ArkHandle::Ark2NeedRebaseWrapper(ArkTransOp op) {/*{{{*/
  //异步强行执行NeedRebase
  StopArk();
  ark_status_->SetArkStatus(ucloud::udisk::UTM_STATUS_NEED_REBASE);
  ark_status_->Ark2NeedRebase(op);
} /*}}}*/

}  // namespace gate
}  // namespace udisk
