#include "frag_io_request.h"
#include <ustevent/base/logging.h>
#include <ustevent/libevent/connection_libevent.h>
#include "msgr.h"
#include "gate.h"
#include "manager_thread.h"
#include "udisk_types.h"
#include "gate_io_proto.h"
#include "udisk_handle.h"

namespace udisk {

namespace gate {

using namespace common;

FragIORequest::FragIORequest(UDiskHandle* handle)
    : udisk_handle(handle),
      timer_count(handle->io_timer_count()),
      retry_times(0),
      start_time(base::Timestamp::now()),
      chunk_conn_id(0) {  // io开始时间,用于延时统计
  memset(&gate_req_head, 0, GATE_REQ_HEAD_SIZE);
}

int FragIORequest::SendFragIO() {
  gate_req_head.pc_no = begin_sector / (udisk_handle->GetPCSize() / SECTOR_SIZE);
  gate_req_head.offset = begin_sector * SECTOR_SIZE % udisk_handle->GetPCSize();
  gate_req_head.length = secnum * SECTOR_SIZE;
  if (gate_req_head.cmd == common::GATE_CMD_READ) {
    gate_req_head.size = 0;
  } else {  // common::GATE_CMD_WRITE 需要带上数据长度
    gate_req_head.size = gate_req_head.length;
  }
  ConnectionUeventPtr chunk_conn = udisk_handle->GetChunkConnection(this);
  if (!chunk_conn) {
    ULOG_ERROR << "get chunk connection error";
    return -1;
  }
  // Connect成功, 可以发送数据
  DoSendFragIO(chunk_conn);
  return 0;
}

int FragIORequest::DoSendFragIO(const ConnectionUeventPtr& conn) {
  // 记录上次该IO发送的conn_id,当断开某个连接时
  // 方便重试该连接上的所有IO
  chunk_conn_id = conn->GetId();
  MessageHeader msg_head;
  msg_head.data_len = GATE_REQ_HEAD_SIZE + gate_req_head.size;
  msg_head.version = 0;
  msg_head.msg_type = MSG_GATE_IO_REQ;
  conn->SendData(&msg_head, sizeof(MessageHeader));
  ULOG_TRACE << "send frag request to chunkserver:"
             << DumpGateReqHead(gate_req_head);
  conn->SendData(&gate_req_head, GATE_REQ_HEAD_SIZE);
  if (gate_req_head.size != 0) {  // 写命令带有数据
    conn->SendData(data, gate_req_head.size);
  }
  return 0;
}

void FragIORequest::DecTimerCount() {
  --timer_count;
  if (timer_count == 0) {
    timer_count =
        udisk_handle->io_timer_count();  // 重置超时计数,否则会保持0,一直触发
    TimeoutCb();
  }
}

// 超时后重试
void FragIORequest::TimeoutCb() {
  ++ retry_times;
  ULOG_ERROR << "gate io request timeout or error, retry times: "
            << retry_times << DumpGateReqHead(gate_req_head);
  udisk_handle->IncIORetryCount();
  std::string chunk_ip;
  const ConnectionUeventPtr& chunk_conn = udisk_handle->GetChunkConnection(this);
  if (!chunk_conn) {
    ULOG_ERROR << "get chunk connection error";
    chunk_ip = "";
  } else {
    chunk_ip = chunk_conn->GetPeerAddress().ToString();
  }

  ManagerThread::Instance()->ReportIOTimeout(
      udisk_handle->extern_id(), retry_times, 
      udisk_handle->lc_set_name(), udisk_handle->zk_server(),
      chunk_ip, chunk_id);
  SendFragIO();
}

}  // namespace gate
}  // namespace udisk
