#include "manager_thread.h"

#include <ustevent/base/timestamp.h>
#include <ustevent/base/my_uuid.h>
#include <ustevent/message_util.h>
#include <ustevent/libevent/connector_libevent.h>
#include "zk_name_container.h"
#include "gate.h"
#include "udisk_handle.h"
#include "my_config_parser.h"
#include "gate_chunk_iostats.h"
#include "rebase_login.h"
#include "rebase_logout.h"
#include "ark_on.h"
#include "ark_off.h"
#include "set_ark_max_pending_inflight_size.h"
#include "gate_listener.h"
#include "reload_config_option.h"
#include "set_lc_qos.h"
#include "block_gate_abort.h"

namespace udisk {
namespace gate {

using namespace uevent;
using namespace base;
using namespace common;

ManagerThread* ManagerThread::instance_ = NULL;

//这个单例启动时只有主线程会调用，不会有线程间的竞争
ManagerThread* ManagerThread::Instance() {
  if (instance_ == NULL) {
    instance_ = new ManagerThread();
  }
  return instance_;
}

ManagerThread::ManagerThread()
    : work_thread_("manager_thread", nullptr), loop_(NULL), throttle_broaden_time_(0) {}

void ManagerThread::Start() {
  loop_ = work_thread_.StartWorker()->eventloop();
  loop_->RunInLoop(std::bind(&ManagerThread::StartInLoop, this));
}

void ManagerThread::StartInLoop() {
  loop_->AssertInLoopThread();
  REGISTE_PROTO_HANDLER(loop_, 
      ucloud::udisk::GATE_CHUNK_IOSTATS_REQUEST, GateChunkIOStatsHandle);
  REGISTE_PROTO_HANDLER(loop_, 
      ucloud::udisk::GET_LC_LAST_RW_TICK_REQUEST, GetLcRwTick);
  REGISTE_PROTO_HANDLER(loop_, 
      ucloud::udisk::REBASE_LOGIN_REQUEST, RebaseLoginHandle);
  REGISTE_PROTO_HANDLER(loop_, 
      ucloud::udisk::REBASE_LOGOUT_REQUEST, RebaseLogoutHandle);
  REGISTE_PROTO_HANDLER(loop_, 
      ucloud::udisk::ARK_ON_REQUEST, ArkOnHandle);
  REGISTE_PROTO_HANDLER(loop_, 
      ucloud::udisk::ARK_OFF_REQUEST, ArkOffHandle);
  REGISTE_PROTO_HANDLER(loop_, 
      ucloud::udisk::SET_ARK_MAX_PENDING_INFLIGHT_SIZE_REQUEST, SetArkMaxPendingInflightSizeHandle);
  REGISTE_PROTO_HANDLER(loop_,
      ucloud::udisk::GET_LC_QOS_STATUS_REQUEST, GetLcQosStatus);
  REGISTE_PROTO_HANDLER(loop_,
      ucloud::udisk::RELOAD_CONFIG_OPTION_REQUEST, ReloadConfigOption);
  REGISTE_PROTO_HANDLER(loop_,
      ucloud::udisk::SET_LC_QOS_REQUEST, SetLcQos);
  REGISTE_PROTO_HANDLER(loop_,
      ucloud::udisk::BLOCK_GATE_TERMINATE_REQUEST, BlockGateAbort);
  loop_->RunEvery(g_config_parser->report_odin_period(),
                  std::bind(&ManagerThread::ReportOdinTimer, this));
  // 60s检查一次ark相关的内存状态
  loop_->RunEvery(g_config_parser->ark_mem_check_period(),
                  std::bind(&ManagerThread::ArkWoodpeckerTimer, this));
  ListenerInit();
}

void ManagerThread::ListenerInit() {
  uevent::UsockAddress listen_addr(g_config_parser->listen_ip(),
                                   g_config_parser->listen_port(), false);
  listener_.reset(new uevent::ListenerLibevent((PosixWorker*)loop_->worker(),
                                               listen_addr, "GateManListener",
                                               uevent::Option()));
  listener_->SetConnectionSuccessCb(
      std::bind(&ManagerThread::ManConnSuccessCb, this, std::placeholders::_1));
  listener_->SetConnectionClosedCb(
      std::bind(&ManagerThread::ManConnClosedCb, this, std::placeholders::_1));
  listener_->SetMessageReadCb(std::bind(
      &uevent::MessageUtil::ProtobufReadCallBack, std::placeholders::_1));
  listener_->Start();
}

void ManagerThread::ManConnSuccessCb(const ConnectionUeventPtr& conn) {
  ULOG_INFO << "new connection from pb client, connection name: "
           << conn->GetName() << "connection id: " << conn->GetId()
           << ", peer address: " << conn->GetPeerAddress().ToString();
}

void ManagerThread::ManConnClosedCb(const ConnectionUeventPtr& conn) {
  ULOG_INFO << "disconnect from pb client, connection name: "
           << conn->GetName() << "connection id: "<< conn->GetId()
           << ", peer address: " << conn->GetPeerAddress().ToString();
  //由listener中统一的入口对accept的连接进行删除和析构
  listener_->RemoveConnection(conn);
}

// 采用短连接方式，直接获取connnetor, 使用完释放
ConnectorUeventPtr ManagerThread::CreateAccessConnector() {
  ucloud::uns::NameNodeContent nnc;
  if (g_name_containers[g_config_parser->zk_server()]
         ->GetNNCForName(common::ConfigParser::kGlobalSetName,
         common::ConfigParser::kAccessName, nnc) == -1) {
    ULOG_ERROR << "get nnc for access error";
    return ConnectorUeventPtr();
  }
  std::string access_ip = nnc.ip();
  uint32_t access_port = nnc.port();
  UsockAddress access_addr(access_ip, access_port);
  // 这里会析构之前的connector
  ConnectorUeventPtr access_ctor(
      new ConnectorLibevent((PosixWorker*)loop_->worker(), 
                               access_addr, "AccessConnector"));
  access_ctor->SetConnectionSuccessCb(std::bind(
      &ManagerThread::ConnectorConnSuccessCb,
      this, std::placeholders::_1));
  access_ctor->SetConnectionClosedCb(std::bind(
      &ManagerThread::ConnectorConnClosedCb,
      this, std::placeholders::_1));
  access_ctor->SetMessageReadCb(std::bind(
      MessageUtil::ProtobufReadCallBack, std::placeholders::_1));
  access_ctor->Connect();
  return access_ctor;
}

void ManagerThread::ConnectorConnSuccessCb(const ConnectionUeventPtr& conn) {
  ULOG_INFO << "connect to server success, peer address: "
           << conn->GetPeerAddress().ToString(); 
}

void ManagerThread::ConnectorConnClosedCb(const ConnectionUeventPtr& conn) {
  ULOG_INFO << "disconnect from server, peer address: "
           << conn->GetPeerAddress().ToString(); 
}

ConnectionUeventPtr ManagerThread::GetMetaServerConnection(
        const std::string& set_name, const std::string& zk_server) {
  ucloud::uns::NameNodeContent nnc;
  auto it = g_name_containers.find(zk_server);
  if (it == g_name_containers.end()) {
    ULOG_ERROR << "zk server not exist";
    return ConnectionUeventPtr();
  }
  if (it->second->GetNNCForName(set_name,
      common::ConfigParser::kMetaServerName, nnc, true) == -1) {
    ULOG_ERROR << "get nnc for metaserver error";
    return ConnectionUeventPtr();
  }
  ucloud::udisk::MetaserverPortPair extend_info;
  it->second->ParseMetaServerExtendInfo(nnc, &extend_info);
  std::string metaserver_ip = nnc.ip();
  uint32_t metaserver_port = extend_info.gate_port();
  return GetConnection(metaserver_ip, metaserver_port);
}

ConnectionUeventPtr ManagerThread::GetOdinConnection(
         const std::string& set_name, const std::string& zk_server) {
  std::string odin_name;
  // 判断是机房全局的odin还是获取指定set的odin, 当没有获取到lc所属set
  // 的odin时，使用全局的odin上报故障
  if (set_name == common::ConfigParser::kGlobalSetName) {
    odin_name = MyConfigParser::kGlobalOdinName;
  } else {
    odin_name = common::ConfigParser::kOdinName;
  }
  ucloud::uns::NameNodeContent nnc;
  auto it = g_name_containers.find(zk_server);
  if (it == g_name_containers.end()) {
    ULOG_ERROR << "zk server not exist";
    return ConnectionUeventPtr();
  }
  // 获取odin 的leader 节点
  if (it->second->GetNNCForName(
      set_name, odin_name, nnc, true) == -1) {
    ULOG_ERROR << "get nnc for odin error";
    return ConnectionUeventPtr();
  }
  ucloud::udisk::OdinPortPair extend_info;
  if (!extend_info.ParseFromString(nnc.reserved())) {
    ULOG_ERROR << "parse odin pair fail.";
    return ConnectionUeventPtr();
  }
  std::string odin_ip = nnc.ip();
  uint32_t odin_port = extend_info.gate_port();
  return GetConnection(odin_ip, odin_port);
}

void ManagerThread::LoginAccess(UDiskHandle* handle) {
  HandleEntry entry(handle->handle_id(), handle);
  loop_->RunInLoop(std::bind(
      &ManagerThread::LoginAccessInLoop, this, entry));
}

void ManagerThread::LoginAccessInLoop(HandleEntry entry) {
  UDiskHandle* handle = entry.second;
  ucloud::UMessage um;
  NewMessage_v2(&um, MessageUtil::Flowno(), base::MyUuid::NewUuid(),
                ucloud::udisk::UDISK_LOGIN_REQUEST, 0, false,
                MessageUtil::ObjId(), 0, "UDiskLogin", NULL, NULL);
  ucloud::udisk::UDiskLoginRequest* req_body =
      um.mutable_body()->MutableExtension(ucloud::udisk::udisk_login_request);
  req_body->set_extern_id(handle->extern_id());
  req_body->set_ip(g_config_parser->listen_ip());
  req_body->set_port(g_config_parser->listen_port());
  ConnectorUeventPtr access_ctor = CreateAccessConnector();
  if (!access_ctor || access_ctor->HasAvailableConnection() == false) {
     ULOG_ERROR << "connect to access error";
     LoginAccessFinish(-1, entry);
     return;
  }
  ConnectionUeventPtr access_conn = access_ctor->GetConnection();
  ULOG_INFO << um.DebugString();
  MessageUtil::SendPbRequest(access_conn, um, 
      std::bind(&ManagerThread::LoginResponseCb,
          this, std::placeholders::_1, entry, access_ctor),
      std::bind(&ManagerThread::LoginTimeoutCb, this, entry, access_ctor),
      2.0);
}

void ManagerThread::LoginResponseCb(const UMessagePtr& um, HandleEntry entry,
                                    const ConnectorUeventPtr& ctor) {
  ULOG_INFO << um->DebugString();
  assert(um->head().message_type() == ucloud::udisk::UDISK_LOGIN_RESPONSE);
  assert(um->has_body());
  assert(um->body().HasExtension(ucloud::udisk::udisk_login_response));
  login_rsp_  =
      um->body().GetExtension(ucloud::udisk::udisk_login_response);
  if (login_rsp_.rc().retcode() != 0) {
    ULOG_ERROR << "udisk login response error," 
              << login_rsp_.rc().error_message();
    LoginAccessFinish(login_rsp_.rc().retcode(), entry);
  } else {
    std::string zk_server, global_zk_server;
    if (login_rsp_.has_zk_server()) {
      zk_server = login_rsp_.zk_server();
    }
    else {
      zk_server = g_config_parser->zk_server();
    }
    if (login_rsp_.has_global_zk_server()) {
      global_zk_server = login_rsp_.global_zk_server();
    }
    else {
      global_zk_server = g_config_parser->global_zk_server();
    }
    auto it1 = g_name_containers.find(zk_server);
    if (it1 == g_name_containers.end()) {
      std::shared_ptr<common::NameContainer> name_container;
      name_container.reset(new NameContainer(zk_server));
      if (name_container->Init() == -1) {
        ULOG_ERROR << "can't connect to zookeeper "
                  << zk_server;
        LoginAccessFinish(-1, entry);
        return;
      }
      g_name_containers.insert(std::make_pair(zk_server, name_container));
    }
    auto it2 = g_name_containers.find(global_zk_server);
    if (it2 == g_name_containers.end()) {
      std::shared_ptr<common::NameContainer> name_container;
      name_container.reset(new NameContainer(global_zk_server));
      if (name_container->Init() == -1) {
        ULOG_ERROR << "can't connect to zookeeper "
                  << global_zk_server;
        LoginAccessFinish(-1, entry);
        return;
      }
      g_name_containers.insert(std::make_pair(global_zk_server, name_container));
    }
    std::string set_name = login_rsp_.set_name();
    ZkNameOfSetPtr zk_name_set_ptr(new ZkNameOfSet(set_name));
    ZkNameOfSetPtr global_zk_name_set_ptr(new ZkNameOfSet(set_name));
    for (int i = 0; i < login_rsp_.zk_info_size(); i++) {
      if (login_rsp_.zk_info(i).name() == common::ConfigParser::kArkAccessName) {
        global_zk_name_set_ptr->AddNamePath(login_rsp_.zk_info(i).name(),
               login_rsp_.zk_info(i).path());
      }
      else {
        zk_name_set_ptr->AddNamePath(login_rsp_.zk_info(i).name(),
            login_rsp_.zk_info(i).path());
      }
    } 
    //会触发拉取节点信息
    g_name_containers[zk_server]->AddZkNameOfSet(zk_name_set_ptr); 
    g_name_containers[global_zk_server]->AddZkNameOfSet(global_zk_name_set_ptr); 

    LoginAccessFinish(0, entry);
  }
  // 退出后access ctor会析构
}

void ManagerThread::LoginTimeoutCb(HandleEntry entry,
                                   const ConnectorUeventPtr& ctor) {
  ULOG_ERROR << "udisk login access timeout";
  LoginAccessFinish(-1, entry);
  // 退出后access ctor会析构
}

void ManagerThread::LoginAccessFinish(int32_t ret_code, HandleEntry entry) {
   UDiskHandle* udisk_handle = entry.second;
   int64_t handle_id = entry.first;
  if (ret_code == 0) {
    ULOG_INFO << "login access success, will second login success to qemu";
  } else {
    ULOG_ERROR << "login access error";
  }
  udisk_handle->SendLoginResponse(ret_code, handle_id, login_rsp_);
}

void ManagerThread::GetMetaData(UDiskHandle* handle) {
  HandleEntry entry(handle->handle_id(), handle);
  loop_->RunInLoop(std::bind(
      &ManagerThread::GetMetaDataInLoop, this, entry));
}

void ManagerThread::GetMetaDataInLoop(HandleEntry entry) {
  ucloud::UMessage um; 
  NewMessage_v2(&um, MessageUtil::Flowno(), base::MyUuid::NewUuid(),
                ucloud::udisk::GET_META_DATA_REQUEST, 0, false,
                MessageUtil::ObjId(), 0, "GetMetaData", NULL, NULL);

  UDiskHandle* handle = entry.second;
  ucloud::udisk::GetMetaDataRequest* req =
      um.mutable_body()->MutableExtension(ucloud::udisk::get_meta_data_request);
  req->set_cluster_version(0);
  ConnectionUeventPtr metaserver_conn =
      GetMetaServerConnection(handle->lc_set_name(), handle->zk_server());
  if (!metaserver_conn) {
    ULOG_ERROR << "no available metaserver connection";
    return;
  }
  ULOG_INFO << um.DebugString();
  MessageUtil::SendPbRequest(
      metaserver_conn, um, std::bind(&ManagerThread::GetMetaDataResponseCb,
                                     this, std::placeholders::_1, entry),
      std::bind(&ManagerThread::GetMetaDataTimeoutCb, this, entry), 2.0);
}

// 在 manager thread 中执行
void ManagerThread::GetMetaDataResponseCb(const UMessagePtr& um,
                                          HandleEntry entry) {
  ULOG_INFO << um->DebugString();
  int64_t handle_id = entry.first;
  UDiskHandle* handle = entry.second;
  assert(um->head().message_type() == ucloud::udisk::GET_META_DATA_RESPONSE);
  assert(um->has_body());
  assert(um->body().HasExtension(ucloud::udisk::get_meta_data_response));
  ucloud::udisk::GetMetaDataResponse rsp =
      um->body().GetExtension(ucloud::udisk::get_meta_data_response);
  if (rsp.rc().retcode() != 0) {
    ULOG_ERROR << "get_meta_data_response error," << rsp.rc().error_message();
  } else {
    // 在io loop 中执行
    handle->UpdateRouteManager(rsp.cluster_info(), rsp.chunk_info(),
                               rsp.pg_info(), handle_id);
  }
}

void ManagerThread::GetMetaDataTimeoutCb(HandleEntry entry) {
  ULOG_ERROR << "get meta data for metaserver timeout, udisk_handle: "
             << entry.second << " handle_id: " << entry.first;
}

void ManagerThread::Heartbeat(UDiskHandle* handle) {
  // 这里还运行在gate io线程中，可以直接使用handle中数据
  ucloud::udisk::LCIOStats iostat;
  SegmentIOInfo segment_iostat;
  struct timeval now;
  gettimeofday(&now, NULL);
  handle->GetIOStatistics(iostat, g_config_parser->heartbeat_period(), now.tv_sec);
  handle->GetSegmentIOStatistics(segment_iostat, g_config_parser->heartbeat_period(), now.tv_sec);
  handle->ClearIOStats(); // 重置统计数据
  handle->SwapChunkIOStats();
  HandleEntry entry(handle->handle_id(), handle);
  loop_->RunInLoop(
      std::bind(&ManagerThread::HeartbeatInLoop, this, 
                          entry, iostat, segment_iostat));
}

void ManagerThread::HeartbeatInLoop(HandleEntry& entry, 
                        ucloud::udisk::LCIOStats& iostat,
                        SegmentIOInfo& segment_iostat) {
  StatsInfoHandle(entry, iostat, segment_iostat);
  // 处理心跳信息
  ucloud::UMessage um;
  NewMessage_v2(&um, MessageUtil::Flowno(), base::MyUuid::NewUuid(),
                ucloud::udisk::HEARTBEAT_GATE_METASERVER_REQUEST, 0, false,
                MessageUtil::ObjId(), 0, "GateHeartbeat", NULL, NULL);
  ucloud::udisk::HeartbeatGateMetaServerRequest* req =
      um.mutable_body()->MutableExtension(
          ucloud::udisk::heartbeat_gate_metaserver_request);
  uint64_t cluster_version = 0;
  if (entry.second->route_manager_ptr()) {
    cluster_version = entry.second->route_manager_ptr()->GetClusterVersion();
  } else {
    ULOG_WARN << "route manager has not been initialized";
  }
  req->set_cluster_version(cluster_version);
  req->set_extern_id(entry.second->extern_id());
  req->set_thread_name(std::to_string(entry.second->GetLoop()->thread_id()));
  ConnectionUeventPtr metaserver_conn =
      GetMetaServerConnection(entry.second->lc_set_name(), 
                              entry.second->zk_server());
  if (!metaserver_conn) {
    ULOG_ERROR << "no available metaserver connection";
    return;
  }
  ULOG_DEBUG << um.DebugString();
  MessageUtil::SendPbRequest(
      metaserver_conn, um, std::bind(&ManagerThread::HeartbeatResponseCb, this,
                                     std::placeholders::_1, entry),
      std::bind(&ManagerThread::HeartbeatTimeoutCb, this, entry), 2.0);
}

// 处理随心跳上报的统计信息，主要是缓存到管理线程
void ManagerThread::StatsInfoHandle(HandleEntry& entry,
                      ucloud::udisk::LCIOStats& iostat,
                      SegmentIOInfo& segment_iostat) {
  vector<ucloud::udisk::LCIOStats>& udisk_stat = udisk_stats_[entry];
  vector<SegmentIOInfo>& udisk_segment_stat = udisk_segment_stats_[entry];
  udisk_stat.push_back(iostat);
  udisk_segment_stat.push_back(segment_iostat);
}

int ManagerThread::GetChunkIOStatistics(const std::string& extern_id,
                   const std::shared_ptr<GateChunkIOStatsHandle>& ptr) {
  std::vector<uevent::EventLoop*> all_loops 
                            = g_listener->GetAllLoops();
  for (size_t i = 0; i < all_loops.size(); i++) {
    UDiskHandle* handle = (UDiskHandle*)all_loops[i]->GetLoopHandle();
    if (handle->extern_id() == extern_id) {
      all_loops[i]->RunInLoop(std::bind(&UDiskHandle::GetChunkIOStatistics, 
                            handle, ptr, g_config_parser->heartbeat_period()));
      return 0;
    }
  }
  return -1;
}

void ManagerThread::GetChunkIOStatisticsResponse(
            std::vector<ucloud::udisk::GateChunkIOStats> stats,
            std::unordered_map<uint32_t, ucloud::udisk::GatePCIOStats> pc_stats,
            std::shared_ptr<GateChunkIOStatsHandle> ptr) {
  ptr->GetChunkIOStatisticsResponse(stats, pc_stats); 
}

// 在 manager thread 中执行
void ManagerThread::HeartbeatResponseCb(const UMessagePtr& um,
                                        HandleEntry entry) {
  int64_t handle_id = entry.first;
  UDiskHandle* handle = entry.second;
  assert(um->head().message_type() ==
         ucloud::udisk::HEARTBEAT_GATE_METASERVER_RESPONSE);
  assert(um->has_body());
  assert(um->body().HasExtension(
      ucloud::udisk::heartbeat_gate_metaserver_response));
  ucloud::udisk::HeartbeatGateMetaServerResponse rsp = um->body().GetExtension(
      ucloud::udisk::heartbeat_gate_metaserver_response);
  if (rsp.rc().retcode() != 0) {
    ULOG_ERROR << "gate heartbeat_response error," << rsp.rc().error_message();
  } else {
    handle->set_last_heartbeat_tick(base::Timestamp::now());
    if (rsp.has_cluster_info()) {
      // 在io loop 中执行
      handle->UpdateRouteManager(rsp.cluster_info(), rsp.chunk_info(),
                                 rsp.pg_info(), handle_id);
    }
  }
}

void ManagerThread::HeartbeatTimeoutCb(HandleEntry entry) {
  ULOG_ERROR << "heartbeat responsetimeout, udisk_handle: " << entry.second
             << " handle_id: " << entry.first;
}

void ManagerThread::ReportOverload(const std::string& info, bool recover) {
  ucloud::udisk::OdinWarningRequest warn_request;
  std::string uuid = g_config_parser->listen_ip() + ":" +
                     std::to_string(g_config_parser->listen_port());
  warn_request.set_uuid(uuid);
  if (recover) {
    warn_request.set_item_id(ConfigParser::kGateOverloadRecoverItemId);
  } else {
    warn_request.set_item_id(ConfigParser::kGateOverloadItemId);
  }
  warn_request.set_value(1);
  warn_request.set_info(info);
  warn_request.set_time(base::Timestamp::now().secondsSinceEpoch());
  WarningToOdin(warn_request, ConfigParser::kGlobalSetName, g_config_parser->zk_server());
  return;
}

int ManagerThread::GetQosPercentByType(QosOpType type, const HandleEntry& entry) {
  if (type == kQosReadBw) {
    return qos_info_[entry].limit_read_bw_percent;
  } else if (type == kQosWriteBw) {
    return qos_info_[entry].limit_write_bw_percent;
  } else if (type == kQosTotal) {
    return qos_info_[entry].limit_bw_percent;
  }

  return 0;
}

string ManagerThread::GetLimitBWTypeString(QosOpType type) {
  if (type == kQosReadBw) {
    return "read bw";
  } else if (type == kQosWriteBw) {
    return "write bw";
  } else if (type == kQosTotal) {
    return "total bw";
  }
 
  return "";
}

void ManagerThread::SetLimitBWPercent(QosOpType type, UDiskHandle* handle,
                                     int limit_bw_percent) {
  if (type == kQosReadBw) {
    handle->SetLimitReadBWPercent(limit_bw_percent);
  } else if (type == kQosWriteBw) {
    handle->SetLimitWriteBWPercent(limit_bw_percent);
  } else if (type == kQosTotal) {
    handle->SetLimitBWPercent(limit_bw_percent);
  }
}

void ManagerThread::QosThrottle() {
  double total_bw[kQosTypeNum] = {0};
  // rate -> Handle
  std::multimap<double, HandleEntry> lcs_rate[kQosTypeNum];
  // 计算各lc的带宽使用比例
  for (auto it = udisk_stats_.begin(); it != udisk_stats_.end(); ++it) {
    uint32_t item_count = it->second.size();
    if (UNLIKELY(item_count == 0)) {
      ULOG_ERROR << "impossible!!!";
      continue;
    }

    auto info = qos_info_.find(it->first);
    if (UNLIKELY(info == qos_info_.end())) {
      ULOG_ERROR << "udisk may logout!!!";
      continue;
    }
  
    double bw[kQosTypeNum] = {0};
    for (auto item : it->second) {
      if (item.byteps_write() > 0 || item.byteps_ark() > 0) {
        bw[kQosWriteBw] += item.byteps_write() + item.byteps_ark();
      }

      if (item.byteps_read() > 0) {
        bw[kQosReadBw] += item.byteps_read();
      }
    }
      
    bw[kQosTotal] = bw[kQosWriteBw] + bw[kQosReadBw];  
    for (int type = 0; type < kQosTypeNum; ++type) {
      bw[type] = bw[type] / item_count;
      total_bw[type] += bw[type];
      double rate_bw = bw[type] / info->second.max_bw; 
      ULOG_TRACE << "type:" << type
                 << "; lc_id:" << it->first.second->extern_id()
                 << "; rate:" << rate_bw;
      lcs_rate[type].insert(std::pair<double, HandleEntry>(rate_bw, it->first));
    }
  }

  for (int type = 0; type < kQosTypeNum; ++type) {
    QosThrottleHandle(QosOpType(type), total_bw[type], lcs_rate[type]); 
  }
}

void ManagerThread::QosThrottleHandle(QosOpType type, double total_bw,
    std::multimap<double, HandleEntry> lcs_rate) {
  // 带宽超过网卡带宽，则按对应比例限制各个盘，以致使各盘带宽总和降到网卡带宽之下
  uint64_t network_bandwidth = g_config_parser->network_bandwidth();
  if (type == kQosTotal) {
    network_bandwidth = network_bandwidth * 2;
  }

  ULOG_TRACE << "Qos throttle type:" << type
            << "total_bw:" << total_bw
            << "network_bandwidth:" << network_bandwidth;
  if (total_bw > network_bandwidth) {
    ULOG_INFO << "Qos throttle type:" << type << "; total bw:" << total_bw
             << " > network bandwitdth:" << network_bandwidth;

    bool is_limit = false;
    std::ostringstream ss;
    ss << GetLimitBWTypeString(type) << " over network bandwidth, will limit.";
    for (auto it = lcs_rate.rbegin(); it != lcs_rate.rend(); ++it) {
      UDiskHandle* handle = it->second.second;
      uint32_t limit_bw_percent = 
        100.0 * it->first * network_bandwidth / total_bw;

      if (limit_bw_percent <= g_config_parser->throttle_min_percent()) {
        ULOG_INFO << "Qos throttle has limited to minimum, will ignore limit"
                 << " lc:" << handle->extern_id()
                 << "; percent:" << limit_bw_percent
                 << "; type:" << type;
        continue;
      }

      if (limit_bw_percent > 100) {
        limit_bw_percent = 100;
      }

      if ((int32_t)limit_bw_percent == GetQosPercentByType(type, it->second)) {
        ULOG_INFO << "Qos throttle percent is equal to prior, will ignore limit"
                 << " lc:" << handle->extern_id()
                 << "; percent:"<< limit_bw_percent
                 << "; type:" << type;
        continue;
      }

      ULOG_INFO << "Qos throttle will limit bw for lc:" << handle->extern_id()
               << "; percent:" << limit_bw_percent
               << "; type:" << type;
      ss << "(" << handle->extern_id() << "," << limit_bw_percent << ")";
      SetLimitBWPercent(type, handle, limit_bw_percent);
      is_limit = true; 
    }

    if (is_limit) {
      ReportOverload(ss.str(), false);
      throttle_broaden_time_ = Timestamp::now().secondsSinceEpoch();
    }
  } else if (total_bw * 100 > network_bandwidth *
                              g_config_parser->throttle_high_water_line()) {
    // 带宽超过上水位线，则取使用率最高的N个进行限制
    uint32_t num = 0;
    std::ostringstream ss;
    ss << GetLimitBWTypeString(type)
       << " over the high water line of network bandwidth , will limit.";
    for (auto it = lcs_rate.rbegin(); it != lcs_rate.rend(); ++it) {
      UDiskHandle* handle = it->second.second;
      uint32_t limit_bw_percent = GetQosPercentByType(type, it->second);
      if (limit_bw_percent <= g_config_parser->throttle_min_percent()) {
        ULOG_INFO << "Qos throttle has limited to minimum, will ignore limit"
                 << " lc:" << handle->extern_id()
                 << "; percent:" << limit_bw_percent
                 << "; type:" << type;
        continue;
      }

      limit_bw_percent =
          limit_bw_percent - g_config_parser->throttle_step_percent();
      if (limit_bw_percent < g_config_parser->throttle_min_percent()) {
        limit_bw_percent = g_config_parser->throttle_min_percent();
      }

      ULOG_INFO << "Qos throttle will limit bw for lc:" << handle->extern_id()
               << "; all lc total_bw:" << total_bw
               << "; limit to percent:" << limit_bw_percent
               << "; type:" << type;
      ss << "(" << handle->extern_id() << "," << limit_bw_percent << ")";

      SetLimitBWPercent(type, handle, limit_bw_percent);
      num++;
      if (num == g_config_parser->throttle_udisk_num()) {
        break;
      }
    }

    if (num != 0) {
      ReportOverload(ss.str(), false);
      throttle_broaden_time_ = Timestamp::now().secondsSinceEpoch();
    }
  } else if (total_bw * 100 < network_bandwidth *
                              g_config_parser->throttle_low_water_line()) {
    // 未达到指定最小放宽时间
    if (Timestamp::now().secondsSinceEpoch() - throttle_broaden_time_ <
        g_config_parser->throttle_broaden_time()) {
      ULOG_TRACE << "The time is less throttle broaden time, diff:"
                << Timestamp::now().secondsSinceEpoch() - throttle_broaden_time_
                << "; throttle_broaden_time:"
                << g_config_parser->throttle_broaden_time()
                << "; type:" << type;
      return;
    }

    // 带宽低于低水位线，则取使用率最低的N个进行放宽
    uint64_t num = 0;
    std::ostringstream ss;
    ss << GetLimitBWTypeString(type)
       << " below the low water line of network bandwidth , will broaden.";
    for (auto it = lcs_rate.begin(); it != lcs_rate.end(); ++it) {
      UDiskHandle* handle = it->second.second;
      uint32_t limit_bw_percent = GetQosPercentByType(type, it->second);
      if (limit_bw_percent >= 100) {
        ULOG_DEBUG << "Qos throttle has remove limited to maximum, will ignore broaden"
                  << " lc:" << handle->extern_id()
                  << "; percent:" << limit_bw_percent
                  << ", type:" << type;
        continue;
      }

      limit_bw_percent =
          limit_bw_percent + g_config_parser->throttle_step_percent();
      if (limit_bw_percent > 100) {
        limit_bw_percent = 100;
      }

      ULOG_INFO << "Qos throttle will remove limited bw for lc:" << handle->extern_id()
               << "; all lc total_bw:" << total_bw
               << "; increase to percent:" << limit_bw_percent
               << "; type:" << type;
      ss << "(" << handle->extern_id() << "," << limit_bw_percent << ")";

      SetLimitBWPercent(type, handle, limit_bw_percent);
      num++;
      if (num == g_config_parser->throttle_udisk_num()) {
        break;
      }
    }

    if (num != 0) {
      ReportOverload(ss.str(), true);
    }
  }
}

// TODO(yeheng) 这里直接使用了handle指针，可能Handle中的内容已经变化
// 比如extern_id lc_set_name, 造成统计信息错误
void ManagerThread::ReportOdinTimer() {
  ULOG_DEBUG << "ReportOdinTimer start, udisk_size=" << udisk_stats_.size();
  // 上报io重试信息
  ReportOdinIOTimeout();

  if (g_config_parser->is_qos()) {
    QosThrottle();
  }

  // 上报udisk IO统计信息
  ReportIOStat();

  // 上报IO分段统计信息
  ReportSegmentIOStat();
}

void ManagerThread::ReportIOStat() {
  for (auto it = udisk_stats_.begin(); it != udisk_stats_.end(); ) {
    ucloud::UMessage um; 
    NewMessage_v2(&um, MessageUtil::Flowno(), base::MyUuid::NewUuid(),
                  ucloud::udisk::REPORT_GATE_ODIN_REQUEST, 0, false,
                  MessageUtil::ObjId(), 0, "ReportIOStat", NULL, NULL);
    ucloud::udisk::ReportGateOdinRequest* req =
        um.mutable_body()->MutableExtension(
            ucloud::udisk::report_gate_odin_request);
    HandleEntry entry = it->first;
    ucloud::udisk::LCIOStats* iostat = req->add_io_stats(); //会初始化为0
    for (auto& item : it->second) { // 对某个lc的多个点求和
      iostat->set_iops_read(iostat->iops_read() + item.iops_read());
      iostat->set_iops_write(iostat->iops_write() + item.iops_write());
      iostat->set_byteps_read(iostat->byteps_read() + item.byteps_read());
      iostat->set_byteps_write(iostat->byteps_write() + item.byteps_write());
      iostat->set_read_latency(iostat->read_latency() + item.read_latency());
      iostat->set_write_latency(iostat->write_latency() + item.write_latency());
      iostat->set_io_retry(iostat->io_retry() + item.io_retry());
    }
    uint32_t item_count = it->second.size();
    if (item_count == 0) {
      ULOG_ERROR << "impossible!!!" << entry.second->extern_id();
      it = udisk_stats_.erase(it);
      continue;
    }
    if (iostat->iops_read() != 0) {
      iostat->set_read_latency(ceil(iostat->read_latency() * 1.0 / iostat->iops_read()));
    } else {
      iostat->set_read_latency(0);
    }
    if (iostat->iops_write() != 0) {
      iostat->set_write_latency(ceil(iostat->write_latency() * 1.0 / iostat->iops_write()));
    } else {
      iostat->set_write_latency(0);
    }
    iostat->set_iops_read(ceil(iostat->iops_read() * 1.0 / g_config_parser->report_odin_period()));
    iostat->set_iops_write(ceil(iostat->iops_write() * 1.0 / g_config_parser->report_odin_period()));
    iostat->set_byteps_read(ceil(iostat->byteps_read() * 1.0 / item_count));
    iostat->set_byteps_write(ceil(iostat->byteps_write() * 1.0 / item_count));
    iostat->set_extern_id(entry.second->extern_id());
    iostat->set_stats_time(base::Timestamp::now().secondsSinceEpoch());
    iostat->set_stats_period(g_config_parser->report_odin_period());
    it = udisk_stats_.erase(it);  // 统计完毕以后删除统计信息
    // 获取set name, 可能是错的 FIXME(yeheng)
    ConnectionUeventPtr odin_conn = GetOdinConnection(entry.second->lc_set_name(), 
                                                   entry.second->zk_server());
    if (!odin_conn) {
      ULOG_ERROR << "no available odin connection";
      return;
    }
    ULOG_DEBUG << um.DebugString();
    MessageUtil::SendPbRequest(
        odin_conn, um, std::bind(&ManagerThread::ReportIOStatResponseCb, this,
                                 std::placeholders::_1),
        std::bind(&ManagerThread::ReportIOStatTimeout, this), 2.0);
  }
}

void ManagerThread::ReportIOStatResponseCb(const UMessagePtr& um) {
  const ucloud::udisk::ReportGateOdinResponse& res =
      um->body().GetExtension(ucloud::udisk::report_gate_odin_response);
  if (res.rc().retcode() != 0) {
    ULOG_ERROR << "ReportIOStatResponse ERROR, code=" << res.rc().retcode()
               << ", msg=" << res.rc().error_message();
    return;
  }
}

void ManagerThread::ReportIOStatTimeout() {
  ULOG_ERROR << "ReportIOStatTimeout. ";
}

inline void ManagerThread::AssignSegmentIOInfo(const ucloud::udisk::LCStats& src_lcstat,
                                               ucloud::udisk::LCStats* dst_lcstat,
                                               uint32_t item_count) {
  if (src_lcstat.iops_read() != 0) {
    dst_lcstat->set_read_latency(ceil(src_lcstat.read_latency() * 1.0 / src_lcstat.iops_read()));
  } else {
    dst_lcstat->set_read_latency(0);
  }
  if (src_lcstat.iops_write() != 0) {
    dst_lcstat->set_write_latency(ceil(src_lcstat.write_latency() * 1.0 / src_lcstat.iops_write()));
  } else {
    dst_lcstat->set_write_latency(0);
  }
  dst_lcstat->set_iops_read(ceil(src_lcstat.iops_read() * 1.0 / g_config_parser->report_odin_period()));
  dst_lcstat->set_iops_write(ceil(src_lcstat.iops_write() * 1.0 / g_config_parser->report_odin_period()));
  dst_lcstat->set_byteps_read(src_lcstat.byteps_read());
  dst_lcstat->set_byteps_write(src_lcstat.byteps_write());
}

inline void ManagerThread::SumSegmentIOInfo(const ucloud::udisk::LCStats& src_lcstat, 
                                            ucloud::udisk::LCStats* dst_lcstat) {
  dst_lcstat->set_iops_read(dst_lcstat->iops_read() + src_lcstat.iops_read());
  dst_lcstat->set_iops_write(dst_lcstat->iops_write() + src_lcstat.iops_write());
  dst_lcstat->set_byteps_read(dst_lcstat->byteps_read() + src_lcstat.byteps_read());
  dst_lcstat->set_byteps_write(dst_lcstat->byteps_write() + src_lcstat.byteps_write());
  dst_lcstat->set_read_latency(dst_lcstat->read_latency() + src_lcstat.read_latency());
  dst_lcstat->set_write_latency(dst_lcstat->write_latency() + src_lcstat.write_latency());
}

inline void ManagerThread::CeilSegmentIOInfo(ucloud::udisk::LCStats* lcstat, uint32_t item_count) {
  if (item_count == 0) {
    return;
  }
  if (lcstat->iops_read() != 0) {
    lcstat->set_read_latency(ceil(lcstat->read_latency() * 1.0 / lcstat->iops_read()));
  } else {
    lcstat->set_read_latency(0);
  }
  if (lcstat->iops_write() != 0) {
    lcstat->set_write_latency(ceil(lcstat->write_latency() *1.0 / lcstat->iops_write()));
  } else {
    lcstat->set_write_latency(0);
  }
  lcstat->set_iops_read(ceil(lcstat->iops_read() * 1.0 / g_config_parser->report_odin_period()));
  lcstat->set_iops_write(ceil(lcstat->iops_write() * 1.0 / g_config_parser->report_odin_period()));
  lcstat->set_byteps_read(lcstat->byteps_read());
  lcstat->set_byteps_write(lcstat->byteps_write());
}

void ManagerThread::ReportSegmentIOStat() {
  for (auto it = udisk_segment_stats_.begin(); it != udisk_segment_stats_.end(); ) {
    ucloud::UMessage um; 
    NewMessage_v2(&um, MessageUtil::Flowno(), base::MyUuid::NewUuid(),
        ucloud::udisk::REPORT_SEGMENT_IOSTAT_REQUEST, 0, false, 
        MessageUtil::ObjId(), 0, "ReportSegmentIOStat", NULL, NULL);
    ucloud::udisk::ReportSegmentIOStatRequest* req = 
        um.mutable_body()->MutableExtension(
        ucloud::udisk::report_segment_iostat_request);
    HandleEntry entry = it->first;

    SegmentIOInfo tmp_stat; // 临时累计用
    tmp_stat.clear();
    for (auto& lcstat : it->second) { // 对某个lc的多个点求和 按IO大小区分统计
      tmp_stat.resize(lcstat.size());
      for (uint32_t i = 0; i < lcstat.size(); i++) {
         tmp_stat[i].set_iops_read(tmp_stat[i].iops_read() + lcstat[i].iops_read());
         tmp_stat[i].set_iops_write(tmp_stat[i].iops_write() + lcstat[i].iops_write());
         tmp_stat[i].set_byteps_read(tmp_stat[i].byteps_read() + lcstat[i].byteps_read());
         tmp_stat[i].set_byteps_write(tmp_stat[i].byteps_write() + lcstat[i].byteps_write());
         tmp_stat[i].set_read_latency(tmp_stat[i].read_latency() + lcstat[i].read_latency());
         tmp_stat[i].set_write_latency(tmp_stat[i].write_latency() + lcstat[i].write_latency());
       }
    }
    uint32_t item_count = it->second.size();
    if (item_count == 0) {
      ULOG_ERROR << "impossible!!!" << entry.second->extern_id();
      it = udisk_segment_stats_.erase(it);
      continue;
    }
    uint32_t iotype_cnt = tmp_stat.size();
    for (uint32_t i = 0; i < iotype_cnt; i++) {
      tmp_stat[i].set_iops_read(tmp_stat[i].iops_read());
      tmp_stat[i].set_iops_write(tmp_stat[i].iops_write());
      tmp_stat[i].set_byteps_read(ceil(tmp_stat[i].byteps_read() * 1.0 / item_count));
      tmp_stat[i].set_byteps_write(ceil(tmp_stat[i].byteps_write() * 1.0 / item_count));
      tmp_stat[i].set_read_latency(tmp_stat[i].read_latency());
      tmp_stat[i].set_write_latency(tmp_stat[i].write_latency());
      tmp_stat[i].set_extern_id(entry.second->extern_id());
      tmp_stat[i].set_stats_time(base::Timestamp::now().secondsSinceEpoch());
      tmp_stat[i].set_stats_period(g_config_parser->report_odin_period());
    }
    //分段累计
    SegmentIOInfo result_stat; // 临时累计用
    result_stat.clear();
    result_stat.resize(ucloud::udisk::kIOSizeNum);

    if (iotype_cnt > kIOSize8KRange) {
      AssignSegmentIOInfo(tmp_stat[ucloud::udisk::kIOSizeLT4K], &result_stat[ucloud::udisk::kIOSizeLT4K], item_count);
      AssignSegmentIOInfo(tmp_stat[ucloud::udisk::kIOSize4K], &result_stat[ucloud::udisk::kIOSize4K], item_count);
      AssignSegmentIOInfo(tmp_stat[ucloud::udisk::kIOSize8K], &result_stat[ucloud::udisk::kIOSize8K], item_count);
      for (uint32_t i = kIOSize8KRange; i < std::min(kIOSize16KRange, iotype_cnt); i++) {
        if (tmp_stat[i].iops_read() != 0 || tmp_stat[i].iops_write() != 0) {
          SumSegmentIOInfo(tmp_stat[i], &result_stat[ucloud::udisk::kIOSize16K]);
        }
      }
      CeilSegmentIOInfo(&result_stat[ucloud::udisk::kIOSize16K], item_count);
      for (uint32_t i = kIOSize16KRange; i < std::min(kIOSize64KRange, iotype_cnt); i++) {
        if (tmp_stat[i].iops_read() != 0 || tmp_stat[i].iops_write() != 0) {
          SumSegmentIOInfo(tmp_stat[i], &result_stat[ucloud::udisk::kIOSize64K]);
        }
      }
      CeilSegmentIOInfo(&result_stat[ucloud::udisk::kIOSize64K], item_count);      
      for (uint32_t i = kIOSize64KRange; i < std::min(kIOSize256KRange, iotype_cnt); i++) {
        if (tmp_stat[i].iops_read() != 0 || tmp_stat[i].iops_write() != 0) {
          SumSegmentIOInfo(tmp_stat[i], &result_stat[ucloud::udisk::kIOSize256K]);
        }
      }
      CeilSegmentIOInfo(&result_stat[ucloud::udisk::kIOSize256K], item_count);
      for (uint32_t i = kIOSize256KRange; i < tmp_stat.size(); i++) {
        if (tmp_stat[i].iops_read() != 0 || tmp_stat[i].iops_write() != 0) {
          SumSegmentIOInfo(tmp_stat[i], &result_stat[ucloud::udisk::kIOSizeGT256K]);
        }
      }
      CeilSegmentIOInfo(&result_stat[ucloud::udisk::kIOSizeGT256K], item_count);
    } else {
      result_stat.swap(tmp_stat);
      for (uint32_t i = 0; i < iotype_cnt; i++) {
        CeilSegmentIOInfo(&result_stat[i], item_count);
      }
    }
    it = udisk_segment_stats_.erase(it); // 统计完毕以后删除统计信息

    // 构造上报消息 {extern_id + io_size + LCStats}
    for (uint32_t i = 0; i < result_stat.size(); i++) {
      ucloud::udisk::SegmentIOStats* iostat = req->add_io_stats();
      ucloud::udisk::LCStats* stat = iostat->mutable_io_stat();
      stat->set_iops_read(result_stat[i].iops_read());
      stat->set_iops_write(result_stat[i].iops_write());
      stat->set_byteps_read(result_stat[i].byteps_read());
      stat->set_byteps_write(result_stat[i].byteps_write());
      stat->set_read_latency(result_stat[i].read_latency());
      stat->set_write_latency(result_stat[i].write_latency());
      stat->set_extern_id(entry.second->extern_id());
      stat->set_stats_time(base::Timestamp::now().secondsSinceEpoch());
      stat->set_stats_period(g_config_parser->report_odin_period());
      iostat->set_extern_id(entry.second->extern_id());
      iostat->set_io_type(ucloud::udisk::IOSIZE_TYPE(i));
    }
    // 获取set name, 可能是错的 FIXME(yeheng)
    ConnectionUeventPtr odin_conn = GetOdinConnection(entry.second->lc_set_name(), 
                                                   entry.second->zk_server());
    if (!odin_conn) {
      ULOG_ERROR << "no available odin connection";
      return;
    }
    ULOG_DEBUG << um.DebugString();
    MessageUtil::SendPbRequest(odin_conn, um,
        std::bind(&ManagerThread::ReportSegmentIOStatResponseCb, this,
              std::placeholders::_1), 
        std::bind(&ManagerThread::ReportSegmentIOStatTimeout, this), 2.0);
  }
}

void ManagerThread::ReportSegmentIOStatResponseCb(const uevent::UMessagePtr& um) {
  const ucloud::udisk::ReportSegmentIOStatResponse &res = 
    um->body().GetExtension(ucloud::udisk::report_segment_iostat_response); 
  if (res.rc().retcode() != 0) {
    ULOG_ERROR << "ReportSegmentIOStatResponse ERROR, code=" << res.rc().retcode()
               << ", msg=" << res.rc().error_message();
    return;
  }
}

void ManagerThread::ReportSegmentIOStatTimeout() {
  ULOG_ERROR << "ReportSegmentIOStatTimeout. ";
}

void ManagerThread::WarningToOdin(
    ucloud::udisk::OdinWarningRequest& warn_request,
    const std::string& set_name, const std::string& zk_server) {
  loop_->RunInLoop(std::bind(
      &ManagerThread::WarningToOdinInLoop, this, warn_request, 
                            set_name, zk_server));
}

void ManagerThread::WarningToOdinInLoop(
             ucloud::udisk::OdinWarningRequest& warn_request,
             const std::string& set_name, const std::string& zk_server) {
  ULOG_INFO << "report waring to odin";
  ConnectionUeventPtr odin_conn = GetOdinConnection(set_name, zk_server);
  if (!odin_conn) {
    ULOG_ERROR << "odin connection not available for set: " << set_name;
    return;
  }
  ucloud::UMessage um;
  uint32_t obj_id = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&um, flowno, base::MyUuid::NewUuid(),
                ucloud::udisk::ODIN_WARNING_REQUEST, 0, false, obj_id, 0,
                "OdinWarningRequest", NULL, NULL);
  ucloud::udisk::OdinWarningRequest* req =
      um.mutable_body()->MutableExtension(ucloud::udisk::odin_warning_request);
  req->Swap(&warn_request);
  ULOG_INFO << um.DebugString();
  MessageUtil::SendPbRequest(
      odin_conn, um, std::bind(&ManagerThread::OdinWarningResponseCb, this,
                               std::placeholders::_1),
      std::bind(&ManagerThread::OdinWarningTimeout, this), 2.0);
}

void ManagerThread::OdinWarningResponseCb(const UMessagePtr& um) {
  const ucloud::udisk::OdinWarningResponse& res =
      um->body().GetExtension(ucloud::udisk::odin_warning_response);
  if (res.rc().retcode() != 0) {
    ULOG_ERROR << "odin warning response error";
  }
}

void ManagerThread::OdinWarningTimeout() {
  ULOG_ERROR << "odin waring request timeout";
}

uevent::ConnectionUeventPtr ManagerThread::GetConnection(const std::string &ip,
                                                uint32_t port) {
  ConnectorKey key = std::make_pair(ip, port);
  auto it = connectors_.find(key);
  if (it != connectors_.end()) {
    if (it->second->HasAvailableConnection() == false) {
      ULOG_ERROR << "no available connection to "
                << "ip: " << ip
                << "port: " << port;
      return uevent::ConnectionUeventPtr();
    }
    else {
      return it->second->GetConnection();
    }
  }
  std::stringstream ss;
  uevent::UsockAddress addr(ip, port, false);
  ss << "connector-" << ip << ":" << port;
  ConnectorUevent* connector = 
        new ConnectorLibevent((PosixWorker*)loop_->worker(), addr, ss.str());
  connector->SetConnectionSuccessCb(std::bind(
      &ManagerThread::ConnectorConnSuccessCb, this, std::placeholders::_1));
  connector->SetConnectionClosedCb(std::bind(
      &ManagerThread::ConnectorConnClosedCb, this, std::placeholders::_1));
  connector->SetMessageReadCb(&uevent::MessageUtil::ProtobufReadCallBack);
  connector->Connect();
  connectors_.insert(std::make_pair(key, connector));
  if (connector->HasAvailableConnection() == false) {
    ULOG_ERROR << "no available connection to ip:" << ip
              << " port: " << port;
    return uevent::ConnectionUeventPtr();
  }
  else {
    return connector->GetConnection();
  }
}

//Ark
void ManagerThread::ArkAccessConnSuccessCb(const ConnectionUeventPtr& conn) {
  ULOG_INFO << "connect to Ark Access success, peer address: "
            << conn->GetPeerAddress().ToString();
}

void ManagerThread::ArkAccessConnClosedCb(const ConnectionUeventPtr& conn) {
  ULOG_INFO << "disconnect from ark access, peer address: "
            << conn->GetPeerAddress().ToString();
}

ConnectionUeventPtr ManagerThread::GetArkAccessConnection(
        const std::string& set_name, const std::string& global_zk_server) {
  ucloud::uns::NameNodeContent nnc;
  auto it1 = g_name_containers.find(global_zk_server);
  if (it1 == g_name_containers.end()) {
    ULOG_ERROR << "zk server not exist";
    return ConnectionUeventPtr();
  }
  if (it1->second->GetNNCForName(set_name,
      common::ConfigParser::kArkAccessName, nnc, false) == -1) {
    ULOG_ERROR << "get nnc for ark access error";
    return ConnectionUeventPtr();
  }
  std::string ark_access_ip = nnc.ip();
  uint32_t ark_access_port = nnc.port();
  UsockAddress ark_access_addr(ark_access_ip, ark_access_port);
  auto it = ark_access_connector_map_.find(set_name);
  //已经与access建立连接,且没有切换，返回现有的connetion
  //否则需要重新建立连接
  if (it != ark_access_connector_map_.end() &&
      it->second->GetPeerAddress().ToString() == ark_access_addr.ToString()) {
    if (it->second->HasAvailableConnection() == false) {
      ULOG_ERROR << "connection to ark access is not available";
      return ConnectionUeventPtr();
    }
    return it->second->GetConnection();
  }
  ConnectorUeventPtr ark_access_ctor(new ConnectorLibevent(
      (PosixWorker*)loop_->worker(), ark_access_addr, "ArkAccessConnector"));
  ark_access_ctor->SetConnectionSuccessCb(std::bind(
      &ManagerThread::ArkAccessConnSuccessCb, this, std::placeholders::_1));
  // 这里传绑connector的裸指针，否则会循环引用无法析构
  ark_access_ctor->SetConnectionClosedCb(std::bind(
      &ManagerThread::ArkAccessConnClosedCb, this, std::placeholders::_1));
  ark_access_ctor->SetMessageReadCb(
      std::bind(MessageUtil::ProtobufReadCallBack, std::placeholders::_1));
  ark_access_ctor->Connect();
  // 如果发生了主access切换，这里会析构之前access_connector_
  // 也会释放其中的connection
  ark_access_connector_map_[set_name] = ark_access_ctor;
  if (ark_access_ctor->HasAvailableConnection() == false) {
    ULOG_ERROR << "connect to ark access error";
    return ConnectionUeventPtr();
  }
  return ark_access_ctor->GetConnection();
}

// SetArkStatus
void ManagerThread::SetArkStatus(UDiskHandle* handle,
                                 ucloud::udisk::UTM_STATUS target_utm_status,
                                 ucloud::udisk::UTM_STATUS current_utm_status) {
  HandleEntry entry(handle->handle_id(), handle);
  //本函数结束后，ark_handle可能已经被析构，所以需要存下状态信息
  std::string extern_id = handle->extern_id();
  std::string set_name = handle->lc_set_name();
  loop_->RunInLoop(std::bind(&ManagerThread::SetArkStatusInLoop, this, entry,
                             target_utm_status, current_utm_status, extern_id,
                             set_name));
}

void ManagerThread::SetArkStatusInLoop(
    HandleEntry entry, ucloud::udisk::UTM_STATUS target_utm_status,
    ucloud::udisk::UTM_STATUS current_utm_status, std::string extern_id,
    std::string set_name) {
  ucloud::UMessage um;
  NewMessage_v2(&um, MessageUtil::Flowno(), base::MyUuid::NewUuid(),
                ucloud::udisk::SET_ARK_STATUS_REQUEST, 0, false,
                MessageUtil::ObjId(), 0, "SetArkStatus", NULL, NULL);

  //在Set流程中,Ark状态锁定不能发生变化，除非是NeedRebase
  ucloud::udisk::SetArkStatusRequest* req = um.mutable_body()->MutableExtension(
      ucloud::udisk::set_ark_status_request);
  req->set_current_utm_status(current_utm_status);
  req->set_target_utm_status(target_utm_status);
  req->set_extern_id(extern_id);
  ConnectionUeventPtr metaserver_conn =
      GetMetaServerConnection(set_name, entry.second->zk_server());
  if (!metaserver_conn) {
    ULOG_ERROR << "no available metaserver connection";
    return;
  }
  ULOG_INFO << um.DebugString();
  MessageUtil::SendPbRequest(
      metaserver_conn, um, std::bind(&ManagerThread::SetArkStatusResponseCb,
                                     this, std::placeholders::_1, entry),
      std::bind(&ManagerThread::SetArkStatusTimeoutCb, this, entry), 2.0);
}

void ManagerThread::SetArkStatusTimeoutCb(HandleEntry entry) {
  int64_t handle_id = entry.first;
  UDiskHandle* handle = entry.second;
  ULOG_ERROR << "set ark status timeout, udisk_handle: " << entry.second
             << " handle_id: " << entry.first;
  handle->ArkStatTransTimeout(handle_id);
}

void ManagerThread::SetArkStatusResponseCb(const UMessagePtr& um,
                                           HandleEntry entry) {
  ULOG_INFO << um->DebugString();
  int64_t handle_id = entry.first;
  UDiskHandle* handle = entry.second;
  assert(um->head().message_type() == ucloud::udisk::SET_ARK_STATUS_RESPONSE);
  assert(um->has_body());
  assert(um->body().HasExtension(ucloud::udisk::set_ark_status_response));
  ucloud::udisk::SetArkStatusResponse rsp =
      um->body().GetExtension(ucloud::udisk::set_ark_status_response);
  if (rsp.rc().retcode() != 0) {
    ULOG_ERROR << "set_ark_status_response error," << rsp.rc().error_message();
    handle->ArkStatTransFailed(handle_id);
  } else {
    // Ark Status sync successfully
    handle->ArkStatTransSuccess(handle_id);
  }
}

//从方舟Access获取ArkFront的Router
void ManagerThread::GetArkRouter(UDiskHandle* handle) {
  HandleEntry entry(handle->handle_id(), handle);
  loop_->RunInLoop(std::bind(&ManagerThread::GetArkRouterInLoop, this, entry));
}

void ManagerThread::GetArkRouterInLoop(HandleEntry entry) {
  ucloud::UMessage um;
  NewMessage_v2(&um, MessageUtil::Flowno(), base::MyUuid::NewUuid(),
                ucloud::utimemachine::ACCESS_GET_IO_ROUTER_REQUEST, 0, false,
                MessageUtil::ObjId(), 0, "GetArkRouter", NULL, NULL);

  UDiskHandle* handle = entry.second;
  ucloud::utimemachine::AccessGetIoRouterRequest* req =
      um.mutable_body()->MutableExtension(
          ucloud::utimemachine::access_get_io_router_request);
  req->set_vdisk_id(handle->extern_id());
  ConnectionUeventPtr ark_access_conn = GetArkAccessConnection(
                handle->lc_set_name(), handle->global_zk_server());
  if (!ark_access_conn) {
    ULOG_ERROR << "no available ark access connection";
    return;
  }
  ULOG_INFO << um.DebugString();
  MessageUtil::SendPbRequest(
      ark_access_conn, um, std::bind(&ManagerThread::GetArkRouterResponseCb,
                                     this, std::placeholders::_1, entry),
      std::bind(&ManagerThread::GetArkRouterTimeoutCb, this, entry), 2.0);
}

void ManagerThread::GetArkRouterResponseCb(const UMessagePtr& um,
                                           HandleEntry entry) {
  ULOG_INFO << um->DebugString();
  int64_t handle_id = entry.first;
  UDiskHandle* handle = entry.second;
  assert(um->head().message_type() ==
         ucloud::utimemachine::ACCESS_GET_IO_ROUTER_RESPONSE);
  assert(um->has_body());
  assert(um->body().HasExtension(
      ucloud::utimemachine::access_get_io_router_response));
  ucloud::utimemachine::AccessGetIoRouterResponse rsp = um->body().GetExtension(
      ucloud::utimemachine::access_get_io_router_response);
  if (rsp.rc().retcode() != 0) {
    ULOG_ERROR << "access_get_io_router_response error,"
               << rsp.rc().error_message();
    handle->GetArkRouterFailed(rsp.rc().retcode(), handle_id);
  } else {
    UsockAddress ark_addr(rsp.ip(), rsp.gate_port());
    handle->GetArkRouterSuccess(ark_addr, handle_id);
  }
}

void ManagerThread::GetArkRouterTimeoutCb(HandleEntry entry) {
  ULOG_ERROR << "get ark router for ark access timeout, udisk_handle: "
             << entry.second << " handle_id: " << entry.first;
  int64_t handle_id = entry.first;
  UDiskHandle* handle = entry.second;
  handle->GetArkRouterTimeout(handle_id);
}

UDiskHandle* ManagerThread::GetUDiskHandleByExternId(
    const std::string& extern_id) {
  std::vector<EventLoop*> all_loops = g_listener->GetAllLoops();
  for (auto lp : all_loops) {
    UDiskHandle* udisk_handle =
        reinterpret_cast<UDiskHandle*>(lp->GetLoopHandle());
    if (udisk_handle->GetRefs() > 0 && udisk_handle->extern_id() == extern_id) {
      return udisk_handle;
    }
  }

  return nullptr;
}

void ManagerThread::ArkResponse(ArkResponseCb cb, int retcode,
                                std::string msg) {
  loop_->RunInLoop(
      std::bind(&ManagerThread::ArkResponseInLoop, this, cb, retcode, msg));
}

void ManagerThread::ArkResponseInLoop(ArkResponseCb cb, int retcode,
                                      std::string& msg) {
  if (cb != nullptr) {
    cb(retcode, msg);
  }
}

void ManagerThread::ArkWoodpeckerTimer() {
  ULOG_DEBUG << "ArkWoodpeckerTimer start";
  std::vector<EventLoop*> all_loops = g_listener->GetAllLoops();
  uint32_t total_ark_size = 0;
  uint32_t max_ark_size = 0;
  UDiskHandle* giant_handle = nullptr;
  int64_t gaint_handle_id = 0;
  for (auto lp : all_loops) {
    UDiskHandle* udisk_handle =
        reinterpret_cast<UDiskHandle*>(lp->GetLoopHandle());
    if (udisk_handle->GetRefs() > 0) {
      int64_t pre_handle_id = udisk_handle->handle_id();
      uint32_t cur_ark_size =
          udisk_handle->ArkInflightSize() + udisk_handle->ArkPendingSize();
      int64_t after_handle_id = udisk_handle->handle_id();
      ULOG_DEBUG << "udisk_handle:" << after_handle_id
                 << ", total_ark_size:" << total_ark_size
                 << " pending_size:" << udisk_handle->ArkPendingSize()
                 << " inflight_size:" << udisk_handle->ArkInflightSize();
      if (pre_handle_id == after_handle_id) {
        total_ark_size += cur_ark_size;
        if (cur_ark_size > max_ark_size) {
          giant_handle = udisk_handle;
          max_ark_size = cur_ark_size;
          gaint_handle_id = after_handle_id;
        }
      }
    }
  }

  if (max_ark_size > ((uint64_t)MAX_ARK_SIZE_MB << 20)) {
    ULOG_INFO << "udisk handle:" << gaint_handle_id
              << " is out of global memory: " << MAX_ARK_SIZE_MB << "MB";
    giant_handle->ArkKill(gaint_handle_id);
  }
}

void ManagerThread::ArkExit() {
  ULOG_INFO << "ark notify ark_handle start sending pending io and wait 3s, "
               "then it will exit";
  std::vector<EventLoop*> all_loops = g_listener->GetAllLoops();
  //通知所有ark_handle，尽快发出IO
  for (auto lp : all_loops) {
    UDiskHandle* udisk_handle =
        reinterpret_cast<UDiskHandle*>(lp->GetLoopHandle());
    if (udisk_handle->GetRefs() > 0) {
      udisk_handle->ArkFinalSend();
    }
  }

  //等dead_line发出所有IO,此时Qemu可读，不能写
  loop_->RunAfter(g_config_parser->terminal_dead_line(), std::bind(&ManagerThread::ArkFinalSendTimeUp, this));
}

void ManagerThread::ArkFinalSendTimeUp() {
  ULOG_INFO << "ark final send time's up, start check ark_handle status";
  std::vector<EventLoop*> all_loops = g_listener->GetAllLoops();
  //通知所有ark_handle，尽快发出IO
  for (auto lp : all_loops) {
    UDiskHandle* udisk_handle =
        reinterpret_cast<UDiskHandle*>(lp->GetLoopHandle());
    if (udisk_handle->GetRefs() > 0) {
      udisk_handle->ArkFinalCheck();
    }
  }
  //等1s等ark_handle设置数据库状态
  g_listener->GetLoop()->RunAfter(1, std::bind(&TerminateBlockGate));
  ULOG_INFO << "block_gate will terminal in 1s";
}

void ManagerThread::ReportIOTimeout(const std::string& extern_id,
                                    uint32_t retry_times,
                                    const std::string& set_name, 
                                    const std::string& zk_server,
                                    const std::string& chunk_ip,
                                    uint32_t chunk_id) {
  loop_->RunInLoop(std::bind(
      &ManagerThread::ReportIOTimeoutInLoop, this, extern_id,
          retry_times, set_name, zk_server, chunk_ip, chunk_id));
}

void ManagerThread::ReportIOTimeoutInLoop(const std::string& extern_id,
                                          uint32_t retry_times,
                                          const std::string& set_name, 
                                          const std::string& zk_server,
                                          const std::string& chunk_ip,
                                          uint32_t chunk_id) {
  ULOG_INFO << "report io timeout, extern_id: " << extern_id
            << ", retry_times: " << retry_times
            << ", set_name: " << set_name
            << ", chunk_ip: " << chunk_ip
            << ", chunk_id: " << chunk_id;
  auto it = lc_timeout_.find(extern_id);
  if (it == lc_timeout_.end()) {
    lc_timeout_[extern_id] = std::make_tuple(set_name, retry_times, zk_server, chunk_ip, chunk_id);
    return;
  }

  if (std::get<1>(it->second) < retry_times) {
    std::get<1>(it->second) = retry_times;
  }
  return;
}

void ManagerThread::ReportOdinIOTimeout() {
  LCTimeoutMap timeout_map;
  timeout_map.swap(lc_timeout_);
  ucloud::udisk::OdinWarningRequest warn_request;
  for (auto it = timeout_map.begin(); it != timeout_map.end(); ++it) {
    // ip:port:extern_id 拼成uuid, 唯一标识这个告警
    std::string uuid = g_config_parser->listen_ip() + ":" +
        std::to_string(g_config_parser->listen_port()) + ":" +
        it->first;
    uint32_t retry_times = std::get<1>(it->second);
    const std::string& set_name = std::get<0>(it->second);
    const std::string& zk_server = std::get<2>(it->second);
    const std::string& chunk_ip = std::get<3>(it->second);
    uint32_t chunk_id = std::get<4>(it->second);
    warn_request.set_uuid(uuid);
    warn_request.set_item_id(ConfigParser::kIORetryManyTimesItemId);
    warn_request.set_value(retry_times);
    warn_request.set_info("retry more than " + std::to_string(retry_times) +
                          " times. chunk_info[" + chunk_ip + ":" + std::to_string(chunk_id) + "]");
    warn_request.set_time(base::Timestamp::now().secondsSinceEpoch());
    WarningToOdinInLoop(warn_request, set_name, zk_server);
  }
  return;
}

void ManagerThread::SetUDiskQosInfo(UDiskHandle* handle, const QosInfo& info) {
  HandleEntry entry(handle->handle_id(), handle);
  loop_->RunInLoop(
      std::bind(&ManagerThread::SetUDiskQosInfoInLoop, this, entry, info));
}

void ManagerThread::SetUDiskQosInfoInLoop(const HandleEntry& entry,
                                          const QosInfo& info) {
  ULOG_DEBUG << "set qos info. lc:" << entry.second->extern_id()
             << " ;max_bw:" << info.max_bw
             << " ;max_iops:" << info.max_iops
             << " ;limit_bw_percent:" << info.limit_bw_percent
             << " ;limit_iops_percent:" << info.limit_iops_percent;
  qos_info_[entry] = info;
}

void ManagerThread::DeleteUDiskQosInfo(UDiskHandle* handle) {
  HandleEntry entry(handle->handle_id(), handle);
  loop_->RunInLoop(
      std::bind(&ManagerThread::DeleteUDiskQosInfoInLoop, this, entry));
}

void ManagerThread::DeleteUDiskQosInfoInLoop(const HandleEntry& entry) {
  ULOG_DEBUG << "clear qos info. lc:" << entry.second->extern_id();
  qos_info_.erase(entry);
}

// 为保持兼容，key统一转成string类型(可能存在更新版本时间差，跨机房挂载存在有set无uuid的情况)
// 全部升级完成，可直接使用uint32_t做为key
std::string ManagerThread::ValidClusterUuid(const UDiskHandle* handle, uint32_t uuid) {
  std::ostringstream ss;
  if (uuid != 0) {
    ss << uuid << ":";
  }

  ss << handle->lc_set_name() << ":" << handle->zk_server();
  return ss.str();
}

void ManagerThread::InitClusterNodes(UDiskHandle* handle) {
  HandleEntry entry(handle->handle_id(), handle);
  loop_->RunInLoop(std::bind(&ManagerThread::InitClusterNodesInLoop,
                             this, entry));
}

void ManagerThread::InitClusterNodesInLoop(HandleEntry entry) {
  ULOG_WARN << "Entry init cluster nodes. lc:" << entry.second->extern_id();
  int64_t handle_id = entry.first;
  UDiskHandle* handle = entry.second;

  if (handle_id != handle->handle_id()) {
    ULOG_WARN << "handle id changed; old handle_id:" << handle_id
             << " now handle_id:" << handle->handle_id();
    return;
  }

  uint32_t uuid = handle->route_manager_ptr()->GetClusterUuid();
  std::string key = ValidClusterUuid(handle, uuid);
  auto node_map = cluster_node_map_cache_.find(key);
  if (node_map != cluster_node_map_cache_.end()) {
    ULOG_DEBUG << "Exist hash ring in map cache for key:" << key
               << ", will trigger set hash ring. lc:"
               << entry.second->extern_id();
    handle->SetHashNodes(node_map->second, handle_id);
    return;
  }

  auto range = wait_init_hash_handle_.equal_range(key);
  for (auto it = range.first; it != range.second; ++it) {
    if (it->second.first == handle_id && it->second.second == handle) {
      ULOG_DEBUG << "This udisk is in wait_init_hash_handle list, will continue wait. lc:"
                 << entry.second->extern_id();
      return;
    }
  }

  // 先插入，确保Init异步回调时，此handle已经在wait_init_hash_handle
  // 插入不会影响range中的迭代器
  wait_init_hash_handle_.emplace(key, entry);
  if (range.first == range.second) {
    ULOG_INFO << "No exist hash ring in map cache. will trigger init hash ring. lc:"
              << entry.second->extern_id();
    handle->InitHashRing(handle_id);
  }

  ULOG_INFO << "Insert in wait_init_hash_handle list. lc:" << entry.second->extern_id()
            << "; wait_init_hash_handle size:" << wait_init_hash_handle_.size();
}

void ManagerThread::ReportInitHashRingResult(bool result, UDiskHandle* handle,
                                             const cluster::ClusterHashRing::VirtualNodeMap* node_map) {
  ULOG_INFO << "Init hash ring result:" << result
            << "; handle_id:" << handle->handle_id()
            << "; lc:" << handle-> extern_id();
  HandleEntry entry(handle->handle_id(), handle);
  uint32_t uuid = handle->route_manager_ptr()->GetClusterUuid();
  if (result == false) {
    loop_->RunInLoop(std::bind(&ManagerThread::InitHashRingFailureInLoop,
                               this, entry, uuid));
  } else {
    // 此处nodes会发生一次拷贝，防止init的handle被reset,导致nodes被释放
    loop_->RunInLoop(std::bind(&ManagerThread::InitHashRingSuccessInLoop,
                               this, entry, uuid, *node_map));
  }
}

void ManagerThread::InitHashRingFailureInLoop(HandleEntry entry, uint32_t uuid) {
  UDiskHandle* handle = entry.second;
  std::string key = ValidClusterUuid(handle, uuid);
  auto range = wait_init_hash_handle_.equal_range(key);
  // 清除失败handle，使用下一handle继续初始化
  auto it = range.first;
  while (it != range.second) {
    // 若比较handle_id可能造成handle_id变化时
    // 永远不会清除wait_init_hash_handle_中的此handle
    if (it->second.second == handle) {
      ULOG_INFO << "Delete failed init hash ring. lc:"
                << handle->extern_id()
                << "handle_id:" << entry.first
                << "wait handle_id:" << it->second.first;
      it = wait_init_hash_handle_.erase(it);
      break;
    } else {
      ++it;
    }
  }

  if (it != range.second) {
    ULOG_INFO << "Trigger init hash ring by next. lc:"
              << it->second.second->extern_id();
    it->second.second->InitHashRing(it->second.first);
  }
}

void ManagerThread::InitHashRingSuccessInLoop(HandleEntry entry, uint32_t uuid,
                                              const cluster::ClusterHashRing::VirtualNodeMap& node_map) {
  ULOG_TRACE << "Node map size: " << node_map.size();
  UDiskHandle* handle = entry.second;
  std::string key = ValidClusterUuid(handle, uuid); 
  ULOG_INFO << "Wait init hash node map size: " << wait_init_hash_handle_.size();
  auto result = cluster_node_map_cache_.emplace(key, node_map);
  if (result.second == false) {
    ULOG_FATAL << "Failed to insert cluster node map cache. "
               << "key:" << key << ";handle_id:" << entry.first
               << "; extern_id:" << handle->extern_id();
  }

  // 使用map中的值设置其他udisk的hash环
  const auto& node_in_map_cache = result.first->second;
  auto range = wait_init_hash_handle_.equal_range(key);
  auto it = range.first;
  while (it != range.second) {
    if (it->second.second != handle) {
      ULOG_INFO << "Set hash node for handle_id:" << it->second.first
                << "extern_id:" << it->second.second->extern_id();
      it->second.second->SetHashNodes(node_in_map_cache, it->second.first);
    }
    it = wait_init_hash_handle_.erase(it);
  }

  ULOG_INFO << "cluster size: " << cluster_node_map_cache_.size();
}

void ManagerThread::Resize(UDiskHandle* handle, uint32_t size, ResizeResponseCb cb) {
  HandleEntry entry(handle->handle_id(), handle);
  loop_->RunInLoop(std::bind(&ManagerThread::ResizeInLoop, this, entry, size, std::move(cb)));
}

void ManagerThread::ResizeInLoop(HandleEntry entry, uint32_t size, ResizeResponseCb cb) {
  ucloud::UMessage um; 
  NewMessage_v2(&um, MessageUtil::Flowno(), base::MyUuid::NewUuid(),
                ucloud::udisk::GATE_RESIZE_REQUEST, 0, false, 
                MessageUtil::ObjId(), 0, "gate resize", NULL, NULL);

  ucloud::udisk::GateResizeRequest* req =
    um.mutable_body()->MutableExtension(ucloud::udisk::gate_resize_request);
  req->set_extern_id(entry.second->extern_id());
  req->set_size(size);
  ConnectionUeventPtr metaserver_conn =
      GetMetaServerConnection(entry.second->lc_set_name(), entry.second->zk_server());
  if (!metaserver_conn) {
    ULOG_ERROR << "no available metaserver connection";
    cb(false, entry.first);
    return;
  }
  ULOG_INFO << um.DebugString();
  MessageUtil::SendPbRequest(metaserver_conn, um,
      std::bind(&ManagerThread::ResizeResponse, this,
          std::placeholders::_1, entry, cb), 
      std::bind(&ManagerThread::ResizeTimeout, this, entry, cb),
      2.0);
}

void ManagerThread::ResizeResponse(const UMessagePtr& um, HandleEntry entry, ResizeResponseCb cb) {
  ULOG_INFO << um->DebugString();
  ucloud::udisk::GateResizeResponse rsp =
    um->body().GetExtension(ucloud::udisk::gate_resize_response);
  if (rsp.rc().retcode() != 0) {
    ULOG_ERROR << "gate resize failed, retcode: " << rsp.rc().retcode()
              << ", message: " << rsp.rc().error_message();
    cb(false, entry.first);
    return;
  }
  cb(true, entry.first);
}

void ManagerThread::ResizeTimeout(HandleEntry entry, ResizeResponseCb cb) {
  ULOG_ERROR << "gate resize timeout, udisk_handle: "
             << entry.second << " handle_id: " << entry.first;
  cb(false, entry.first);
}

} // namespace gate
} // namespace udisk


