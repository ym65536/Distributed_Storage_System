#include <climits>
#include "gate_chunk_iostats.h"
#include <ustevent/message_util.h>
#include "umessage_common.h"

namespace udisk {
namespace gate {

int GateChunkIOStatsHandle::type_ = ucloud::udisk::GATE_CHUNK_IOSTATS_REQUEST;

void GateChunkIOStatsHandle::SendResponse(int retcode,
                                          const std::string& message) {
  resp_body_->mutable_rc()->set_retcode(retcode);
  resp_body_->mutable_rc()->set_error_message(message);
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void GateChunkIOStatsHandle::EntryInit(const ConnectionUeventPtr& conn,
                                       const UMessagePtr& um) {
  conn_ = conn;
  assert(um->head().message_type() == type_);
  assert(um->body().HasExtension(ucloud::udisk::gate_chunk_iostats_request));

  req_body_ = um->body().GetExtension(ucloud::udisk::gate_chunk_iostats_request);
  MakeResponse(um.get(), ucloud::udisk::GATE_CHUNK_IOSTATS_RESPONSE, &response_);
  resp_body_ = response_.mutable_body()->MutableExtension(
      ucloud::udisk::gate_chunk_iostats_response);

  // 处理
  GetChunkIOStatistics();
}

void GateChunkIOStatsHandle::GetChunkIOStatistics() {
  std::shared_ptr<GateChunkIOStatsHandle> ptr = 
        std::dynamic_pointer_cast<GateChunkIOStatsHandle>(shared_from_this());
  int ret = 
      ManagerThread::Instance()->GetChunkIOStatistics(req_body_.extern_id(), ptr);
  if (ret != 0) {
    SendResponse(-1, "this extern id is not exist");
  }
}

void GateChunkIOStatsHandle::GetChunkIOStatisticsResponse(
      const std::vector<ucloud::udisk::GateChunkIOStats>& stats,
      const std::unordered_map<uint32_t, ucloud::udisk::GatePCIOStats>& pc_stats) {
  std::string extern_id = req_body_.extern_id();
  uint32_t chunk_id = req_body_.has_chunk_id() ? req_body_.chunk_id() : (-1U);
  ULOG_INFO << "recv gate_chunk_iostats_request, extern_id:"
           <<  extern_id << " chunk_id:" << chunk_id; 
  
  // 获取chunk 统计信息
  if (chunk_id == (-1U)) { // 获取所有chunk信息
    for (uint32_t id = 0; id < stats.size(); ++id) {
      ucloud::udisk::GateChunkIOStats* stat = resp_body_->add_stats();
      stat->CopyFrom(stats[id]);
    }
  } else { // 获取指定chunk信息
    ucloud::udisk::GateChunkIOStats* stat = resp_body_->add_stats();
    stat->CopyFrom(stats[chunk_id]);
  }

  // 获取pc统计信息
  uint32_t pc_begin = req_body_.has_pc_no_begin() ? req_body_.pc_no_begin() : 0;
  uint32_t pc_end = req_body_.has_pc_no_end() ? req_body_.pc_no_end() : ULONG_MAX;
  for (auto it = pc_stats.begin(); it != pc_stats.end(); ++it) {
    if (it->first >= pc_begin && it->first <= pc_end) {
      ucloud::udisk::GatePCIOStats* stat = resp_body_->add_pc_stats();
      stat->CopyFrom(it->second);
    }
  }
  SendResponse(0, "sucess");
  return;
}

}
}
