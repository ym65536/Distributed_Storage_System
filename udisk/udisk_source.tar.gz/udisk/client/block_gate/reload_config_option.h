#ifndef UDISK_GATE_RELOAD_CONFIG_OPTION_H_
#define UDISK_GATE_RELOAD_CONFIG_OPTION_H_

#include <ustevent/base/logging.h>
#include <ustevent/eventloop.h>
#include <ustevent/pb_request_handle.h>
#include "udisk_message.h"

using namespace uevent;

namespace udisk {
namespace gate {

class ReloadConfigOption : public PbRequestHandle {
 public:
  ReloadConfigOption(uevent::EventLoop* loop) : loop_(loop) {}
  virtual ~ReloadConfigOption() {}
  virtual void EntryInit(const ConnectionUeventPtr& conn,
                         const UMessagePtr& um);

  void SendResponse(int retcode, const std::string& message);
  MYSELF_CREATE(ReloadConfigOption);

  void DestroyMyself();

 private:
  static int type_;
  uevent::EventLoop* loop_;
  ucloud::UMessage response_;
  ucloud::udisk::ReloadConfigOptionResponse* resp_body_;
};
}
}
#endif
