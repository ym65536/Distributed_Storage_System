#include "set_lc_qos.h"
#include "gate.h"
#include "udisk_handle.h"
#include "umessage_common.h"
#include "manager_thread.h"

namespace udisk {
namespace gate {

using namespace uevent;

int SetLcQos::type_ = ucloud::udisk::SET_LC_QOS_REQUEST;

void SetLcQos::EntryInit(const ConnectionUeventPtr& conn,
                         const UMessagePtr& um) {
  ULOG_INFO << um->DebugString();
  conn_ = conn;
  assert(um->head().message_type() == type_);
  assert(um->body().HasExtension(ucloud::udisk::set_lc_qos_request));
  ucloud::udisk::SetLcQosRequest req_body =
      um->body().GetExtension(ucloud::udisk::set_lc_qos_request);
  MakeResponse(um.get(), ucloud::udisk::SET_LC_QOS_RESPONSE, &response_);
  std::shared_ptr<SetLcQos> ptr =
      std::dynamic_pointer_cast<SetLcQos>(shared_from_this());
  UDiskHandle* udisk_handle =
      ManagerThread::Instance()->GetUDiskHandleByExternId(req_body.extern_id());
  if (udisk_handle != nullptr) {
    udisk_handle->SetQos(req_body.extern_id(), req_body.iops(), req_body.bw());
    SendResponse(0, "success");
  } else {
    SendResponse(-1, "not found lc");
  }
}

void SetLcQos::SendResponse(int retcode, const std::string& message) {
  ucloud::udisk::SetLcQosResponse* res =
      response_.mutable_body()->MutableExtension(
          ucloud::udisk::set_lc_qos_response);
  res->mutable_rc()->set_retcode(retcode);
  res->mutable_rc()->set_error_message(message);
  ULOG_INFO << response_.DebugString();
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

}  // namespace gate
}  // namespace udisk
