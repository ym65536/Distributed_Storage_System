#include "my_config_parser.h"
#include <ustevent/base/logging.h>
#include "udisk_types.h"

namespace udisk {
namespace gate {

const std::string MyConfigParser::kThreadNum = std::string("thread_num");
const std::string MyConfigParser::kReportOdinPeriod =
    std::string("report_odin_period");
const std::string MyConfigParser::kHeartbeatPeriod =
    std::string("heartbeat_period");
const std::string MyConfigParser::kArkHeartbeatPeriod =
    std::string("ark_heartbeat_period");
const std::string MyConfigParser::kGlobalOdinName = std::string("global_odin");
const std::string MyConfigParser::kUDiskHandleDelayResetTime =
    std::string("udisk_handle_delay_reset_time");
const std::string MyConfigParser::kArkMemCheckPeriod =
    std::string("ark_mem_check_period");
const std::string MyConfigParser::kQosSwitch = std::string("qos_switch");
const std::string MyConfigParser::kNetworkBandwidth =
    std::string("network_bandwidth");
const std::string MyConfigParser::kThrottleHighWaterLine =
    std::string("throttle_high_water_line");
const std::string MyConfigParser::kThrottleLowWaterLine =
    std::string("throttle_low_water_line");
const std::string MyConfigParser::kThrottleUdiskNum =
    std::string("throttle_udisk_num");
const std::string MyConfigParser::kThrottleMinPercent =
    std::string("throttle_min_percent");
const std::string MyConfigParser::kThrottleStepPercent =
    std::string("throttle_step_percent");
const std::string MyConfigParser::kThrottleBroadenTime =
                                        std::string("throttle_broaden_time");
const std::string MyConfigParser::kTerminalDeadLine = 
                                        std::string("terminal_dead_line");
const std::string MyConfigParser::kMaxPendingTime =
                                        std::string("max_pending_time");

using namespace base;

MyConfigParser::MyConfigParser(const std::string& file) : ConfigParser(file) {}

void MyConfigParser::Init() {
  ConfigParser::Init();
  //必要部分为填无法启动
  if (listen_ip().empty()) {
    ULOG_FATAL << "listen_ip is empty";
  }
  if (listen_port() == 0) {
    ULOG_FATAL << "listen_port is empty";
  }
  if (zk_server().empty()) {
    ULOG_FATAL << "zk server is empty";
  }
  if (global_zk_server().empty()) {
    ULOG_FATAL << "global zk server is empty";
  }
  if (listen_unix_addr().empty()) {
    ULOG_FATAL << "listen unix addr is empty";
  }
  if (hydra_zk_path().empty()) {
    ULOG_FATAL << "hydra_zk_path is empty";
  }
  if (ark_access_zk_path().empty()) {
    ULOG_FATAL << "ark_access is empty";
  }
  if (access_zk_path().empty()) {
    ULOG_FATAL << "access_zk_path is empty";
  }

  thread_num_ = parser_.IntValue(kSectionUDisk, kThreadNum);
  if (thread_num_ == 0) {
    ULOG_INFO << "thread_num is empty or 0 in config file";
  }
  udisk_handle_delay_reset_time_ =
      parser_.IntValue(kSectionUDisk, kUDiskHandleDelayResetTime);
  if (udisk_handle_delay_reset_time_ == 0) {
    ULOG_INFO << "udisk_handle_delay_reset_time is empty or 0 in config file";
  }
  ULOG_INFO << "udisk_handle_delay_reset_time:"
            << udisk_handle_delay_reset_time_;

  report_odin_period_ = parser_.IntValue(kSectionCommon, kReportOdinPeriod);
  if (report_odin_period_ == 0) {
    ULOG_INFO << "report odin period error, use default=5s";
    report_odin_period_ = 5;
  } else {
    ULOG_INFO << " report_odin_period: " << report_odin_period_;
  }
  heartbeat_period_ = parser_.IntValue(kSectionCommon, kHeartbeatPeriod);
  if (heartbeat_period_ == 0) {
    ULOG_INFO << "heartbeat period error, use default=1s";
    heartbeat_period_ = 1;
  } else {
    ULOG_INFO << "heartbeat period: " << heartbeat_period_;
  }
  ark_heartbeat_period_ = parser_.IntValue(kSectionCommon, kArkHeartbeatPeriod);
  if (ark_heartbeat_period_ == 0) {
    ULOG_INFO << "ark heartbeat period error, use default=10s";
    ark_heartbeat_period_ = 10;
  } else {
    ULOG_INFO << "ark heartbeat period: " << ark_heartbeat_period_;
  }

  LoadMayReloadOption();
  global_odin_zk_path_ = parser_.GetValue(kSectionName, kGlobalOdinName);
  if (global_odin_zk_path_.empty()) {
    ULOG_FATAL << "global odin is empty in config file";
  }
  ULOG_INFO << "global odin path: " << global_odin_zk_path_;

  ark_mem_check_period_ = parser_.IntValue(kSectionCommon, kArkMemCheckPeriod);
  if (ark_mem_check_period_ == 0) {
    ULOG_INFO << "ark memory check period is empty, use default=60s";
    ark_mem_check_period_ = 60;
  } else {
    ULOG_INFO << " ark_mem_check_period: " << ark_mem_check_period_;
  }

  terminal_dead_line_ = parser_.IntValue(kSectionCommon, kTerminalDeadLine);
  if (terminal_dead_line_ == 0) {
    ULOG_INFO << "terminal_dead_line is empty, use default=1s";
    terminal_dead_line_ = 1;
  } else {
    ULOG_INFO << " terminal_dead_line: " <<  terminal_dead_line_;
  }

  max_pending_time_ = parser_.IntValue(kSectionCommon, kMaxPendingTime);
  if (max_pending_time_ == 0) {
    LOG_INFO << "max_pending_time is empty, use default 8s";
    max_pending_time_ = 8;
  } else {
    LOG_INFO << "max_pending_time: " <<  max_pending_time_;
  }
}

std::tuple<int, std::string> MyConfigParser::Reload() {
  if (ConfigParser::Reload() != 0) {
    std::string msg = "reload config file failed: " + config_file_;
    ULOG_ERROR << msg;
    return std::make_tuple(-1, msg);
  }

  return LoadMayReloadOption();
}

std::tuple<int, std::string> MyConfigParser::LoadMayReloadOption() {
  int64_t qos_switch = parser_.IntValue(kSectionCommon, kQosSwitch);
  if (qos_switch == 0) {
    ULOG_INFO << "qos switch is OFF";
    is_qos_ = false;
  } else {
    is_qos_ = true;
    ULOG_INFO << "qos switch is ON";
  }

  network_bandwidth_ = parser_.IntValue(kSectionCommon, kNetworkBandwidth);
  if (network_bandwidth_ == 0) {
    ULOG_INFO << "network_bandwidth is empty or 0 in config file,"
              << "use default=1000MBps";
    network_bandwidth_ = 125 << MB_SHIFT;
  } else {
    ULOG_INFO << "network bandwidth: " << network_bandwidth_;
  }

  throttle_high_water_line_ =
      parser_.IntValue(kSectionCommon, kThrottleHighWaterLine);
  if (throttle_high_water_line_ == 0) {
    ULOG_INFO << "throttle_high_water_line is empty or 0 in config file,"
              << "use default=95";
    throttle_high_water_line_ = 95;
  } else {
    ULOG_INFO << "throttle_high_water_line:" << throttle_high_water_line_;
  }

  throttle_low_water_line_ =
      parser_.IntValue(kSectionCommon, kThrottleLowWaterLine);
  if (throttle_low_water_line_ == 0) {
    ULOG_INFO << "throttle_low_water_line is empty or 0 in config file,"
              << "use default=80";
    throttle_low_water_line_ = 80;
  } else {
    ULOG_INFO << "throttle_low_water_line:" << throttle_low_water_line_;
  }

  throttle_udisk_num_ = parser_.IntValue(kSectionCommon, kThrottleUdiskNum);
  if (throttle_udisk_num_ == 0) {
    ULOG_INFO << "throttle_udisk_num is empty or 0 in config file,"
              << "use default=2";
    throttle_udisk_num_ = 2;
  } else {
    ULOG_INFO << "throttle_udisk_num:" << throttle_udisk_num_;
  }

  throttle_min_percent_ = parser_.IntValue(kSectionCommon, kThrottleMinPercent);
  if (throttle_min_percent_ == 0) {
    ULOG_INFO << "throttle_min_percent is empty or 0 in config file,"
              << "use default=10";
    throttle_min_percent_ = 10;
  } else {
    ULOG_INFO << "throttle_min_percent:" << throttle_min_percent_;
  }

  throttle_step_percent_ =
      parser_.IntValue(kSectionCommon, kThrottleStepPercent);
  if (throttle_step_percent_ == 0) {
    ULOG_INFO << "throttle_step_percent is empty or 0 in config file,"
              << "use default=5";
    throttle_step_percent_ = 5;
  } else {
    ULOG_INFO << "throttle_step_percent:" << throttle_step_percent_;
  }

  throttle_broaden_time_ = parser_.IntValue(kSectionCommon, kThrottleBroadenTime);
  if (throttle_broaden_time_ == 0) {
    ULOG_INFO << "throttle_broaden_time is empty or 0 in config file,"
              << "use default 30 minute";
    throttle_broaden_time_ = 1800;
  } else {
    ULOG_INFO << "throttle_broaden_time:" << throttle_broaden_time_;
  }

  log_level_ = parser_.GetValue(kSectionLog, kLogLevel);
  base::Logger::setLogLevel(log_level_);
  ULOG_INFO << "log_level: " << log_level_;  
  return std::make_tuple(0, "");
}

}  // namespace gate
}  // namespace udisk
