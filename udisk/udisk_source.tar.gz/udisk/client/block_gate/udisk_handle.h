#ifndef UDISK_GATE_UDISK_HANDLE_H_
#define UDISK_GATE_UDISK_HANDLE_H_

#include <string>
#include <unordered_map>
#include <memory>
#include <deque>
#include <list>
#include <ustevent/base/logging.h>
#include <ustevent/eventloop.h>
#include <ustevent/timer.h>
#include <ustevent/usock_address.h>
#include <utility>
#include "qemu_io_proto.h"
#include "gate_io_proto.h"
#include "route_manager.h"
#include "udisk_message.h"
#include "get_lc_last_rw_tick.h"
#include "ark_handle.h"
#include "flow_ctrl.h"
#include "get_lc_qos_status.h"
#include "udisk_types.h"

namespace udisk {
namespace gate {

class GateChunkIOStatsHandle;

typedef std::function<void(int)> ResizeCb;

typedef struct AmountIOStats {
  int64_t amount_io_read;
  int64_t amount_io_write;
  int64_t amount_byte_read;
  int64_t amount_byte_write;
  int64_t amount_read_latency;   // 单位us
  int64_t amount_write_latency;  // 单位us
  int64_t amount_rw_latency;     // 单位us
  int64_t amount_byte_ark;
  AmountIOStats() :
      amount_io_read(0), amount_io_write(0), amount_byte_read(0),
      amount_byte_write(0), amount_read_latency(0), amount_write_latency(0),
      amount_rw_latency(0), amount_byte_ark(0) {}
} AmountIOStats;

class IORequest;
class FragIORequest;
class GetLcRwTick;

using uevent::LoopHandle;
using uevent::ConnectionUeventPtr;
using uevent::ConnectorUeventPtr;
using uevent::EventLoop;
using common::QemuIOHead;
using common::QemuLoginInfo;
using common::GateIOResponseHead;

class UDiskHandle : public LoopHandle {
 public:
  static const uint32_t kMinIOSizeShift = 12;  // IO最小划分位数(4k)
  static LoopHandle* CreateMyself(EventLoop* loop);
  inline int64_t handle_id() { return handle_id_; }
  UDiskHandle(EventLoop* loop);
  ~UDiskHandle() {}
  void Reset();
  void RwRequestHandle(const ConnectionUeventPtr& conn, QemuIOHead* head);
  void RwResponseHandle(const ConnectionUeventPtr& conn,
                        GateIOResponseHead* head);
  void IOErrorHandle(int32_t retcode, FragIORequest* frag_req,
                     const ConnectionUeventPtr& conn);
  void RetryErrorFragIO(FragIORequest* frag_req, int timer_count);
  void RetryAllSameConnFragIO(int64_t conn_id);
  void SendPendingIO();
  void IOTimerCb();
  void LoginHandle(QemuIOHead& head, QemuLoginInfo& info);
  void LoginHandleInLoop(QemuIOHead& head, QemuLoginInfo& info);
  void SendLoginResponse(int32_t ret_code,
                         int64_t handle_id,
                         ucloud::udisk::UDiskLoginResponse& rsp);
  void SendLoginResponseInLoop(bool success, int64_t handle_id,
                               ucloud::udisk::UDiskLoginResponse rsp);
  void FlushHandle(QemuIOHead* head);
  ConnectionUeventPtr GetChunkConnection(FragIORequest* frag_req);
  void DestroyChunkConnection(uint64_t conn_id);
  void UpdateRouteManager(const ucloud::udisk::ClusterInfoPb& cluster_info,
                          const ::google::protobuf::RepeatedPtrField<
                              ::ucloud::udisk::ChunkInfoPb>& chunk_info,
                          const ::google::protobuf::RepeatedPtrField<
                              ::ucloud::udisk::PGInfoPb>& pg_info,
                          int64_t handle_id);
  void UpdateRouteManagerInLoop(const ucloud::udisk::ClusterInfoPb cluster_info,
                                const ::google::protobuf::RepeatedPtrField<
                                    ::ucloud::udisk::ChunkInfoPb> chunk_info,
                                const ::google::protobuf::RepeatedPtrField<
                                    ::ucloud::udisk::PGInfoPb> pg_info,
                                int64_t handle_id);

  uevent::ConnectorUeventPtr GetChunkConnector(
      const uevent::UsockAddress& addr);
  inline EventLoop* GetLoop() { return loop_; }
  // 考虑效率返回引用
  inline const ConnectionUeventPtr& GetQemuConn() const { return qemu_conn_; }
  inline const uint32_t GetLcId() const { return lc_id_; }
  inline void SetLcId(uint32_t lc_id) { lc_id_ = lc_id; }
  inline const uint32_t GetRandomId() const { return lc_random_id_; }
  inline void SetRandomId(uint32_t lc_random_id) {
    lc_random_id_ = lc_random_id;
  }
  inline void SetLcSetName(const std::string& set_name) {
    lc_set_name_ = set_name;
  }
  inline void SetLcSize(uint64_t size) { size_ = size; }
  inline uint64_t GetLcSize() { return size_; }
  inline void SetPCSize(uint64_t pc_size) { pc_size_ = pc_size; }
  inline uint64_t GetPCSize() { return pc_size_; }
  inline std::string lc_set_name() const {
    return lc_set_name_;
  }
  inline const std::string &zk_server() const {
    return zk_server_;
  }
  inline void set_zk_server(const std::string &zk_server) {
    zk_server_ = zk_server;
  }
  inline const std::string &global_zk_server() const {
    return global_zk_server_;
  }
  inline void set_global_zk_server(const std::string &global_zk_server) {
    global_zk_server_ = global_zk_server;
  }
  inline std::string extern_id() const {
    return extern_id_;
  }
  inline std::shared_ptr<RouteManager> route_manager_ptr() const {
    return route_manager_ptr_;
  }
  inline bool RouteIsReady() {
    if (route_manager_ptr_ && route_manager_ptr_->IsReady()) {
      return true;
    }
    return false;
  }

  void SetHashNodes(const cluster::ClusterHashRing::VirtualNodeMap& node_map, int64_t handle_id);
  void SetHashNodesInLoop(const cluster::ClusterHashRing::VirtualNodeMap& node_map, int64_t handle_id);
  void InitHashRing(int64_t handle_id);
  void InitHashRingInLoop(int64_t handle_id);

  // 根据IO大小计算其所属区间4K、8K、16K、64K、256K、256K+
  inline uint32_t CalcIOInterval(int64_t io_size) {
    return io_size >> kMinIOSizeShift;
  }
  // 根据IO大小分别统计各IO的iops、时延
  inline void IncReadIOCount(int64_t io_size) {
    io_stats_.amount_io_read ++;
    uint32_t type = CalcIOInterval(io_size);
    if (type >= segmentation_io_stats_.size()) {
      segmentation_io_stats_.resize(type + 1);
    }
    segmentation_io_stats_[type].amount_io_read ++;
  }
  inline void IncWriteIOCount(int64_t io_size) {
    io_stats_.amount_io_write ++;
    uint32_t type = CalcIOInterval(io_size);
    if (type >= segmentation_io_stats_.size()) {
      segmentation_io_stats_.resize(type + 1);
    }
    segmentation_io_stats_[type].amount_io_write ++;
  }
  inline void IncReadBytesCount(int64_t io_size) {
    io_stats_.amount_byte_read += io_size;
    segmentation_io_stats_[CalcIOInterval(io_size)].amount_byte_read += io_size;
  }
  inline void IncWriteBytesCount(int64_t io_size) {
    io_stats_.amount_byte_write += io_size;
    segmentation_io_stats_[CalcIOInterval(io_size)].amount_byte_write += io_size;
  }
  inline void AddReadLatency(int64_t lat, int64_t io_size) {
    io_stats_.amount_read_latency += lat;
    segmentation_io_stats_[CalcIOInterval(io_size)].amount_read_latency += lat;
  }
  inline void AddWriteLatency(int64_t lat, int64_t io_size) {
    io_stats_.amount_write_latency += lat;
    segmentation_io_stats_[CalcIOInterval(io_size)].amount_write_latency += lat;
  }
  inline void IncArkBytesCount(int64_t io_size) {
    io_stats_.amount_byte_ark += io_size;
  }
  inline void set_last_read_tick(base::Timestamp tick) {
    last_read_tick_ = tick.secondsSinceEpoch();
  }
  inline void set_last_write_tick(base::Timestamp tick) {
    last_write_tick_ = tick.secondsSinceEpoch();
  }
  inline void set_last_heartbeat_tick(base::Timestamp tick) {
    last_heartbeat_tick_ = tick.secondsSinceEpoch();
  }

  void GetIOStatistics(ucloud::udisk::LCIOStats& stats, int interval, time_t stat_time);
  void GetSegmentIOStatistics(
        std::vector<ucloud::udisk::LCStats>& segment_iostat,
        int interval, time_t stat_time);

  inline void IncReadIOCount(uint32_t chunk_id, uint32_t pc_no) {
    if (chunk_id >= chunk_io_stats_.size()) {
      chunk_io_stats_.resize(chunk_id + 1);
    }
    chunk_io_stats_[chunk_id].amount_io_read ++;
    pc_io_stats_[pc_no].amount_io_read ++;
  }
  inline void IncWriteIOCount(uint32_t chunk_id, uint32_t pc_no) {
    if (chunk_id >= chunk_io_stats_.size()) {
      chunk_io_stats_.resize(chunk_id + 1);
    }
    chunk_io_stats_[chunk_id].amount_io_write ++;
    pc_io_stats_[pc_no].amount_io_write ++;
  }
  inline void IncReadBytesCount(uint32_t chunk_id, uint32_t pc_no,
                                int64_t io_size) {
    chunk_io_stats_[chunk_id].amount_byte_read += io_size;
    pc_io_stats_[pc_no].amount_byte_read += io_size;
  }
  inline void IncWriteBytesCount(uint32_t chunk_id, uint32_t pc_no,
                                 int64_t io_size) {
    chunk_io_stats_[chunk_id].amount_byte_write += io_size;
    pc_io_stats_[pc_no].amount_byte_write += io_size;
  }
  inline void AddReadLatency(uint32_t chunk_id, uint32_t pc_no, int64_t lat) {
    chunk_io_stats_[chunk_id].amount_read_latency += lat;
    pc_io_stats_[pc_no].amount_read_latency += lat;
  }
  inline void AddWriteLatency(uint32_t chunk_id, uint32_t pc_no, int64_t lat) {
    chunk_io_stats_[chunk_id].amount_write_latency += lat;
    pc_io_stats_[pc_no].amount_write_latency += lat;
  }
  void GetChunkIOStatistics(
      std::shared_ptr<GateChunkIOStatsHandle> ptr,
      int interval);
  inline void SwapChunkIOStats() {
    before_chunk_io_stats_ = std::move(chunk_io_stats_);
    chunk_io_stats_.resize(before_chunk_io_stats_.size());
    before_pc_io_stats_ = std::move(pc_io_stats_);
  }

  inline void ClearIOStats() {
    io_stats_.amount_io_read = 0;
    io_stats_.amount_byte_read = 0;
    io_stats_.amount_byte_write = 0;
    io_stats_.amount_io_write = 0;
    io_stats_.amount_read_latency = 0;
    io_stats_.amount_write_latency = 0;
    io_stats_.amount_rw_latency = 0;
    io_stats_.amount_byte_ark = 0;
    segmentation_io_stats_.clear();
    amount_io_retry_ = 0;
  }
  inline std::list<IORequest*>& GetPendingList() { return pending_list_; }
  inline std::list<IORequest*>& GetInflightList() { return inflight_list_; }
  inline void IncIORetryCount() { amount_io_retry_ ++; }
  static void QemuConnSuccessCb(const ConnectionUeventPtr& conn);
  static void QemuConnClosedCb(const ConnectionUeventPtr& conn);
  static void QemuConnReadCb(const ConnectionUeventPtr& conn);
  void GetRwTickInfo(std::shared_ptr<GetLcRwTick> ptr);
  int io_timer_count() const { return io_timer_count_; }
  void ArkStatTransTimeout(int64_t handle_id);
  void ArkStatTransFailed(int64_t handle_id);
  void ArkStatTransSuccess(int64_t handle_id);
  void ArkRebaseLogin(ArkResponseCb cb, int64_t handle_id);
  void ArkRebaseLogout(ArkResponseCb cb, int64_t handle_id);
  void GetArkRouterSuccess(const uevent::UsockAddress& addr, int64_t handle_id);
  void GetArkRouterFailed(int ret_code, int64_t handle_id);
  void GetArkRouterTimeout(int64_t handle_id);
  void ArkOn(ArkResponseCb cb, int64_t handle_id);
  void ArkOff(ArkResponseCb cb, int64_t handle_id);
  void ArkKill(int64_t handle_id);
  void ArkFinalSend();
  void ArkFinalCheck();
  uint32_t ArkPendingSize();
  uint32_t ArkInflightSize();
  ArkHandle* GetArkHandle(){return ark_handle_;}
  void ArkInitComplete(int retcode, const std::string& msg);

  // qos
  int limit_iops_percent() { return bucket_->percent(kLimitIops); }

  int limit_bw_percent() { return bucket_->percent(kLimitBW); }

  int limit_read_bw_percent() {
    return bucket_->percent(kLimitReadBW);
  }

  int limit_write_bw_percent() {
    return bucket_->percent(kLimitWriteBW);
  }

  uint64_t max_bw() {
    return max_bw_;
  }

  uint64_t max_iops() { return max_iops_; }

  void SetLimitBWPercent(int limit_bw_percent);
  void SetLimitIopsPercent(int limit_bw_percent);
  void SetLimitReadBWPercent(int limit_bw_percent);
  void SetLimitWriteBWPercent(int limit_bw_percent);
  void InitQos(uint64_t iops, uint64_t bw);
  void SetQos(const std::string& extern_id, uint64_t iops, uint64_t bw);
  void GetQosStatusInfo(std::shared_ptr<GetLcQosStatus> ptr);
  void Resize(const std::string& extern_id, uint32_t size, ResizeCb cb);
  void ResizeResponse(bool success, int64_t handle_id, uint32_t size,
                      ResizeCb cb);
  void ReportPendingIOTimeout();

 private:
  static void ChunkConnSuccessCb(const ConnectionUeventPtr& conn);
  static void ChunkConnClosedCb(const ConnectionUeventPtr& conn);
  static void ChunkConnReadCb(const ConnectionUeventPtr& conn);
  // ark private
  void ArkFlow(IORequest* io_req);
  void ArkInit(ucloud::udisk::UTM_MODE ark_mode, 
               ucloud::udisk::UTM_STATUS ark_status,
               ucloud::udisk::UDISK_MOUNT_STATUS mount_status,
               std::string set_name);
  void ArkStatTransTimeoutInLoop(int64_t handle_id);
  void ArkStatTransFailedInLoop(int64_t handle_id);
  void ArkStatTransSuccessInLoop(int64_t handle_id);
  void ArkRebaseLoginInLoop(ArkResponseCb cb, int64_t handle_id);
  void ArkRebaseLogoutInLoop(ArkResponseCb cb, int64_t handle_id);
  void GetArkRouterSuccessInLoop(const uevent::UsockAddress addr,
                                 int64_t handle_id);
  void GetArkRouterFailedInLoop(int ret_code, int64_t handle_id);
  void GetArkRouterTimeoutInLoop(int64_t handle_id);
  void ArkOnInLoop(ArkResponseCb cb, int64_t handle_id);
  void ArkOffInLoop(ArkResponseCb cb, int64_t handle_id);
  void ArkKillInLoop(int64_t handle_id);
  void ArkFinalSendInLoop();
  void ArkFinalCheckInLoop();
  void PendingQemuIO() { need_pending_qemu_io_ = true; }
  bool IsQemuIOPending() { return need_pending_qemu_io_; }
  bool NeedFlowCtrl(IORequest* req);
  void ReportUDiskQosInfo();
  void SetLimitBWPercentInLoop(int percent);
  void SetLimitIopsPercentInLoop(int percent);
  void SetLimitReadBWPercentInLoop(int limit_bw_percent);
  void SetLimitWriteBWPercentInLoop(int limit_bw_percent);
  void QosTimerCb();
  void SetQosInLoop(const std::string& extern_id, uint64_t iops, uint64_t bw);
  void DoSendLoginResponse();
  void OdinWarning(const std::string& warn_info, int32_t item_id);
  void ResizeResponseInLoop(bool success, int64_t handle_id, uint32_t size,
                            ResizeCb cb);
  
  EventLoop* loop_;
  int64_t handle_id_;
  ConnectionUeventPtr qemu_conn_;
  bool conn_is_reset_;
  // 长连接的connector不需要释放
  std::unordered_map<uint64_t, ConnectorUeventPtr> chunk_connector_map_;
  std::string extern_id_;
  uint32_t lc_id_;
  uint32_t lc_random_id_;
  std::string lc_set_name_;
  std::string zk_server_;
  std::string global_zk_server_;
  uint64_t size_;    // 单位GB
  uint64_t pc_size_; // 单位byte
  AmountIOStats io_stats_;
  std::vector<AmountIOStats> chunk_io_stats_;
  std::vector<AmountIOStats> before_chunk_io_stats_;
  std::unordered_map<uint32_t, AmountIOStats> pc_io_stats_; // index->pc_no
  std::unordered_map<uint32_t, AmountIOStats> before_pc_io_stats_; // index->pc_no
  std::vector<AmountIOStats> segmentation_io_stats_; //0,1,2,3,4.....IO大小分别统计
  bool has_flush_;
  uint32_t last_read_tick_;
  uint32_t last_write_tick_;
  uint32_t last_heartbeat_tick_;
  std::list<IORequest*> pending_list_;
  std::list<IORequest*> inflight_list_;
  std::list<IORequest*> qos_list_;
  QemuIOHead login_head_;
  std::shared_ptr<RouteManager> route_manager_ptr_;
  uevent::TimerId heartbeat_timer_id_;
  uevent::TimerId io_timer_id_;
  int io_timer_count_; //10ms触发一次timer
  int64_t amount_io_retry_;
  // ark
  bool need_pending_qemu_io_;
  ArkHandle* ark_handle_;
  // qos
  static uint64_t kTokenPerIO;
  enum {
    kLimitIops = 0,
    kLimitBW,
    kLimitReadBW,
    kLimitWriteBW,
    kLimitMax,
  } LIMIT_TYPE;

  CompoundTokenBucket<uint64_t, kLimitMax>* bucket_;
  uevent::TimerId qos_timer_id_;
  uint64_t max_iops_;
  uint64_t max_bw_;
};

}  // namespace gate
}  // namespace udisk

#endif
