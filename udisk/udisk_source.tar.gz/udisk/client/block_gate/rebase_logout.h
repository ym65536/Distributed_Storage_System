#ifndef UDISK_GATE_REBASE_LOGOUT_H_
#define UDISK_GATE_REBASE_LOGOUT_H_

#include <ustevent/base/logging.h>
#include <ustevent/pb_request_handle.h>
#include "udisk_message.h"

using namespace uevent;

namespace udisk {
namespace gate {

class RebaseLogoutHandle : public PbRequestHandle {
 public:
  explicit RebaseLogoutHandle(uevent::EventLoop* loop) : loop_(loop) {}
  virtual ~RebaseLogoutHandle() {}
  virtual void EntryInit(const ConnectionUeventPtr& conn,
                         const UMessagePtr& um);

  void RebaseLogoutProcess();
  void SendResponse(int retcode, const std::string& message);
  MYSELF_CREATE(RebaseLogoutHandle);

 private:
  static int type_;
  uevent::EventLoop* loop_;
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage response_;
  ucloud::udisk::RebaseLogoutResponse* resp_body_;
  ucloud::udisk::RebaseLogoutRequest req_body_;
};

}  // namespace gate
}  // namespace udisk
#endif
