#include "reload_config_option.h"
#include <ustevent/message_util.h>
#include "umessage_common.h"
#include "gate.h"

namespace udisk {
namespace gate {

using namespace uevent;

int ReloadConfigOption::type_ = ucloud::udisk::RELOAD_CONFIG_OPTION_REQUEST;

void ReloadConfigOption::EntryInit(const ConnectionUeventPtr& conn,
                                   const UMessagePtr& um) {
  ULOG_INFO << um->DebugString();
  assert(um->head().message_type() == type_);
  assert(um->body().HasExtension(ucloud::udisk::reload_config_option_request));
  ucloud::udisk::ReloadConfigOptionRequest req_body =
      um->body().GetExtension(ucloud::udisk::reload_config_option_request);
  MakeResponse(um.get(), ucloud::udisk::RELOAD_CONFIG_OPTION_RESPONSE,
               &response_);
  resp_body_ = response_.mutable_body()->MutableExtension(
      ucloud::udisk::reload_config_option_response);

  std::tuple<int, std::string> rsp = g_config_parser->Reload();

  resp_body_->mutable_rc()->set_retcode(std::get<0>(rsp));
  resp_body_->mutable_rc()->set_error_message(std::get<1>(rsp));
  ULOG_INFO << response_.DebugString();
  uevent::MessageUtil::SendPbResponse(conn, response_);
}

}  // namespace gate
}  // namespace udisk
