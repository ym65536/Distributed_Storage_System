#include "gate_listener.h"
#include <unistd.h>
#include <ustevent/base/logging.h>
#include <ustevent/libevent/connection_libevent.h>
#include <ustevent/libevent/libevent_driver.h>
#include <ustevent/libevent/eventloop_libevent.h>
#include <ustevent/libevent/posix_stack.h>
#include "qemu_io_proto.h"
#include "udisk_types.h"
#include "udisk_handle.h"

namespace udisk {
namespace gate {

using namespace uevent;
using namespace base;
using namespace common;
using std::placeholders::_1;

Processor::Processor(GateListener* listener, PosixWorker* w)
    : listener_(listener), worker_(w) {
  eventloop_ = reinterpret_cast<EventLoopLibevent*>(w->eventloop());
}

int Processor::Bind(const UsockAddress& listen_addr) {
  int r;
  eventloop_->RunInLoop([this, &listen_addr, &r]() {
                          r = worker_->listen(listen_addr, listen_socket_);
                        },
                        false);
  ULOG_INFO << "do listen, ret: " << r;
  return r;
}

// 启动监听
void Processor::Start() {
  // start thread
  if (listen_socket_) {
    ULOG_INFO << "start listen";
    eventloop_->RunInLoop([this]() {
                            accept_event_idx_ =
                                eventloop_->driver()->CreateEvent(
                                    listen_socket_->fd(), EV_READ,
                                    AcceptEventCbWrapper, this);
                            eventloop_->driver()->AddEvent(accept_event_idx_);
                          },
                          false);
  }
}

void Processor::AcceptEventCbWrapper(int fd, short event, void* arg) {
  Processor* instance = reinterpret_cast<Processor*>(arg);
  instance->Accept();
}

//监听的fd可读会会触发accept
void Processor::Accept() {
  while (true) {
    UsockAddress addr;
    ConnectedSocketPtr proxy_socket;
    // 创建一个kAccepting状态的盘
    int r = listen_socket_->accept(proxy_socket, &addr);
    if (r == 0) {
      int proxy_fd = proxy_socket->fd();
      ULOG_INFO << "accept new connection from gate_proxy: " << addr.ToString()
                << ", and the proxy fd: " << proxy_fd;
      int data_len = sizeof(QemuIOHead) + sizeof(QemuCommandBody);
      char* data = reinterpret_cast<char*>(malloc(data_len));
      int re_fd = -1, ret = -1;
      do {
        // gate_proxy may have a delay to send_fd, which would lead to a EAGAIN
        // here.
        // Just retry if we got EAGAIN.
        ret = RecvFd(proxy_fd, data, data_len, &re_fd);
      } while ((ret < 0) && (errno == EAGAIN));
      if (ret == 0) {
        ULOG_INFO << "connection closed by gate_proxy";
        free(data);
        ::close(proxy_fd);  // 出错关闭连接
        return;
      } else if (ret < 0) {
        ULOG_SYSERR << "receive fd error by proxy_fd: " << proxy_fd;
        free(data);
        ::close(proxy_fd);  // 出错关闭连接
        return;
      } else if (ret != data_len) {
        ULOG_ERROR << "data len not enough";
        free(data);
        ::close(proxy_fd);  // 出错关闭连接
        ::close(re_fd);
        return;
      }
      ULOG_INFO << "receive fd: " << re_fd << " by proxy fd: " << proxy_fd;
      ::close(proxy_fd);  // re_fd 读出后关闭proxy_fd
      // fd,head,body 由gate_proxy一起转发过来
      QemuIOHead head;
      memcpy(&head, data, sizeof(QemuIOHead));
      switch (head.cmd) {
        case QEMU_CMD_LOGIN: {
          QemuLoginInfo login_info;
          memcpy(&login_info, data + sizeof(QemuIOHead), sizeof(QemuLoginInfo));
          PosixWorker* w = listener_->GetEmptyLoopWorker();
          if (w == nullptr) {
            ULOG_ERROR << "can't get an available loop for new connection";
            ::close(re_fd);
            break;
          }
          ConnectedSocketPtr client_socket(
              new ConnectedSocket(addr, re_fd, ConnectionUevent::kAccepting));
          listener_->CreateConnection(w, client_socket, addr);
          LoopHandle* loop_handle = w->eventloop()->GetLoopHandle();
          UDiskHandle* udisk_handle =
              reinterpret_cast<UDiskHandle*>(loop_handle);
          // 必须在QemuConnSuccessCb之后执行，否则没有所需的qemu_conn
          udisk_handle->LoginHandle(head, login_info);
          break;
        }
        case QEMU_CMD_RESIZE: {
          QemuResizeInfo qemu_resize_info;
          memcpy(&qemu_resize_info, data + sizeof(QemuIOHead),
                 sizeof(QemuResizeInfo));
          ConnectedSocketPtr client_socket(
              new ConnectedSocket(addr, re_fd, ConnectionUevent::kAccepting));
          ConnectionUeventPtr conn =
              listener_->CreateResizeConnection(worker_, client_socket, addr);
          listener_->HandleQemuCommand(head, qemu_resize_info, conn);
          break;
        }
        default: {
          ULOG_ERROR << "unknown cmd: " << head.cmd;
          ::close(re_fd);
          break;
        }
      }
      free(data);
      continue;
    } else {
      if (r == -EINTR) {
        continue;
      } else if (r == -EAGAIN) {
        break;
      } else if (r == -EMFILE || r == -ENFILE) {
        ULOG_SYSERR << "open file descriptions limit reached listen_fd:"
                    << listen_socket_->fd();
        break;
      } else if (r == -ECONNABORTED) {
        ULOG_SYSERR << "it was closed because of rst arrived listen_fd:"
                    << listen_socket_->fd();
        continue;
      } else {
        ULOG_ERROR << "ret:" << r << " other error";
        break;
      }
    }
  }
}

int Processor::RecvFd(int fd, void* ptr, int nbytes, int* re_fd) {
  uint32_t control_len = CMSG_LEN(sizeof(int));
  struct msghdr msg;
  struct iovec iov[1];
  struct cmsghdr* cmptr = reinterpret_cast<cmsghdr*>(malloc(control_len));

  msg.msg_name = NULL;
  msg.msg_namelen = 0;

  iov[0].iov_base = ptr;
  iov[0].iov_len = nbytes;
  msg.msg_iov = iov;
  msg.msg_iovlen = 1;
  msg.msg_control = cmptr;
  msg.msg_controllen = control_len;
  int ret = recvmsg(fd, &msg, 0);
  if (ret < 0) {
    ULOG_SYSERR << "recvmsg error, ret: " << ret;
    free(cmptr);
    return ret;
  }
  ULOG_INFO << "login data len: " << ret;
  if ((cmptr = CMSG_FIRSTHDR(&msg)) != NULL && cmptr->cmsg_len == control_len) {
    if (cmptr->cmsg_level != SOL_SOCKET) {
      ULOG_ERROR << "cmsg_level error";
      free(cmptr);
      return -1;
    }
    if (cmptr->cmsg_type != SCM_RIGHTS) {
      ULOG_ERROR << "cmsg_type error";
      free(cmptr);
      return -1;
    }
    *re_fd = *((int*)CMSG_DATA(cmptr));
  } else {
    ULOG_ERROR << "receive fd error";
    free(cmptr);
    return -1;
  }

  free(cmptr);
  return ret;
}

void Processor::Stop() {
  if (listen_socket_) {
    eventloop_->RunInLoop([this]() {
                            eventloop_->driver()->FreeEvent(accept_event_idx_);
                            listen_socket_->abort_accept();
                          },
                          false);
  }
}

GateListener::~GateListener() { delete processor_; }

int GateListener::Bind() {
  int r = processor_->Bind(listen_addr_);
  if (r) {
    ULOG_SYSFATAL << "listener bind error";
  }
  processor_->Start();
  return 0;
}

int GateListener::Start() {
  if (worker_num_ > 0) {  // 只有需要线程池才创建stack
    stack_.reset(new PosixStack(worker_num_, option_, create_loop_handle_cb_));
    stack_->Start();  // 会等线程初始化完成
  }
  processor_ = new Processor(this, worker_);
  Bind();  // 线程启动后,启动监听
  assert(!started_);
  started_ = true;
  worker_->Running("main-listener");
  return 0;
}

// TODO yeheng 代码中所有的停止退出机制都没有完善,
// 作为服务程序, 一般都不会退出
int GateListener::Stop() {
  processor_->Stop();
  if (stack_ != false) {
    stack_->Stop();
  }
  started_ = false;
  return 0;
}

PosixWorker* GateListener::GetEmptyLoopWorker() {
  std::vector<Worker*> workers = stack_->GetAllWorkers();
  for (auto& w : workers) {
    if (w->eventloop()->GetLoopHandle()->GetRefs() == 0) {
      return reinterpret_cast<PosixWorker*>(w);
    }
  }
  return nullptr;
}
// 在ListenerUevent所在线程执行，避免操作共享数据时加锁
void GateListener::CreateConnection(PosixWorker* w,
                                    const ConnectedSocketPtr& cli_socket,
                                    const UsockAddress& addr) {
  worker_->eventloop()
      ->RunInLoop([this, addr, w, cli_socket]() {
                    std::string conn_name =
                        name_ + "-connection-" + std::to_string(next_conn_id_);
                    ConnectionLibevent* conn_libevent = new ConnectionLibevent(
                        w, conn_name, next_conn_id_, addr);
                    ConnectionUeventPtr conn(conn_libevent);
                    conn->SetConnectionSuccessCb(connection_success_cb_);
                    conn->SetConnectionClosedCb(connection_closed_cb_);
                    conn->SetMessageReadCb(message_read_cb_);
                    conn->SetMessageWriteCb(message_write_cb_);
                    conn->Init();
                    // 将cli_socket加到connection中, 会触发连接成功回调
                    conn_libevent->Accept(cli_socket);
                    ++next_conn_id_;
                    accepted_conns_.insert(make_pair(conn->GetId(), conn));
                    w->eventloop()->GetLoopHandle()->IncRefs();  // 增加引用计数
                  },
                  true);
}

// 在ListenerUevent所在线程执行，避免操作共享数据时加锁
ConnectionUeventPtr GateListener::CreateResizeConnection(
    PosixWorker* w, const ConnectedSocketPtr& cli_socket,
    const UsockAddress& addr) {
  std::string conn_name =
      name_ + "-connection-" + std::to_string(next_conn_id_);
  ConnectionLibevent* conn_libevent =
      new ConnectionLibevent(worker_, conn_name, next_conn_id_, addr);
  ConnectionUeventPtr conn(conn_libevent);
  conn->SetConnectionSuccessCb(
      std::bind(&GateListener::QemuCmdConnSuccessCb, this, _1));
  conn->SetConnectionClosedCb(
      std::bind(&GateListener::QemuCmdConnClosedCb, this, _1));
  conn->SetMessageReadCb(uevent::DefaultMessageReadCb);
  conn->SetMessageWriteCb(uevent::DefaultMessageWriteCb);
  conn->Init();
  // 将cli_socket加到connection中, 会触发连接成功回调
  conn_libevent->Accept(cli_socket);
  ++next_conn_id_;
  accepted_conns_.insert(make_pair(conn->GetId(), conn));
  w->eventloop()->GetLoopHandle()->IncRefs();  // 增加引用计数
  return conn;
}

// 可以不在connection所属的线程调用
void GateListener::RemoveConnection(const ConnectionUeventPtr& conn) {
  worker_->eventloop()->RunInLoop(
      [this, conn]() {
        auto it = accepted_conns_.find(conn->GetId());
        if (it == accepted_conns_.end()) {
          ULOG_INFO << "Invalid Connection, conn id:" << conn->GetId()
                    << " peer addr:" << conn->GetPeerAddress().ToString();
          return;
        }
        ULOG_DEBUG << "listener name:" << name_
                   << "connection name:" << it->second->GetName()
                   << " connection id:" << it->second->GetId();
        // 必须放在ForceClose之前, 阻止ForceClose后重复进入
        accepted_conns_.erase(it);
        conn->ForceClose();
      },
      true);
}

void GateListener::QemuCmdConnSuccessCb(const ConnectionUeventPtr& conn) {
  ULOG_INFO << "new connection for qemu command, id: " << conn->GetId();
}

void GateListener::QemuCmdConnClosedCb(const ConnectionUeventPtr& conn) {
  ULOG_INFO << "remove connection for qemu command, id: " << conn->GetId();
  RemoveConnection(conn);
}

void GateListener::HandleQemuCommand(const QemuIOHead& head,
                                     const QemuResizeInfo& info,
                                     const ConnectionUeventPtr& conn) {
  uint64_t new_resize_in_bytes = head.secnum << SECTOR_SHIFT;
  uint32_t size = new_resize_in_bytes >> GB_SHIFT;
  std::string extern_id(info.udisk_id);
  // 扇区数不是整GB
  if (new_resize_in_bytes % GB_SIZE != 0) {
    ULOG_ERROR << "invalid secnum: " << head.secnum;
    ResponseQemuCommand(QEMU_FAILURE, head, conn);
    return;
  }
  ULOG_INFO << "resize udisk " << extern_id << ", new size " << size;
  std::vector<EventLoop *> all_loops = GetAllLoops();
  ResizeCb callback =
      std::bind(&GateListener::ResponseQemuCommand, this, _1, head, conn);
  for (size_t i = 0; i < all_loops.size(); i++) {
    UDiskHandle* handle = (UDiskHandle*)all_loops[i]->GetLoopHandle();
    if (handle->extern_id() == extern_id) {
      all_loops[i]->RunInLoop(
          std::bind(&UDiskHandle::Resize, handle, extern_id, size, callback));
      return;
    }
  }
  // 找不到对应的udisk_handle
  ULOG_ERROR << extern_id << " not found";
  ResponseQemuCommand(QEMU_FAILURE, head, conn);
  return;
}

void GateListener::ResponseQemuCommand(int retcode, QemuIOHead head,
                                       const ConnectionUeventPtr& conn) {
  head.retcode = retcode;
  ULOG_INFO << "response qemu resize: " << DumpQemuIOHead(head);
  conn->SendData(&head, sizeof(QemuIOHead));
}

}  // namespace gate
}  // namespace uevent
