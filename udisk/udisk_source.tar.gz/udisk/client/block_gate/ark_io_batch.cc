#include "ark_io_batch.h"
#include <ustevent/base/logging.h>
#include <ustevent/libevent/connection_libevent.h>
#include "ark_front_io_proto.h"
#include "ark_handle.h"
#include "io_request.h"
#include "msgr.h"
#include "udisk_types.h"
#include "udisk_handle.h"

namespace udisk {
namespace gate {

using namespace uevent;
using namespace common;

ArkIOBatch::ArkIOBatch(ArkHandle* handle) /*{{{*/
    : ark_handle_(handle),
      batch_no_(0),
      batch_size_(0) {} /*}}}*/

ArkIOBatch::~ArkIOBatch() {/*{{{*/
  for (auto iter = batch_.begin(); iter != batch_.end(); iter++) {
    delete *iter;
  }
} /*}}}*/

void ArkIOBatch::Insert(ArkIORequest* ark_io) {/*{{{*/
  batch_size_ += ark_io->io_size();
  batch_.push_back(ark_io);
} /*}}}*/

void ArkIOBatch::Send() {/*{{{*/
  GateIORequest gate_io_req;
  memset(&gate_io_req, 0, sizeof(GateIORequest));
  gate_io_req.m_squence_number_ = batch_no_;
  gate_io_req.m_sector_size_ = SECTOR_SIZE;
  gate_io_req.m_data_size_ = batch_.size() * sizeof(IOFlag) + batch_size_;
  gate_io_req.m_batch_num_ = batch_.size();
  std::string extern_id = ark_handle_->extern_id();
  strncpy(gate_io_req.m_key_id_, extern_id.c_str(), extern_id.length());

  const ConnectionUeventPtr& conn = ark_handle_->GetConnection();
  if (conn == nullptr) {
    ULOG_ERROR << "send ark batch:" << batch_no_ << " failed";
    return;
  }

  MessageHeader msg_head;
  msg_head.data_len = sizeof(GateIORequest) + gate_io_req.m_data_size_;
  msg_head.msg_type = MSG_FRONT_GATE_IO_REQ;

  conn->SendData(&msg_head, sizeof(MessageHeader));
  conn->SendData(&gate_io_req, sizeof(GateIORequest));

  ULOG_INFO << "lc:" << extern_id << ", start send ark batch_no:" << batch_no_
            << " batch_num:" << batch_.size()
            << " size:" << (batch_size_ + batch_.size() * sizeof(IOFlag));

  //方舟侧需要先发完IOFlag，再发数据
  for (auto iter = batch_.begin(); iter != batch_.end(); iter++) {
    IOFlag io_flag;
    io_flag.squence_number_ = (*iter)->seq_no();
    io_flag.sector_ = (*iter)->begin_sector();
    io_flag.sector_num_ = (*iter)->io_secnum();

    ULOG_DEBUG << "lc:" << extern_id << ", sending ark batch_no:" << batch_no_
               << ", seq_no:" << io_flag.squence_number_
               << " sector_num:" << (*iter)->io_secnum()
               << " begin_sector:" << (*iter)->begin_sector()
               << " size:" << (*iter)->io_size();

    conn->SendData(&io_flag, sizeof(IOFlag));
  }

  for (auto iter = batch_.begin(); iter != batch_.end(); iter++) {
    conn->SendData((*iter)->io_data(), (*iter)->io_size());
  }
  ark_handle_->udisk_handle()->IncArkBytesCount(batch_size_);

  ULOG_INFO << "lc:" << extern_id << ", send ark batch_no:" << batch_no_
            << " complete size:" << batch_.size();
} /*}}}*/

}  // namespace gate
}  // namespace udisk
