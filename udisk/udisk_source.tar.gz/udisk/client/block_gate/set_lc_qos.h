#ifndef UDISK_GATE_SET_LC_QOS_H_
#define UDISK_GATE_SET_LC_QOS_H_

#include <ustevent/message_util.h>
#include <ustevent/pb_request_handle.h>
#include "udisk_message.h"

using namespace uevent;

namespace udisk {
namespace gate {

class SetLcQos : public PbRequestHandle {
 public:
  explicit SetLcQos(uevent::EventLoop* loop) : loop_(loop) {}
  virtual ~SetLcQos() {}

  virtual void EntryInit(const ConnectionUeventPtr& conn, const UMessagePtr& um);

  void SendResponse(int retcode, const std::string& message);

  MYSELF_CREATE(SetLcQos);

 private:
  void SetLcQosCbInLoop(bool hit);
  static int type_;
  uevent::EventLoop* loop_;
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage response_;
};
}  // namespace gate
}  // namespace udisk
#endif
