#include "my_config_parser.h"
#include "logging.h"

#include <stdlib.h>
#include <time.h>

namespace udisk {
namespace trans_gate_proxy {

const std::string MyConfigParser::kOldGateCount = std::string("old_gate_count");
const std::string MyConfigParser::kOldGateName = std::string("old_gate");
const std::string MyConfigParser::kBlockGateName = std::string("block_gate");
const std::string MyConfigParser::kTransGateName = std::string("trans_gate");
const std::string MyConfigParser::kTriggerPath = std::string("trigger");
const std::string MyConfigParser::kTriggerName = std::string("trigger");
using namespace base;

MyConfigParser::MyConfigParser(const std::string& file) : ConfigParser(file) {}

void MyConfigParser::Init() {
  ConfigParser::Init();
  //必要部分为填无法启动
  if (zk_server().empty()) {
    LOG_FATAL << "listen_ip is empty";
  }
  if (listen_unix_addr().empty()) {
    LOG_FATAL << "listen unix addr is empty";
  }
  if (hydra_zk_path().empty()) {
    LOG_FATAL << "hydra_zk_path is empty";
  }
  int32_t old_gate_count = parser_.IntValue(kSectionName, kOldGateCount);
  if (old_gate_count == 0) {
    LOG_FATAL << "old gate count is empty in config file";
  } else {
    for (int i = 0; i < old_gate_count; i++) {
      std::string old_gate_item = kOldGateName + std::to_string(i);
      std::string old_gate_addr = parser_.GetValue(kSectionName, old_gate_item);
      if (old_gate_addr.empty()) {
        LOG_FATAL << old_gate_item << " is empty in config file";
      } else {
        LOG_INFO << old_gate_item << " : " << old_gate_addr;
        old_gate_addrs_.push_back(old_gate_addr);
      }
    }
  }
  block_gate_addr_ = parser_.GetValue(kSectionName, kBlockGateName);
  if (block_gate_addr_.empty()) {
    LOG_FATAL << kBlockGateName << " is empty in config file";
  }
  LOG_INFO << kBlockGateName << " : " << block_gate_addr_;

  trans_gate_addr_ = parser_.GetValue(kSectionName, kTransGateName);
  if (trans_gate_addr_.empty()) {
    LOG_FATAL << kTransGateName << " is empty in config file";
  }
  LOG_INFO << kTransGateName << " : " << trans_gate_addr_;

  trigger_path_ = parser_.GetValue(kSectionName, kTriggerPath);
  if (trigger_path_.empty()) {
    LOG_FATAL << kTriggerPath << " is empty in config file";
  }
  LOG_INFO << kTriggerPath << " : " << trigger_path_;
}

std::string MyConfigParser::get_gate_addr(const std::string& gate_name) {
  if (gate_name == std::string("block_gate")) {
    return block_gate_addr_;
  } else if (gate_name == std::string("trans_gate")) {
    return trans_gate_addr_;
  } else if (gate_name == std::string("old_gate")) {
    srand((int)time(0));
    int i = rand() % old_gate_addrs_.size();
    return old_gate_addrs_.at(i);
  } else {
    return std::string("");
  }
}

}  // ns trans_gate_proxy
}  // ns udisk
