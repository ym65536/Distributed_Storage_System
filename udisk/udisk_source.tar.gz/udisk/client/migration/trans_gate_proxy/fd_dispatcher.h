#ifndef UDISK_TRANS_GATE_PROXY_FD_DISPATCHER_H_
#define UDISK_TRANS_GATE_PROXY_FD_DISPATCHER_H_

#include <map>
#include <memory>
#include "usock_address.h"
#include "qemu_io_proto.h"
#include "login_gate_strategy.h"

namespace uevent {
class UeventLoop;
class ConnectionUevent;
class ConnectorUevent;
class ListenerUevent;
}

namespace udisk {

namespace trans_gate_proxy {

class LoginGateStrategy;

struct LoginInfoEntry {
  uint32_t flowno;
  common::QemuIOHead login_head;
  common::QemuLoginInfo login_info;
  uevent::ConnectionUeventPtr conn;
};

class FdDispatcher {
 public:
  FdDispatcher(uevent::UeventLoop* loop,
               std::shared_ptr<MyConfigParser> config_parser);
  void Init();
  void Start();
  void LoginRequestHandle(common::QemuIOHead* head,
                          const uevent::ConnectionUeventPtr& conn);
  std::shared_ptr<LoginInfoEntry> GetLoginInfoEntry(uint32_t flowno);
  int Dispatch(std::shared_ptr<LoginInfoEntry> entry,
               const std::string& gate_name, const std::string& trans_ip,
               uint32_t trans_port);
  void RemoveConn(uevent::ConnectionUeventPtr& conn);

 private:
  void QemuConnSuccessCb(const uevent::ConnectionUeventPtr& conn);
  void QemuConnClosedCb(const uevent::ConnectionUeventPtr& conn);
  void QemuConnReadCb(const uevent::ConnectionUeventPtr& conn);
  uevent::ConnectorUeventPtr CreateGateConnector(const std::string& gate_name);
  void GateConnSuccessCb(const uevent::ConnectionUeventPtr& conn);
  void GateConnClosedCb(const uevent::ConnectionUeventPtr& conn);
  void DelGateConnector(std::string& name);
  void GateConnReadCb(const uevent::ConnectionUeventPtr& conn);
  int SendFd(int fd, void* ptr, int nbytes, int sendfd);
  void DelLoginInfoEntryByConn(const uevent::ConnectionUeventPtr& conn);
  void DelLoginInfoEntryByFlowno(uint32_t flowno);

  uevent::UeventLoop* loop_;
  std::shared_ptr<MyConfigParser> config_parser_;
  std::unique_ptr<uevent::ListenerUevent> listener_;
  std::unique_ptr<LoginGateStrategy> login_strategy_;
  int64_t gate_ctor_id_;  //标识不同的ctor, 帮助短连接析构
  std::map<std::string, uevent::ConnectorUeventPtr> gate_connectors_;
  common::QemuLoginInfo* login_info_;
  std::map<uint32_t, std::shared_ptr<LoginInfoEntry> > flowno_to_login_entry_;
};

}  // ns trans_gate_proxy
}  // ns udisk

#endif
