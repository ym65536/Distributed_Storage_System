#include "login_gate_strategy.h"
#include "logging.h"
#include "my_uuid.h"
#include "uevent.h"
#include "connector_libevent.h"
#include "message_util.h"
#include "umessage.h"
#include "usock_address.h"
#include "zk_name_container.h"
#include "trans_gate_proxy.h"
#include "fd_dispatcher.h"
#include "my_config_parser.h"

namespace udisk {
namespace trans_gate_proxy {

using namespace uevent;

LoginGateStrategy::LoginGateStrategy(
    UeventLoop* loop, FdDispatcher* dispatcher,
    std::shared_ptr<MyConfigParser> config_parser)
    : loop_(loop), dispatcher_(dispatcher), config_parser_(config_parser) {}

ConnectorUeventPtr LoginGateStrategy::CreateTriggerConnector() {
  ucloud::uns::NameNodeContent nnc;
  if (g_name_container->GetNNCForName(common::ConfigParser::kGlobalSetName,
                                      MyConfigParser::kTriggerName,
                                      nnc) == -1) {
    LOG_ERROR << "get nnc for trigger error";
    return ConnectorUeventPtr();
  }
  std::string trigger_ip = nnc.ip();
  uint32_t trigger_port = nnc.port();
  UsockAddress trigger_addr(trigger_ip, trigger_port);
  ConnectorUeventPtr trigger_ctor = std::make_shared<ConnectorLibevent>(
      loop_, trigger_addr, "TriggerConnector");
  trigger_ctor->SetConnectionSuccessCb(std::bind(
      &LoginGateStrategy::TriggerConnSuccessCb, this, std::placeholders::_1));
  trigger_ctor->SetConnectionClosedCb(std::bind(
      &LoginGateStrategy::TriggerConnClosedCb, this, std::placeholders::_1));
  trigger_ctor->SetMessageReadCb(
      std::bind(MessageUtil::ProtobufReadCallBack, std::placeholders::_1));
  return trigger_ctor;
}

void LoginGateStrategy::TriggerConnSuccessCb(const ConnectionUeventPtr& conn) {
  LOG_INFO << "connect to trigger success, peer address: "
           << conn->GetPeerAddress().ToString();
}

// 这里使用短连接，每次都会析构上次的connector,
// 创建一个新的connector。这里断开连接时不用DestroyConnection
// 不用担心connector中的无效connection 会被使用
void LoginGateStrategy::TriggerConnClosedCb(const ConnectionUeventPtr& conn) {
  LOG_INFO << "disconnect from Trigger, peer address: "
           << conn->GetPeerAddress().ToString();
}

void LoginGateStrategy::GetMigrateUDiskTask(
    std::shared_ptr<LoginInfoEntry> entry) {
  ucloud::UMessage um;
  NewMessage_v2(&um, entry->flowno, base::MyUuid::NewUuid(),
                ucloud::udisk::GET_MIGRATE_UDISK_TASK_REQUEST, 0, false,
                MessageUtil::ObjId(), 0, "GetMigrateUDiskTask", NULL, NULL);
  ucloud::udisk::GetMigrateUDiskTaskRequest* req_body =
      um.mutable_body()->MutableExtension(
          ucloud::udisk::get_migrate_udisk_task_request);
  req_body->set_extern_id(std::string(entry->login_info.udisk_id));

  ConnectorUeventPtr trigger_ctor = CreateTriggerConnector();
  if (!trigger_ctor || trigger_ctor->HasAvailableConnection() == false) {
    LOG_ERROR << "connect to trigger error";
    dispatcher_->RemoveConn(entry->conn);
    return;  // 这里返回. trigger_ctor 会被自动析构
  }
  ConnectionUeventPtr trigger_conn = trigger_ctor->GetConnection();
  LOG_INFO << um.DebugString();
  MessageUtil::SendPbRequest(
      trigger_conn, um,
      std::bind(&LoginGateStrategy::Entry_GetMigrateUDiskTask, this,
                std::placeholders::_1, trigger_ctor, entry),
      std::bind(&LoginGateStrategy::Timeout, this, trigger_ctor, entry), 2.0);
}

void LoginGateStrategy::Entry_GetMigrateUDiskTask(
    ucloud::UMessage* um, const ConnectorUeventPtr& ctor,
    const std::shared_ptr<LoginInfoEntry>& entry) {
  LOG_INFO << um->DebugString();
  assert(um->head().message_type() ==
         ucloud::udisk::GET_MIGRATE_UDISK_TASK_RESPONSE);
  assert(um->has_body());
  assert(
      um->body().HasExtension(ucloud::udisk::get_migrate_udisk_task_response));
  uint32_t flowno = um->head().flow_no();
  const ucloud::udisk::GetMigrateUDiskTaskResponse& rsp =
      um->body().GetExtension(ucloud::udisk::get_migrate_udisk_task_response);
  std::string gate_name;
  // TODO 获取gate失败如何处理，使用默认gate or 向qemu返回错误
  if (rsp.rc().retcode() != 0) {
    LOG_ERROR << "get migrate udisk task response error. "
              << rsp.rc().error_message();
    dispatcher_->RemoveConn(entry->conn);
    return;
  }

  std::string trans_ip;
  uint32_t trans_port = 0;

  if (rsp.migrate_udisk().status() == ucloud::udisk::MIGRATE_INEXISTENCE) {
    gate_name = std::string("old_gate");
  } else if (rsp.migrate_udisk().status() == ucloud::udisk::MIGRATE_INPROCESS ||
             rsp.migrate_udisk().status() == ucloud::udisk::MIGRATE_SUSPENDED) {
    gate_name = std::string("trans_gate");
    trans_ip = rsp.migrate_udisk().trans_ip();
    trans_port = rsp.migrate_udisk().trans_port();
  } else if (rsp.migrate_udisk().status() == ucloud::udisk::MIGRATE_COMPLETE) {
    gate_name = std::string("block_gate");
  } else {
    LOG_ERROR << "migrate task status is error. ";
    dispatcher_->RemoveConn(entry->conn);
    return;
  }

  Dispatch(flowno, gate_name, trans_ip, trans_port);
  // 这个函数返回后trigger_ctor引用为0, 自动析构
}

int LoginGateStrategy::Dispatch(uint32_t flowno, const std::string& gate_name,
                                const std::string& trans_ip,
                                uint32_t trans_port) {
  std::shared_ptr<LoginInfoEntry> entry =
      dispatcher_->GetLoginInfoEntry(flowno);
  if (!entry) {
    LOG_ERROR << "can't find login info entry when get gate response";
    return -1;
  }
  dispatcher_->Dispatch(entry, gate_name, trans_ip, trans_port);
  return 0;
}

void LoginGateStrategy::Timeout(const ConnectorUeventPtr& ctor,
                                const std::shared_ptr<LoginInfoEntry>& entry) {
  // TODO 获取gate失败如何处理，使用默认gate or 向qemu返回错误
  LOG_ERROR << "get migrate gate timeout";
  dispatcher_->RemoveConn(entry->conn);
  // 这个函数返回后trigger_ctor引用为0, 自动析构
}

}  // ns trans_gate_proxy
}  // ns udisk
