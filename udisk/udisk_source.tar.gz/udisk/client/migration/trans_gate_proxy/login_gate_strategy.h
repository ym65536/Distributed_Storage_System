#ifndef UDISK_TRANS_GATE_PROXY_LOGIN_GATE_STRATEGY_H_
#define UDISK_TRANS_GATE_PROXY_LOGIN_GATE_STRATEGY_H_

#include <memory>
#include <umessage.h>
#include "callbacks.h"

namespace uevent {
class UeventLoop;
class ConnectionUevent;
class ConnectorUevent;
}

namespace udisk {

namespace trans_gate_proxy {

class FdDispatcher;
class MyConfigParser;
struct LoginInfoEntry;

class LoginGateStrategy {
 public:
  LoginGateStrategy(uevent::UeventLoop* loop, FdDispatcher* dispatcher,
                    std::shared_ptr<MyConfigParser> config_parser);

  uevent::ConnectorUeventPtr CreateTriggerConnector();
  int Dispatch(uint32_t flowno, const std::string& gate_name,
               const std::string& trans_ip, uint32_t trans_port);
  void TriggerConnSuccessCb(const uevent::ConnectionUeventPtr& conn);
  void TriggerConnClosedCb(const uevent::ConnectionUeventPtr& conn);
  void GetMigrateUDiskTask(std::shared_ptr<LoginInfoEntry> entry);
  void Entry_GetMigrateUDiskTask(ucloud::UMessage* um,
                                 const uevent::ConnectorUeventPtr& ctor,
                                 const std::shared_ptr<LoginInfoEntry>& entry);
  void Timeout(const uevent::ConnectorUeventPtr& ctor,
               const std::shared_ptr<LoginInfoEntry>& entry);

 private:
  uevent::UeventLoop* loop_;
  FdDispatcher* dispatcher_;
  std::shared_ptr<MyConfigParser> config_parser_;
};

}  // ns trans_gate_proxy
}  // ns udisk

#endif
