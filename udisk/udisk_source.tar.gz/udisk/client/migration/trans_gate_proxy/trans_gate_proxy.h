#ifndef UDISK_TRANS_GATE_PROXY_H_
#define UDISK_TRANS_GATE_PROXY_H_

#include <memory>

namespace udisk {

namespace common {
class NameContainer;
}

namespace trans_gate_proxy {

extern std::unique_ptr<common::NameContainer> g_name_container;

}  // ns trans_gate_proxy
}  // ns udisk

#endif
