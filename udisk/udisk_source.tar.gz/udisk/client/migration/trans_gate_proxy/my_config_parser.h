#ifndef UDISK_TRANS_GATE_PROXY_CONFIG_PARSER_H_
#define UDISK_TRANS_GATE_PROXY_CONFIG_PARSER_H_

#include "config_parser.h"
#include <string>
#include <vector>

namespace udisk {
namespace trans_gate_proxy {

class MyConfigParser : public common::ConfigParser {
 public:
  explicit MyConfigParser(const std::string &file);
  void Init();
  std::string get_gate_addr(const std::string &gate_name);
  const std::string &trigger_path() { return trigger_path_; }
  const static std::string kOldGateCount;
  const static std::string kOldGateName;
  const static std::string kBlockGateName;
  const static std::string kTransGateName;
  const static std::string kTriggerPath;
  const static std::string kTriggerName;

 private:
  std::vector<std::string> old_gate_addrs_;
  std::string block_gate_addr_;
  std::string trans_gate_addr_;
  std::string trigger_path_;
};

}  // ns trans_gate_proxy
}  // ns udisk

#endif
