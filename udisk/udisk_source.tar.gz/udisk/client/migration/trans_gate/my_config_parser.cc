#include "my_config_parser.h"
#include "logging.h"

namespace udisk {
namespace trans_gate {

const std::string MyConfigParser::kThreadNum = std::string("thread_num");

using namespace base;

MyConfigParser::MyConfigParser(const std::string& file) : ConfigParser(file) {}

void MyConfigParser::Init() {
  ConfigParser::Init();
  //必要部分为填无法启动
  if (zk_server().empty()) {
    LOG_FATAL << "zk server is empty";
  }
  if (listen_unix_addr().empty()) {
    LOG_FATAL << "listen unix addr is empty";
  }

  thread_num_ = parser_.IntValue(kSectionUDisk, kThreadNum);
  if (thread_num_ == 0) {
    LOG_INFO << "thread_num is empty or 0 in config file";
  }
}

}  // ns trans_gate
}  // ns udisk
