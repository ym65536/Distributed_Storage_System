#ifndef UDISK_TRANS_GATE_LISTENER_LIBEVENT_H_
#define UDISK_TRANS_GATE_LISTENER_LIBEVENT_H_

#include <string>
#include <event2/listener.h>
#include "uevent.h"

namespace udisk {
namespace trans_gate {

class TransGateListener : public uevent::ListenerUevent {
 public:
  TransGateListener(uevent::UeventLoop* loop,
                    const uevent::UsockAddress& listen_addr,
                    const std::string& name,
                    const uevent::Option& option = uevent::Option());
  virtual ~TransGateListener() {}
  static void AcceptCb(struct evconnlistener* listener, evutil_socket_t sockfd,
                       struct sockaddr* addr, int len, void* arg);
  static void AcceptErrorCb(struct evconnlistener* listener, void* arg);

 private:
  int recv_fd(int fd, void* ptr, int nbytes, int* re_fd);
  struct evconnlistener* evlistener_;
};

}  // ns trans_gate
}  // ns udisk

#endif
