#include "trans_gate_listener.h"

#include <unistd.h>
#include <arpa/inet.h>
#include "eventloop_libevent.h"
#include "connection_libevent.h"
#include "ueventloop_thread_pool.h"
#include "logging.h"
#include "qemu_io_proto.h"
#include "trans_loop_handle.h"

namespace udisk {
namespace trans_gate {

using namespace uevent;
using namespace base;
using namespace common;

TransGateListener::TransGateListener(UeventLoop* loop,
                                     const UsockAddress& listen_addr,
                                     const std::string& name,
                                     const Option& option)
    : ListenerUevent(loop, listen_addr, name, option), evlistener_(NULL) {
  uint32_t flag = LEV_OPT_CLOSE_ON_FREE;
  if (option.reuse_port) {
    flag |= LEV_OPT_REUSEABLE;
  }
  evlistener_ = evconnlistener_new_bind(
      static_cast<EventLoopLibevent*>(loop)->GetInnerBase(), AcceptCb, this,
      flag, -1, listen_addr_.GetSockAddr(), listen_addr_.GetSockAddrLen());
  if (!evlistener_) {
    LOG_FATAL << "can't create udisk listener";
  }
  evconnlistener_set_error_cb(evlistener_, AcceptErrorCb);
}

void TransGateListener::AcceptCb(struct evconnlistener* listener,
                                 evutil_socket_t sockfd, struct sockaddr* addr,
                                 int len, void* arg) {
  TransGateListener* pobj = reinterpret_cast<TransGateListener*>(arg);
  int login_data_len = sizeof(QemuIOHead) + sizeof(QemuLoginInfo) +
                       sizeof(struct in_addr) + sizeof(uint32_t);
  char* login_data = reinterpret_cast<char*>(malloc(login_data_len));
  int re_fd = -1, ret = -1;
  do {
    // gate_proxy may have a delay to send_fd, which would lead to a EAGAIN
    // here.
    // Just retry if we got EAGAIN.
    ret = pobj->recv_fd(sockfd, login_data, login_data_len, &re_fd);
  } while ((ret < 0) && (errno == EAGAIN));
  if (ret == 0) {
    LOG_INFO << "connection closed by gate_proxy";
    ::close(sockfd);  // 出错关闭连接
    return;
  } else if (ret < 0) {
    LOG_SYSERR << "receive fd error by fd: " << sockfd;
    ::close(sockfd);  // 出错关闭连接
    return;
  } else if (ret != login_data_len) {
    LOG_ERROR << "data len  not enough";
    ::close(sockfd);  // 出错关闭连接
    ::close(re_fd);
    return;
  }
  LOG_INFO << "receive fd: " << re_fd << " by fd: " << sockfd;
  // fd,login_head,login_info,trans_ip,trans_port 由gate_proxy一起转发过来
  char* ptr = login_data;
  QemuIOHead login_head;
  QemuLoginInfo login_info;
  memcpy(&login_head, ptr, sizeof(QemuIOHead));
  ptr += sizeof(QemuIOHead);
  memcpy(&login_info, ptr, sizeof(QemuLoginInfo));
  ptr += sizeof(QemuLoginInfo);
  struct in_addr trans_ip_data;
  char addr_data[INET_ADDRSTRLEN];
  memcpy(&trans_ip_data, ptr, sizeof(struct in_addr));
  ::inet_ntop(AF_INET, &trans_ip_data, addr_data, INET_ADDRSTRLEN);
  std::string trans_ip(addr_data);
  ptr += sizeof(struct in_addr);
  uint32_t trans_port;
  memcpy(&trans_port, ptr, sizeof(uint32_t));
  LOG_INFO << "trans_ip: " << trans_ip.c_str() << "trans_port: " << trans_port;
  free(login_data);
  struct sockaddr_storage* p = reinterpret_cast<struct sockaddr_storage*>(addr);
  UsockAddress peer_addr(*p);
  LOG_DEBUG << "new connection from client:" << peer_addr.ToString()
            << ", and the fd: " << re_fd;
  EventLoopLibevent* io_loop =
      reinterpret_cast<EventLoopLibevent*>(pobj->thread_pool_->GetEmptyLoop());
  if (io_loop == NULL) {
    ::close(re_fd);
    ::close(sockfd);
    LOG_ERROR << "can't get an available loop for new connection, fd: "
              << re_fd;
    return;
  }
  // fd 已经成功传送可以关闭sockfd
  ::close(sockfd);
  LoopHandle* loop_handle = io_loop->GetLoopHandle();
  // 为loop的引用计数加一
  loop_handle->IncRefs();
  int64_t conn_id = pobj->next_conn_id_++;
  ConnectionUeventPtr conn(new ConnectionLibevent(
      io_loop, re_fd, conn_id, "TransGateListenerConnection", peer_addr));
  conn->Init();
  LOG_INFO << "accept new connection, conn_id:" << conn_id << " fd:" << re_fd
           << " perr address:" << peer_addr.ToString();
  pobj->connections_[conn_id] = conn;  // 保存在这里，退出后不会析构
  conn->SetConnectionSuccessCb(pobj->connection_success_cb_);
  conn->SetConnectionClosedCb(pobj->connection_closed_cb_);
  conn->SetMessageReadCb(pobj->message_read_cb_);
  conn->SetMessageWriteCb(pobj->message_write_cb_);
  io_loop->RunInLoop(std::bind(&ConnectionUevent::ConnectionEstablished, conn));
  TransLoopHandle* trans_loop_handle =
      reinterpret_cast<TransLoopHandle*>(loop_handle);
  // 必须在QemuConnSuccessCb之后执行，否则没有所需的qemu_conn
  trans_loop_handle->SetTransIPPort(trans_ip, trans_port);
  trans_loop_handle->SendLoginData(login_head, login_info);
}

int TransGateListener::recv_fd(int fd, void* ptr, int nbytes, int* re_fd) {
  uint32_t control_len = CMSG_LEN(sizeof(int));
  struct msghdr msg;
  struct iovec iov[1];
  struct cmsghdr* cmptr = reinterpret_cast<cmsghdr*>(malloc(control_len));

  msg.msg_name = NULL;
  msg.msg_namelen = 0;

  iov[0].iov_base = ptr;
  iov[0].iov_len = nbytes;
  msg.msg_iov = iov;
  msg.msg_iovlen = 1;
  msg.msg_control = cmptr;
  msg.msg_controllen = control_len;
  int ret = -1;
  ret = recvmsg(fd, &msg, 0);
  if (ret < 0) {
    LOG_SYSERR << "recvmsg error, ret: " << ret;
    return ret;
  }
  LOG_INFO << "login data len: " << ret;
  if ((cmptr = CMSG_FIRSTHDR(&msg)) != NULL && cmptr->cmsg_len == control_len) {
    if (cmptr->cmsg_level != SOL_SOCKET) {
      LOG_ERROR << "cmsg_level error";
      free(cmptr);
      return -1;
    }
    if (cmptr->cmsg_type != SCM_RIGHTS) {
      LOG_ERROR << "cmsg_type error";
      free(cmptr);
      return -1;
    }
    *re_fd = *((int*)CMSG_DATA(cmptr));
  } else {
    LOG_ERROR << "receive fd error";
    free(cmptr);
    return -1;
  }

  free(cmptr);
  return ret;
}

void TransGateListener::AcceptErrorCb(struct evconnlistener* listener,
                                      void* arg) {
  TransGateListener* pobj = reinterpret_cast<TransGateListener*>(arg);
  LOG_FATAL << "get an error on libevent listener, name:" << pobj->GetName();
}

}  // ns trans_gate
}  // ns udisk
