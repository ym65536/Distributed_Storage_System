#ifndef UDISK_TRANS_GATE_MY_CONFIG_PARSER_H_
#define UDISK_TRANS_GATE_MY_CONFIG_PARSER_H_

#include "config_parser.h"

namespace udisk {
namespace trans_gate {

class MyConfigParser : public common::ConfigParser {
 public:
  explicit MyConfigParser(const std::string& file);
  void Init();
  inline int32_t thread_num() const { return thread_num_; }

  const static std::string kThreadNum;

 private:
  int32_t thread_num_;
};

}  // ns trans_gate
}  // ns udisk

#endif
