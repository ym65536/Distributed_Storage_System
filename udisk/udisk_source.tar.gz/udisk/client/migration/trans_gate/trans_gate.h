#ifndef UDISK_TRANS_GATE_H_
#define UDISK_TRANS_GATE_H_

#include <memory>
#include "my_config_parser.h"

namespace uevent {
class ListenerLibevent;
}

namespace udisk {

namespace common {
class NameContainer;
}

namespace trans_gate {

class TransGateListener;

extern std::unique_ptr<TransGateListener> g_listener;
extern std::unique_ptr<common::NameContainer> g_name_container;
extern std::unique_ptr<MyConfigParser> g_config_parser;

}  // ns trans_gate
}  // ns udisk

#endif
