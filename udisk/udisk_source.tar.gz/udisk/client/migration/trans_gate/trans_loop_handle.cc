#include "trans_loop_handle.h"

#include "logging.h"
#include "loop_handle.h"
#include "uevent.h"
#include "listener_libevent.h"
#include "connector_libevent.h"

#include "msgr.h"
#include "qemu_io_proto.h"
#include "trans_gate.h"
#include "trans_gate_listener.h"
#include "my_config_parser.h"

namespace udisk {
namespace trans_gate {

using namespace uevent;
using namespace base;
using namespace common;

LoopHandle* TransLoopHandle::CreateMyself(UeventLoop* loop) {
  return reinterpret_cast<LoopHandle*>(new TransLoopHandle(loop));
}

TransLoopHandle::TransLoopHandle(UeventLoop* loop) : loop_(loop) {}

void TransLoopHandle::Reset() {
  // 标识该trans loop handle 负责其他的盘
  //由listener中统一的入口对accept的连接进行删除和析构
  LOG_INFO << "trans loop handle do reset";
  qemu_conn_.reset();
  trans_ctor_.reset();
  trans_ip_ = "";
  trans_port_ = 0;
  DecRefs();
  assert(GetRefs() == 0);
}

void TransLoopHandle::QemuConnSuccessCb(const ConnectionUeventPtr& conn) {
  LoopHandle* loop_handle = conn->GetLoop()->GetLoopHandle();
  TransLoopHandle* instance = reinterpret_cast<TransLoopHandle*>(loop_handle);
  LOG_INFO << "new connection from qemu, connection name:" << conn->GetName()
           << " connection id: " << conn->GetId();
  if (instance->qemu_conn()) {
    LOG_FATAL << "the before qemu connection still exist, conn_id:"
              << instance->qemu_conn_->GetId();
  }
  instance->qemu_conn_ = conn;
}

void TransLoopHandle::QemuConnClosedCb(const ConnectionUeventPtr& conn) {
  LoopHandle* loop_handle = conn->GetLoop()->GetLoopHandle();
  TransLoopHandle* instance = reinterpret_cast<TransLoopHandle*>(loop_handle);
  LOG_INFO << "disconnect from qemu, connection name: " << conn->GetName()
           << "connection id: " << conn->GetId();
  if (!(instance->qemu_conn()->IsClosed())) {
    g_listener->RemoveConnection(instance->qemu_conn());
  }
  instance->trans_ctor()->DestroyConnection();
  instance->Reset();
}

void TransLoopHandle::QemuConnReadCb(const ConnectionUeventPtr& conn) {
  LoopHandle* loop_handle = conn->GetLoop()->GetLoopHandle();
  TransLoopHandle* instance = reinterpret_cast<TransLoopHandle*>(loop_handle);
  size_t readable = conn->ReadableLength();
  char* qemu_data = (char*)::malloc(readable);
  conn->RemoveData(qemu_data, readable);
  const ConnectionUeventPtr& trans_conn = instance->GetTransConnection();
  if (!trans_conn) {
    LOG_ERROR << "get trans connection fail";
    return;
  }
  trans_conn->SendData(qemu_data, readable);
  ::free(qemu_data);
}

void TransLoopHandle::SetTransIPPort(const std::string& trans_ip,
                                     uint32_t trans_port) {
  loop_->RunInLoop(std::bind(&TransLoopHandle::SetTransIPPortInLoop, this,
                             trans_ip, trans_port));
}

void TransLoopHandle::SetTransIPPortInLoop(const std::string& trans_ip,
                                           uint32_t trans_port) {
  loop_->AssertInLoopThread();
  trans_ip_ = trans_ip;
  trans_port_ = trans_port;
  uevent::UsockAddress trans_addr(trans_ip, trans_port, false);
  trans_ctor_.reset(reinterpret_cast<ConnectorUevent*>(
      new ConnectorLibevent(loop_, trans_addr, "TransConnector")));
  trans_ctor_->SetConnectionSuccessCb(std::bind(
      &TransLoopHandle::TransConnSuccessCb, this, std::placeholders::_1));
  trans_ctor_->SetConnectionClosedCb(std::bind(
      &TransLoopHandle::TransConnClosedCb, this, std::placeholders::_1));
  trans_ctor_->SetMessageReadCb(std::bind(&TransLoopHandle::TransConnReadCb,
                                          this, std::placeholders::_1));
}

void TransLoopHandle::SendLoginData(QemuIOHead& head, QemuLoginInfo& info) {
  loop_->RunInLoop(
      std::bind(&TransLoopHandle::SendLoginDataInLoop, this, head, info));
}

void TransLoopHandle::SendLoginDataInLoop(QemuIOHead& head,
                                          QemuLoginInfo& info) {
  loop_->AssertInLoopThread();
  LOG_TRACE << "send login head" << common::DumpQemuIOHead(head);
  const ConnectionUeventPtr& trans_conn = GetTransConnection();
  if (!trans_conn) {
    LOG_ERROR << "get trans connection fail";
    return;
  }
  trans_conn->SendData(&head, sizeof(QemuIOHead));
  trans_conn->SendData(&info, sizeof(QemuLoginInfo));
}

void TransLoopHandle::TransConnSuccessCb(const ConnectionUeventPtr& conn) {
  LOG_INFO << "connect to trans success, peer name:"
           << conn->GetPeerAddress().ToString();
}

void TransLoopHandle::TransConnClosedCb(const ConnectionUeventPtr& conn) {
  LoopHandle* loop_handle = conn->GetLoop()->GetLoopHandle();
  TransLoopHandle* instance = reinterpret_cast<TransLoopHandle*>(loop_handle);
  LOG_INFO << "disconnect from trans, "
           << " peer addr:" << conn->GetPeerAddress().ToString();
  if (!(instance->qemu_conn()->IsClosed())) {
    g_listener->RemoveConnection(instance->qemu_conn());
  }
}

void TransLoopHandle::TransConnReadCb(const ConnectionUeventPtr& conn) {
  LoopHandle* loop_handle = conn->GetLoop()->GetLoopHandle();
  TransLoopHandle* instance = reinterpret_cast<TransLoopHandle*>(loop_handle);
  size_t readable = conn->ReadableLength();
  LOG_TRACE << "readable: " << readable;
  char* trans_data = (char*)::malloc(readable);
  conn->RemoveData(trans_data, readable);
  instance->qemu_conn()->SendData(trans_data, readable);
  ::free(trans_data);
}

ConnectionUeventPtr TransLoopHandle::GetTransConnection() {
  if (trans_ctor_->HasAvailableConnection() == false) {
    LOG_ERROR << "no available connection to chunk";
    return ConnectionUeventPtr();
  }
  return trans_ctor_->GetConnection();
}

}  // ns trans_gate
}  // ns udisk
