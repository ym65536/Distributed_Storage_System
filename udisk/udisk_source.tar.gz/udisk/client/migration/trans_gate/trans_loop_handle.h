#ifndef UDISK_TRANS_LOOP_HANDLE_H_
#define UDISK_TRANS_LOOP_HANDLE_H_

#include <string>
#include <memory>
#include "loop_handle.h"
#include "usock_address.h"
#include "qemu_io_proto.h"
#include "callbacks.h"

namespace uevent {
class UeventLoop;
}

namespace udisk {
namespace trans_gate {

using uevent::LoopHandle;
using uevent::ConnectionUeventPtr;
using uevent::ConnectorUeventPtr;
using uevent::UeventLoop;
using common::QemuIOHead;
using common::QemuLoginInfo;

class TransLoopHandle : public LoopHandle {
 public:
  TransLoopHandle(UeventLoop* loop);
  ~TransLoopHandle() {}

  void Reset();

  static LoopHandle* CreateMyself(UeventLoop* loop);

  inline UeventLoop* GetLoop() { return loop_; }

  inline const ConnectionUeventPtr& qemu_conn() const { return qemu_conn_; }

  inline void set_qemu_conn(const ConnectionUeventPtr& conn) {
    qemu_conn_ = conn;
  }

  inline const ConnectorUeventPtr& trans_ctor() const { return trans_ctor_; }

  void SetTransIPPort(const std::string& trans_ip, uint32_t trans_port);
  void SetTransIPPortInLoop(const std::string& trans_ip, uint32_t trans_port);

  void SendLoginData(QemuIOHead& head, QemuLoginInfo& info);
  void SendLoginDataInLoop(QemuIOHead& head, QemuLoginInfo& info);

  uevent::ConnectionUeventPtr GetTransConnection();

  static void QemuConnSuccessCb(const ConnectionUeventPtr& conn);
  static void QemuConnClosedCb(const ConnectionUeventPtr& conn);
  static void QemuConnReadCb(const ConnectionUeventPtr& conn);

 private:
  void TransConnSuccessCb(const ConnectionUeventPtr& conn);
  void TransConnClosedCb(const ConnectionUeventPtr& conn);
  void TransConnReadCb(const ConnectionUeventPtr& conn);

  UeventLoop* loop_;
  ConnectionUeventPtr qemu_conn_;
  std::string trans_ip_;
  uint32_t trans_port_;
  ConnectorUeventPtr trans_ctor_;
};

}  // ns trans_gate
}  // ns udisk

#endif
