#include "trans_gate.h"

#include <stdlib.h>
#include <getopt.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string>
#include "flock_util.h"
#include "logging.h"
#include "async_logging.h"
#include "uevent.h"
#include "eventloop_libevent.h"
#include "zk_name_container.h"
#include "trans_gate_listener.h"
#include "trans_loop_handle.h"

namespace udisk {
namespace trans_gate {

#define str(a) (#a)
#define xstr(a) (str(a))

#ifdef VERSION_TAG
//用于标识版本号，可以用nm -C 查看
const char *version_tag = xstr(VERSION_TAG);  //两次转换将宏的值转成字符串
#else
const char *version_tag = "unknown";
#endif

static struct option long_options[] = {{"help", 0, nullptr, 'h'},
                                       {"version", 0, nullptr, 'v'},
                                       {"conf", 1, nullptr, 'c'},
                                       {"foregroud", 0, nullptr, 'f'}, };

static const char *short_options = "hvfc:";

static void print_help(const char *name) {
  LOG_INFO << name << " Usage: \n"
           << "-h | --help, print this\n"
           << "-c | --conf config file, conf file\n"
           << "-v | --version, get the version\n"
           << "-f | --foregroud, run this on front end\n";
}

static void print_version(const char *name) {
  printf("version tag: %s\n", version_tag);
}

static void init_daemon() {
  pid_t pid;

  pid = fork();
  if (pid < 0) exit(EXIT_FAILURE);
  if (pid > 0) exit(EXIT_SUCCESS);
  if (setsid() < 0) exit(EXIT_FAILURE);

  signal(SIGCHLD, SIG_IGN);
  signal(SIGHUP, SIG_IGN);

  pid = fork();
  if (pid < 0) exit(EXIT_FAILURE);
  if (pid > 0) exit(EXIT_SUCCESS);

  umask(0);
  chdir("/");

  close(STDOUT_FILENO);
  close(STDIN_FILENO);
}

std::unique_ptr<base::AsyncLogging> g_asyncLog;
std::unique_ptr<common::NameContainer> g_name_container;
std::unique_ptr<MyConfigParser> g_config_parser;
std::unique_ptr<TransGateListener> g_listener;

void AsyncOutput(const char *msg, int len) { g_asyncLog->append(msg, len); }

void InitLogging(const char *argv0, bool foreground) {
  char name[256];
  strncpy(name, argv0, 256);
  std::string name_str = g_config_parser->log_common_path() +
                         std::string(::basename(name));     // 加上进程名
  base::Logger::setLogLevel(g_config_parser->log_level());  //设置日志级别
  if (!foreground) {  // 如果是前台运行，日志打到标准输出
    g_asyncLog.reset(
        new base::AsyncLogging(name_str, g_config_parser->log_roll_size()));
    g_asyncLog->start();  //会等待日志线程初始化好
    base::Logger::setOutput(AsyncOutput);
  }
}

}  // ns trans_gate
}  // ns udisk

using namespace uevent;
using namespace udisk::common;
using namespace udisk::trans_gate;

void sTerminate(int signo) {
  std::cout << "Get a SIGTERM signal, signo=" << signo << std::endl;
  exit(EXIT_SUCCESS);
  return;
}

int main(int argc, char **argv) {
  //  sigset(SIGTERM, sTerminate);
  std::string conf_file;
  bool foreground(false);
  // 解析命令行输入
  while (true) {
    int c = -1;
    int index = -1;
    c = getopt_long(argc, argv, short_options, long_options, &index);
    if (c == -1) {
      break;
    }
    switch (c) {
      case 'v':
        print_version(argv[0]);
        std::exit(0);
      case 'c':
        conf_file = std::string(optarg);
        break;
      case 'h':
        print_help(argv[0]);
        std::exit(0);
      case 'f':
        foreground = true;
        break;
      default:
        print_help(argv[0]);
        std::exit(-1);
    }
  }
  FlockUtil file_lock("/tmp/trans_gate.lck");
  if (!file_lock.lock()) {
    LOG_FATAL << "trans_gate server has exist";
  }
  if (conf_file.empty()) {  // 需要指定配置文件
    LOG_FATAL << "need specify the config file";
  }
  g_config_parser.reset(new MyConfigParser(conf_file));
  g_config_parser->Init();
  if (!foreground) {
    init_daemon();
  }
  InitLogging(argv[0], foreground);  // 初始化异步日志系统,完成后继续执行
  LOG_INFO << "==================Trans Gate Restart======================";
  g_name_container.reset(new NameContainer(g_config_parser->zk_server()));
  // Init 阻塞直达与zk连接成功，或者是报错
  if (g_name_container->Init() == -1) {
    LOG_SYSFATAL << "can't connect to zookeeper";
  }
  ZkNameOfSetPtr global_set_ptr(new ZkNameOfSet(ConfigParser::kGlobalSetName));
  g_name_container->AddZkNameOfSet(global_set_ptr);
  EventLoopLibevent loop("main_thread", TransLoopHandle::CreateMyself);
  unlink(g_config_parser->listen_unix_addr().c_str());
  UsockAddress listen_addr(g_config_parser->listen_unix_addr());
  g_listener.reset(
      new TransGateListener(&loop, listen_addr, "TransGateListener"));
  g_listener->SetConnectionSuccessCb(TransLoopHandle::QemuConnSuccessCb);
  g_listener->SetConnectionClosedCb(TransLoopHandle::QemuConnClosedCb);
  g_listener->SetMessageReadCb(TransLoopHandle::QemuConnReadCb);
  g_listener->SetCreateLoopHandleCb(TransLoopHandle::CreateMyself);
  g_listener->SetThreadNum(g_config_parser->thread_num());
  g_listener->Start();
  return 0;
}
