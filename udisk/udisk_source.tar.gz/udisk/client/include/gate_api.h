#ifndef UDISK_GATE_API_H_
#define UDISK_GATE_API_H_

#include <stddef.h>
#include <stdint.h>
#include <sys/queue.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef void (*CB_GET_DEVICE)(void *, void *);

struct udisk_info {
  uint32_t block_size;
  uint64_t num_blocks;
};

enum UDISK_IO_TYPE {
  READ = 0,
  WRITE = 1,
};

struct udisk_io {
  enum UDISK_IO_TYPE type;
  uint64_t flowno;
  uint64_t shard_idx;
  uint64_t offset_blocks;
  uint64_t num_blocks;
  struct iovec *iovs;
  int iovcnt;
  int ret;
  void *ctx;
  TAILQ_ENTRY(udisk_io) link;
};

int gate_init(const char *config_file);

int get_udisk_device(const char *extern_id, CB_GET_DEVICE cb, void *ctx);

void put_udisk_device(void *device);

int get_udisk_info(void *device, struct udisk_info *info);

// struct udisk_io由使用者申请/释放
// 提交一个io任务到udisk_handle，通过gate_io_poll轮询获取结果
int gate_io_submit(void *device, struct udisk_io *io);

// 批量提交io
// 返回值是成功提交的io个数
size_t gate_io_batch_submit(void *device, struct udisk_io **ios, size_t cnt);

// 指定获取多少个已完成的io任务，返回值表示获取到的io任务个数，不超过cnt，返回0表示当前没有已完成的io任务
size_t gate_io_poll(void *device, struct udisk_io **ios, size_t cnt);

#ifdef __cplusplus
}
#endif

#endif