#include "udisk_device.h"

#include "gate.h"
#include "manager_thread.h"
#include "udisk_controller.h"

namespace udisk {
namespace gate {

UDiskDevice::~UDiskDevice() {
  for (auto it = workers_.begin(); it != workers_.end();
       it = workers_.erase(it)) {
    (*it)->Reset();
  }
  free(batch_io_);
}

void UDiskDevice::LoginAsync(std::function<void(bool, void*)> cb) {
  login_cb_ = cb;
  ManagerThread::Instance()->LoginHydra(this);
}

void UDiskDevice::LoginFinish(bool success,
                              const ucloud::udisk::UDiskLoginResponse& rsp) {
  if (success == false) {
    ucloud::udisk::OdinWarningRequest warn_request;
    // ip:port:extern_id 拼成uuid, 唯一标识这个告警
    std::string uuid = g_config_parser->listen_ip() + ":" +
                       std::to_string(g_config_parser->listen_port()) + ":" +
                       extern_id_;
    warn_request.set_uuid(uuid);
    warn_request.set_item_id(common::ConfigParser::kLoginFailedItemId);
    warn_request.set_info("login failed in vhost_gate");
    warn_request.set_time(base::Timestamp::now().secondsSinceEpoch());
    // 由于login 失败无法获取set，发给机房的全局odin
    ManagerThread::Instance()->WarningToOdin(
        warn_request, common::ConfigParser::kGlobalSetName);
  }
  loop_->RunInLoop(
      std::bind(&UDiskDevice::LoginFinishInLoop, this, success, rsp));
}

void UDiskDevice::LoginFinishInLoop(
    bool success, const ucloud::udisk::UDiskLoginResponse& rsp) {
  if (!success) {
    login_cb_(false, this);
    return;
  }
  // 初始化设备
  lc_id_ = rsp.lc_id();
  lc_random_id_ = rsp.lc_random_id();
  lc_set_name_ = rsp.set_name();
  size_ = rsp.size();
  // 初始化io线程
  threads_ = GetThreadNumber();
  batch_io_ = (struct CachedBatchIo *)malloc(threads_ * sizeof(struct CachedBatchIo));
  ULOG_INFO << "udisk device " << extern_id_ << " use " << threads_
            << " threads";
  for (uint32_t i = 0; i < threads_; ++i) {
    batch_io_[i].count = 0;
    UDiskWorker* w = g_controller->GetUDiskWorker();
    if (!w) {
      ULOG_ERROR << "get udisk worker fail";
      success = false;
      break;
    }
    // 初始化udisk_worker
    w->Init(extern_id_, rsp);
    ULOG_INFO << "get udisk worker " << w;
    workers_.push_back(w);
  }
  if (!success) {
    ULOG_ERROR << extern_id_ << " get udisk worker fail";
    for (auto it = workers_.begin(); it != workers_.end();
         it = workers_.erase(it)) {
      (*it)->Reset();
    }
  }
  login_cb_(success, this);
  return;
}

uint32_t UDiskDevice::GetThreadNumber() {
  // TODO: 初始化后根据盘内存，大小等信息确定线程数，暂时设定使用2个线程
  return 2;
}

size_t UDiskDevice::SubmitIo(struct udisk_io** ios, size_t cnt) {
  assert(threads_ != 0);
  uint32_t i, thread_idx;
  size_t idx;
  for (i = 0; i < cnt; ++i) {
    thread_idx = ios[i]->shard_idx % threads_;
    idx = batch_io_[thread_idx].count++;
    batch_io_[thread_idx].io[idx] = ios[i];
  }
  for (i = 0; i < threads_; ++i) {
    if (batch_io_[i].count != 0) {
      // 目前spdk_ring的批量入队只有可能全成功或全失败，不存在只入队一部分的情况
      size_t ret = workers_[i]->SubmitIo(batch_io_[i].io, batch_io_[i].count);
      if (ret != batch_io_[i].count) {
        ULOG_FATAL << "submit io to udisk worker fail, extern_id: " << extern_id_
                   << ", thread_index: " << i
                   << ", udisk_worker: " << workers_[i];
      }
      // 清空批量提交缓存
      batch_io_[i].count = 0;
    }
  }
  return cnt;
}

size_t UDiskDevice::GetIoCompleted(struct udisk_io** ios, size_t cnt) {
  size_t complete_cnt = 0;
  size_t ret;
  for (uint32_t i = 0; i < threads_; ++i) {
    if (complete_cnt == cnt) {
      break;
    }
    ret = workers_[i]->GetIoCompleted(&ios[complete_cnt], cnt - complete_cnt);
    complete_cnt += ret;
  }

  return complete_cnt;
}

}  // namespace gate
}  // namespace udisk
