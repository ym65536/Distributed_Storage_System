#ifndef UDISK_GATE_H_
#define UDISK_GATE_H_

#include <memory>
#include "my_config_parser.h"

namespace udisk {

namespace common {
class NameContainer;
}

namespace gate {

class UDiskController;

extern std::unique_ptr<common::NameContainer> g_name_container;
extern std::unique_ptr<MyConfigParser> g_config_parser;
extern std::unique_ptr<UDiskController> g_controller;

}  // namespace gate
}  // namespace udisk

#endif
