#ifndef UDISK_GATE_FRAG_IO_REQUEST_H_
#define UDISK_GATE_FRAG_IO_REQUEST_H_

#include <memory>
#include <ustevent/base/timestamp.h>
#include <ustevent/callbacks.h>
#include "gate_io_proto.h"
#include "io_util.h"

namespace udisk {

namespace gate {

class UDiskWorker;

struct FragIORequest {
  explicit FragIORequest(UDiskWorker* udisk_worker);
  ~FragIORequest() {
    if (iovs) {
      free(iovs);
    }
  }
  inline void SetTimerCount(int count) { timer_count = count; }
  static void SendData(struct iovec* iov,
                       const uevent::ConnectionUeventPtr& conn);
  int SendFragIO();
  int DoSendFragIO(const uevent::ConnectionUeventPtr& conn);
  void DecTimerCount();
  void TimeoutCb();
  uint64_t begin_sector;
  uint64_t secnum;
  uint32_t chunk_id;
  common::GateIORequestHead gate_req_head;
  UDiskWorker* worker;
  int timer_count;
  int retry_times;
  base::Timestamp start_time;
  int64_t chunk_conn_id;  // 记录要发向的chunk的连接id
  struct iovec* iovs;
  int iovcnt;
};

}  // namespace gate
}  // namespace udisk

#endif
