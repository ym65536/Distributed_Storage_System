#include "udisk_controller.h"
#include <ustevent/base/logging.h>
#include <ustevent/libevent/posix_stack.h>

using namespace uevent;

namespace udisk {
namespace gate {

void UDiskController::StartThreadPool() {
  Option option;
  option.worker_strategy = Option::kEmptyOne;
  stack_.reset(new PosixStack(thread_num_, option, UDiskWorker::CreateMyself));
  stack_->Start();
}

void UDiskController::Start() {
  loop_ = work_thread_.StartWorker()->eventloop();
  loop_->RunInLoop(std::bind(&UDiskController::StartThreadPool, this));
}

void UDiskController::GetUDiskDevice(const std::string &extern_id,
                                     std::function<void(void *)> cb) {
  loop_->RunInLoop(
      std::bind(&UDiskController::GetUDiskDeviceInLoop, this, extern_id, cb));
}

void UDiskController::GetUDiskDeviceInLoop(const std::string &extern_id,
                                           std::function<void(void *)> cb) {
  UDiskDevice *device = new UDiskDevice(extern_id, loop_);
  assert(device != nullptr);
  ULOG_INFO << "create udisk device " << extern_id;
  device->LoginAsync(std::bind(&UDiskController::LoginCallback, this,
                               std::placeholders::_1, std::placeholders::_2,
                               cb));
}

void UDiskController::LoginCallback(bool success, void *device,
                                    std::function<void(void *)> cb) {
  UDiskDevice *udisk_device = (UDiskDevice *)device;
  if (success) {
    ULOG_INFO << "udisk device login success " << udisk_device->extern_id();
    if (devices_.find(udisk_device->extern_id()) != devices_.end()) {
      ULOG_FATAL << "device already exists, extern_id: "
                 << udisk_device->extern_id();
    }
    devices_[udisk_device->extern_id()] = udisk_device;
    cb(udisk_device);
  } else {
    ULOG_ERROR << "udisk device login fail " << udisk_device->extern_id();
    delete udisk_device;
    cb(nullptr);
  }
}

void UDiskController::PutUDiskDevice(UDiskDevice *device) {
  assert(device != nullptr);
  auto it = devices_.find(device->extern_id());
  if (it == devices_.end()) {
    ULOG_WARN << "unknown device: " << device
              << ", extern_id: " << device->extern_id();
    return;
  }
  ULOG_INFO << "delete udisk device " << device->extern_id();
  delete it->second;
  devices_.erase(it);
}

UDiskWorker *UDiskController::GetUDiskWorker() {
  Worker *worker = stack_->GetWorker();
  if (!worker) {
    ULOG_ERROR << "no empty worker";
    return nullptr;
  }
  worker->IncRefs();
  UDiskWorker *w =
      reinterpret_cast<UDiskWorker *>(worker->eventloop()->GetLoopHandle());
  w->IncRefs();
  return w;
}

}  // namespace gate
}  // namespace udisk