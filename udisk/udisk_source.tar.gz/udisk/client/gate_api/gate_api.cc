#include "gate_api.h"
#include <ustevent/base/async_logging.h>
#include <ustevent/base/logging.h>
#include "zk_name_container.h"
#include "udisk_types.h"
#include "manager_thread.h"
#include "my_config_parser.h"
#include "udisk_controller.h"
#include "udisk_device.h"

namespace udisk {
namespace gate {

std::unique_ptr<base::AsyncLogging> g_asyncLog;
std::unique_ptr<common::NameContainer> g_name_container;
std::unique_ptr<MyConfigParser> g_config_parser;
std::unique_ptr<UDiskController> g_controller;

static void AsyncOutput(const char* msg, int len) {
  g_asyncLog->append(msg, len);
}

static void InitLogging() {
  char name[256];
  strncpy(name, "vhost_gate", 256);
  std::string name_str = g_config_parser->log_common_path() +
                         std::string(::basename(name));     // 加上进程名
  base::Logger::setLogLevel(g_config_parser->log_level());  //设置日志级别
  g_asyncLog.reset(
      new base::AsyncLogging(name_str, g_config_parser->log_roll_size(),
                             1, true));
  g_asyncLog->start();  //会等待日志线程初始化好
  base::Logger::setOutput(AsyncOutput);
}

static int __gate_init(const char* config_file) {
  if (!config_file) {
    ULOG_FATAL << "need specify the config file";
  }
  std::string conf_file(config_file);
  g_config_parser.reset(new MyConfigParser(conf_file));
  g_config_parser->Init();

  // 初始化异步日志系统
  InitLogging();
  // 初始化udisk zk服务
  g_name_container.reset(
      new common::NameContainer(g_config_parser->zk_server()));
  // Init 阻塞直达与zk连接成功，或者是报错
  if (g_name_container->Init() == -1) {
    ULOG_SYSFATAL << "can't connect to zookeeper";
  }
  common::ZkNameOfSetPtr udisk_set_ptr(
      new common::ZkNameOfSet(common::ConfigParser::kGlobalSetName));
  udisk_set_ptr->AddNamePath(common::ConfigParser::kHydraName,
                             g_config_parser->hydra_zk_path());
  udisk_set_ptr->AddNamePath(MyConfigParser::kGlobalOdinName,
                             g_config_parser->global_odin_zk_path());
  // hydra等zk节点获取可能败, gate任然正常拉起
  // 后续使用这个节点时报错，并且重新出发获取
  g_name_container->AddZkNameOfSet(udisk_set_ptr);
  ucloud::uns::NameNodeContent nnc;
  if (g_name_container->GetNNCForName(common::ConfigParser::kGlobalSetName,
                                      common::ConfigParser::kHydraName,
                                      nnc) == -1) {
    ULOG_FATAL << "get nnc for hydra error, can't start";
  }

  // 启动管理线程
  ManagerThread::Instance()->Start();
  // 启动io线程池
  UDiskController* controller = new UDiskController("ctrl");
  controller->SetThreadNum(g_config_parser->thread_num());
  controller->Start();
  g_controller.reset(controller);
  ULOG_INFO << "gate init success";
  return 0;
}

static int __get_udisk_device(const char* extern_id, CB_GET_DEVICE cb,
                              void* ctx) {
  if (!extern_id) {
    ULOG_ERROR << "extern_id invalid";
    return -1;
  }
  std::string id(extern_id);
  g_controller->GetUDiskDevice(id, std::bind(cb, std::placeholders::_1, ctx));
  return 0;
}

static void __put_udisk_device(void* device) {
  UDiskDevice* udisk_device = (UDiskDevice*)device;
  g_controller->PutUDiskDevice(udisk_device);
}

static int __gate_udisk_info(void* device, struct udisk_info* info) {
  if (!device) {
    ULOG_ERROR << "device invalid";
    return -1;
  }
  UDiskDevice* udisk_device = (UDiskDevice*)device;
  info->block_size = SECTOR_SIZE;
  info->num_blocks = (uint64_t)udisk_device->size() * (GB_SIZE / SECTOR_SIZE);
  return 0;
}

static int __gate_io_submit(void* device, struct udisk_io* io) {
  if (!device) {
    ULOG_ERROR << "device invalid";
    return -1;
  }
  UDiskDevice* udisk_device = (UDiskDevice*)device;
  if (1 != udisk_device->SubmitIo(&io, 1)) {
    ULOG_ERROR << "submit io fail, extern_id:" << udisk_device->extern_id();
    return -1;
  }
  return 0;
}

static size_t __gate_io_batch_submit(void* device, struct udisk_io** ios,
                                     size_t cnt) {
  if (!device) {
    ULOG_ERROR << "device invalid";
    return -1;
  }
  UDiskDevice* udisk_device = (UDiskDevice*)device;
  size_t count = udisk_device->SubmitIo(ios, cnt);
  if (count != cnt) {
    ULOG_ERROR << "did not submit all ios, expected: " << cnt
               << ", actually: " << count;
  }
  return count;
}

static size_t __gate_io_poll(void* device, struct udisk_io** ios, size_t cnt) {
  if (!device) {
    ULOG_ERROR << "device invalid";
    return -1;
  }
  UDiskDevice* udisk_device = (UDiskDevice*)device;
  return udisk_device->GetIoCompleted(ios, cnt);
}

}  // namespace gate
}  // namespace udisk

int gate_init(const char* config_file) {
  return udisk::gate::__gate_init(config_file);
}

int get_udisk_device(const char* extern_id, CB_GET_DEVICE cb, void* ctx) {
  return udisk::gate::__get_udisk_device(extern_id, cb, ctx);
}

void put_udisk_device(void* device) { udisk::gate::__put_udisk_device(device); }

int get_udisk_info(void* device, struct udisk_info* info) {
  return udisk::gate::__gate_udisk_info(device, info);
}

int gate_io_submit(void* device, struct udisk_io* io) {
  return udisk::gate::__gate_io_submit(device, io);
}

size_t gate_io_batch_submit(void* device, struct udisk_io** ios, size_t cnt) {
  return udisk::gate::__gate_io_batch_submit(device, ios, cnt);
}

size_t gate_io_poll(void* device, struct udisk_io** ios, size_t cnt) {
  return udisk::gate::__gate_io_poll(device, ios, cnt);
}
