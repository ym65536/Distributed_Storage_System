#include "route_manager.h"
#include "udisk_worker.h"
#include "udisk_types.h"

namespace udisk {
namespace gate {

RouteManager::RouteManager(UDiskWorker* worker)
    : worker_(worker),
      is_ready_(false),
      size_(worker->GetLcSize()),
      chunk_route_cache_(UDISK_PC_COUNT_GB(size_)) {}

RouteManager::~RouteManager() { ULOG_DEBUG << "route manager destruct"; }

// 在IO线程中执行
void RouteManager::UpdateClusterMap(
    const ucloud::udisk::ClusterInfoPb& cluster_info,
    const ::google::protobuf::RepeatedPtrField<::ucloud::udisk::ChunkInfoPb>&
        chunk_info,
    const ::google::protobuf::RepeatedPtrField<::ucloud::udisk::PGInfoPb>&
        pg_info) {
  // 如果集群信息已经初始化，而且版本号相同,直接返回
  if (cluster_map_.IsInit() &&
      cluster_map_.GetClusterVersion() == cluster_info.version()) {
    return;
  }
  uint64_t old_version = 0;  // 没有初始化，上次的version显示为0
  if (cluster_map_.IsInit()) {
    old_version = cluster_map_.GetClusterVersion();
  }
  ULOG_INFO << "route version changed, old: " << old_version
            << " new: " << cluster_info.version();
  cluster_map_.Init(cluster_info);
  for (auto i = chunk_info.begin(); i != chunk_info.end(); ++i) {
    cluster_map_.ChunkAdd(*i);
  }
  for (auto i = pg_info.begin(); i != pg_info.end(); ++i) {
    cluster_map_.PGAdd(*i);
  }
  // route ready 之后需要触发pending住的的IO
  if (!is_ready_) {
    // 构建哈希环，可能比较费时, 由于不变只构建一次
    hash_ring_.Init(cluster_map_);
    // const hash_ring::HashRing::VirtualNodeMap& node_map =
    // hash_ring_.NodeMap();
    // for (auto it = node_map.begin(); it != node_map.end(); ++it) {
    // ULOG_DEBUG << "pg_hash_value: " << it->first
    //            << " pg_key: " << it->second.key();
    // }
    is_ready_ = true;
    worker_->SendPendingIO();
  }
}

void RouteManager::GetChunkRoute(uint32_t lc_id, uint32_t pc_no,
                                 uint32_t lc_random_id, uint64_t* version,
                                 uint32_t* pg_id, uint32_t* chunk_id,
                                 ConnectorUeventPtr* ctor) {
  // 只有在route ready 才会调用这个函数
  assert(is_ready_ == true);
  //如果cache中存在路由, 且与集群版本号相同直接返回
  *version = cluster_map_.GetClusterVersion();
  if (chunk_route_cache_[pc_no].version == *version) {
    *pg_id = chunk_route_cache_[pc_no].pg_id;
    *ctor = chunk_route_cache_[pc_no].ctor;
    *chunk_id = chunk_route_cache_[pc_no].chunk_id;
    return;
  }
  //查找hash环获取路由，并且保存在cache中
  *pg_id = hash_ring_.GetPGId(lc_id, pc_no, lc_random_id);
  ucloud::udisk::ChunkInfoPb* chunk_info_ptr;
  bool ret = cluster_map_.GetPrimaryChunkInfoPtr(*pg_id, &chunk_info_ptr);
  assert(ret == true);
  (void)ret;
  *chunk_id = chunk_info_ptr->id();
  uevent::UsockAddress chunk_addr(chunk_info_ptr->ip(),
                                  chunk_info_ptr->io_port());
  *ctor = worker_->GetChunkConnector(chunk_addr);
  chunk_route_cache_[pc_no].version = *version;
  chunk_route_cache_[pc_no].pg_id = *pg_id;
  chunk_route_cache_[pc_no].ctor = *ctor;
  chunk_route_cache_[pc_no].chunk_id = *chunk_id;
}

}  // namespace gate
}  // namespace udisk
