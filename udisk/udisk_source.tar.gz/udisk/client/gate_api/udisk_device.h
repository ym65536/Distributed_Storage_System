#ifndef UDISK_GATE_UDISK_DEVICE_H_
#define UDISK_GATE_UDISK_DEVICE_H_

#include <functional>
#include <vector>
#include "udisk_worker.h"
#include "udisk_message.h"

namespace udisk {
namespace gate {

class UDiskDevice {
 public:
  explicit UDiskDevice(const std::string &extern_id, uevent::EventLoop *loop)
      : extern_id_(extern_id), threads_(0), loop_(loop) {}
  ~UDiskDevice();

  void LoginAsync(std::function<void(bool, void *)> cb);
  void LoginFinish(bool success, const ucloud::udisk::UDiskLoginResponse &rsp);
  size_t SubmitIo(struct udisk_io **ios, size_t cnt);
  size_t GetIoCompleted(struct udisk_io **ios, size_t cnt);
  std::string extern_id() const { return extern_id_; }
  uint32_t size() const { return size_; }

 private:
  void LoginFinishInLoop(bool success,
                         const ucloud::udisk::UDiskLoginResponse &rsp);
  uint32_t GetThreadNumber();

  std::string extern_id_;
  uint32_t lc_id_;
  uint32_t lc_random_id_;
  std::string lc_set_name_;
  uint32_t size_;

  uint32_t threads_;
  struct CachedBatchIo {
    struct udisk_io* io[128];
    size_t count;
  };
  struct CachedBatchIo *batch_io_; // 每线程一个CachedBatchIo，用于缓存准备批量提交的io
  std::vector<UDiskWorker *> workers_;
  uevent::EventLoop *loop_;
  std::function<void(bool, void *)> login_cb_;
};

}  // namespace gate
}  // namespace udisk

#endif
