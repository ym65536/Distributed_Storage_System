#ifndef UDISK_GATE_MANAGER_THREAD_H_
#define UDISK_GATE_MANAGER_THREAD_H_

#include <set>
#include <map>
#include <memory>
#include <ustevent/worker_thread.h>
#include <ustevent/libevent/listener_libevent.h>
#include "umessage.h"

namespace uevent {
class EventLoop;
class ListenerUevent;
class ConnectionUevent;
class ConnectorUevent;
}

namespace udisk {
namespace gate {

class MyConfigParser;
class UDiskWorker;
class LoginHydra;
class UDiskDevice;
// timestamp <-> stat info
typedef std::map<uint32_t, ucloud::udisk::GateChunkIOStats> ChunkStatPairMap;
// extern_id <-> chunks stat
typedef std::map<std::string, vector<ChunkStatPairMap>> ChunkStatsMap;

// timestamp <-> stat info
typedef std::map<uint32_t, ucloud::udisk::GatePCIOStats> PCStatPairMap;
// extern_id <-> chunks stat
typedef std::map<std::string, vector<PCStatPairMap>> PCStatsMap;

typedef std::map<std::string, std::pair<std::string, uint32_t>> LCTimeoutMap;
class ManagerThread {
 public:
  // handle_id,UDiskWorker* 组合才能唯一标识一个handle
  typedef std::pair<int64_t, UDiskWorker*> HandleEntry;
  typedef std::map<std::string, uevent::ConnectorUeventPtr>
      SetNameToConnectorMap;

  static ManagerThread* Instance();
  inline uevent::EventLoop* GetLoop() { return loop_; }
  uevent::ConnectorUeventPtr CreateHydraConnector();
  uevent::ConnectionUeventPtr GetMetaServerConnection(
      const std::string& set_name);
  uevent::ConnectionUeventPtr GetOdinConnection(const std::string& set_name);

  ChunkStatsMap& GetChunkStats() { return chunk_stats_; }
  PCStatsMap& GetPCStats() { return pc_stats_; }

  // thread safe
  void Start();
  void StartInLoop();

  void LoginHydra(UDiskDevice* device);
  void GetMetaData(UDiskWorker* handle);
  void Heartbeat(UDiskWorker* handle);
  void DelLoginHydraPtr(UDiskWorker* handle, int64_t handle_id);
  void ReportOdinTimer();
  void WarningToOdin(ucloud::udisk::OdinWarningRequest& warn_request,
                     const std::string& set_name);
  void ReportIOTimeout(const std::string& extern_id, uint32_t retry_times,
                       const std::string& set_name);

 private:
  typedef std::map<HandleEntry, std::vector<ucloud::udisk::LCIOStats>>
      UDiskStatMap;

  ManagerThread();
  ~ManagerThread();
  void ListenerInit();
  void HydraConnSuccessCb(const uevent::ConnectionUeventPtr& conn);
  void HydraConnClosedCb(const uevent::ConnectionUeventPtr& conn);
  void ManConnSuccessCb(const uevent::ConnectionUeventPtr& conn);
  void ManConnClosedCb(const uevent::ConnectionUeventPtr& conn);
  void MetaServerConnSuccessCb(const uevent::ConnectionUeventPtr& conn);
  void MetaServerConnClosedCb(const uevent::ConnectionUeventPtr& conn);
  void OdinConnSuccessCb(const uevent::ConnectionUeventPtr& conn);
  void OdinConnClosedCb(const uevent::ConnectionUeventPtr& conn);
  void LoginHydraInLoop(UDiskDevice* device);
  void GetMetaDataInLoop(UDiskWorker* handle);
  void HeartbeatInLoop(
      HandleEntry& entry, ucloud::udisk::LCIOStats& iostat,
      std::vector<ucloud::udisk::GateChunkIOStats>& chunk_stats,
      std::vector<ucloud::udisk::GatePCIOStats>& pc_stats);
  void StatsInfoHandle(
      HandleEntry& entry, ucloud::udisk::LCIOStats& iostat,
      std::vector<ucloud::udisk::GateChunkIOStats>& chunk_stats,
      std::vector<ucloud::udisk::GatePCIOStats>& pc_stats);
  void WarningToOdinInLoop(ucloud::udisk::OdinWarningRequest& warn_request,
                           const std::string& set_name);
  void LoginResponseCb(const uevent::UMessagePtr& um, UDiskDevice* device,
                       const uevent::ConnectorUeventPtr& ctor);
  void LoginTimeoutCb(UDiskDevice* device,
                      const uevent::ConnectorUeventPtr& ctor);
  void LoginHydraFinish(bool success, UDiskDevice* device);
  void GetMetaDataResponseCb(const uevent::UMessagePtr& um, HandleEntry entry);
  void GetMetaDataTimeoutCb(HandleEntry entry);
  void HeartbeatResponseCb(const uevent::UMessagePtr& um, HandleEntry entry);
  void HeartbeatTimeoutCb(HandleEntry entry);
  void ReportIOStatResponseCb(const uevent::UMessagePtr& um);
  void ReportIOStatTimeout();
  void OdinWarningResponseCb(const uevent::UMessagePtr& um);
  void OdinWarningTimeout();
  void ReportIOTimeoutInLoop(const std::string& extern_id, uint32_t retry_times,
                             const std::string& set_name);
  void ReportOdinIOTimeout();

  uevent::WorkerThread work_thread_;
  uevent::EventLoop* loop_;
  // 管理线程的listener，接收PB请求
  std::shared_ptr<uevent::ListenerUevent> listener_;
  ucloud::udisk::UDiskLoginResponse login_hydra_rsp_;
  SetNameToConnectorMap metaserver_connector_map_;
  SetNameToConnectorMap odin_connector_map_;
  static ManagerThread* instance_;
  UDiskStatMap udisk_stats_;
  ChunkStatsMap chunk_stats_;
  PCStatsMap pc_stats_;
  LCTimeoutMap lc_timeout_;
};

}  // namespace gate
}  // namespace udisk

#endif
