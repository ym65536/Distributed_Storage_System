#include "io_request.h"
#include <ustevent/base/logging.h>
#include <ustevent/libevent/connection_libevent.h>
#include "udisk_types.h"
#include "udisk_worker.h"
#include "frag_io_request.h"
#include "io_util.h"

namespace udisk {

namespace gate {

// IO 按1MB 切片
#define SECTOR_PER_SLICE 2048

using namespace uevent;
using namespace base;
using namespace common;

IORequest::IORequest(UDiskWorker* worker, struct udisk_io* io)
    : worker_(worker),
      io_(io),
      end_sector_(io_->offset_blocks + io_->num_blocks),  //结束位置，便于计算
      start_time_(Timestamp::now()) {  // io开始时间,用于延时统计
}

IORequest::~IORequest() {
  for (auto it = frag_req_vec_.begin(); it != frag_req_vec_.end(); it++) {
    delete *it;  //析构包含的分片请求
  }
}

void IORequest::Init() {
  FragIORequest* frag_io_req = NULL;
  int iov_idx = 0, start_iov_idx;
  size_t buf_off = 0, start_buf_off;
  struct iovec* vecs;

  ULOG_TRACE << "io request from vhost:" << DumpUDiskIO(io_);
  for (uint64_t b = io_->offset_blocks,
                e = b - b % SECTOR_PER_SLICE + SECTOR_PER_SLICE;
       b < end_sector_; e += SECTOR_PER_SLICE) {
    if (e > end_sector_) {
      e = end_sector_;
    }
    frag_io_req = new FragIORequest(worker_);
    start_iov_idx = iov_idx;
    start_buf_off = buf_off;

    //按1M为单元切割iovec
    if (ioutil::IovecGetIdx(io_->iovs, io_->iovcnt, &iov_idx, &buf_off,
                            (e - b) * SECTOR_SIZE)) {
      ULOG_FATAL << "get iovec fail, " << iov_idx << ", " << buf_off;
    }
    ULOG_TRACE << "io split on " << iov_idx << ", " << buf_off;
    frag_io_req->iovcnt = iov_idx - start_iov_idx;
    if (buf_off) {
      ++frag_io_req->iovcnt;
    }
    vecs = (struct iovec*)malloc(frag_io_req->iovcnt * sizeof(struct iovec));
    if (frag_io_req->iovcnt == 1) {
      vecs[0].iov_base =
          (char*)io_->iovs[start_iov_idx].iov_base + start_buf_off;
      vecs[0].iov_len =
          (buf_off) ? (buf_off - start_buf_off)
                    : (io_->iovs[start_iov_idx].iov_len - start_buf_off);
      ULOG_TRACE << "[0]base: " << vecs[0].iov_base
                 << ", len: " << vecs[0].iov_len;
    } else {
      for (int i = 0; i < frag_io_req->iovcnt; ++i) {
        vecs[i].iov_base =
            (char*)io_->iovs[start_iov_idx + i].iov_base + start_buf_off;
        // 判断最后一个iovec是否需要切割
        if (i == frag_io_req->iovcnt - 1 && buf_off != 0) {
          vecs[i].iov_len = buf_off - start_buf_off;
        } else {
          vecs[i].iov_len =
              io_->iovs[start_iov_idx + i].iov_len - start_buf_off;
        }
        // 只有第一个iovec需要start_buf_off定位
        start_buf_off = 0;
        ULOG_TRACE << "[" << i << "]base: " << vecs[i].iov_base
                   << ", len: " << vecs[i].iov_len;
      }
    }
    frag_io_req->iovs = vecs;

    frag_io_req->begin_sector = b;
    frag_io_req->secnum = e - b;
    frag_bit_set_[frag_req_vec_.size()] = 1;
    frag_req_vec_.push_back(frag_io_req);
    b = e;
  }
  ULOG_TRACE << "frag size: " << frag_req_vec_.size();
  if (frag_req_vec_.size() > 1024) {
    ULOG_FATAL << "io frag size is too large";
  }
}

int IORequest::Send() {
  if (worker_->RouteIsReady() == false) {
    ULOG_DEBUG << "udisk route is not ready";
    return -1;
  }
  //遍历所有分片，依次发送
  for (uint32_t i = 0; i < frag_req_vec_.size(); i++) {
    frag_req_vec_[i]->gate_req_head.flowno = io_->flowno;
    frag_req_vec_[i]->gate_req_head.magic = 0xf123987a;
    frag_req_vec_[i]->gate_req_head.fragno = i;
    frag_req_vec_[i]->gate_req_head.cmd = io_->type;
    //没有检查返回值，只要执行了就放入inflight队列,如果失败，依赖超时重发
    frag_req_vec_[i]->SendFragIO();
  }
  return 0;
}

// 为了实现IO的保序，
// 有重叠的的区域必须等待之前IO应答，即与pending_list
// 中位于本IO之前所有的IO都不重叠才能发送，不要考虑之后的IO
bool IORequest::CheckOverlap() {
  for (auto it = worker_->GetInflightList().begin();
       it != worker_->GetInflightList().end(); it++) {
    if (end_sector_ <= (*it)->GetBeginSector() ||
        io_->offset_blocks >= (*it)->GetEndSector()) {
      continue;  //无重叠继续下一个
    }
    ULOG_TRACE << "has overlap with inflight io";
    return true;  // 有重叠， 不发送直接返回
  }
  for (auto it = worker_->GetPendingList().begin();
       it != worker_->GetPendingList().end() &&
       (*it)->GetFlowno() != io_->flowno;
       it++) {
    if (end_sector_ <= (*it)->GetBeginSector() ||
        io_->offset_blocks >= (*it)->GetEndSector()) {
      continue;  //无重叠继续下一个
    }
    ULOG_TRACE << "has overlap with pending io";
    return true;  // 有重叠， 不发送直接返回
  }
  return false;
}

void IORequest::Response() {
  ULOG_TRACE << "io response to vhost:" << DumpUDiskIO(io_);
  Timestamp end_time(Timestamp::now());
  if (io_->type == READ) {      // 读请求需要带上数据
    worker_->IncReadIOCount();  // 记录IO的统计信息
    worker_->IncReadBytesCount(io_->num_blocks * SECTOR_SIZE);
    worker_->AddReadLatency(base::timeDifferenceUs(end_time, start_time_));
    worker_->set_last_read_tick(end_time);
  } else {
    worker_->IncWriteIOCount();  // 记录IO的统计信息
    worker_->IncWriteBytesCount(io_->num_blocks * SECTOR_SIZE);
    worker_->AddWriteLatency(base::timeDifferenceUs(end_time, start_time_));
    worker_->set_last_write_tick(end_time);
  }
  worker_->CompleteIo(io_);
}

void IORequest::DecTimerCount() {
  for (uint32_t i = 0; i < frag_req_vec_.size(); i++) {
    if (frag_bit_set_[i] == 1) {  //没有收到回复才需要减计数
      frag_req_vec_[i]->DecTimerCount();
    }
  }
}

}  // namespace gate
}  // namespace udisk
