#include "udisk_worker.h"
#include <sys/time.h>
#include <event2/event.h>
#include <ustevent/base/logging.h>
#include <ustevent/libevent/connector_libevent.h>
#include <ustevent/libevent/listener_libevent.h>
#include <ustevent/libevent/eventloop_libevent.h>
#include <ustevent/socket_util.h>
#include "msgr.h"
#include "udisk_types.h"
#include "likely.h"
#include "gate_io_proto.h"
#include "gate.h"
#include "io_request.h"
#include "frag_io_request.h"
#include "manager_thread.h"
#include "route_manager.h"
#include "my_config_parser.h"
#include "io_util.h"

namespace udisk {
namespace gate {

using std::placeholders::_1;
using std::placeholders::_2;
using namespace uevent;
using namespace base;
using namespace common;

LoopHandle* UDiskWorker::CreateMyself(EventLoop* loop) {
  return reinterpret_cast<LoopHandle*>(new UDiskWorker(loop));
}

UDiskWorker::UDiskWorker(EventLoop* loop)
    : LoopHandle(loop),
      handle_id_(0),
      conn_is_reset_(false),
      last_read_tick_(0),
      last_write_tick_(0),
      io_timer_count_(200),
      event_idx_(-1) {}

bool UDiskWorker::Init(const std::string& extern_id,
                       const ucloud::udisk::UDiskLoginResponse& rsp) {
  if (!VhostIoInit()) {
    ULOG_ERROR << "VhostIoInit fail, extern_id:" << extern_id_;
    return false;
  }
  extern_id_ = extern_id;
  size_ = rsp.size();
  lc_id_ = rsp.lc_id();
  lc_random_id_ = rsp.lc_random_id();
  lc_set_name_ = rsp.set_name();
  if (rsp.has_io_timeout() && rsp.io_timeout() != 0) {
    io_timer_count_ = rsp.io_timeout() * 100;
  }
  //记录每个pc的统计信息，pc_no 作为索引
  pc_io_stats_.resize(UDISK_PC_COUNT_GB(size_) + 1);
  // 连接建立成功后开始获取MetaData和heartbeat
  // 这两个获取metadata的请求完成的先后顺序不重要
  ManagerThread::Instance()->GetMetaData(this);
  heartbeat_timer_id_ = loop_->RunEvery(
      g_config_parser->heartbeat_period(),
      std::bind(&ManagerThread::Heartbeat, ManagerThread::Instance(), this));
  // 启动IO超时定时器
  io_timer_id_ =
      loop_->RunEvery(0.01, std::bind(&UDiskWorker::IOTimerCb, this));
  return true;
}

void UDiskWorker::Reset() {
  // 标识该UDisk Handle 负责其他的盘
  //由listener中统一的入口对accept的连接进行删除和析构
  ULOG_INFO << "udisk handle do reset, extern_id:" << extern_id_
            << " set name:" << lc_set_name_ << " lc_id:" << lc_id_;

  ++handle_id_;
  DecRefs();
  GetLoop()->worker()->DecRefs();
  assert(GetRefs() == 0);
  assert(GetLoop()->worker()->GetRefs() == 0);
  // 取消心跳
  loop_->CancelTimer(heartbeat_timer_id_);
  loop_->CancelTimer(io_timer_id_);
  for (auto it = pending_list_.begin(); it != pending_list_.end(); ++it) {
    delete *it;
  }
  for (auto it = inflight_list_.begin(); it != inflight_list_.end(); ++it) {
    delete *it;
  }
  pending_list_.clear();
  inflight_list_.clear();
  route_manager_ptr_.reset();
  extern_id_ = "has_reset";
  //必须释放连接否则之前连接Buffer中残留的数据会导致解包失败
  for (auto it = chunk_connector_map_.begin(); it != chunk_connector_map_.end();
       it++) {
    it->second->DestroyConnection();
  }
  // chunk_connector_map_.clear(); //connector可以保留
  login_finish_cb_ = nullptr;
  VhostIoFini();
}

size_t UDiskWorker::SubmitIo(struct udisk_io** ios, size_t cnt) {
  uint64_t count = spdk_ring_enqueue(submit_ring_, (void**)ios, cnt);
  if (count != 0) {
    ssize_t n = ::write(listen_fd_, &count, sizeof(uint64_t));
    if (n != sizeof(uint64_t)) {
      ULOG_FATAL << "unexpected length " << n;
    }
  }
  return (size_t)count;
}

void UDiskWorker::CompleteIo(struct udisk_io* io) {
  uint64_t count = spdk_ring_enqueue(done_ring_, (void**)&io, 1);
  if (count != 1) {
    ULOG_FATAL << "complete io failed";
  }
}

size_t UDiskWorker::GetIoCompleted(struct udisk_io** ios, size_t cnt) {
  return spdk_ring_dequeue(done_ring_, (void**)ios, cnt);
}

void UDiskWorker::EventReadCb(int fd, short event, void* ctx) {
  assert(event == EV_READ);
  UDiskWorker* handle = reinterpret_cast<UDiskWorker*>(ctx);
  uint64_t io_count;
  ssize_t n = ::read(fd, &io_count, sizeof(uint64_t));
  if (n != sizeof(uint64_t)) {
    ULOG_ERROR << "unexpected length " << n;
    return;
  }
  ULOG_TRACE << handle->extern_id() << " receive io, count " << io_count;
  handle->HandleVhostIO(io_count);
}

void UDiskWorker::HandleVhostIO(uint32_t io_count) {
  struct udisk_io* ios[128];
  size_t cnt;
  size_t num;
  while (io_count != 0) {
    cnt = io_count > 128 ? 128 : io_count;
    num = spdk_ring_dequeue(submit_ring_, (void**)ios, cnt);
    if (num != cnt) {
      ULOG_FATAL << "dequeue unexpected length, num: " << num
                 << ", expected_cnt: " << cnt;
    }
    for (size_t i = 0; i < cnt; ++i) {
      struct udisk_io* io = ios[i];
      RwRequestHandle(io);
      // test
      // io->ret = 0;
      // CompleteIo(io);
    }
    io_count -= cnt;
  }
}

bool UDiskWorker::VhostIoInit() {
  uevent::EventLoopLibevent* evloop =
      dynamic_cast<uevent::EventLoopLibevent*>(loop_);
  assert(evloop);

  submit_ring_ =
      spdk_ring_create(SPDK_RING_TYPE_SP_SC, 65536, SPDK_ENV_SOCKET_ID_ANY);
  if (!submit_ring_) {
    ULOG_ERROR << "create submit ring fail, extern_id:" << extern_id_;
    return false;
  }
  done_ring_ =
      spdk_ring_create(SPDK_RING_TYPE_SP_SC, 65536, SPDK_ENV_SOCKET_ID_ANY);
  if (!done_ring_) {
    ULOG_ERROR << "create done ring fail, extern_id:" << extern_id_;
    spdk_ring_free(submit_ring_);
    submit_ring_ = NULL;
    return false;
  }
  listen_fd_ = SocketUtil::CreateEventFd();
  if (listen_fd_ < 0) {
    ULOG_ERROR << "Failed in eventfd";
    spdk_ring_free(submit_ring_);
    spdk_ring_free(done_ring_);
    submit_ring_ = NULL;
    done_ring_ = NULL;
    return false;
  }
  event_idx_ = evloop->RegisterEvent(listen_fd_, EV_READ,
                                     UDiskWorker::EventReadCb, this);
  return true;
}

void UDiskWorker::VhostIoFini() {
  if (submit_ring_) {
    spdk_ring_free(submit_ring_);
    submit_ring_ = NULL;
  }
  if (done_ring_) {
    spdk_ring_free(done_ring_);
    done_ring_ = NULL;
  }
  if (event_idx_ >= 0) {
    uevent::EventLoopLibevent* evloop =
        dynamic_cast<uevent::EventLoopLibevent*>(loop_);
    evloop->UnregisterEvent(event_idx_);
    ::close(listen_fd_);
    event_idx_ = -1;
    listen_fd_ = 0;
  }
}

// io_req->Send()只要满足发送条件（路由ready，符合保序的要求）
// 就会正确返回，将IO加入inflight list, 但这个时候io可能并没有
// 发送成功发送(发送报错),这时依赖超时重发。不满足发送条件加入pending list,
// 等chunk的IO response时,触发发送pending住的IO
void UDiskWorker::RwRequestHandle(struct udisk_io* io) {
  IORequest* io_req = new IORequest(this, io);
  io_req->Init();
  if (io_req->Send() != 0) {
    pending_list_.push_back(io_req);
    ULOG_TRACE << "pending list size:" << pending_list_.size();
  } else {
    inflight_list_.push_back(io_req);
    ULOG_TRACE << "inflight list size:" << inflight_list_.size();
  }
}

void UDiskWorker::ChunkConnSuccessCb(const ConnectionUeventPtr& conn) {
  LoopHandle* loop_handle = conn->GetLoop()->GetLoopHandle();
  UDiskWorker* instance = reinterpret_cast<UDiskWorker*>(loop_handle);
  ULOG_INFO << "connect to chunkserver success, connection name:"
            << conn->GetName() << " connection id:" << conn->GetId()
            << " lc_id:" << instance->GetLcId();
}

void UDiskWorker::ChunkConnClosedCb(const ConnectionUeventPtr& conn) {
  LoopHandle* loop_handle = conn->GetLoop()->GetLoopHandle();
  UDiskWorker* instance = reinterpret_cast<UDiskWorker*>(loop_handle);
  ULOG_INFO << "disconnect from chunkserver, lc_id:" << instance->GetLcId()
            << " peer addr:" << conn->GetPeerAddress().ToString();
}

void UDiskWorker::ChunkConnReadCb(const ConnectionUeventPtr& conn) {
  LoopHandle* loop_handle = conn->GetLoop()->GetLoopHandle();
  UDiskWorker* instance = reinterpret_cast<UDiskWorker*>(loop_handle);
  size_t readable = conn->ReadableLength();
  uint32_t size;
  while (readable >=
         sizeof(MessageHeader)) {  // head len enough 数据不够不能清除
    conn->ReceiveData(&size, sizeof(size));
    if (readable >= size + sizeof(MessageHeader)) {  // data len enough
      MessageHeader msg_head;
      conn->RemoveData(&msg_head, sizeof(MessageHeader));
      readable -= (size + sizeof(MessageHeader));
      if (msg_head.msg_type == MSG_GATE_IO_RES) {
        GateIOResponseHead* res_head = new GateIOResponseHead();
        conn->RemoveData(res_head, GATE_RES_HEAD_SIZE);
        switch (res_head->cmd) {
          case GATE_CMD_READ:
          case GATE_CMD_WRITE:
            instance->RwResponseHandle(conn, res_head);
            break;
          default:
            ULOG_ERROR << "unknown response cmd: " << (uint32_t)res_head->cmd
                       << DumpGateResHead(*res_head);
            break;
        }
        delete res_head;
      } else {
        ULOG_ERROR << "unknown message type: " << msg_head.msg_type
                   << ", data_len: " << msg_head.data_len
                   << ", version: " << msg_head.version
                   << ", readable: " << readable
                   << ", peer_address: " << conn->GetPeerAddress().ToString();
      }
    } else {  // 数据不够， 退出
      break;
    }
    //发生了connection_reset错误，连接已经被释放, 继续读会core
    if (instance->conn_is_reset_ == true) {
      instance->conn_is_reset_ = false;
      break;
    }
  }
}

void UDiskWorker::RecvData(struct iovec* iov, const ConnectionUeventPtr& conn) {
  ULOG_TRACE << "recv data, base: " << iov->iov_base
             << ", len: " << iov->iov_len;
  conn->RemoveData(iov->iov_base, iov->iov_len);
}

void UDiskWorker::RwResponseHandle(const ConnectionUeventPtr& conn,
                                   GateIOResponseHead* head) {
  ULOG_TRACE << "receive response from chunksever: "
             << conn->GetPeerAddress().ToString() << DumpGateResHead(*head);
  bool find = false;
  for (auto it = inflight_list_.begin(); it != inflight_list_.end(); it++) {
    if (head->flowno == (*it)->GetFlowno()) {
      find = true;
      FragIORequest* frag_req = (*it)->GetFragIORequest(head->fragno);
      // 如果有数据，读取出数据
      if (head->size != 0) {
        assert(head->cmd == GATE_CMD_READ);
        ioutil::IovecTraverse(
            frag_req->iovs, frag_req->iovcnt,
            std::bind(&UDiskWorker::RecvData, std::placeholders::_1, conn));
      }
      // 错误的分片不标记完成，稍后会重试，不立即重试
      if (head->retcode != 0) {
        ULOG_ERROR << "error gate response head:" << DumpGateResHead(*head);
        IOErrorHandle(head->retcode, frag_req, conn);
      } else {  // 收到正确的回复
        // 区分chunk统计信息, 这里统计的是分片的iops
        Timestamp end_time(Timestamp::now());
        if (head->cmd == GATE_CMD_READ) {
          IncReadIOCount(frag_req->chunk_id,
                         frag_req->gate_req_head.pc_no);  // 记录IO的统计信息
          IncReadBytesCount(frag_req->chunk_id, frag_req->gate_req_head.pc_no,
                            frag_req->gate_req_head.length);
          AddReadLatency(frag_req->chunk_id, frag_req->gate_req_head.pc_no,
                         timeDifferenceUs(end_time, frag_req->start_time));
        } else {
          IncWriteIOCount(frag_req->chunk_id,
                          frag_req->gate_req_head.pc_no);  // 记录IO的统计信息
          IncWriteBytesCount(frag_req->chunk_id, frag_req->gate_req_head.pc_no,
                             frag_req->gate_req_head.length);
          AddWriteLatency(
              frag_req->chunk_id, frag_req->gate_req_head.pc_no,
              base::timeDifferenceUs(end_time, frag_req->start_time));
        }

        if ((*it)->MarkFragReceived(head->fragno) == true) {  //收到了所有分片
          ULOG_TRACE << "receive all fragment";
          (*it)->Response();
          delete *it;  // 释放IORequest
          inflight_list_.erase(it);
        }
      }
      break;  //找到对应的request 就可以break
    }
  }
  //可能是chunk已经回复过一次，重复回复(gate进行了超时重试)
  if (find == false) {
    // 将数据部分从缓冲区移除，防止后续解包错误
    if (head->size != 0) {
      assert(head->cmd == GATE_CMD_READ);
      conn->DrainData(head->size);
    }
    ULOG_ERROR << "can't find this response from chunkserver: "
               << conn->GetPeerAddress().ToString() << DumpGateResHead(*head);
  }
}

// bit: 0~7 主副本retcode， 8~15 从副本retcode, 16~23 从副本retcode
// 错误处理时，低位错误处理优先
void UDiskWorker::IOErrorHandle(int32_t retcode, FragIORequest* frag_req,
                                const ConnectionUeventPtr& conn) {
  assert(retcode != 0);
  bool first_error_index = true;  // 按最低位的错误标记处理
  for (int i = 0; i < kReplicaNum; i++) {
    uint8_t one_replica_retcode = (uint8_t)(retcode >> (i * 8));
    if (one_replica_retcode != 0) {
      ULOG_ERROR << "error replica index: " << i
                 << ", retcode: " << (uint32_t)one_replica_retcode
                 << " message: " << RetcodeMsg(one_replica_retcode)
                 << " is_first_error_index: " << first_error_index;
      if (first_error_index == true) {
        first_error_index = false;
      } else {
        continue;  // 更高位的错误不需要处理, 只是打印log
      }
      switch (one_replica_retcode) {
        case RETCODE_CLUSTER_VERSION_ERR:
        case RETCODE_CHUNK_NOT_READY:
          ULOG_INFO << "retry error io after 1s";
          RetryErrorFragIO(frag_req, 100);  // 1s 后重试
          break;
        case RETCODE_RESET_CONNECTION:
          //主动断开连接后立即重试
          DestroyChunkConnection(conn->GetId());
          ULOG_INFO << "retry all io immediately at conn id: " << conn->GetId();
          RetryAllSameConnFragIO(conn->GetId());
          conn_is_reset_ = true;
          break;
        case RETCODE_AIO_ERR:
        case RETCODE_AIO_WRITE_TIMEOUT:
        case RETCODE_AIO_READ_TIMEOUT:
        case RETCODE_REPLICA_TIMEOUT:
        case RETCODE_OTHER_ERR:
          ULOG_INFO << "retry error io after 2s";
          RetryErrorFragIO(frag_req, 200);  // 2s 后重试
          break;
        default:
          //主动断开连接后立即重试
          DestroyChunkConnection(conn->GetId());
          ULOG_ERROR << "unknow error, retry all io immediately at conn id: "
                     << conn->GetId();
          RetryAllSameConnFragIO(conn->GetId());
          break;
      }
    }
  }
}

// 这里重置超时时间，依赖定时器超时，重试IO
void UDiskWorker::RetryErrorFragIO(FragIORequest* frag_req, int timer_count) {
  // 计数设为1然后主动减一，立即出发了重试
  if (timer_count == 0) {
    frag_req->SetTimerCount(1);
    frag_req->DecTimerCount();
  } else {
    frag_req->SetTimerCount(timer_count);
  }
}

// 重试指定连接上的所有的IO
void UDiskWorker::RetryAllSameConnFragIO(int64_t conn_id) {
  for (auto it = inflight_list_.begin(); it != inflight_list_.end(); it++) {
    std::vector<FragIORequest*>* frag_req_vec = (*it)->GetFragReqVec();
    for (auto it1 = frag_req_vec->begin(); it1 != frag_req_vec->end(); it1++) {
      if ((*it1)->chunk_conn_id == conn_id) {
        RetryErrorFragIO(*it1, 0);  //
      }
    }
  }
}

void UDiskWorker::IOTimerCb() {
  for (auto it = inflight_list_.begin(); it != inflight_list_.end(); ++it) {
    (*it)->DecTimerCount();
  }
}

void UDiskWorker::SendPendingIO() {
  // 收到应答后要尝试发送，避免PENDING的IO得不到发送
  ULOG_TRACE << "pending list size: " << pending_list_.size();
  for (auto it = pending_list_.begin(); it != pending_list_.end();) {
    if ((*it)->Send() == 0) {
      inflight_list_.push_back(*it);
      pending_list_.erase(it++);
    } else {
      it++;
    }
  }
}

ConnectionUeventPtr UDiskWorker::GetChunkConnection(FragIORequest* frag_req) {
  frag_req->gate_req_head.lc_id = lc_id_;
  frag_req->gate_req_head.lc_random_id = lc_random_id_;
  frag_req->gate_req_head.lc_size = size_;
  ConnectorUeventPtr chunk_ctor;
  route_manager_ptr_->GetChunkRoute(
      lc_id_, frag_req->gate_req_head.pc_no, lc_random_id_,
      &frag_req->gate_req_head.route_version, &frag_req->gate_req_head.pg_id,
      &frag_req->chunk_id, &chunk_ctor);
  ULOG_TRACE << "chunk id:" << frag_req->chunk_id << " lc_id:" << lc_id_
             << " pg_id:" << frag_req->gate_req_head.pg_id
             << " pc_no:" << frag_req->gate_req_head.pc_no;
  if (chunk_ctor->HasAvailableConnection() == false) {
    ULOG_ERROR << "no available connection to chunk";
    return ConnectionUeventPtr();
  }
  return chunk_ctor->GetConnection();
}

// 主动断开与chunkserver的连接
void UDiskWorker::DestroyChunkConnection(uint64_t conn_id) {
  auto it = chunk_connector_map_.find(conn_id);
  if (it == chunk_connector_map_.end()) {
    ULOG_FATAL << "no connector in chunk_connector_map with conn_id: "
               << conn_id;
  }
  ULOG_INFO << "gate close connection with chunkserver: "
            << it->second->GetPeerAddress().ToString();
  // 销毁connector 中的连接, 会触发与chunk连接关闭回调
  it->second->DestroyConnection();
}

ConnectorUeventPtr UDiskWorker::GetChunkConnector(const UsockAddress& addr) {
  // 这个id 的构造方法与connetor中构造connection设置的id相同, 所以
  // 需要断开连接时可以通过这个id找到对应的conector
  uint64_t conn_id =
      (static_cast<uint64_t>(addr.IpNetEndian()) << 16) | addr.PortNetEndian();
  ConnectorUeventPtr ctor;
  auto it = chunk_connector_map_.find(conn_id);
  if (it == chunk_connector_map_.end()) {
    ctor.reset(reinterpret_cast<ConnectorUevent*>(new ConnectorLibevent(
        (PosixWorker*)loop_->worker(), addr, "ChunkConnector")));
    ctor->SetConnectionSuccessCb(ChunkConnSuccessCb);
    ctor->SetConnectionClosedCb(ChunkConnClosedCb);
    ctor->SetMessageReadCb(ChunkConnReadCb);
    ctor->Connect();
    chunk_connector_map_[conn_id] = ctor;

  } else {
    ctor = chunk_connector_map_[conn_id];
  }
  return ctor;
}

void UDiskWorker::UpdateRouteManager(
    const ucloud::udisk::ClusterInfoPb& cluster_info,
    const ::google::protobuf::RepeatedPtrField<::ucloud::udisk::ChunkInfoPb>&
        chunk_info,
    const ::google::protobuf::RepeatedPtrField<::ucloud::udisk::PGInfoPb>&
        pg_info,
    int64_t handle_id) {
  loop_->RunInLoop(std::bind(&UDiskWorker::UpdateRouteManagerInLoop, this,
                             cluster_info, chunk_info, pg_info, handle_id));
}

void UDiskWorker::UpdateRouteManagerInLoop(
    const ucloud::udisk::ClusterInfoPb cluster_info,
    const ::google::protobuf::RepeatedPtrField<::ucloud::udisk::ChunkInfoPb>
        chunk_info,
    const ::google::protobuf::RepeatedPtrField<::ucloud::udisk::PGInfoPb>
        pg_info, int64_t handle_id) {
  if (handle_id != handle_id_) {
    ULOG_WARN << "handle id changed";
    return;
  }
  if (!route_manager_ptr_) {
    route_manager_ptr_.reset(new RouteManager(this));
  }
  route_manager_ptr_->UpdateClusterMap(cluster_info, chunk_info, pg_info);
}

void UDiskWorker::GetIOStatistics(ucloud::udisk::LCIOStats& stats,
                                  int interval) {
  stats.set_iops_read(io_stats_.amount_io_read / interval);
  stats.set_iops_write(io_stats_.amount_io_write / interval);
  stats.set_byteps_read(io_stats_.amount_byte_read / interval);
  stats.set_byteps_write(io_stats_.amount_byte_write / interval);

  if (io_stats_.amount_io_read != 0) {  //计算读平均延时
    stats.set_read_latency(
        ceil(io_stats_.amount_read_latency * 1.0 / io_stats_.amount_io_read));
  } else {
    stats.set_read_latency(0);
  }
  if (io_stats_.amount_io_write != 0) {  //计算写平均延时
    stats.set_write_latency(
        ceil(io_stats_.amount_write_latency * 1.0 / io_stats_.amount_io_write));
  } else {
    stats.set_write_latency(0);
  }

  struct timeval now;
  gettimeofday(&now, NULL);
  stats.set_stats_time(now.tv_sec);
}

void UDiskWorker::GetChunkIOStatistics(
    std::vector<ucloud::udisk::GateChunkIOStats>& stats,
    vector<ucloud::udisk::GatePCIOStats>& pc_stats, int interval) {
  stats.resize(chunk_io_stats_.size());
  for (uint32_t chunk_id = 0; chunk_id < chunk_io_stats_.size(); ++chunk_id) {
    AmountIOStats& io_stat = chunk_io_stats_[chunk_id];
    stats[chunk_id].set_chunk_id(chunk_id);
    stats[chunk_id].set_iops_read(io_stat.amount_io_read / interval);
    stats[chunk_id].set_iops_write(io_stat.amount_io_write / interval);
    stats[chunk_id].set_byteps_read(io_stat.amount_byte_read / interval);
    stats[chunk_id].set_byteps_write(io_stat.amount_byte_write / interval);

    if (io_stat.amount_io_read != 0) {  //计算读平均延时
      stats[chunk_id].set_read_latency(
          ceil(io_stat.amount_read_latency * 1.0 / io_stat.amount_io_read));
    } else {
      stats[chunk_id].set_read_latency(0);
    }
    if (io_stat.amount_io_write != 0) {  //计算写平均延时
      stats[chunk_id].set_write_latency(
          ceil(io_stat.amount_write_latency * 1.0 / io_stat.amount_io_write));
    } else {
      stats[chunk_id].set_write_latency(0);
    }
  }

  pc_stats.resize(pc_io_stats_.size());
  for (uint32_t pc_no = 0; pc_no < pc_io_stats_.size(); ++pc_no) {
    AmountIOStats& io_stat = pc_io_stats_[pc_no];
    pc_stats[pc_no].set_pc_no(pc_no);
    pc_stats[pc_no].set_iops_read(io_stat.amount_io_read / interval);
    pc_stats[pc_no].set_iops_write(io_stat.amount_io_write / interval);
    pc_stats[pc_no].set_byteps_read(io_stat.amount_byte_read / interval);
    pc_stats[pc_no].set_byteps_write(io_stat.amount_byte_write / interval);

    if (io_stat.amount_io_read != 0) {  //计算读平均延时
      pc_stats[pc_no].set_read_latency(
          ceil(io_stat.amount_read_latency * 1.0 / io_stat.amount_io_read));
    } else {
      pc_stats[pc_no].set_read_latency(0);
    }
    if (io_stat.amount_io_write != 0) {  //计算写平均延时
      pc_stats[pc_no].set_write_latency(
          ceil(io_stat.amount_write_latency * 1.0 / io_stat.amount_io_write));
    } else {
      pc_stats[pc_no].set_write_latency(0);
    }
  }
}

void UDiskWorker::GetRwTickInfo(std::shared_ptr<GetLcRwTick> ptr) {
  ucloud::udisk::LcLastRwTickInfo tick_info;
  if (GetRefs() == 0) {  //该udisk handle没有被使用
    ptr->GetRwTickInfosCb(false, tick_info);
    return;
  }
  tick_info.set_extern_id(extern_id_);
  tick_info.set_lc_id(lc_id_);
  tick_info.set_last_read_tick(last_read_tick_);
  tick_info.set_last_write_tick(last_write_tick_);
  ptr->GetRwTickInfosCb(true, tick_info);
}

}  // namespace gate
}  // namespace udisk
