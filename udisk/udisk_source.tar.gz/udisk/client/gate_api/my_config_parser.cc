#include "my_config_parser.h"
#include <ustevent/base/logging.h>

namespace udisk {
namespace gate {

const std::string MyConfigParser::kThreadNum = std::string("thread_num");
const std::string MyConfigParser::kReportOdinPeriod =
    std::string("report_odin_period");
const std::string MyConfigParser::kHeartbeatPeriod =
    std::string("heartbeat_period");
const std::string MyConfigParser::kGlobalOdinName = std::string("global_odin");

using namespace base;

MyConfigParser::MyConfigParser(const std::string& file) : ConfigParser(file) {}

void MyConfigParser::Init() {
  ConfigParser::Init();
  //必要部分为填无法启动
  if (listen_ip().empty()) {
    ULOG_FATAL << "listen_ip is empty";
  }
  if (listen_port() == 0) {
    ULOG_FATAL << "listen_port is empty";
  }
  if (zk_server().empty()) {
    ULOG_FATAL << "zk server is empty";
  }
  if (hydra_zk_path().empty()) {
    ULOG_FATAL << "hydra_zk_path is empty";
  }

  thread_num_ = parser_.IntValue(kSectionUDisk, kThreadNum);
  if (thread_num_ == 0) {
    ULOG_INFO << "thread_num is empty or 0 in config file";
  }

  report_odin_period_ = parser_.IntValue(kSectionCommon, kReportOdinPeriod);
  if (report_odin_period_ == 0) {
    ULOG_INFO << "report odin period error, use default=5s";
    report_odin_period_ = 5;
  } else {
    ULOG_INFO << " report_odin_period: " << report_odin_period_;
  }
  heartbeat_period_ = parser_.IntValue(kSectionCommon, kHeartbeatPeriod);
  if (heartbeat_period_ == 0) {
    ULOG_INFO << "heartbeat period error, use default=1s";
    heartbeat_period_ = 1;
  } else {
    ULOG_INFO << "heartbeat period: " << heartbeat_period_;
  }
  global_odin_zk_path_ = parser_.GetValue(kSectionName, kGlobalOdinName);
  if (global_odin_zk_path_.empty()) {
    ULOG_FATAL << "global odin is empty in config file";
  }
  ULOG_INFO << "global odin path: " << global_odin_zk_path_;
}

}  // namespace gate
}  // namespace udisk
