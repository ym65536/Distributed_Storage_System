#ifndef UDISK_GATE_CHUNK_IOSTATS_HANDLE_H_
#define UDISK_GATE_CHUNK_IOSTATS_HANDLE_H_

#include <ustevent/base/logging.h>
#include <ustevent/pb_request_handle.h>
#include <ustevent/eventloop.h>
#include "manager_thread.h"
#include "udisk_message.h"

using namespace uevent;

namespace udisk {
namespace gate {

class GateChunkIOStatsHandle : public PbRequestHandle {
 public:
  explicit GateChunkIOStatsHandle(uevent::EventLoop* loop) : loop_(loop) {}
  virtual ~GateChunkIOStatsHandle() {}
  virtual void EntryInit(const ConnectionUeventPtr& conn,
                         const UMessagePtr& um);

  void SendResponse(int retcode, const std::string& message);
  void GetMetaDataProcess(uint64_t cluster_version);
  void GateChunkIOStatsProcess(ucloud::udisk::GateChunkIOStatsRequest req);
  ucloud::udisk::GateChunkIOStats MergeChunkStat(uint32_t chunk_id,
                                                 ChunkStatPairMap& pair_map);
  ucloud::udisk::GatePCIOStats MergePCStat(uint32_t pc_no,
                                           PCStatPairMap& pair_map);

  MYSELF_CREATE(GateChunkIOStatsHandle);

  void DestroyMyself();

 private:
  static int type_;
  uevent::EventLoop* loop_;
  uevent::ConnectionUeventPtr conn_;
  ucloud::UMessage response_;
  ucloud::udisk::GateChunkIOStatsResponse* resp_body_;
};
}
}
#endif
