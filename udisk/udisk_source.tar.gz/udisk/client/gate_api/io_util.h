#ifndef GATE_IO_UTIL_H_
#define GATE_IO_UTIL_H_

#include <sys/uio.h>

namespace udisk {
namespace gate {
namespace ioutil {

// 定位数据在iovec数组的位置，搜索起始位置为iovs[*iov_idx] + *buf_off
// iovecs 数组地址
// iovcnt 数组长度
// iov_idx 搜索的起始iovecs数组下标，返回目的位置的iovecs数组下标
// buf_off 搜索的起始iovec buffer偏移，返回目的位置的iovec buffer偏移
// offset 相对于起始位置的偏移
// return 0:成功定位到目标位置，-1:失败
inline int IovecGetIdx(struct iovec *iovs, int iovcnt, int *iov_idx,
                       size_t *buf_off, size_t offset) {
  int i = *iov_idx;
  size_t j = *buf_off;
  if (i >= iovcnt || j >= iovs[i].iov_len) {
    return -1;
  }
  while (i < iovcnt) {
    if (offset > iovs[i].iov_len - j) {
      offset -= (iovs[i].iov_len - j);
      j = 0;
      ++i;
    } else if (offset == iovs[i].iov_len - j) {
      *iov_idx = i + 1;
      *buf_off = 0;
      return 0;
    } else {
      *iov_idx = i;
      *buf_off = j + offset;
      return 0;
    }
  }

  return -1;
}

typedef std::function<void(struct iovec *)> TraverseFunc;

// 遍历iovec数组，func以iovec数组中元素为参数
inline void IovecTraverse(struct iovec *iovs, int iovcnt, TraverseFunc func) {
  for (int i = 0; i < iovcnt; ++i) {
    func(&iovs[i]);
  }
}

}  // namespace ioutil
}  // namespace gate
}  // namespace udisk

#endif
