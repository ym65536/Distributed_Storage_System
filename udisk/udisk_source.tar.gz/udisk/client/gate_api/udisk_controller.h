#ifndef GATE_UDISK_CONTROLLER_H_
#define GATE_UDISK_CONTROLLER_H_

#include <memory>
#include <ustevent/worker_thread.h>
#include <ustevent/stack.h>
#include "udisk_device.h"

namespace udisk {
namespace gate {

class UDiskController {
 public:
  UDiskController(const std::string &name) : name_(name), work_thread_(name, nullptr) {}
  ~UDiskController() {}
  void Start();
  void SetThreadNum(int thread_num) { thread_num_ = thread_num; }
  void GetUDiskDevice(const std::string &extern_id,
                      std::function<void(void *)> cb);
  void GetUDiskDeviceInLoop(const std::string &extern_id,
                            std::function<void(void *)> cb);
  void LoginCallback(bool success, void *device,
                     std::function<void(void *)> cb);
  void PutUDiskDevice(UDiskDevice *device);
  UDiskWorker *GetUDiskWorker();

  inline std::vector<EventLoop *> GetAllLoops() const {
    return stack_->GetAllLoops();
  }

 private:
  void StartThreadPool();
  std::string name_;
  int thread_num_;
  uevent::WorkerThread work_thread_;
  uevent::EventLoop *loop_;
  std::unique_ptr<Stack> stack_;
  std::map<std::string, UDiskDevice *> devices_;
};

}  // namespace gate
}  // namespace udisk

#endif
