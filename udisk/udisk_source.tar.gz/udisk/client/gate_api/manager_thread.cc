#include "manager_thread.h"
#include <unistd.h>
#include <ustevent/base/timestamp.h>
#include <ustevent/base/my_uuid.h>
#include <ustevent/message_util.h>
#include <ustevent/libevent/connector_libevent.h>
#include "zk_name_container.h"
#include "gate.h"
#include "udisk_worker.h"
#include "my_config_parser.h"
#include "gate_chunk_iostats.h"
#include "udisk_controller.h"
#include "udisk_device.h"

namespace udisk {
namespace gate {

using namespace uevent;
using namespace base;
using namespace common;

ManagerThread* ManagerThread::instance_ = NULL;

//这个单例启动时只有主线程会调用，不会有线程间的竞争
ManagerThread* ManagerThread::Instance() {
  if (instance_ == NULL) {
    instance_ = new ManagerThread();
  }
  return instance_;
}

ManagerThread::ManagerThread() : work_thread_("manager_thread"), loop_(NULL) {}

void ManagerThread::Start() {
  loop_ = work_thread_.StartWorker()->eventloop();
  loop_->RunInLoop(std::bind(&ManagerThread::StartInLoop, this));
}

void ManagerThread::StartInLoop() {
  loop_->AssertInLoopThread();
  REGISTE_PROTO_HANDLER(loop_, ucloud::udisk::GATE_CHUNK_IOSTATS_REQUEST,
                        GateChunkIOStatsHandle);
  REGISTE_PROTO_HANDLER(loop_, ucloud::udisk::GET_LC_LAST_RW_TICK_REQUEST,
                        GetLcRwTick);
  loop_->RunEvery(g_config_parser->report_odin_period(),
                  std::bind(&ManagerThread::ReportOdinTimer, this));
  ListenerInit();
}

void ManagerThread::ListenerInit() {
  uevent::UsockAddress listen_addr(g_config_parser->listen_ip(),
                                   g_config_parser->listen_port(), false);
  listener_.reset(new uevent::ListenerLibevent((PosixWorker*)loop_->worker(),
                                               listen_addr, "GateManListener",
                                               uevent::Option()));
  listener_->SetConnectionSuccessCb(
      std::bind(&ManagerThread::ManConnSuccessCb, this, std::placeholders::_1));
  listener_->SetConnectionClosedCb(
      std::bind(&ManagerThread::ManConnClosedCb, this, std::placeholders::_1));
  listener_->SetMessageReadCb(std::bind(
      &uevent::MessageUtil::ProtobufReadCallBack, std::placeholders::_1));
  listener_->Start();
}

void ManagerThread::ManConnSuccessCb(const ConnectionUeventPtr& conn) {
  ULOG_INFO << "new connection from pb client, connection name: "
            << conn->GetName() << "connection id: " << conn->GetId();
}

void ManagerThread::ManConnClosedCb(const ConnectionUeventPtr& conn) {
  ULOG_INFO << "disconnect from pb client, connection name: " << conn->GetName()
            << "connection id: " << conn->GetId();
  //由listener中统一的入口对accept的连接进行删除和析构
  listener_->RemoveConnection(conn);
}

void ManagerThread::HydraConnSuccessCb(const ConnectionUeventPtr& conn) {
  ULOG_INFO << "connect to hydra success, peer address: "
            << conn->GetPeerAddress().ToString();
}

void ManagerThread::HydraConnClosedCb(const ConnectionUeventPtr& conn) {
  ULOG_INFO << "disconnect from hydra, peer address: "
            << conn->GetPeerAddress().ToString();
}

// 采用短连接方式，直接获取connnetor, 使用完释放
ConnectorUeventPtr ManagerThread::CreateHydraConnector() {
  ucloud::uns::NameNodeContent nnc;
  if (g_name_container->GetNNCForName(common::ConfigParser::kGlobalSetName,
                                      common::ConfigParser::kHydraName,
                                      nnc) == -1) {
    ULOG_ERROR << "get nnc for hydra error";
    return ConnectorUeventPtr();
  }
  std::string hydra_ip = nnc.ip();
  uint32_t hydra_port = nnc.port();
  UsockAddress hydra_addr(hydra_ip, hydra_port);
  // 这里会析构之前的connector
  ConnectorUeventPtr hydra_ctor(new ConnectorLibevent(
      (PosixWorker*)loop_->worker(), hydra_addr, "HydraConnector"));
  hydra_ctor->SetConnectionSuccessCb(std::bind(
      &ManagerThread::HydraConnSuccessCb, this, std::placeholders::_1));
  hydra_ctor->SetConnectionClosedCb(std::bind(&ManagerThread::HydraConnClosedCb,
                                              this, std::placeholders::_1));
  hydra_ctor->SetMessageReadCb(
      std::bind(MessageUtil::ProtobufReadCallBack, std::placeholders::_1));
  hydra_ctor->Connect();
  return hydra_ctor;
}

void ManagerThread::OdinConnSuccessCb(const ConnectionUeventPtr& conn) {
  ULOG_INFO << "connect to Odin success, peer address: "
            << conn->GetPeerAddress().ToString();
}

void ManagerThread::OdinConnClosedCb(const ConnectionUeventPtr& conn) {
  ULOG_INFO << "disconnect from odin, peer address: "
            << conn->GetPeerAddress().ToString();
}

void ManagerThread::MetaServerConnSuccessCb(const ConnectionUeventPtr& conn) {
  ULOG_INFO << "connect to MetaServer success, peer address: "
            << conn->GetPeerAddress().ToString();
}

void ManagerThread::MetaServerConnClosedCb(const ConnectionUeventPtr& conn) {
  ULOG_INFO << "disconnect from MetaServer, peer address: "
            << conn->GetPeerAddress().ToString();
}

ConnectionUeventPtr ManagerThread::GetMetaServerConnection(
    const std::string& set_name) {
  ucloud::uns::NameNodeContent nnc;
  if (g_name_container->GetNNCForName(
          set_name, common::ConfigParser::kMetaServerName, nnc, true) == -1) {
    ULOG_ERROR << "get nnc for metaserver error";
    return ConnectionUeventPtr();
  }
  ucloud::udisk::MetaserverPortPair extend_info;
  g_name_container->ParseMetaServerExtendInfo(nnc, &extend_info);
  std::string metaserver_ip = nnc.ip();
  uint32_t metaserver_port = extend_info.gate_port();
  UsockAddress metaserver_addr(metaserver_ip, metaserver_port);
  auto it = metaserver_connector_map_.find(set_name);
  //已经与metaserver建立连接,且没有切换，返回现有的connetion
  //否则需要重新建立连接
  if (it != metaserver_connector_map_.end() &&
      it->second->GetPeerAddress().ToString() == metaserver_addr.ToString()) {
    if (it->second->HasAvailableConnection() == false) {
      ULOG_ERROR << "connect to metaserver error";
      return ConnectionUeventPtr();
    }
    return it->second->GetConnection();
  }
  ConnectorUeventPtr metaserver_ctor(new ConnectorLibevent(
      (PosixWorker*)loop_->worker(), metaserver_addr, "MetaServerConnector"));
  metaserver_ctor->SetConnectionSuccessCb(std::bind(
      &ManagerThread::MetaServerConnSuccessCb, this, std::placeholders::_1));
  // 这里传绑connector的裸指针，否则会循环引用无法析构
  metaserver_ctor->SetConnectionClosedCb(std::bind(
      &ManagerThread::MetaServerConnClosedCb, this, std::placeholders::_1));
  metaserver_ctor->SetMessageReadCb(
      std::bind(MessageUtil::ProtobufReadCallBack, std::placeholders::_1));
  metaserver_ctor->Connect();
  // 如果发生了主metaserver切换，这里会析构之前metaserver_connector_
  // 也会释放其中的connection
  metaserver_connector_map_[set_name] = metaserver_ctor;
  if (metaserver_ctor->HasAvailableConnection() == false) {
    ULOG_ERROR << "connect to metaserver error";
    return ConnectionUeventPtr();
  }
  return metaserver_ctor->GetConnection();
}

ConnectionUeventPtr ManagerThread::GetOdinConnection(
    const std::string& set_name) {
  std::string odin_name;
  // 判断是机房全局的odin还是获取指定set的odin, 当没有获取到lc所属set
  // 的odin时，使用全局的odin上报故障
  if (set_name == common::ConfigParser::kGlobalSetName) {
    odin_name = MyConfigParser::kGlobalOdinName;
  } else {
    odin_name = common::ConfigParser::kOdinName;
  }
  ucloud::uns::NameNodeContent nnc;
  // 获取odin 的leader 节点
  if (g_name_container->GetNNCForName(set_name, odin_name, nnc, true) == -1) {
    ULOG_ERROR << "get nnc for odin error";
    return ConnectionUeventPtr();
  }
  ucloud::udisk::OdinPortPair extend_info;
  if (!extend_info.ParseFromString(nnc.reserved())) {
    ULOG_ERROR << "parse odin pair fail.";
    return ConnectionUeventPtr();
  }
  std::string odin_ip = nnc.ip();
  uint32_t odin_port = extend_info.gate_port();
  UsockAddress odin_addr(odin_ip, odin_port);
  auto it = odin_connector_map_.find(set_name);
  //已经与odin建立连接,且没有切换，返回现有的connetion
  //否则需要重新建立连接
  if (it != odin_connector_map_.end() &&
      it->second->GetPeerAddress().ToString() == odin_addr.ToString()) {
    if (it->second->HasAvailableConnection() == false) {
      ULOG_ERROR << "connect to odin error";
      return ConnectionUeventPtr();
    }
    return it->second->GetConnection();
  }
  ConnectorUeventPtr odin_ctor(new ConnectorLibevent(
      (PosixWorker*)loop_->worker(), odin_addr, "OdinConnector"));
  odin_ctor->SetConnectionSuccessCb(std::bind(&ManagerThread::OdinConnSuccessCb,
                                              this, std::placeholders::_1));
  odin_ctor->SetConnectionClosedCb(
      std::bind(&ManagerThread::OdinConnClosedCb, this, std::placeholders::_1));
  odin_ctor->SetMessageReadCb(
      std::bind(MessageUtil::ProtobufReadCallBack, std::placeholders::_1));
  odin_ctor->Connect();
  // 如果发生了主odin切换，这里会析构之前odin_connector_
  odin_connector_map_[set_name] = odin_ctor;
  if (odin_ctor->HasAvailableConnection() == false) {
    ULOG_ERROR << "connect to metaserver error";
    return ConnectionUeventPtr();
  }
  return odin_ctor->GetConnection();
}

void ManagerThread::LoginHydra(UDiskDevice* device) {
  loop_->RunInLoop(std::bind(&ManagerThread::LoginHydraInLoop, this, device));
}

void ManagerThread::LoginHydraInLoop(UDiskDevice* device) {
  ucloud::UMessage um;
  NewMessage_v2(&um, MessageUtil::Flowno(), base::MyUuid::NewUuid(),
                ucloud::udisk::UDISK_LOGIN_REQUEST, 0, false,
                MessageUtil::ObjId(), 0, "UDiskLogin", NULL, NULL);
  ucloud::udisk::UDiskLoginRequest* req_body =
      um.mutable_body()->MutableExtension(ucloud::udisk::udisk_login_request);
  req_body->set_extern_id(device->extern_id());
  req_body->set_ip(g_config_parser->listen_ip());
  req_body->set_port(g_config_parser->listen_port());
  ConnectorUeventPtr hydra_ctor = CreateHydraConnector();
  if (!hydra_ctor || hydra_ctor->HasAvailableConnection() == false) {
    ULOG_ERROR << "connect to hydra error";
    LoginHydraFinish(false, device);
    return;
  }
  ConnectionUeventPtr hydra_conn = hydra_ctor->GetConnection();
  ULOG_INFO << um.DebugString();
  MessageUtil::SendPbRequest(
      hydra_conn, um, std::bind(&ManagerThread::LoginResponseCb, this,
                                std::placeholders::_1, device, hydra_ctor),
      std::bind(&ManagerThread::LoginTimeoutCb, this, device, hydra_ctor), 2.0);
}

void ManagerThread::LoginResponseCb(const UMessagePtr& um, UDiskDevice* device,
                                    const ConnectorUeventPtr& ctor) {
  ULOG_INFO << um->DebugString();
  assert(um->head().message_type() == ucloud::udisk::UDISK_LOGIN_RESPONSE);
  assert(um->has_body());
  assert(um->body().HasExtension(ucloud::udisk::udisk_login_response));
  login_hydra_rsp_ =
      um->body().GetExtension(ucloud::udisk::udisk_login_response);
  if (login_hydra_rsp_.rc().retcode() != 0) {
    ULOG_ERROR << "udisk login response error,"
               << login_hydra_rsp_.rc().error_message();
    LoginHydraFinish(false, device);
  } else {
    std::string set_name = login_hydra_rsp_.set_name();
    ZkNameOfSetPtr zk_name_set_ptr(new ZkNameOfSet(set_name));
    for (int i = 0; i < login_hydra_rsp_.zk_info_size(); i++) {
      zk_name_set_ptr->AddNamePath(login_hydra_rsp_.zk_info(i).name(),
                                   login_hydra_rsp_.zk_info(i).path());
    }
    //会触发拉取节点信息
    g_name_container->AddZkNameOfSet(zk_name_set_ptr);
    LoginHydraFinish(true, device);
  }
  // 退出后hydra ctor会析构
}

void ManagerThread::LoginTimeoutCb(UDiskDevice* device,
                                   const ConnectorUeventPtr& ctor) {
  ULOG_ERROR << "udisk login hydra timeout";
  LoginHydraFinish(false, device);
  // 退出后hydra ctor会析构
}

void ManagerThread::LoginHydraFinish(bool success, UDiskDevice* device) {
  if (success == true) {
    ULOG_INFO << "login hydra success";
    device->LoginFinish(true, login_hydra_rsp_);
  } else {
    ULOG_ERROR << "login hydra error";
    device->LoginFinish(false, login_hydra_rsp_);
  }
}

void ManagerThread::GetMetaData(UDiskWorker* worker) {
  loop_->RunInLoop(std::bind(&ManagerThread::GetMetaDataInLoop, this, worker));
}

void ManagerThread::GetMetaDataInLoop(UDiskWorker* worker) {
  ucloud::UMessage um;
  NewMessage_v2(&um, MessageUtil::Flowno(), base::MyUuid::NewUuid(),
                ucloud::udisk::GET_META_DATA_REQUEST, 0, false,
                MessageUtil::ObjId(), 0, "GetMetaData", NULL, NULL);

  HandleEntry entry(worker->handle_id(), worker);
  ucloud::udisk::GetMetaDataRequest* req =
      um.mutable_body()->MutableExtension(ucloud::udisk::get_meta_data_request);
  req->set_cluster_version(0);
  ConnectionUeventPtr metaserver_conn =
      GetMetaServerConnection(worker->lc_set_name());
  if (!metaserver_conn) {
    ULOG_ERROR << "no available metaserver connection";
    return;
  }
  ULOG_INFO << um.DebugString();
  MessageUtil::SendPbRequest(
      metaserver_conn, um, std::bind(&ManagerThread::GetMetaDataResponseCb,
                                     this, std::placeholders::_1, entry),
      std::bind(&ManagerThread::GetMetaDataTimeoutCb, this, entry), 2.0);
}

// 在 manager thread 中执行
void ManagerThread::GetMetaDataResponseCb(const UMessagePtr& um,
                                          HandleEntry entry) {
  ULOG_INFO << um->DebugString();
  int64_t handle_id = entry.first;
  UDiskWorker* worker = entry.second;
  assert(um->head().message_type() == ucloud::udisk::GET_META_DATA_RESPONSE);
  assert(um->has_body());
  assert(um->body().HasExtension(ucloud::udisk::get_meta_data_response));
  ucloud::udisk::GetMetaDataResponse rsp =
      um->body().GetExtension(ucloud::udisk::get_meta_data_response);
  if (rsp.rc().retcode() != 0) {
    ULOG_ERROR << "get_meta_data_response error," << rsp.rc().error_message();
  } else {
    // 在io loop 中执行
    worker->UpdateRouteManager(rsp.cluster_info(), rsp.chunk_info(),
                               rsp.pg_info(), handle_id);
  }
}

void ManagerThread::GetMetaDataTimeoutCb(HandleEntry entry) {
  ULOG_ERROR << "get meta data for metaserver timeout, udisk_worker: "
             << entry.second << " handle_id: " << entry.first;
}

void ManagerThread::Heartbeat(UDiskWorker* worker) {
  // 这里还运行在gate io线程中，可以直接使用worker中数据
  ucloud::udisk::LCIOStats iostat;
  worker->GetIOStatistics(iostat, g_config_parser->heartbeat_period());
  worker->ClearIOStats();  // 重置统计数据
  std::vector<ucloud::udisk::GateChunkIOStats> chunk_stats;
  std::vector<ucloud::udisk::GatePCIOStats> pc_stats;
  worker->GetChunkIOStatistics(chunk_stats, pc_stats,
                               g_config_parser->heartbeat_period());
  worker->ClearChunkIOStats();
  HandleEntry entry(worker->handle_id(), worker);
  loop_->RunInLoop(std::bind(&ManagerThread::HeartbeatInLoop, this, entry,
                             iostat, chunk_stats, pc_stats));
}

void ManagerThread::HeartbeatInLoop(
    HandleEntry& entry, ucloud::udisk::LCIOStats& iostat,
    std::vector<ucloud::udisk::GateChunkIOStats>& chunk_stats,
    std::vector<ucloud::udisk::GatePCIOStats>& pc_stats) {
  StatsInfoHandle(entry, iostat, chunk_stats, pc_stats);
  // 处理心跳信息
  ucloud::UMessage um;
  NewMessage_v2(&um, MessageUtil::Flowno(), base::MyUuid::NewUuid(),
                ucloud::udisk::HEARTBEAT_GATE_METASERVER_REQUEST, 0, false,
                MessageUtil::ObjId(), 0, "GateHeartbeat", NULL, NULL);
  ucloud::udisk::HeartbeatGateMetaServerRequest* req =
      um.mutable_body()->MutableExtension(
          ucloud::udisk::heartbeat_gate_metaserver_request);
  uint64_t cluster_version = 0;
  if (entry.second->route_manager_ptr()) {
    cluster_version = entry.second->route_manager_ptr()->GetClusterVersion();
  } else {
    ULOG_ERROR << "route manager has been delete";
    return;
  }
  req->set_cluster_version(cluster_version);
  req->set_extern_id(entry.second->extern_id());
  req->set_thread_name(std::to_string(entry.second->GetLoop()->thread_id()));
  ConnectionUeventPtr metaserver_conn =
      GetMetaServerConnection(entry.second->lc_set_name());
  if (!metaserver_conn) {
    ULOG_ERROR << "no available metaserver connection";
    return;
  }
  ULOG_DEBUG << um.DebugString();
  MessageUtil::SendPbRequest(
      metaserver_conn, um, std::bind(&ManagerThread::HeartbeatResponseCb, this,
                                     std::placeholders::_1, entry),
      std::bind(&ManagerThread::HeartbeatTimeoutCb, this, entry), 2.0);
}

// 处理随心跳上报的统计信息，主要是缓存到管理线程
void ManagerThread::StatsInfoHandle(
    HandleEntry& entry, ucloud::udisk::LCIOStats& iostat,
    std::vector<ucloud::udisk::GateChunkIOStats>& chunk_stats,
    std::vector<ucloud::udisk::GatePCIOStats>& pc_stats) {
  vector<ucloud::udisk::LCIOStats>& udisk_stat = udisk_stats_[entry];
  udisk_stat.push_back(iostat);
  uint32_t ts = base::Timestamp::now().secondsSinceEpoch();
  for (uint32_t chunk_id = 0; chunk_id < chunk_stats.size(); ++chunk_id) {
    ucloud::udisk::GateChunkIOStats& stat = chunk_stats[chunk_id];
    if (chunk_stats_[entry.second->extern_id()].size() <= chunk_id) {
      chunk_stats_[entry.second->extern_id()].resize(chunk_id + 1);
    }
    ChunkStatPairMap& stats = chunk_stats_[entry.second->extern_id()][chunk_id];
    stats[ts].set_chunk_id(chunk_id);
    stats[ts].set_iops_read(stat.iops_read());
    stats[ts].set_iops_write(stat.iops_write());
    stats[ts].set_byteps_read(stat.byteps_read());
    stats[ts].set_byteps_write(stat.byteps_write());
    stats[ts].set_read_latency(stat.read_latency());
    stats[ts].set_write_latency(stats[ts].write_latency());
  }
  for (auto it = chunk_stats_.begin(); it != chunk_stats_.end(); ++it) {
    vector<ChunkStatPairMap>& chunk_stats = it->second;
    for (uint32_t chunk_id = 0; chunk_id < chunk_stats.size(); ++chunk_id) {
      ChunkStatPairMap& stats = chunk_stats[chunk_id];
      // 清理每个chunk的统计信息：
      // 1. 超过60s没有更新，清除
      // 2. 超过60个node，清除
      for (auto stat_it = stats.begin(); stat_it != stats.end();) {
        if (stat_it->first + 60 < ts) {
          stat_it = stats.erase(stat_it);
        } else {
          ++stat_it;
        }
      }
      while (stats.size() > 60) {  // 只保留最近1min内的统计信息
        stats.erase(stats.begin());
      }
    }
  }
  // pc统计信息
  for (uint32_t pc_no = 0; pc_no < pc_stats.size(); ++pc_no) {
    ucloud::udisk::GatePCIOStats& stat = pc_stats[pc_no];
    if (pc_stats_[entry.second->extern_id()].size() <= pc_no) {
      pc_stats_[entry.second->extern_id()].resize(pc_no + 1);
    }
    PCStatPairMap& pc_stats = pc_stats_[entry.second->extern_id()][pc_no];
    pc_stats[ts].set_pc_no(pc_no);
    pc_stats[ts].set_iops_read(stat.iops_read());
    pc_stats[ts].set_iops_write(stat.iops_write());
    pc_stats[ts].set_byteps_read(stat.byteps_read());
    pc_stats[ts].set_byteps_write(stat.byteps_write());
    pc_stats[ts].set_read_latency(stat.read_latency());
    pc_stats[ts].set_write_latency(stat.write_latency());
  }
  for (auto it = pc_stats_.begin(); it != pc_stats_.end(); ++it) {
    for (uint32_t pc_no = 0; pc_no < it->second.size(); ++pc_no) {
      PCStatPairMap& pc_stats = it->second[pc_no];
      // 清理每个chunk的统计信息：
      // 1. 超过5s没有更新，清除
      // 2. 超过5个node，清除
      for (auto stat_it = pc_stats.begin(); stat_it != pc_stats.end();) {
        if (stat_it->first + 5 < ts) {
          stat_it = pc_stats.erase(stat_it);
        } else {
          ++stat_it;
        }
      }
      while (pc_stats.size() > 5) {  // 只保留最近5s内的统计信息
        pc_stats.erase(pc_stats.begin());
      }
    }
  }
}

// 在 manager thread 中执行
void ManagerThread::HeartbeatResponseCb(const UMessagePtr& um,
                                        HandleEntry entry) {
  int64_t handle_id = entry.first;
  UDiskWorker* worker = entry.second;
  assert(um->head().message_type() ==
         ucloud::udisk::HEARTBEAT_GATE_METASERVER_RESPONSE);
  assert(um->has_body());
  assert(um->body().HasExtension(
      ucloud::udisk::heartbeat_gate_metaserver_response));
  ucloud::udisk::HeartbeatGateMetaServerResponse rsp = um->body().GetExtension(
      ucloud::udisk::heartbeat_gate_metaserver_response);
  if (rsp.rc().retcode() != 0) {
    ULOG_ERROR << "gate heartbeat_response error," << rsp.rc().error_message();
  } else {
    if (rsp.has_cluster_info()) {
      // 在io loop 中执行
      worker->UpdateRouteManager(rsp.cluster_info(), rsp.chunk_info(),
                                 rsp.pg_info(), handle_id);
    }
  }
}

void ManagerThread::HeartbeatTimeoutCb(HandleEntry entry) {
  ULOG_ERROR << "heartbeat responsetimeout, udisk_worker: " << entry.second
             << " handle_id: " << entry.first;
}

// TODO(yeheng) 这里直接使用了worker指针，可能worker中的内容已经变化
// 比如extern_id lc_set_name, 造成统计信息错误
void ManagerThread::ReportOdinTimer() {
  ULOG_DEBUG << "ReportOdinTimer start, udisk_size=" << udisk_stats_.size();
  // 上报io重试信息
  ReportOdinIOTimeout();
  for (auto it = udisk_stats_.begin(); it != udisk_stats_.end();) {
    ucloud::UMessage um;
    NewMessage_v2(&um, MessageUtil::Flowno(), base::MyUuid::NewUuid(),
                  ucloud::udisk::REPORT_GATE_ODIN_REQUEST, 0, false,
                  MessageUtil::ObjId(), 0, "ReportIOStat", NULL, NULL);
    ucloud::udisk::ReportGateOdinRequest* req =
        um.mutable_body()->MutableExtension(
            ucloud::udisk::report_gate_odin_request);
    HandleEntry entry = it->first;
    ucloud::udisk::LCIOStats* iostat = req->add_io_stats();  //会初始化为0
    for (auto item : it->second) {  // 对某个lc的多个点求和
      iostat->set_iops_read(iostat->iops_read() + item.iops_read());
      iostat->set_iops_write(iostat->iops_write() + item.iops_write());
      iostat->set_byteps_read(iostat->byteps_read() + item.byteps_read());
      iostat->set_byteps_write(iostat->byteps_write() + item.byteps_write());
      iostat->set_read_latency(iostat->read_latency() + item.read_latency());
      iostat->set_write_latency(iostat->write_latency() + item.write_latency());
    }
    uint32_t item_count = it->second.size();
    if (item_count == 0) {
      ULOG_ERROR << "impossible!!!" << entry.second->extern_id();
      it = udisk_stats_.erase(it);
      continue;
    }
    iostat->set_iops_read(ceil(iostat->iops_read() * 1.0 / item_count));
    iostat->set_iops_write(ceil(iostat->iops_write() * 1.0 / item_count));
    iostat->set_byteps_read(ceil(iostat->byteps_read() * 1.0 / item_count));
    iostat->set_byteps_write(ceil(iostat->byteps_write() * 1.0 / item_count));
    iostat->set_read_latency(ceil(iostat->read_latency() * 1.0 / item_count));
    iostat->set_write_latency(ceil(iostat->write_latency() * 1.0 / item_count));
    iostat->set_extern_id(entry.second->extern_id());
    iostat->set_stats_time(base::Timestamp::now().secondsSinceEpoch());
    iostat->set_stats_period(g_config_parser->report_odin_period());
    it = udisk_stats_.erase(it);  // 统计完毕以后删除统计信息
    // 获取set name, 可能是错的 FIXME(yeheng)
    ConnectionUeventPtr odin_conn =
        GetOdinConnection(entry.second->lc_set_name());
    if (!odin_conn) {
      ULOG_ERROR << "no available odin connection";
      return;
    }
    ULOG_DEBUG << um.DebugString();
    MessageUtil::SendPbRequest(
        odin_conn, um, std::bind(&ManagerThread::ReportIOStatResponseCb, this,
                                 std::placeholders::_1),
        std::bind(&ManagerThread::ReportIOStatTimeout, this), 2.0);
  }
}

void ManagerThread::ReportIOStatResponseCb(const UMessagePtr& um) {
  const ucloud::udisk::ReportGateOdinResponse& res =
      um->body().GetExtension(ucloud::udisk::report_gate_odin_response);
  if (res.rc().retcode() != 0) {
    ULOG_ERROR << "ReportIOStatResponse ERROR, code=" << res.rc().retcode()
               << ", msg=" << res.rc().error_message();
    return;
  }
}

void ManagerThread::ReportIOStatTimeout() {
  ULOG_ERROR << "ReportIOStatTimeout. ";
}

void ManagerThread::WarningToOdin(
    ucloud::udisk::OdinWarningRequest& warn_request,
    const std::string& set_name) {
  loop_->RunInLoop(std::bind(&ManagerThread::WarningToOdinInLoop, this,
                             warn_request, set_name));
}

void ManagerThread::WarningToOdinInLoop(
    ucloud::udisk::OdinWarningRequest& warn_request,
    const std::string& set_name) {
  ULOG_INFO << "report waring to odin";
  ConnectionUeventPtr odin_conn = GetOdinConnection(set_name);
  if (!odin_conn) {
    ULOG_ERROR << "odin connection not available for set: " << set_name;
    return;
  }
  ucloud::UMessage um;
  uint32_t obj_id = uevent::MessageUtil::ObjId();
  uint32_t flowno = uevent::MessageUtil::Flowno();
  NewMessage_v2(&um, flowno, base::MyUuid::NewUuid(),
                ucloud::udisk::ODIN_WARNING_REQUEST, 0, false, obj_id, 0,
                "OdinWarningRequest", NULL, NULL);
  ucloud::udisk::OdinWarningRequest* req =
      um.mutable_body()->MutableExtension(ucloud::udisk::odin_warning_request);
  req->Swap(&warn_request);
  ULOG_INFO << um.DebugString();
  MessageUtil::SendPbRequest(
      odin_conn, um, std::bind(&ManagerThread::OdinWarningResponseCb, this,
                               std::placeholders::_1),
      std::bind(&ManagerThread::OdinWarningTimeout, this), 2.0);
}

void ManagerThread::OdinWarningResponseCb(const UMessagePtr& um) {
  const ucloud::udisk::OdinWarningResponse& res =
      um->body().GetExtension(ucloud::udisk::odin_warning_response);
  if (res.rc().retcode() != 0) {
    ULOG_ERROR << "odin warning response error";
  }
}

void ManagerThread::OdinWarningTimeout() {
  ULOG_ERROR << "odin waring request timeout";
}

void ManagerThread::ReportIOTimeout(const std::string& extern_id,
                                    uint32_t retry_times,
                                    const std::string& set_name) {
  loop_->RunInLoop(std::bind(&ManagerThread::ReportIOTimeoutInLoop, this,
                             extern_id, retry_times, set_name));
}

void ManagerThread::ReportIOTimeoutInLoop(const std::string& extern_id,
                                          uint32_t retry_times,
                                          const std::string& set_name) {
  ULOG_INFO << "report io timeout, extern_id: " << extern_id
            << ", retry_times: " << retry_times << ", set_name: " << set_name;
  auto it = lc_timeout_.find(extern_id);
  if (it == lc_timeout_.end()) {
    lc_timeout_[extern_id] = std::make_pair(set_name, retry_times);
    return;
  }

  if (it->second.second < retry_times) {
    it->second.second = retry_times;
  }
  return;
}

void ManagerThread::ReportOdinIOTimeout() {
  LCTimeoutMap timeout_map;
  timeout_map.swap(lc_timeout_);
  ucloud::udisk::OdinWarningRequest warn_request;
  for (auto it = timeout_map.begin(); it != timeout_map.end(); ++it) {
    // ip:port:extern_id 拼成uuid, 唯一标识这个告警
    std::string uuid = g_config_parser->listen_ip() + ":" +
                       std::to_string(g_config_parser->listen_port()) + ":" +
                       it->first;
    uint32_t retry_times = it->second.second;
    const std::string& set_name = it->second.first;
    warn_request.set_uuid(uuid);
    warn_request.set_item_id(ConfigParser::kIORetryManyTimesItemId);
    warn_request.set_value(retry_times);
    warn_request.set_info("retry more than " + std::to_string(retry_times) +
                          " times");
    warn_request.set_time(base::Timestamp::now().secondsSinceEpoch());
    WarningToOdinInLoop(warn_request, set_name);
  }
  return;
}

}  // namespace gate
}  // namespace udisk
