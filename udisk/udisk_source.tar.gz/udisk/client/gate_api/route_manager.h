#ifndef UDISK_GATE_ROUTE_MANAGER_H_
#define UDISK_GATE_ROUTE_MANAGER_H_

#include <vector>
#include <string>
#include <memory>
#include <ustevent/callbacks.h>
#include "udisk_message.h"
#include "cluster_map.h"
#include "cluster_hash_ring.h"

namespace udisk {
namespace gate {

class UDiskWorker;

class RouteManager {
 public:
  struct ChunkRouteEntry {
    ChunkRouteEntry() : version(0) {}
    uint64_t version;
    uint32_t pg_id;
    uint32_t chunk_id;
    uevent::ConnectorUeventPtr ctor;
  };
  explicit RouteManager(UDiskWorker* worker);
  ~RouteManager();
  void GetChunkRoute(uint32_t lc_id, uint32_t pc_no, uint32_t lc_random_id,
                     uint64_t* version, uint32_t* pg_id, uint32_t* chunk_id,
                     uevent::ConnectorUeventPtr* ctor);
  void UpdateClusterMap(const ucloud::udisk::ClusterInfoPb& cluster_info,
                        const ::google::protobuf::RepeatedPtrField<
                            ::ucloud::udisk::ChunkInfoPb>& chunk_info,
                        const ::google::protobuf::RepeatedPtrField<
                            ::ucloud::udisk::PGInfoPb>& pg_info);
  inline bool IsReady() { return is_ready_; }
  inline uint64_t GetClusterVersion() const {
    if (cluster_map_.IsInit()) {
      return cluster_map_.GetClusterVersion();
    }
    return 0;
  }

 private:
  UDiskWorker* worker_;
  bool is_ready_;
  uint32_t size_;
  std::vector<ChunkRouteEntry> chunk_route_cache_;
  cluster::ClusterMap cluster_map_;
  cluster::ClusterHashRing hash_ring_;
};

}  // namespace gate
}  // namespace udisk

#endif
