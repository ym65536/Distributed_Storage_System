#ifndef UDISK_GATE_UDISK_WORKER_H_
#define UDISK_GATE_UDISK_WORKER_H_

#include <string>
#include <unordered_map>
#include <memory>
#include <deque>
#include <list>
#include <ustevent/base/logging.h>
#include <ustevent/eventloop.h>
#include <ustevent/timer.h>
#include <ustevent/usock_address.h>
#include <spdk/env.h>
#include "qemu_io_proto.h"
#include "gate_io_proto.h"
#include "route_manager.h"
#include "udisk_message.h"
#include "get_lc_last_rw_tick.h"
#include "gate_api.h"

namespace udisk {
namespace gate {

typedef struct AmountIOStats {
  int64_t amount_io_read;
  int64_t amount_io_write;
  int64_t amount_byte_read;
  int64_t amount_byte_write;
  int64_t amount_read_latency;   // 单位us
  int64_t amount_write_latency;  // 单位us
  int64_t amount_rw_latency;     // 单位us
} AmountIOStats;

class LoginHydra;
class IORequest;
class FragIORequest;
class GetLcRwTick;

using uevent::LoopHandle;
using uevent::ConnectionUeventPtr;
using uevent::ConnectorUeventPtr;
using uevent::EventLoop;
using common::GateIOResponseHead;

class UDiskWorker : public LoopHandle {
 public:
  static LoopHandle* CreateMyself(EventLoop* loop);
  inline int64_t handle_id() { return handle_id_; }
  UDiskWorker(EventLoop* loop);
  ~UDiskWorker();
  bool Init(const std::string& extern_id,
            const ucloud::udisk::UDiskLoginResponse& rsp);
  void Reset();
  void RwRequestHandle(struct udisk_io* io);
  void RwResponseHandle(const ConnectionUeventPtr& conn,
                        GateIOResponseHead* head);
  void IOErrorHandle(int32_t retcode, FragIORequest* frag_req,
                     const ConnectionUeventPtr& conn);
  void RetryErrorFragIO(FragIORequest* frag_req, int timer_count);
  void RetryAllSameConnFragIO(int64_t conn_id);
  void SendPendingIO();
  void IOTimerCb();
  ConnectionUeventPtr GetChunkConnection(FragIORequest* frag_req);
  void DestroyChunkConnection(uint64_t conn_id);
  void UpdateRouteManager(const ucloud::udisk::ClusterInfoPb& cluster_info,
                          const ::google::protobuf::RepeatedPtrField<
                              ::ucloud::udisk::ChunkInfoPb>& chunk_info,
                          const ::google::protobuf::RepeatedPtrField<
                              ::ucloud::udisk::PGInfoPb>& pg_info,
                          int64_t handle_id);
  void UpdateRouteManagerInLoop(const ucloud::udisk::ClusterInfoPb cluster_info,
                                const ::google::protobuf::RepeatedPtrField<
                                    ::ucloud::udisk::ChunkInfoPb> chunk_info,
                                const ::google::protobuf::RepeatedPtrField<
                                    ::ucloud::udisk::PGInfoPb> pg_info,
                                int64_t handle_id);

  uevent::ConnectorUeventPtr GetChunkConnector(
      const uevent::UsockAddress& addr);
  // 考虑效率返回引用
  inline const uint32_t GetLcId() const { return lc_id_; }
  inline void SetLcId(uint32_t lc_id) { lc_id_ = lc_id; }
  inline const uint32_t GetRandomId() const { return lc_random_id_; }
  inline void SetRandomId(uint32_t lc_random_id) {
    lc_random_id_ = lc_random_id;
  }
  inline void SetLcSetName(const std::string& set_name) {
    lc_set_name_ = set_name;
  }
  inline void SetLcSize(uint64_t size) { size_ = size; }
  inline uint64_t GetLcSize() { return size_; }
  inline std::string lc_set_name() const { return lc_set_name_; }
  inline std::string extern_id() const { return extern_id_; }
  inline std::shared_ptr<RouteManager> route_manager_ptr() const {
    return route_manager_ptr_;
  }
  inline bool RouteIsReady() {
    if (route_manager_ptr_ && route_manager_ptr_->IsReady()) {
      return true;
    }
    return false;
  }

  inline void IncReadIOCount() { io_stats_.amount_io_read++; }
  inline void IncWriteIOCount() { io_stats_.amount_io_write++; }
  inline void IncReadBytesCount(int64_t io_size) {
    io_stats_.amount_byte_read += io_size;
  }
  inline void IncWriteBytesCount(int64_t io_size) {
    io_stats_.amount_byte_write += io_size;
  }
  inline void AddReadLatency(int64_t lat) {
    io_stats_.amount_read_latency += lat;
  }
  inline void AddWriteLatency(int64_t lat) {
    io_stats_.amount_write_latency += lat;
  }
  inline void set_last_read_tick(base::Timestamp tick) {
    last_read_tick_ = tick.secondsSinceEpoch();
  }
  inline void set_last_write_tick(base::Timestamp tick) {
    last_write_tick_ = tick.secondsSinceEpoch();
  }

  void GetIOStatistics(ucloud::udisk::LCIOStats& stats, int interval);

  inline void IncReadIOCount(uint32_t chunk_id, uint32_t pc_no) {
    if (chunk_id >= chunk_io_stats_.size()) {
      chunk_io_stats_.resize(chunk_id + 1);
    }
    if (pc_no >= pc_io_stats_.size()) {
      ULOG_FATAL << "impossible pc no: " << pc_no;
    }
    chunk_io_stats_[chunk_id].amount_io_read++;
    pc_io_stats_[pc_no].amount_io_read++;
  }
  inline void IncWriteIOCount(uint32_t chunk_id, uint32_t pc_no) {
    if (chunk_id >= chunk_io_stats_.size()) {
      chunk_io_stats_.resize(chunk_id + 1);
    }
    if (pc_no >= pc_io_stats_.size()) {
      ULOG_FATAL << "impossible pc no: " << pc_no;
    }
    chunk_io_stats_[chunk_id].amount_io_write++;
    pc_io_stats_[pc_no].amount_io_write++;
  }
  inline void IncReadBytesCount(uint32_t chunk_id, uint32_t pc_no,
                                int64_t io_size) {
    chunk_io_stats_[chunk_id].amount_byte_read += io_size;
    pc_io_stats_[pc_no].amount_byte_read += io_size;
  }
  inline void IncWriteBytesCount(uint32_t chunk_id, uint32_t pc_no,
                                 int64_t io_size) {
    chunk_io_stats_[chunk_id].amount_byte_write += io_size;
    pc_io_stats_[pc_no].amount_byte_write += io_size;
  }
  inline void AddReadLatency(uint32_t chunk_id, uint32_t pc_no, int64_t lat) {
    chunk_io_stats_[chunk_id].amount_read_latency += lat;
    pc_io_stats_[pc_no].amount_read_latency += lat;
  }
  inline void AddWriteLatency(uint32_t chunk_id, uint32_t pc_no, int64_t lat) {
    chunk_io_stats_[chunk_id].amount_write_latency += lat;
    pc_io_stats_[pc_no].amount_write_latency += lat;
  }
  void GetChunkIOStatistics(std::vector<ucloud::udisk::GateChunkIOStats>&,
                            std::vector<ucloud::udisk::GatePCIOStats>&, int);

  inline void ClearChunkIOStats() {
    std::vector<AmountIOStats> chunk_io_stats(chunk_io_stats_.size());
    chunk_io_stats_.swap(chunk_io_stats);
    std::vector<AmountIOStats> pc_io_stats(pc_io_stats_.size());
    pc_io_stats_.swap(pc_io_stats);
  }

  inline void ClearIOStats() {
    io_stats_.amount_io_read = 0;
    io_stats_.amount_byte_read = 0;
    io_stats_.amount_byte_write = 0;
    io_stats_.amount_io_write = 0;
    io_stats_.amount_read_latency = 0;
    io_stats_.amount_write_latency = 0;
    io_stats_.amount_rw_latency = 0;
  }
  inline std::list<IORequest*>& GetPendingList() { return pending_list_; }
  inline std::list<IORequest*>& GetInflightList() { return inflight_list_; }
  static void EventReadCb(int fd, short event, void* ctx);
  void GetRwTickInfo(std::shared_ptr<GetLcRwTick> ptr);
  int io_timer_count() const { return io_timer_count_; }
  size_t SubmitIo(struct udisk_io** ios, size_t cnt);
  void CompleteIo(struct udisk_io* io);
  size_t GetIoCompleted(struct udisk_io** ios, size_t cnt);
  static void RecvData(struct iovec* iov, const ConnectionUeventPtr& conn);

 private:
  static void ChunkConnSuccessCb(const ConnectionUeventPtr& conn);
  static void ChunkConnClosedCb(const ConnectionUeventPtr& conn);
  static void ChunkConnReadCb(const ConnectionUeventPtr& conn);

  bool VhostIoInit();
  void VhostIoFini();
  void HandleVhostIO(uint32_t io_count);

  int64_t handle_id_;
  bool conn_is_reset_;
  // 长连接的connector不需要释放
  std::unordered_map<uint64_t, ConnectorUeventPtr> chunk_connector_map_;
  std::string extern_id_;
  uint32_t lc_id_;
  uint32_t lc_random_id_;
  std::string lc_set_name_;
  uint64_t size_;
  AmountIOStats io_stats_;
  std::vector<AmountIOStats> chunk_io_stats_;
  // login 得到lc_size时会resize
  std::vector<AmountIOStats> pc_io_stats_;  // index->pc_no
  uint32_t last_read_tick_;
  uint32_t last_write_tick_;
  std::list<IORequest*> pending_list_;
  std::list<IORequest*> inflight_list_;
  std::shared_ptr<RouteManager> route_manager_ptr_;
  uevent::TimerId heartbeat_timer_id_;
  uevent::TimerId io_timer_id_;
  int io_timer_count_;  // 10ms触发一次timer

  std::function<void(void*)> login_finish_cb_;
  int listen_fd_;
  int event_idx_;
  struct spdk_ring* submit_ring_;
  struct spdk_ring* done_ring_;
};

}  // namespace gate
}  // namespace udisk

#endif
