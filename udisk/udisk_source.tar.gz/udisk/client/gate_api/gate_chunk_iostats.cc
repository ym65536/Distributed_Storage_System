#include "gate_chunk_iostats.h"
#include <ustevent/message_util.h>
#include "umessage_common.h"

namespace udisk {
namespace gate {

int GateChunkIOStatsHandle::type_ = ucloud::udisk::GATE_CHUNK_IOSTATS_REQUEST;

void GateChunkIOStatsHandle::SendResponse(int retcode,
                                          const std::string& message) {
  resp_body_->mutable_rc()->set_retcode(retcode);
  resp_body_->mutable_rc()->set_error_message(message);
  uevent::MessageUtil::SendPbResponse(conn_, response_);
}

void GateChunkIOStatsHandle::EntryInit(const ConnectionUeventPtr& conn,
                                       const UMessagePtr& um) {
  conn_ = conn;
  assert(um->head().message_type() == type_);
  assert(um->body().HasExtension(ucloud::udisk::gate_chunk_iostats_request));

  ucloud::udisk::GateChunkIOStatsRequest req_body =
      um->body().GetExtension(ucloud::udisk::gate_chunk_iostats_request);
  MakeResponse(um.get(), ucloud::udisk::GATE_CHUNK_IOSTATS_RESPONSE,
               &response_);
  resp_body_ = response_.mutable_body()->MutableExtension(
      ucloud::udisk::gate_chunk_iostats_response);

  // 处理
  GateChunkIOStatsProcess(req_body);
}

void GateChunkIOStatsHandle::GateChunkIOStatsProcess(
    ucloud::udisk::GateChunkIOStatsRequest req) {
  std::string extern_id = req.extern_id();
  uint32_t chunk_id = req.has_chunk_id() ? req.chunk_id() : (-1U);
  ULOG_INFO << "recv gate_chunk_iostats_request, extern_id:" << extern_id
            << " chunk_id:" << chunk_id;

  // 获取chunk 统计信息
  ChunkStatsMap chunk_stats = ManagerThread::Instance()->GetChunkStats();
  auto it = chunk_stats.find(extern_id);
  if (it == chunk_stats.end()) {
    SendResponse(-1, "req extern_id not exist");
    ULOG_ERROR << "req extern_id not exist!";
    return;
  }
  vector<ChunkStatPairMap>& pair_maps = it->second;
  if (chunk_id == (-1U)) {  // 获取所有chunk信息
    for (uint32_t id = 0; id < pair_maps.size(); ++id) {
      ucloud::udisk::GateChunkIOStats* stat = resp_body_->add_stats();
      stat->CopyFrom(MergeChunkStat(id, pair_maps[id]));
    }
  } else {  // 获取指定chunk信息
    if (pair_maps[chunk_id].size() > 0) {
      ucloud::udisk::GateChunkIOStats* stat = resp_body_->add_stats();
      stat->CopyFrom(MergeChunkStat(chunk_id, pair_maps[chunk_id]));
    }
  }

  // 获取pc统计信息
  PCStatsMap pc_stats = ManagerThread::Instance()->GetPCStats();
  auto pc_it = pc_stats.find(extern_id);
  if (pc_it == pc_stats.end()) {
    SendResponse(0, "sucess");
    ULOG_ERROR << "req pc stat empty!";
    return;
  }
  vector<PCStatPairMap>& pc_pair_maps = pc_it->second;
  uint32_t pc_begin = req.has_pc_no_begin() ? req.pc_no_begin() : 0;
  uint32_t pc_end = req.has_pc_no_end() ? req.pc_no_end() : pc_pair_maps.size();
  pc_end = pc_end > pc_pair_maps.size() ? pc_pair_maps.size() : pc_end;
  for (uint32_t pc_no = pc_begin; pc_no < pc_end; ++pc_no) {
    ucloud::udisk::GatePCIOStats pc_stat =
        MergePCStat(pc_no, pc_pair_maps[pc_no]);
    if (pc_stat.iops_read() + pc_stat.iops_write() == 0) {  // 读写都是0，不返还
      ULOG_DEBUG << "extern_id=" << extern_id << ", pc_no=" << pc_no
                 << " no read and write, ignore.";
      continue;
    }
    ucloud::udisk::GatePCIOStats* stat = resp_body_->add_pc_stats();
    stat->CopyFrom(pc_stat);
  }
  SendResponse(0, "sucess");
  return;
}

ucloud::udisk::GateChunkIOStats GateChunkIOStatsHandle::MergeChunkStat(
    uint32_t chunk_id, ChunkStatPairMap& pair_map) {
  uint32_t item_count = pair_map.size();
  ucloud::udisk::GateChunkIOStats stat;
  stat.set_chunk_id(chunk_id);
  for (auto it = pair_map.begin(); it != pair_map.end(); ++it) {
    stat.set_iops_read(stat.iops_read() + it->second.iops_read());
    stat.set_iops_write(stat.iops_write() + it->second.iops_write());
    stat.set_byteps_read(stat.byteps_read() + it->second.byteps_read());
    stat.set_byteps_write(stat.byteps_write() + it->second.byteps_write());
    stat.set_read_latency(stat.read_latency() + it->second.read_latency());
    stat.set_write_latency(stat.write_latency() + it->second.write_latency());
  }
  stat.set_iops_read(ceil(stat.iops_read() * 1.0 / item_count));
  stat.set_iops_write(ceil(stat.iops_write() * 1.0 / item_count));
  stat.set_byteps_read(ceil(stat.byteps_read() * 1.0 / item_count));
  stat.set_byteps_write(ceil(stat.byteps_write() * 1.0 / item_count));
  stat.set_read_latency(ceil(stat.read_latency() * 1.0 / item_count));
  stat.set_write_latency(ceil(stat.write_latency() * 1.0 / item_count));
  return stat;
}

ucloud::udisk::GatePCIOStats GateChunkIOStatsHandle::MergePCStat(
    uint32_t pc_no, PCStatPairMap& pair_map) {
  uint32_t item_count = pair_map.size();
  ucloud::udisk::GatePCIOStats stat;
  stat.set_pc_no(pc_no);
  for (auto it = pair_map.begin(); it != pair_map.end(); ++it) {
    stat.set_iops_read(stat.iops_read() + it->second.iops_read());
    stat.set_iops_write(stat.iops_write() + it->second.iops_write());
    stat.set_byteps_read(stat.byteps_read() + it->second.byteps_read());
    stat.set_byteps_write(stat.byteps_write() + it->second.byteps_write());
    stat.set_read_latency(stat.read_latency() + it->second.read_latency());
    stat.set_write_latency(stat.write_latency() + it->second.write_latency());
  }
  stat.set_iops_read(ceil(stat.iops_read() * 1.0 / item_count));
  stat.set_iops_write(ceil(stat.iops_write() * 1.0 / item_count));
  stat.set_byteps_read(ceil(stat.byteps_read() * 1.0 / item_count));
  stat.set_byteps_write(ceil(stat.byteps_write() * 1.0 / item_count));
  stat.set_read_latency(ceil(stat.read_latency() * 1.0 / item_count));
  stat.set_write_latency(ceil(stat.write_latency() * 1.0 / item_count));
  return stat;
}
}
}
