#ifndef UDISK_GATE_IO_REQUEST_H_
#define UDISK_GATE_IO_REQUEST_H_

#include <bitset>
#include <vector>
#include <sstream>
#include <ustevent/base/timestamp.h>
#include <ustevent/callbacks.h>
#include "gate_api.h"

namespace udisk {
namespace gate {

class UDiskWorker;
class FragIORequest;

class IORequest {
 public:
  IORequest(UDiskWorker* worker, struct udisk_io* io);
  ~IORequest();
  void Init();
  int Send();
  void Response();
  void DecTimerCount();
  inline uint64_t GetFlowno() const { return io_->flowno; }
  inline uint64_t GetBeginSector() const { return io_->offset_blocks; }
  inline uint64_t GetEndSector() const { return end_sector_; }
  inline FragIORequest* GetFragIORequest(uint32_t fragno) {
    return frag_req_vec_[fragno];
  }
  inline std::vector<FragIORequest*>* GetFragReqVec() { return &frag_req_vec_; }

  //最多只能有1024个分片
  inline bool MarkFragReceived(uint32_t fragno) {
    frag_bit_set_[fragno] = 0;
    return frag_bit_set_.none();  // 全为0 表示收到了所有的分片
  }

  inline void MarkFragUnReceived(uint32_t fragno) { frag_bit_set_[fragno] = 1; }

  inline uint64_t GetSectorNumber() { return io_->num_blocks; }

 private:
  inline std::string DumpUDiskIO(struct udisk_io* io) {
    std::ostringstream oss;
    oss << "\nUDiskIO {"
        << " type: " << io->type
        << " flowno: " << io->flowno
        << " shard_idx: " << io->shard_idx
        << " offset_blocks: " << io->offset_blocks
        << " num_blocks: " << io->num_blocks
        << " iovs: " << io->iovs
        << " iovcnt: " << io->iovcnt
        << " ret: " << io->ret << "}";
    return oss.str();
  }
  bool CheckOverlap();
  UDiskWorker* worker_;
  struct udisk_io* io_;
  uint64_t end_sector_;
  std::vector<FragIORequest*> frag_req_vec_;
  std::bitset<1024> frag_bit_set_;
  base::Timestamp start_time_;
};

}  // namespace gate
}  // namespace udisk

#endif
