#ifndef UDISK_GATE_MY_CONFIG_PARSER_H_
#define UDISK_GATE_MY_CONFIG_PARSER_H_

#include "config_parser.h"

namespace udisk {
namespace gate {

class MyConfigParser : public common::ConfigParser {
 public:
  explicit MyConfigParser(const std::string& file);
  void Init();
  inline int32_t thread_num() const { return thread_num_; }
  inline int32_t report_odin_period() const { return report_odin_period_; }
  inline int32_t heartbeat_period() const { return heartbeat_period_; }
  std::string global_odin_zk_path() const { return global_odin_zk_path_; }

  const static std::string kThreadNum;
  const static std::string kReportOdinPeriod;
  const static std::string kHeartbeatPeriod;
  const static std::string kGlobalOdinName;

 private:
  int32_t thread_num_;
  int32_t report_odin_period_;
  int32_t heartbeat_period_;
  std::string global_odin_zk_path_;
};

}  // gate
}  // udisk

#endif
