#!/usr/bin/python
# -*- coding: utf-8 -*-
# ts=2, sw=2

import os, sys, commands
import getopt
import pdb
sys.path.append(os.path.abspath(os.path.join(__file__, '../message')))
import udisk_pb2, wiwo_python

def help():
  print sys.argv[0] + " Usage: [-h] [-i gate_ip] [-p gate_port]"

def main():
  try:
      options, args = getopt.getopt(sys.argv[1:], "hi:p:", [])
  except getopt.GetoptError as e:
    print str(e)
    help()
    sys.exit(1)
  gate_ip = ""
  gate_port = 0
  for option, value in options:
    if option == "-h":
      help()
      sys.exit(0)
    elif option == "-i":
      gate_ip = value
    elif option == "-p":
      gate_port = value
    else:
      help()
      sys.exit(1)
  gate_client = wiwo_python.Client(gate_ip, gate_port)
  try:
    gate_client.connect()
  except Exception as e:
    print "connect error, %s" % str(e)
    sys.exit(1)
  request = udisk_pb2.GetLcLastRwTickRequest()
  response = gate_client.request(request, udisk_pb2.GET_LC_LAST_RW_TICK_REQUEST,\
                            udisk_pb2.get_lc_last_rw_tick_request,\
                            udisk_pb2.get_lc_last_rw_tick_response)
  print "gate response: \n%s" % (str(response))

if __name__ == "__main__":
  main()
