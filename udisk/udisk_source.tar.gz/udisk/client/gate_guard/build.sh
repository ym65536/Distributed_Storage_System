#!/bin/sh

if [ ! $# -eq 1 ];then
  echo "Usage: $0 <devel | release>"
  exit 1
fi

PROTOC=/usr/bin/protoc

message_build() {
  if [ -e message ];then
    echo "message dir exists ! rm -rf message"
    rm -rf message
  fi
  mkdir message
  
  $PROTOC --proto_path=${HOME}/message/proto --python_out=message ${HOME}/message/proto/ucloud.proto
  
  $PROTOC --proto_path=${HOME}/message/proto --python_out=message ${HOME}/message/proto/uns.55000.56000.proto
  mv message/uns/55000/56000_pb2.py message/uns_pb2.py
  rm -rf message/uns
  
  ${PROTOC} --proto_path=${HOME}/message/proto --python_out=message ${HOME}/message/proto/udisk.320000.322000.proto
  mv message/udisk/320000/322000_pb2.py message/udisk_pb2.py
  rm -rf message/udisk
}

devel_build() {
  message_build
}

release_build() {
  message_build
  rm -rf build
  mkdir -p build/gate_guard
  cp -r message build/gate_guard
  cp gate_guard.py build/gate_guard
  cp wiwo_python.py build/gate_guard
  cp -r dep_packages/ build/gate_guard
  cp gate_guard build/gate_guard
  cp -r conf build/gate_guard
  cd build
  tar -zcvf gate_guard.tar.gz gate_guard
  cd -
  rm -rf message
  #rm -rf build
}

if [ $1 == "devel" ];then
  devel_build
else
  release_build
fi
