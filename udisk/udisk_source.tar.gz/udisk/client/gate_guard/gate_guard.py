#!/usr/bin/python
# -*- coding: utf-8 -*-
# ts=2, sw=2

import os, sys, commands
import ConfigParser, getopt
import logging, time
import pdb
sys.path.append(os.path.abspath(os.path.join(__file__, '../message')))
import udisk_pb2, uns_pb2, wiwo_python
import zookeeper
import re
from logging.handlers import TimedRotatingFileHandler
from logging.handlers import RotatingFileHandler

VERSION_TAG = "1.01"  # 版本变动需要改这里
TOP_COUNT = 2 # 通过top命令获取pids_stat的次数

def daemon():
  pid = os.fork()
  if pid > 0:
    sys.exit(0)

  os.chdir("/")
  os.setsid()
  os.umask(0)

  pid = os.fork()
  if pid > 0:
    sys.exit(0)
  os.close(0)
  os.close(1)
  os.close(2)

class GateGuard:
  def __init__(self, config, logger):
    self._config = config
    self._logger = logger

  def gates_stat(self):
    gates = self.running_gate()
    self._logger.info("running_gate: %s" % (str(gates)))
    ret = []
    all_pids = self.pids_stat()
    for item in gates:
      pid = item["pid"]
      tids = self.gate_threads(pid)
      self._logger.info("gate thread count: %s" % (str(len(tids))))
      threads_stat = []
      for tid in tids:
        stat = self.pid_stat(all_pids, tid)
        if not stat:
          self._logger.error("can not find thread %s in all_pids: %s" % (tid, all_pids))
          continue
        threads_stat.append(stat)
        if len(threads_stat) == 0:
          self._logger.error("can not get threads stat %s from all_pids %s" % (tid, all_pids))
          continue
      ret.append({"gate" : pid, "ip" : item["ip"], "port" : item["port"], "stat" : threads_stat})
    return ret

  def command_pid(self, pid):
    comm = os.path.join("/proc", pid, "comm")
    fd = open(comm)
    comm = fd.readline()
    comm = comm.strip()
    return comm

  def pid_stat(self, all_pids, pid):
    count = 0
    for i in all_pids:
      fields = i.split()
      if fields[0] != pid:
        continue
      count = count + 1
      # 只取最后一次
      if count < TOP_COUNT:
        continue

      stat = {"tid" : fields[0], "user" : fields[1],\
              "priority" : fields[2], "nice" : fields[3],\
              "virt" : fields[4], "res" : fields[5],\
              "state" : fields[7], "cpu" : fields[8],\
              "mem" : fields[9], "command" : fields[11]}
      return stat
    return None


  """
    @brief 获取正在运行的gate服务进程
    通过扫描gate的所有的配置文件来定位
    正在运行的gate服务
  """
  def running_gate(self):
    ret = []
    for i in os.listdir(self._config.gate_config_dir()):
      cmd = "ps -ef | grep " + i + ''' | grep block_gate | egrep -v "grep|vim|bash|proxy" '''
      status, output = commands.getstatusoutput(cmd)
      if status != 0:
        continue
      pid = output.split()[1]
      config_file = os.path.join(self._config.gate_config_dir(), i)
      ip, port = self.gate_address_from_file(config_file)
      ret.append({"pid" : pid, "ip" : ip, "port" : port})
      return ret


  def gate_address_from_file(self, config_file):
    config = ConfigParser.RawConfigParser()
    config.read(config_file)
    listen_ip = config.get("network", "listen_ip")
    man_port = config.get("network", "listen_port")
    return (listen_ip, man_port)

  """
    @brief 获取指定的gate服务进程的所有线程
  """
  def gate_threads(self, pid):
    task_dir = os.path.join("/proc", pid, "task")
    if not os.path.exists(task_dir) or not os.path.isdir(task_dir):
      return None
    return os.listdir(task_dir)

  def odin_address(self):
    odin_path = self._config.odin_path()
    zk_server = self._config.zk_server()

    try:
      zookeeper.set_log_stream(open("/dev/null"))
      zkclient = zookeeper.init(zk_server)
    except Exception as e:
      self._logger.error("connect zookeeper server %s faied" % (zk_server))
      return None, None

    try:
      data = zookeeper.get(zkclient, odin_path)
    except Exception as e:
      zookeeper.close(zkclient)
      self._logger.error("odin path %s is not found" % (odin_path))
      return None, None
    zookeeper.close(zkclient)

    if not data or len(data) == 0:
      return None, None
    nc = uns_pb2.NameNodeContent()
    nc.ParseFromString(data[0])

    #if not nc.has_reserved():
    #  return None, None
    port_pair = udisk_pb2.OdinPortPair()
    port_pair.ParseFromString(nc.reserved)

    return nc.ip, port_pair.gate_port

  def start(self):
    while True:
      last_time = time.time()
      time.sleep(self._config.loop_interval())


      try:
        stat = self.gates_stat()
        if 0 == len(stat):
          self._logger.warning("not found running gate")
          continue
        request = self.check_if_need_warning(stat)
      except Exception as e:
        self._logger.error("get gate stat failed: %s" % (str(e)))
        continue

      try:
        if request:
          odin_ip, odin_port = self.odin_address()
          if not odin_ip or not odin_port:
            self._logger.error("can not get the address of odin server from path %s" % (self._config.odin_path()))
            continue
          self._logger.info("current active odin server %s:%s" % (odin_ip, str(odin_port)))
          odin_client = wiwo_python.Client(odin_ip, odin_port)
          odin_client.connect()
          self._logger.info("Request: %s" % str(request))
          response = odin_client.request(request, udisk_pb2.ODIN_WARNING_REQUEST,\
                            udisk_pb2.odin_warning_request,\
                            udisk_pb2.odin_warning_response)
          self._logger.info("odin response: \n%s" % (str(response)));
          odin_client = None   #断开连接
      except Exception as e:
        self._logger.error("send request to %s:%s failed, %s" % (odin_ip, str(odin_port), str(e)))
        continue

# 只会上报第一个检测到的错误
  def check_if_need_warning(self, stat):
    for i in stat:
      need_warning = False
      for j in i["stat"]:
        info = ""
        if float(j["cpu"]) > self._config.cpu_high_level():
          info = "cpu too high:" + j["cpu"] + ":" + j["tid"]
          need_warning = True
        mem_value = j["res"]
        if mem_value.find("k") > 0:
          mem_value = float(mem_value[0:len(mem_value)-1]) * 1000
        elif mem_value.find("m") > 0:
          mem_value = float(mem_value[0:len(mem_value)-1]) * 1000 * 1000
        elif mem_value.find("g") > 0:
          mem_value = float(mem_value[0:len(mem_value)-1]) * 1000 * 1000 * 1000
        if float(mem_value) > self._config.mem_high_level():
          logging.info("mem_value:%s, mem_high_level:%s" % (str(mem_value), str(self._config.mem_high_level())))
          info += "memory too high:" + j["res"]  + ":" + j["tid"]
          need_warning = True
        if True == need_warning:
          warn_request = udisk_pb2.OdinWarningRequest()
          uuid = i["ip"] + ":" + i["port"]
          warn_request.uuid = uuid
          # config_parser.h 中kGateThreadCpuOrMemHighItemId = 4
          warn_request.item_id = 4
          warn_request.period = self._config.loop_interval()
          warn_request.info = info
          warn_request.time = int(time.time())
          return warn_request
    return None

  def pids_stat(self):
    # 加上grep 会失败，commands是非阻塞的
    #cmd = "top -c -H -b -n 1 | grep block_gate"
    cmd = "top -c -H -b -n %d" % TOP_COUNT
    status, output = commands.getstatusoutput(cmd)
    if status != 0:
      logging.error("exec top failed, status: %s" % status)
      return None
    ret = []
    pids = output.split("\n")
    ret = []
    # 输出可能是block_gat+ 或者BlockGa+(watchdog 拉起)的格式
    for i in pids:
      if i.find("block_ga") > 0 or i.find("BlockGa") > 0:
        ret.append(i.strip())
    return ret

  def disks_stat(self, interval = 1, count = 4):
    cmd = "iostat -d -k -x " + str(interval) + " " + str(count)
    cmd = cmd + " | grep Device -A 65535"
    status, output = commands.getstatusoutput(cmd)
    if status != 0:
      return None
    data = output.split("\n")
    data.reverse()
    ret = []
    for i in data:
      i = i.strip()
      if not i:
        continue
      if i.find("Device") < 0:
        ret.append(i.strip())
      else:
        break
    return ret

class UDiskLogger():
  def __init__(self, logname, loglevel, logger='', split='H'):
    self.logger = logging.getLogger(logger)
    self.logger.setLevel(loglevel)

    #日志打印格式
    log_fmt = '%(asctime)s\tline:%(lineno)s\t%(levelname)s: %(message)s'
    formatter = logging.Formatter(log_fmt)
    #创建TimedRotatingFileHandler对象
    handler = TimedRotatingFileHandler(filename=logname, when=split, interval=1, backupCount=30)
    handler.suffix = "%Y-%m-%d_%H-%M-%S.log"
    handler.extMatch = re.compile(r"^\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}.log$")
    handler.setFormatter(formatter) 
    self.logger.addHandler(handler)
  
  def getHandler(self):
    return self.logger;

class Config:
  def __init__(self, f):
    self._file = f

  def load(self):
    config = ConfigParser.RawConfigParser()
    config.read(self._file)

    self._log_file = config.get("logging", "log_file")
    self._log_level = config.get("logging", "log_level")
    self._gate_config_dir = config.get("common", "gate_config_dir")
    self._odin_path = config.get("names", "odin")
    self._zk_server = config.get("zookeeper", "server")
    try:
      self._loop_interval = int(config.get("common", "loop_interval"))
      if self._loop_interval <= 0:
        self._loop_interval = 5
    except:
      self._loop_interval = 5
    try:
      self._cpu_high_level = float(config.get("common", "cpu_high_level"))
      if self._cpu_high_level <= 0:
        self._cpu_high_level = 95
    except:
      self._cpu_high_level = 95
    try:
      self._mem_high_level = float(config.get("common", "mem_high_level"))
      if self._mem_high_level <= 0:
        self._mem_high_level = 10000000000
    except:
        self._mem_high_level = 10000000000

  def log_file(self):
    return self._log_file

  def log_level(self):
    return self._log_level

  def gate_config_dir(self):
    return self._gate_config_dir

  def odin_path(self):
    return self._odin_path

  def cpu_high_level(self):
    return self._cpu_high_level
  def mem_high_level(self):
    return self._mem_high_level

  def zk_server(self):
    return self._zk_server

  def loop_interval(self):
    return self._loop_interval

def help():
  print sys.argv[0] + " Usage: [-h] [-f foreground run] <-c config file>"

def main():
  try:
    options, args = getopt.getopt(sys.argv[1:], "hvfc:", [])
  except getopt.GetoptError as e:
    print str(e)
    help()
    sys.exit(1)

  config_file = None
  foreground = False
  for option, value in options:
    if option == "-h":
      help()
      sys.exit(0)
    elif option == "-v":
      print "version_tag: %s" % VERSION_TAG
      sys.exit(0)
    elif option == "-f":
      foreground = True
    elif option == "-c":
      config_file = value
    else:
      help()
      sys.exit(1)

  if not config_file:
    print "-c option is required"
    help()
    sys.exit(1)

  if not os.path.exists(config_file) or not os.path.isfile(config_file):
    print "file " + config_file + " is not found"
    sys.exit(1)

  config = Config(config_file)
  config.load()

  log_level = config.log_level()
  log_level = log_level.lower()


  if "debug" == log_level:
    log_level = logging.DEBUG
  else:
    log_level = logging.INFO

  if not foreground:
    daemon()

    log_file = config.log_file()
    logger = UDiskLogger(log_file, log_level, split='midnight').getHandler()
  else:
    logging.basicConfig(level = log_level,\
                        stream = sys.stderr,\
                        format='%(asctime)s - %(levelname)s: %(message)s')
    logger = logging.getLogger()

  gate_guard = GateGuard(config, logger)
  gate_guard.start()

if __name__ == "__main__":
  main()
